import { useState, useEffect, useRef, useCallback } from "react";

// ═══════════════════════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════════════════════
const WEAPONS      = ["Stout Shot","Gin Sniper","Tequila Bomb","Whiskey Blast","Cider Surge"];
const WDMG         = {"Stout Shot":15,"Gin Sniper":25,"Tequila Bomb":30,"Whiskey Blast":20,"Cider Surge":12};
const SHOP_ITEMS   = [
  {id:"medkit",    e:"💉", n:"Med Kit",        d:"+30 HP",                   c:20},
  {id:"shield",    e:"🛡️", n:"Shield Brew",    d:"+30 shield",               c:25},
  {id:"nuke",      e:"💣", n:"Nuke Shot",      d:"+50 dmg shot",             c:40},
  {id:"revive",    e:"❤️‍🔥",n:"Revive",         d:"Rise from dead",           c:60},
  {id:"double",    e:"⚡", n:"2× Damage",      d:"3 shots 2× dmg",           c:35},
  {id:"cloak",     e:"👻", n:"Ghost Mode",     d:"60s invisible",            c:50},
  {id:"mine",      e:"💥", n:"Proximity Mine", d:"Plant at bar — auto 35 dmg",c:45},
  {id:"sweeper",   e:"🧹", n:"Mine Sweeper",   d:"Disarms 1 mine at this bar",c:30},
  {id:"mine_emp",  e:"⚡💥",n:"EMP Mine",       d:"Drains 30 coins + 20 dmg", c:65},
  {id:"mine_smoke",e:"💨💥",n:"Smoke Mine",     d:"Cloaks enemy 30s + 15 dmg",c:55},
];

// ── MINE SYSTEM DATA ──────────────────────────────────────────────────────────
// Mines are stored in game.mines: { [mineId]: MineObj }
// MineObj: {id, type, plantedBy, plantedByName, plantedAt, barId, barName,
//           armed, triggered, triggeredBy, damage, disabled, disabledBy}
const MINE_TYPES = {
  mine:       {id:"mine",      e:"💥", n:"Proximity Mine", dmg:35, color:"#FF2D55", desc:"Explodes on contact — deals 35 damage to the first enemy who enters the bar"},
  mine_emp:   {id:"mine_emp",  e:"⚡💥",n:"EMP Mine",       dmg:20, color:"#FF9500", desc:"Zaps target for 20 damage AND drains 30 coins — devastating on rich players"},
  mine_smoke: {id:"mine_smoke",e:"💨💥",n:"Smoke Mine",     dmg:15, color:"#BF5AF2", desc:"Deals 15 damage and cloaks the enemy for 30s — confuses their team"},
};
const COIN_PACKS   = [
  {id:"solo",    label:"SOLO",    coins:100, price:3,   emoji:"🍺", desc:"Basic loadout",   highlight:false},
  {id:"fighter", label:"FIGHTER", coins:200, price:5,   emoji:"🎯", desc:"Most popular",    highlight:true},
  {id:"warlord", label:"WARLORD", coins:400, price:8,   emoji:"💣", desc:"Max coins",       highlight:false},
  {id:"topup",   label:"TOP-UP",  coins:50,  price:1.5, emoji:"⚡", desc:"Mid-game boost",  highlight:false},
];
// ── DIFFICULTY LEVELS ────────────────────────────────────────────────────────
const DIFFICULTY_LEVELS = {
  beginner: {
    id:          "beginner",
    label:       "BEGINNER",
    icon:        "🟢",
    tagline:     "Learn the crawl. No pressure.",
    color:       "#34C759",
    entryMulti:  1.0,    // price multiplier
    coinMulti:   1.5,    // extra starting coins (generous)
    hpBase:      150,    // more HP — harder to kill
    dmgMulti:    0.7,    // weapons do 70% damage
    potShare:    0.50,   // 50% of entry to pot (lower stakes)
    shopDiscount:0.20,   // 20% cheaper shop items
    respawn:     true,   // free respawn once per game
    scanRange:   "any",  // no range restrictions
    mapVisible:  true,   // all players visible on map always
    ctfHold:     5,      // pts per min holding flag
    friendlyFire:false,  // cannot shoot teammates
    rules:[
      "💚 All players visible on the map at all times",
      "💚 Weapons deal 70% normal damage",
      "💚 You start with 1 free respawn",
      "💚 Shop items are 20% cheaper",
      "💚 Friendly fire is disabled — you cannot shoot teammates",
      "💚 No time limit on loot code redemption",
    ],
    perks:[
      {e:"❤️",  t:"150 HP to start"},
      {e:"🛡️",  t:"Free respawn"},
      {e:"🗺️",  t:"Full map visibility"},
      {e:"🏪",  t:"20% shop discount"},
    ],
    restrictions:[],
  },

  intermediate: {
    id:          "intermediate",
    label:       "INTERMEDIATE",
    icon:        "🟡",
    tagline:     "The real game. Build your skills.",
    color:       "#FFCC00",
    entryMulti:  1.0,
    coinMulti:   1.0,
    hpBase:      100,
    dmgMulti:    1.0,
    potShare:    0.70,
    shopDiscount:0.0,
    respawn:     false,
    scanRange:   "any",
    mapVisible:  false,  // enemy positions fade after 60s
    ctfHold:     10,
    friendlyFire:false,
    rules:[
      "🟡 Standard 100 HP — no extra buffer",
      "🟡 Full weapon damage",
      "🟡 No free respawns — buy one from the shop",
      "🟡 Enemy positions fade from map after 60 seconds",
      "🟡 Friendly fire is still disabled",
      "🟡 Standard shop pricing",
    ],
    perks:[
      {e:"⚔️",  t:"Full damage weapons"},
      {e:"🏆",  t:"70% XP bonus"},
      {e:"🎯",  t:"Standard rules"},
      {e:"📈",  t:"Higher kill rewards"},
    ],
    restrictions:[
      "No free respawns",
      "Enemy map positions expire",
    ],
  },

  advanced: {
    id:          "advanced",
    label:       "ADVANCED",
    icon:        "🔴",
    tagline:     "Ranked. Brutal. Legendary loot drops.",
    color:       "#FF2D55",
    entryMulti:  1.5,    // 1.5× entry price — bigger pot
    coinMulti:   0.8,    // fewer starting coins — scarcity
    hpBase:      75,     // fragile — high stakes
    dmgMulti:    1.3,    // 130% damage — fast kills
    potShare:    0.80,   // 80% of entry to pot
    shopDiscount:-0.25,  // 25% more expensive shop items
    respawn:     false,
    scanRange:   "los",  // "line of sight" — must be in same bar
    mapVisible:  false,  // no enemy map at all
    ctfHold:     20,     // more pts per min
    friendlyFire:true,   // yes — friendly fire ON
    ranked:      true,   // affects leaderboard
    rules:[
      "🔴 Only 75 HP — one bad scan can be fatal",
      "🔴 Weapons deal 130% damage",
      "🔴 You must be IN the same bar to scan an enemy",
      "🔴 No enemy locations on the map — find them yourself",
      "🔴 Friendly fire is ENABLED — watch your team",
      "🔴 Shop items cost 25% more",
      "🔴 Hard mode — rare XP drops + legendary loot",
      "🔴 Results count toward ranked leaderboard",
    ],
    perks:[
      {e:"💰",  t:"80% XP bonus + rare loot"},
      {e:"🏅",  t:"Ranked leaderboard"},
      {e:"⚡",  t:"130% weapon damage"},
      {e:"🔥",  t:"High stakes, high glory"},
    ],
    restrictions:[
      "Must be in same bar to scan",
      "No map tracking",
      "Friendly fire ON",
      "75 HP — very fragile",
    ],
  },
};

const DIFF_IDS = ["beginner","intermediate","advanced"];

const MUSICIAN_REWARDS = [
  {id:"sonic",   e:"🌟",n:"Sonic Surge",    d:"Immune to next 2 attacks", rarity:"rare",    color:"#BF5AF2", weight:15},
  {id:"boost",   e:"⚡",n:"2× XP Boost",    d:"Double dmg for 5 shots",   rarity:"rare",    color:"#FF9500", weight:20},
  {id:"blast",   e:"🎸",n:"Feedback Blast", d:"80 dmg — exclusive!",       rarity:"epic",    color:"#FF2D55", weight:10},
  {id:"coins_b", e:"🪙",n:"+150 Coins",     d:"Biggest coin drop",         rarity:"epic",    color:"#FFCC00", weight:10},
  {id:"coins_m", e:"💛",n:"+75 Coins",      d:"Sweet find",                rarity:"uncommon",color:"#FFCC00", weight:25},
  {id:"shield_f",e:"🛡️",n:"Full Shield",    d:"+50 shield HP",             rarity:"uncommon",color:"#00C7BE", weight:20},
];
const RARITY      = {common:{c:"#888",g:"none"},uncommon:{c:"#34C759",g:"0 0 12px #34C75940"},rare:{c:"#007AFF",g:"0 0 16px #007AFF50"},epic:{c:"#BF5AF2",g:"0 0 20px #BF5AF260"}};
const MUSICIANS   = [
  {id:"m1",name:"Luna Vex",       av:"🎸",inst:"Guitar",   bar:"The Rusty Anchor", hint:"Near the jukebox",         hidden:true,  baseFeeCents:200},
  {id:"m2",name:"DJ Static",      av:"🎧",inst:"Decks",    bar:"The Golden Pint",  hint:"Somewhere upstairs",        hidden:true,  baseFeeCents:200},
  {id:"m3",name:"The Brass Monks",av:"🎺",inst:"Brass",    bar:"The Neon Flask",   hint:"Outside in the beer garden",hidden:false, baseFeeCents:200},
  {id:"m4",name:"Ivy & the Roots",av:"🎵",inst:"Acoustic", bar:"The Copper Still", hint:"Visible from the street",   hidden:false, baseFeeCents:200},
];
const TIERS = {
  bronze:{label:"BRONZE",c:"#cd7f32",bg:"#cd7f3215",min:0,   rate:15,perCode:.5, perCrawl:5, perRef:25, perks:["Basic dashboard","Monthly XP report","CrawlFire listing"]},
  silver:{label:"SILVER",c:"#aaaaaa",bg:"#aaaaaa15",min:200, rate:20,perCode:.75,perCrawl:8, perRef:40, perks:["Priority listing","Bi-weekly analytics","Branded QR poster","Social shoutout"]},
  gold:  {label:"GOLD",  c:"#FFCC00",bg:"#FFCC0015",min:600, rate:25,perCode:1,  perCrawl:12,perRef:60, perks:["#1 area listing","Weekly performance report","Custom loot items","Account manager","Merch pack"]},
};
const BAR_ACCOUNTS = [
  {username:"bar1",password:"crawl123",barName:"The Rusty Anchor",emoji:"⚓",tier:"gold",   earned:847,pending:124,crawls:18,codes:94, refs:3,streak:7,refCode:"ANCHOR7",classId:"assassin"},
  {username:"bar2",password:"crawl123",barName:"The Golden Pint",  emoji:"🍺",tier:"silver",earned:512,pending:76, crawls:11,codes:61, refs:2,streak:4,refCode:"GPINT22",classId:"bard"},
  {username:"bar3",password:"crawl123",barName:"The Neon Flask",   emoji:"🌈",tier:"silver",earned:389,pending:55, crawls:8, codes:47, refs:1,streak:2,refCode:"FLASK88",classId:"warrior"},
];
const MUSICIAN_ACCOUNTS = [
  {username:"luna",  password:"music123",musicianId:"m1"},
  {username:"djstatic",password:"music123",musicianId:"m2"},
  {username:"brass", password:"music123",musicianId:"m3"},
  {username:"ivy",   password:"music123",musicianId:"m4"},
];
const AVATARS  = ["🍺","🥃","🍸","🍹","🎯","💣","⚡","🔥","🐺","👻"];

// ── BARTENDER CLASSES  (D&D-style — each class has unique abilities) ──────────
const BARTENDER_CLASSES = {
  assassin: {
    id:"assassin", name:"ASSASSIN", icon:"🗡️", color:"#BF5AF2",
    tagline:"Strike unseen. Vanish before the hit registers.",
    lore:"Masters of the shadow arts. An Assassin bartender works without ceremony — loot appears in player inventories without warning. They know every player's HP at a glance and target the weak.",
    abilities:[
      {id:"shadowdrop",   name:"Shadow Drop",    icon:"🌑", cd:0,  type:"passive", desc:"Loot codes generated by this bartender are delivered silently — no notification to the player until they check inventory. Keeps enemies off guard."},
      {id:"markertarget", name:"Mark Target",    icon:"🎯", cd:45, type:"active",  desc:"Flag a specific player on the bartender dashboard. That player's HP, location and inventory are visible to your whole team for 3 minutes."},
      {id:"poisondose",   name:"Poison Dose",    icon:"🍵", cd:90, type:"active",  desc:"Generate a Cursed Loot code. Looks like a normal item but actually deals 15 damage when claimed by an enemy. Disguised as a Med Kit."},
      {id:"vanish",       name:"Vanish",         icon:"💨", cd:120,type:"active",  desc:"Remove this bar's location marker from the live map for all enemy teams for 5 minutes. Your players can still see it."},
    ],
    lootBonus:   "Epic loot rates +20%",
    damageBonus: null,
    defenseBonus:null,
    special:     "Can generate Cursed Loot codes",
    statBonuses: {epicChance:0.20, silentDrop:true, canPoison:true},
  },

  bard: {
    id:"bard", name:"BARD", icon:"🎸", color:"#FF9500",
    tagline:"The crowd loves you. The enemy fears your words.",
    lore:"Bards are CrawlFire's social engine. Their abilities rally allied players, debuff enemies with distractions, and can boost the XP rewards for musicians. They generate more coins for the crowd.",
    abilities:[
      {id:"rallycry",   name:"Rally Cry",      icon:"📣", cd:0,  type:"passive", desc:"All allied players within the bar receive +10 coins every time the Bard generates a loot code. Morale bonus."},
      {id:"taunt",      name:"Taunt",          icon:"😜", cd:60, type:"active",  desc:"Force a random enemy player to have their next scan miss — their weapon misfires once. Broadcasted as '💢 Distracted by the Bard!'"},
      {id:"inspireally",name:"Inspire",        icon:"⚡", cd:90, type:"active",  desc:"Choose one allied player. Their next hit deals double damage. Effect lasts until they take their next shot."},
      {id:"bardstip",   name:"Encore",         icon:"🎵", cd:30, type:"passive", desc:"Any musician performing at this bar earns +$1 bonus per tip while the Bard is on shift. Stackable."},
    ],
    lootBonus:   "Coin bonuses to nearby allies",
    damageBonus: "Can grant allied 2× damage",
    defenseBonus:null,
    special:     "Musician tip amplifier",
    statBonuses: {allyCoinBonus:10, canTaunt:true, canInspire:true, musicianTipBonus:1.00},
  },

  warrior: {
    id:"warrior", name:"WARRIOR", icon:"⚔️", color:"#FF2D55",
    tagline:"Hold the line. The bar is your fortress.",
    lore:"Warriors command the battlefield from behind the bar. They generate shield items, hold CTF flags longer through defensive bonuses, and can call for backup when the bar is under siege.",
    abilities:[
      {id:"ironshield",  name:"Iron Shield",   icon:"🛡️", cd:0,  type:"passive", desc:"All shield items generated by this bartender have +10 extra HP (30 → 40). Warriors know how to brew a better brew."},
      {id:"fortify",     name:"Fortify",       icon:"🏰", cd:60, type:"active",  desc:"Lock the CTF flag at this bar for 3 minutes. It cannot be stolen while Fortified. Shows a 🏰 icon on the map."},
      {id:"warhorn",     name:"War Horn",       icon:"📯", cd:45, type:"active",  desc:"Broadcast an alert to all allied players: 'WAR HORN at [bar name]! Regroup here!' with a 📯 push notification."},
      {id:"laststand",   name:"Last Stand",    icon:"💪", cd:180,type:"active",  desc:"If an allied player is at <20 HP, this bartender can revive them to 40 HP for free once per game. Emergency save."},
    ],
    lootBonus:   "Shields +10 HP",
    damageBonus: null,
    defenseBonus:"+10 HP on all shield items · CTF Fortify",
    special:     "Can fortify CTF flags",
    statBonuses: {shieldBonus:10, canFortify:true, canWarHorn:true, canLastStand:true},
  },

  paladin: {
    id:"paladin", name:"PALADIN", icon:"✨", color:"#FFCC00",
    tagline:"Justice, healing, and a surprisingly good pour.",
    lore:"Paladins are the healers of the crawl. They can revive downed players, cleanse debuffs, and create safe zones near their bar. No player should die near a Paladin's bar.",
    abilities:[
      {id:"holylight",  name:"Holy Light",    icon:"💛", cd:0,  type:"passive", desc:"Med Kit items generated by this bartender heal 40 HP instead of 30. Blessed brews."},
      {id:"resurrect",  name:"Resurrect",     icon:"❤️", cd:120,type:"active",  desc:"Fully revive one dead allied player. They return with 50 HP and 50 coins. Once per game per player."},
      {id:"sanctify",   name:"Sanctify",      icon:"🌟", cd:90, type:"active",  desc:"Create a 2-minute Safe Zone around this bar. Players inside cannot be targeted by scans. Shown as a golden halo on the map."},
      {id:"smite",      name:"Smite",         icon:"⚡", cd:60, type:"active",  desc:"Deal 25 direct damage to any player who has DQ'd an allied player in the last 10 minutes. Divine retribution."},
    ],
    lootBonus:   "Med Kits heal 40 HP (+10)",
    damageBonus: "Smite: 25 direct dmg",
    defenseBonus:"Resurrect · Safe Zone",
    special:     "Can create safe zones",
    statBonuses: {medKitBonus:10, canResurrect:true, canSanctify:true, canSmite:true},
  },

  ranger: {
    id:"ranger", name:"RANGER", icon:"🏹", color:"#34C759",
    tagline:"Eyes on every corner. You see them before they see you.",
    lore:"Rangers are the eyes of the crawl. They extend map visibility for their team, track enemy movements, and their loot specialises in long-range weapons and scout gear.",
    abilities:[
      {id:"eagleeye",   name:"Eagle Eye",     icon:"👁️", cd:0,  type:"passive", desc:"All allied players can see enemy HP bars on the map for 60 seconds after the Ranger generates a loot code."},
      {id:"tracker",    name:"Tracker",       icon:"🐾", cd:45, type:"active",  desc:"Reveal the exact location of a chosen enemy on the map for your whole team for 2 minutes. The enemy doesn't know they're tracked."},
      {id:"ambush",     name:"Ambush",        icon:"🌿", cd:90, type:"active",  desc:"Generate a hidden Loot Trap. The next enemy player who enters this bar triggers it for 20 damage and loses 25 coins."},
      {id:"supplydrop", name:"Supply Drop",   icon:"📦", cd:60, type:"active",  desc:"Instantly send one random item from the shop to all allied players at this bar. No code needed — items appear in their inventory."},
    ],
    lootBonus:   "Gin Sniper dmg +5 for allies",
    damageBonus: "Ambush trap: 20 dmg",
    defenseBonus:null,
    special:     "Enemy tracking · Supply Drop",
    statBonuses: {revealHp:true, canTrack:true, canAmbush:true, canSupplyDrop:true},
  },

  warlock: {
    id:"warlock", name:"WARLOCK", icon:"🔮", color:"#007AFF",
    tagline:"Deals with dark forces. The loot is cursed. In a good way.",
    lore:"Warlocks dabble in forbidden mixology. Their loot items have unpredictable effects — powerful boons or cruel debuffs — and they can manipulate game state in ways no other class can.",
    abilities:[
      {id:"chaosbreww", name:"Chaos Brew",    icon:"🎲", cd:0,  type:"passive", desc:"Every loot code has a 30% chance to be a Mystery item — random effect between Shield Brew, Med Kit, 2× Damage, or Ghost Mode."},
      {id:"hex",        name:"Hex",           icon:"🔮", cd:60, type:"active",  desc:"Curse a random enemy for 5 minutes. Their weapons all deal 5 less damage until the hex expires."},
      {id:"portal",     name:"Dark Portal",   icon:"🌀", cd:120,type:"active",  desc:"Teleport one allied player's position on the map to appear at a different bar temporarily. Confuses enemy trackers."},
      {id:"soulpact",   name:"Soul Pact",     icon:"💀", cd:90, type:"active",  desc:"Sacrifice 30 of the bartender's earned coins this shift to instantly max-out one allied player's inventory (one of every item)."},
    ],
    lootBonus:   "30% Mystery item chance",
    damageBonus: "Hex: -5 dmg to enemies",
    defenseBonus:"Dark Portal teleport",
    special:     "Chaos loot · Soul Pact sacrifice",
    statBonuses: {mysteryChance:0.30, canHex:true, canPortal:true, canSoulPact:true},
  },

  druid: {
    id:"druid", name:"DRUID", icon:"🌿", color:"#00C7BE",
    tagline:"Nature's balance. Heals allies and amplifies XP rewards.",
    lore:"Druids are the support class. Their abilities focus on amplifying coin and XP rewards, healing teammates, and maintaining balance between teams. They're especially effective in long crawls.",
    abilities:[
      {id:"growthspell", name:"Growth Spell",  icon:"🌱", cd:0,  type:"passive", desc:"Every loot code generated grants +10 bonus XP to the receiving player. Druids amplify rewards with every interaction."},
      {id:"naturelore",  name:"Nature Lore",   icon:"🍃", cd:60, type:"active",  desc:"Boost all allied players' coin earnings by 25% for the next 10 minutes. Everything they earn is amplified."},
      {id:"wildshape",   name:"Wild Shape",    icon:"🐺", cd:90, type:"active",  desc:"Transform this bar's CTF flag into a Wild Flag — any team can score +50 bonus points by holding it for 1 minute, regardless of team."},
      {id:"regenerate",  name:"Regenerate",    icon:"💚", cd:45, type:"active",  desc:"Slowly heal all allied players by 5 HP every 30 seconds for 3 minutes (up to +30 HP total). Passive regen ticker."},
    ],
    lootBonus:   "+10 bonus XP per loot code",
    damageBonus: null,
    defenseBonus:"Regenerate: +5 HP/30s allies",
    special:     "Coin amplifier · Wild Flag",
    statBonuses: {potBonus:0.25, canNatureLore:true, canWildShape:true, canRegenerate:true},
  },

  rogue: {
    id:"rogue", name:"ROGUE", icon:"🃏", color:"#FF6B35",
    tagline:"When the rules bend, the Rogue wins.",
    lore:"Rogues live in the grey area. They can steal from enemy loot pools, forge duplicate codes, and slip extra items to specific players without appearing in the log. The most chaotic class.",
    abilities:[
      {id:"pickpocket",  name:"Pickpocket",   icon:"👋", cd:60, type:"active",  desc:"Steal 20 coins from a chosen enemy player and redistribute them to a chosen allied player. Cannot steal below 10 coins."},
      {id:"forgery",     name:"Forgery",      icon:"📋", cd:90, type:"active",  desc:"Duplicate the last loot code generated at any other bar. Creates a second valid copy for a chosen allied player."},
      {id:"smokebomb",   name:"Smoke Bomb",   icon:"💨", cd:45, type:"active",  desc:"Make one allied player invisible on the enemy map feed for 90 seconds. They can scan freely without appearing."},
      {id:"luckydraw",   name:"Lucky Draw",   icon:"🎰", cd:30, type:"passive", desc:"5% chance any generated code is instantly a Nuke Shot or Ghost Mode regardless of what was selected. The house always has a trick."},
    ],
    lootBonus:   "5% auto-epic loot chance",
    damageBonus: "Pickpocket steals coins",
    defenseBonus:"Smoke Bomb: 90s invisibility",
    special:     "Forgery · Coin theft",
    statBonuses: {luckyChance:0.05, canPickpocket:true, canForge:true, canSmokeBomb:true},
  },
};

const CLASS_IDS = Object.keys(BARTENDER_CLASSES);

// ── DESIGNER ACCOUNTS  (hashed tokens in production — keep secret) ─────────
// Add/remove approved designers here. Never expose in client bundle in prod.
const DESIGNER_ACCOUNTS = [
  {id:"d1", username:"designer",  token:"CRAWLFIRE-DESIGN-2024", name:"Lead Designer",   avatar:"🎨", level:"super"},
  {id:"d2", username:"dev",       token:"CRAWLFIRE-DEV-2024",    name:"Developer",        avatar:"⚙️",  level:"super"},
  {id:"d3", username:"gamemaster",token:"CRAWLFIRE-GM-2024",     name:"Game Master",      avatar:"🎯",  level:"standard"},
];

// ── GAME CONFIG DEFAULTS  (editable by designers) ────────────────────────────
const DEFAULT_GAME_CONFIG = {
  // Entry & economy
  entry: {
    solo:    { coins: 100, price: 3.00, enabled: true },
    fighter: { coins: 200, price: 5.00, enabled: true },
    warlord: { coins: 400, price: 8.00, enabled: true },
    topup:   { coins: 50,  price: 1.50, enabled: true },
  },
  pot: {
    winnerSharePct: 70,  // % of pot paid to winner
    platformPct:    30,  // % kept by CrawlFire
  },
  // Weapons damage
  weapons: {
    "Stout Shot":    { dmg: 15, enabled: true },
    "Gin Sniper":    { dmg: 25, enabled: true },
    "Tequila Bomb":  { dmg: 30, enabled: true },
    "Whiskey Blast": { dmg: 20, enabled: true },
    "Cider Surge":   { dmg: 12, enabled: true },
  },
  // Shop item costs
  shop: {
    medkit:  { cost: 20, enabled: true },
    shield:  { cost: 25, enabled: true },
    nuke:    { cost: 40, enabled: true },
    revive:  { cost: 60, enabled: true },
    double:  { cost: 35, enabled: true },
    cloak:   { cost: 50, enabled: true },
  },
  // Feature toggles — flip to false to instantly suspend
  features: {
    laserTag:       { enabled: true,  label: "QR Laser Tag",      icon: "🎯" },
    ctfMode:        { enabled: true,  label: "Capture The Flag",  icon: "⚑"  },
    musicHunt:      { enabled: true,  label: "Music Hunt",        icon: "🎵" },
    lootCodes:      { enabled: true,  label: "Bartender Loot",    icon: "🎁" },
    prizePayouts:   { enabled: true,  label: "XP Pool Payouts", icon: "💰" },
    merch:          { enabled: true,  label: "Merch Store",       icon: "🏪" },
    newRegistrations:{ enabled: true, label: "New Sign-ups",      icon: "🆕" },
    payments:       { enabled: true,  label: "Payment Processing",icon: "💳" },
    playZone:       { enabled: true,  label: "Play Zone Enforcement",icon: "📍" },
  },
  // Play zone config
  zone: {
    enabled:        true,
    centerLat:      51.5130,   // default: central London — set per crawl
    centerLng:      -0.0900,
    radiusMeters:   1500,      // 1.5km default crawl radius
    warnMeters:     200,       // warn when this close to edge
    graceSecs:      60,        // seconds to return before DQ
    allowedBars:    [],        // optional: array of barIds always in-zone
  },
  // Inactivity timeouts (seconds)
  inactivity: {
    warnSecs: 1680,
    kickSecs: 1800,
  },
  // CTF scoring
  ctf: {
    ptsCapture:  100,
    ptsSteal:    25,
    ptsDefend:   30,
    ptsHoldPerMin: 10,
  },
  // Bar partner tiers (revenue %)
  tiers: {
    bronze: { rate: 15, perCrawl: 5,  perCode: 0.50, perRef: 25 },
    silver: { rate: 20, perCrawl: 8,  perCode: 0.75, perRef: 40 },
    gold:   { rate: 25, perCrawl: 12, perCode: 1.00, perRef: 60 },
  },
  // Maintenance / broadcast
  maintenance: {
    active:  false,
    message: "",
    banner:  "",
  },
  _updatedAt: null,
  _updatedBy: null,
};

// ── CONDUCT & SAFETY RULES ────────────────────────────────────────────────────
const CONDUCT_RULES = [
  {
    id:"r1", category:"SAFETY", icon:"🦺", color:"#FF2D55",
    title:"No physical contact",
    body:"QR scanning is DIGITAL ONLY. Never touch, grab, push, or block another player to prevent being scanned. Keep at least arm's length from other players at all times.",
    severity:"INSTANT DQ",
  },
  {
    id:"r2", category:"SAFETY", icon:"🍺", color:"#FF9500",
    title:"Drink responsibly",
    body:"CrawlFire is an 18+ game played in licensed premises. Know your limits. Visibly intoxicated players who pose a risk to others may be removed by bar staff. Hydrate between shots.",
    severity:"WARNING → DQ",
  },
  {
    id:"r3", category:"SAFETY", icon:"🚶", color:"#FF9500",
    title:"Walk — never run",
    body:"No running inside bars or on public pavements between venues. Walk calmly. Watch for steps, wet floors, and other patrons. This is a pub crawl, not a sprint.",
    severity:"WARNING → DQ",
  },
  {
    id:"r4", category:"SAFETY", icon:"🔦", color:"#FFCC00",
    title:"Torch / flash awareness",
    body:"Do not shine phone screens or torches in other players' eyes when scanning. Hold your phone at chest height and angle it toward their back QR code only.",
    severity:"WARNING",
  },
  {
    id:"r5", category:"CONDUCT", icon:"🤝", color:"#34C759",
    title:"Respect bar staff & other patrons",
    body:"Bar staff have absolute authority inside their venue. Comply immediately with any instruction from bartenders or door staff. Do not disrupt non-players, block service areas, or occupy tables reserved for other customers.",
    severity:"INSTANT DQ",
  },
  {
    id:"r6", category:"CONDUCT", icon:"📵", color:"#34C759",
    title:"No cheating or account sharing",
    body:"One player per device. Do not share your QR code with another player to avoid being scanned. Do not scan your own team members to farm kills. All suspicious activity is logged.",
    severity:"INSTANT DQ",
  },
  {
    id:"r7", category:"CONDUCT", icon:"🔇", color:"#00C7BE",
    title:"Keep noise levels reasonable",
    body:"Celebrating kills is fine — sustained shouting, chanting, or group noise that disturbs other patrons is not. If bar staff ask your group to keep it down, do so immediately.",
    severity:"WARNING",
  },
  {
    id:"r8", category:"CONDUCT", icon:"🚪", color:"#00C7BE",
    title:"Respect venue boundaries",
    body:"Stay in public areas of each bar. Do not go behind the bar, into staff-only areas, private dining rooms, or other restricted zones to hide or place QR codes.",
    severity:"WARNING → DQ",
  },
  {
    id:"r9", category:"FAIR PLAY", icon:"⚖️", color:"#BF5AF2",
    title:"Accept the outcome",
    body:"When a bartender or game admin makes a decision — DQ, warning, or game call — accept it without argument. Disputes can be raised after the game via the support channel, not mid-crawl.",
    severity:"WARNING → DQ",
  },
  {
    id:"r10", category:"FAIR PLAY", icon:"💳", color:"#BF5AF2",
    title:"Game integrity",
    body:"CrawlFire is a fair competition. Any attempt to manipulate the game through collusion, account fraud, or QR tampering will result in immediate disqualification.",
    severity:"INSTANT DQ + BAN",
  },
];

const DQ_REASONS = [
  {id:"physical",   label:"Physical contact / aggression",  severity:"instant", icon:"🤜"},
  {id:"staff",      label:"Disrespecting bar staff",         severity:"instant", icon:"🧑‍💼"},
  {id:"cheating",   label:"Cheating / QR manipulation",      severity:"instant", icon:"🃏"},
  {id:"drunk",      label:"Dangerously intoxicated",         severity:"instant", icon:"🥴"},
  {id:"running",    label:"Running inside venue",            severity:"warn",    icon:"🏃"},
  {id:"noise",      label:"Excessive noise",                 severity:"warn",    icon:"📢"},
  {id:"boundary",   label:"Entering restricted area",        severity:"warn",    icon:"🚧"},
  {id:"torch",      label:"Torch / flash in eyes",           severity:"warn",    icon:"🔦"},
  {id:"other",      label:"Other conduct issue",             severity:"warn",    icon:"⚠️"},
];
const COLORS   = ["#FF2D55","#FF9500","#00C7BE","#BF5AF2","#34C759","#FF6B35"];
const PAYPAL   = "yourcrawlfireaccount";
const VENMO    = "yourcrawlfireaccount";

// ═══════════════════════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════════════════════
const uid  = () => Math.random().toString(36).slice(2,6).toUpperCase();
const fmt  = n  => `$${Number(n).toFixed(2)}`;
const sleep= ms => new Promise(r=>setTimeout(r,ms));
const ppLink  = (a,n) => `https://paypal.me/${PAYPAL}/${a}?currencyCode=USD&note=${encodeURIComponent(n)}`;
const vmLink  = (a,n) => `https://venmo.com/${VENMO}?txn=pay&amount=${a}&note=${encodeURIComponent(n)}`;
const wRandom = pool => { let t=pool.reduce((s,r)=>s+r.weight,0),r=Math.random()*t; for(const x of pool){r-=x.weight;if(r<=0)return x;} return pool[pool.length-1]; };

function genQR(id, sz=200) {
  const c=document.createElement("canvas"); c.width=sz; c.height=sz;
  const x=c.getContext("2d"); x.fillStyle="#fff"; x.fillRect(0,0,sz,sz);
  let h=0; for(let i=0;i<id.length;i++){h=((h<<5)-h)+id.charCodeAt(i);h|=0;}
  const cs=sz/10;
  const df=(px,py)=>{x.fillStyle="#000";x.fillRect(px*cs,py*cs,7*cs,7*cs);x.fillStyle="#fff";x.fillRect((px+1)*cs,(py+1)*cs,5*cs,5*cs);x.fillStyle="#000";x.fillRect((px+2)*cs,(py+2)*cs,3*cs,3*cs);};
  df(0,0); let s=Math.abs(h);
  for(let r=0;r<10;r++)for(let col=0;col<10;col++){if(r<7&&col<7)continue;s=(s*1664525+1013904223)&0xffffffff;if(s%3===0){x.fillStyle="#000";x.fillRect(col*cs,r*cs,cs,cs);}}
  x.fillStyle="#000";x.font=`bold ${Math.floor(cs*1.2)}px monospace`;x.textAlign="center";x.textBaseline="middle";x.fillText(id.slice(-4).toUpperCase(),sz/2,sz*.82);
  return c.toDataURL();
}

// ═══════════════════════════════════════════════════════════════════════════════
// STORAGE  (shared across all "devices")
// ═══════════════════════════════════════════════════════════════════════════════
// ── MULTI-CITY / MULTI-TENANCY KEY SCHEMA ────────────────────────────────────
// Firebase Realtime DB tree:
//
//   regions/
//     {regionId}/          ← "london", "manchester", "nyc", etc.
//       meta/              ← region name, active game count, capacity
//       games/
//         {gameCode}/
//           meta           ← title, host, difficulty, status, playerCount, createdAt
//           game           ← full game state (players, events, pot, …)
//           hunt           ← musician hunt state
//           ctf            ← CTF state
//           chat/
//             all          ← global channel
//             {teamId}     ← team channel
//           codes          ← bartender loot codes for this game
//
//   lobby/                 ← global active games index (read by lobby browser)
//     {regionId}_{gameCode}: {regionId, gameCode, title, status, playerCount, difficulty, createdAt}
//
// All game reads/writes go through K(region,code) which returns the correct path.
// ─────────────────────────────────────────────────────────────────────────────

// Legacy single-game keys (fallback when no region/code context)
const KEYS = {
  game:"cf:game", codes:"cf:codes", hunt:"cf:hunt",
  bars:"cf:bars", payouts:"cf:payouts", ctf:"cf:ctf", chat:"cf:chat",
};

// Fully-scoped key builder for multi-city mode
function K(regionId, gameCode) {
  if (!regionId || !gameCode) return KEYS;
  const base = `regions/${regionId}/games/${gameCode}`;
  return {
    game:    `${base}/game`,
    hunt:    `${base}/hunt`,
    ctf:     `${base}/ctf`,
    codes:   `${base}/codes`,
    bars:    `${base}/bars`,
    payouts: `${base}/payouts`,
    chat:    (ch) => `${base}/chat/${ch}`,
    meta:    `${base}/meta`,
    // Lobby index entry (lightweight, for the global lobby browser)
    lobby:   `lobby/${regionId}_${gameCode}`,
    region:  `regions/${regionId}/meta`,
  };
}

// Region catalogue — add cities here; shown in lobby browser
const REGIONS = [
  {id:"london",     name:"London",      flag:"🇬🇧", tz:"Europe/London",    active:true},
  {id:"manchester", name:"Manchester",  flag:"🇬🇧", tz:"Europe/London",    active:true},
  {id:"edinburgh",  name:"Edinburgh",   flag:"🏴󠁧󠁢󠁳󠁣󠁴󠁿", tz:"Europe/London",    active:true},
  {id:"nyc",        name:"New York",    flag:"🇺🇸", tz:"America/New_York", active:true},
  {id:"chicago",    name:"Chicago",     flag:"🇺🇸", tz:"America/Chicago",  active:true},
  {id:"la",         name:"Los Angeles", flag:"🇺🇸", tz:"America/LA",       active:true},
  {id:"sydney",     name:"Sydney",      flag:"🇦🇺", tz:"Australia/Sydney", active:true},
  {id:"toronto",    name:"Toronto",     flag:"🇨🇦", tz:"America/Toronto",  active:true},
  {id:"berlin",     name:"Berlin",      flag:"🇩🇪", tz:"Europe/Berlin",    active:true},
  {id:"amsterdam",  name:"Amsterdam",   flag:"🇳🇱", tz:"Europe/Amsterdam", active:true},
  {id:"custom",     name:"Custom City", flag:"📍",  tz:"UTC",              active:true},
];

// ── CTF Constants ──────────────────────────────────────────────────────────────
const CTF_TEAMS = [
  {id:"red",  name:"RED WOLVES",   emoji:"🔴",color:"#FF2D55",bg:"#FF2D5518"},
  {id:"blue", name:"BLUE SHARKS",  emoji:"🔵",color:"#007AFF",bg:"#007AFF18"},
  {id:"green",name:"GREEN VIPERS", emoji:"🟢",color:"#34C759",bg:"#34C75918"},
  {id:"gold", name:"GOLD EAGLES",  emoji:"🟡",color:"#FFCC00",bg:"#FFCC0018"},
];
const CTF_FLAG_NAMES = ["The Rusty Anchor","The Golden Pint","The Neon Flask","The Copper Still","The Barrel House","The Iron Tap","The Velvet Stout","The Midnight Brew"];
const CTF_PTS_CAPTURE=100, CTF_PTS_STEAL=25, CTF_PTS_DEFEND=30, CTF_PTS_HOLD=10;
const CTF_STEAL_MSGS = [
  (p,f)=>`⚡ ${p} SNATCHED the flag from ${f}!`,
  (p,f)=>`🔥 ${f} flag STOLEN by ${p}!`,
  (p,f)=>`💀 ${p} just raided ${f}!`,
  (p,f)=>`🚨 ALERT — ${f} flag is now with ${p}!`,
  (p,f)=>`🎯 ${p} grabbed the ${f} flag!`,
];
// ═══════════════════════════════════════════════════════════════════════════════
// FIREBASE REALTIME DATABASE LAYER
// ─────────────────────────────────────────────────────────────────────────────
// Replace FIREBASE_CONFIG values with your own project credentials from
// https://console.firebase.google.com → Project settings → Your apps → SDK
//
// Realtime Database rules for development (lock down before launch):
//   { "rules": { ".read": true, ".write": true } }
//
// Production rules (authenticated writes only):
//   { "rules": {
//       "games": { "$gameId": {
//         ".read": true,
//         ".write": "auth != null"
//       }},
//       "cf:chat": { ".read": true, ".write": "auth != null" }
//   }}
// ═══════════════════════════════════════════════════════════════════════════════

const FIREBASE_CONFIG = {
  apiKey:            "YOUR_API_KEY",
  authDomain:        "YOUR_PROJECT.firebaseapp.com",
  databaseURL:       "https://YOUR_PROJECT-default-rtdb.firebaseio.com",
  projectId:         "YOUR_PROJECT",
  storageBucket:     "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId:             "YOUR_APP_ID",
};

// ── Firebase singleton init ───────────────────────────────────────────────────
let _db   = null;   // Realtime Database instance
let _auth = null;   // Auth instance
let _fbReady = false;
let _fbError = null;

async function initFirebase() {
  if (_db) return _db;
  try {
    const { initializeApp, getApps } = await import("https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js");
    const { getDatabase, ref, get, set, onValue, off } = await import("https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js");
    const { getAuth, signInAnonymously } = await import("https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js");

    const app = getApps().length ? getApps()[0] : initializeApp(FIREBASE_CONFIG);
    _db   = getDatabase(app);
    _auth = getAuth(app);

    // Anonymous auth so we can write with uid-based rules
    await signInAnonymously(_auth);

    _fbReady = true;
    console.log("✅ Firebase connected");
    return _db;
  } catch(e) {
    _fbError = e.message;
    console.warn("⚠️ Firebase unavailable — using local storage fallback:", e.message);
    return null;
  }
}

// ── Sanitise key: Firebase paths cannot contain . # $ [ ] ────────────────────
const fbKey = k => k.replace(/[.#$\[\]]/g, "_");

// ── READ: Firebase first, local storage fallback ─────────────────────────────
const rd = async k => {
  // Try Firebase
  try {
    const db = await initFirebase();
    if (db) {
      const { ref, get } = await import("https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js");
      const snap = await get(ref(db, fbKey(k)));
      return snap.exists() ? snap.val() : null;
    }
  } catch(e) {
    console.warn("rd Firebase error:", e.message);
  }
  // Fallback: local window.storage
  try {
    const r = await window.storage.get(k, true);
    return r ? JSON.parse(r.value) : null;
  } catch { return null; }
};

// ── WRITE: Firebase first, local storage fallback ────────────────────────────
const wr = async (k, v) => {
  // Try Firebase
  try {
    const db = await initFirebase();
    if (db) {
      const { ref, set } = await import("https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js");
      await set(ref(db, fbKey(k)), v);
      return;
    }
  } catch(e) {
    console.warn("wr Firebase error:", e.message);
  }
  // Fallback: local window.storage
  try {
    await window.storage.set(k, JSON.stringify(v), true);
  } catch {}
};

// ── SUBSCRIBE: real-time listener for a key ───────────────────────────────────
// Returns an unsubscribe function. Falls back to polling if Firebase unavailable.
const subscribe = (k, cb) => {
  let unsub = null;
  let pollId = null;
  (async () => {
    try {
      const db = await initFirebase();
      if (db) {
        const { ref, onValue } = await import("https://www.gstatic.com/firebasejs/10.12.0/firebase-database.js");
        const r = ref(db, fbKey(k));
        onValue(r, snap => cb(snap.exists() ? snap.val() : null));
        unsub = () => { const { off } = require; try { off(r); } catch {} };
        return;
      }
    } catch(e) {
      console.warn("subscribe Firebase error:", e.message);
    }
    // Fallback poll every 800ms
    pollId = setInterval(async () => { const v = await rd(k); cb(v); }, 800);
  })();
  return () => {
    if (unsub) unsub();
    if (pollId) clearInterval(pollId);
  };
};

// ── Firebase connection status banner ────────────────────────────────────────
function FirebaseStatus() {
  const [status, setStatus] = useState("checking"); // checking|connected|fallback|error
  const [uid,    setUid]    = useState(null);

  useEffect(() => {
    let mounted = true;
    initFirebase().then(db => {
      if (!mounted) return;
      if (db && _fbReady) {
        setStatus("connected");
        try {
          setUid(_auth?.currentUser?.uid?.slice(0,8));
        } catch {}
      } else {
        setStatus("fallback");
      }
    }).catch(() => { if(mounted) setStatus("error"); });
    return () => { mounted = false; };
  }, []);

  if (status === "connected") return (
    <div style={{display:"flex",alignItems:"center",gap:6,padding:"4px 10px",background:"#34C75915",border:"1px solid #34C75940",borderRadius:20,fontSize:9,color:"#34C759",letterSpacing:1,alignSelf:"flex-start"}}>
      <div style={{width:6,height:6,borderRadius:"50%",background:"#34C759",animation:"pulse 2s ease-in-out infinite"}}/>
      FIREBASE LIVE{uid&&` · ${uid}`}
    </div>
  );
  if (status === "fallback") return (
    <div style={{display:"flex",alignItems:"center",gap:6,padding:"4px 10px",background:"#FF950015",border:"1px solid #FF950040",borderRadius:20,fontSize:9,color:"#FF9500",letterSpacing:1,alignSelf:"flex-start"}}>
      <div style={{width:6,height:6,borderRadius:"50%",background:"#FF9500"}}/>
      LOCAL DEMO MODE — Add Firebase config to go live
    </div>
  );
  return null;
}

// ═══════════════════════════════════════════════════════════════════════════════
// GAME ENGINE
// ═══════════════════════════════════════════════════════════════════════════════
function makePlayer(name,avatar,coins=200){
  return {id:uid(),name,avatar,hp:100,maxHp:100,shield:0,kills:0,coins,alive:true,doubleDmg:0,cloaked:false,inventory:{},joinedAt:Date.now()};
}
function makeGame(hostPlayer){
  return {status:"lobby",hostId:hostPlayer.id,players:{[hostPlayer.id]:hostPlayer},events:[],pot:0,createdAt:Date.now()};
}
function makeHunt(){
  return {musicians:MUSICIANS.map(m=>({...m,reward:wRandom(MUSICIAN_REWARDS),scannedBy:[],tipPool:0})),players:{},tipLog:[],events:[]};
}
// ── CTF ENGINE ────────────────────────────────────────────────────────────────
function makeCTFGame(tc,fc,name){
  return {id:uid(),name:name||"CRAWLFIRE CTF",status:"active",teams:CTF_TEAMS.slice(0,tc).map(t=>({...t,points:0,captures:0})),flags:CTF_FLAG_NAMES.slice(0,fc).map((n,i)=>({id:`flag_${i}`,name:n,heldBy:null,heldByTeam:null,capturedAt:null,history:[]})),players:{},events:[],createdAt:Date.now(),startedAt:Date.now()};
}
function applyCTFCapture(game,flagId,playerId){
  const flag=game.flags.find(f=>f.id===flagId),player=game.players[playerId];
  if(!flag||!player)return{game,result:"invalid"};
  const wasBy=flag.heldBy,wasByTeam=flag.heldByTeam,isSame=wasByTeam===player.teamId,isSteal=!!wasBy&&!isSame,isReclaim=!!wasBy&&isSame;
  let updPl={...game.players},updTms=[...game.teams];
  if(wasBy&&updPl[wasBy]){const hp=Math.floor(((Date.now()-flag.capturedAt)/60000))*CTF_PTS_HOLD;updPl[wasBy]={...updPl[wasBy],points:(updPl[wasBy].points||0)+hp};updTms=updTms.map(t=>t.id===updPl[wasBy].teamId?{...t,points:t.points+hp}:t);}
  if(isReclaim){const nf=game.flags.map(f=>f.id===flagId?{...f,heldBy:null,heldByTeam:null,capturedAt:null}:f);updPl[playerId]={...player,defends:(player.defends||0)+1,points:(player.points||0)+CTF_PTS_DEFEND};updTms=updTms.map(t=>t.id===player.teamId?{...t,points:t.points+CTF_PTS_DEFEND}:t);const ev={id:uid(),type:"defend",flagId,flagName:flag.name,playerId,playerName:player.name,teamId:player.teamId,ts:Date.now(),msg:`🛡️ ${player.name} defended the ${flag.name} flag!`};return{game:{...game,flags:nf,players:updPl,teams:updTms,events:[...game.events,ev].slice(-50)},result:"defended"};}
  const capPts=CTF_PTS_CAPTURE+(isSteal?CTF_PTS_STEAL:0);
  const nHist=[...(flag.history||[]),{playerId,playerName:player.name,teamId:player.teamId,ts:Date.now(),action:isSteal?"steal":"capture"}];
  const nFlags=game.flags.map(f=>f.id===flagId?{...f,heldBy:playerId,heldByTeam:player.teamId,capturedAt:Date.now(),history:nHist}:f);
  updPl[playerId]={...player,captures:(player.captures||0)+1,steals:(player.steals||0)+(isSteal?1:0),points:(player.points||0)+capPts};
  updTms=updTms.map(t=>t.id===player.teamId?{...t,points:t.points+capPts,captures:t.captures+1}:t);
  const msgFn=CTF_STEAL_MSGS[Math.floor(Math.random()*CTF_STEAL_MSGS.length)];
  const ev={id:uid(),type:isSteal?"steal":"capture",flagId,flagName:flag.name,playerId,playerName:player.name,teamId:player.teamId,ts:Date.now(),msg:msgFn(player.name,flag.name),pts:capPts};
  return{game:{...game,flags:nFlags,players:updPl,teams:updTms,events:[...game.events,ev].slice(-50)},result:isSteal?"steal":"capture",pts:capPts};
}
function applyHit(game,fromId,toId,weapon,dmgMulti=1,allowRespawn=false){
  const att=game.players[fromId],tgt=game.players[toId];
  if(!att||!tgt||!tgt.alive||tgt.cloaked) return {game,result:tgt?.cloaked?"cloaked":"miss"};
  // Friendly fire check
  const diff=DIFFICULTY_LEVELS[game.difficulty||"intermediate"]||DIFFICULTY_LEVELS.intermediate;
  if(!diff.friendlyFire && att.teamId && tgt.teamId && att.teamId===tgt.teamId) return{game,result:"miss"};
  const base=Math.round((WDMG[weapon]||20)*dmgMulti), dmg=att.doubleDmg>0?base*2:base;
  const abs=Math.min(tgt.shield||0,dmg),actual=dmg-abs,newHp=Math.max(0,tgt.hp-actual);
  // Beginner free respawn
  const respawnUsed=newHp<=0&&allowRespawn&&!tgt.usedFreeRespawn;
  const finalHp=respawnUsed?30:newHp;
  const killed=finalHp<=0;
  const g={...game,players:{...game.players,
    [toId]:{...tgt,hp:newHp,shield:Math.max(0,tgt.shield-abs),alive:!killed},
    [fromId]:{...att,doubleDmg:Math.max(0,att.doubleDmg-1),kills:att.kills+(killed?1:0)},
  },events:[...(game.events||[]),{id:uid(),type:killed?"kill":"hit",from:fromId,to:toId,weapon,dmg,ts:Date.now()}].slice(-30)};
  const alive=Object.values(g.players).filter(p=>p.alive);
  if(alive.length===1){g.status="ended";g.winner=alive[0].id;}
  return {game:g,result:killed?"kill":"hit",dmg};
}

// ═══════════════════════════════════════════════════════════════════════════════
// SHARED HOOK  — real-time Firebase subscriptions with local fallback
// ─────────────────────────────────────────────────────────────────────────────
// When Firebase is connected: onValue() fires instantly on any remote write —
// all devices see changes within ~100ms.
// When Firebase is unavailable: falls back to polling every 800ms via
// the subscribe() helper above.
// ═══════════════════════════════════════════════════════════════════════════════
// useShared is now region + gameCode aware.
// Pass {regionId, gameCode} to scope all reads/writes to the correct Firebase path.
// Falls back to legacy KEYS when called with no args (demo / offline mode).
function useShared({ regionId, gameCode } = {}){
  const keys = regionId && gameCode ? K(regionId, gameCode) : KEYS;
  const [game,setGame]   = useState(null);
  const [hunt,setHunt]   = useState(null);
  const [codes,setCodes] = useState({});

  useEffect(()=>{
    if(!keys.game) return;
    const u1 = subscribe(keys.game,  v => { if(v) setGame(v);  });
    const u2 = subscribe(keys.hunt,  v => { if(v) setHunt(v);  });
    const u3 = subscribe(keys.codes, v => { if(v) setCodes(v); });
    return () => { u1(); u2(); u3(); };
  },[keys.game, keys.hunt, keys.codes]);

  // mutGame — optimistic local + Firebase broadcast + lobby index update
  const mutGame = useCallback(async fn => {
    const g = await rd(keys.game);
    if(!g) return;
    const next = fn(g);
    setGame(next);
    await wr(keys.game, next);
    // Keep lobby index fresh so the lobby browser shows current player count
    if(keys.lobby) {
      await wr(keys.lobby, {
        regionId, gameCode,
        title:      next.title || `${(REGIONS.find(r=>r.id===regionId)||{}).flag||"🌍"} Crawl`,
        status:     next.status,
        difficulty: next.difficulty || "intermediate",
        playerCount:Object.keys(next.players||{}).length,
        updatedAt:  Date.now(),
      });
    }
  },[keys, regionId, gameCode]);

  const mutHunt = useCallback(async fn => {
    const h = await rd(keys.hunt);
    if(!h) return;
    const next = fn(h);
    setHunt(next);
    await wr(keys.hunt, next);
  },[keys]);

  const mutCodes = useCallback(async fn => {
    const c = (await rd(keys.codes)) || {};
    const next = fn(c);
    setCodes(next);
    await wr(keys.codes, next);
  },[keys]);

  return { game, hunt, codes, keys, setGame, setHunt, mutGame, mutHunt, mutCodes };
}

// ═══════════════════════════════════════════════════════════════════════════════
// SMALL UI COMPONENTS
// ═══════════════════════════════════════════════════════════════════════════════
const Pill=({label,color,bg})=><span style={{background:bg||`${color}18`,border:`1px solid ${color}40`,color,borderRadius:20,padding:"3px 10px",fontFamily:"'Black Han Sans',sans-serif",fontSize:10,letterSpacing:1,whiteSpace:"nowrap"}}>{label}</span>;
const HPBar=({hp,max})=>{const p=Math.max(0,(hp/max)*100),c=p>60?"#34C759":p>25?"#FF9500":"#FF2D55";return<div style={{height:8,background:"#2a2a3a",borderRadius:4,overflow:"hidden"}}><div style={{height:"100%",width:`${p}%`,background:c,borderRadius:4,transition:"width .5s"}}/></div>;};



// ═══════════════════════════════════════════════════════════════════════════════
// PLAY ZONE SYSTEM
// ─────────────────────────────────────────────────────────────────────────────
// GPS-based perimeter enforcement. Warns players approaching the boundary,
// starts a grace-period countdown if they leave, and triggers DQ if they
// don't return. Bartenders can override/exempt individual players.
// ═══════════════════════════════════════════════════════════════════════════════

// Haversine distance between two lat/lng points → metres
function haversineM(lat1, lng1, lat2, lng2) {
  const R = 6371000;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dLat/2)**2 + Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLng/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

// Convert metres to rough SVG pixels for the mini-map
function metresToPx(metres, radiusMetres, mapRadius) {
  return (metres / radiusMetres) * mapRadius;
}

function usePlayZone({ config, active, myId, onWarn, onApproaching, onReturn, onDQ }) {
  const watchId  = useRef(null);
  const graceRef = useRef(null);
  const [pos,        setPos]        = useState(null);   // {lat,lng,accuracy}
  const [distToEdge, setDistToEdge] = useState(null);   // metres remaining before boundary
  const [status,     setStatus]     = useState("ok");   // ok | approaching | outside | grace | dq
  const [graceSecs,  setGraceSecs]  = useState(0);

  const zone = config?.zone;

  const stopGrace = () => { if(graceRef.current){clearInterval(graceRef.current);graceRef.current=null;} };

  const startGrace = useCallback(() => {
    if(graceRef.current) return; // already counting
    let t = zone?.graceSecs || 60;
    setGraceSecs(t);
    setStatus("grace");
    onWarn && onWarn(t);
    graceRef.current = setInterval(() => {
      t--;
      setGraceSecs(t);
      if(t <= 0) {
        stopGrace();
        setStatus("dq");
        onDQ && onDQ();
      }
    }, 1000);
  }, [zone, onWarn, onDQ]);

  useEffect(() => {
    if(!active || !zone?.enabled || !navigator.geolocation) return;

    watchId.current = navigator.geolocation.watchPosition(
      (position) => {
        const { latitude, longitude, accuracy } = position.coords;
        setPos({ lat: latitude, lng: longitude, accuracy });

        const dist = haversineM(latitude, longitude, zone.centerLat, zone.centerLng);
        const toEdge = zone.radiusMeters - dist;
        setDistToEdge(Math.round(toEdge));

        if (dist > zone.radiusMeters) {
          // Outside the zone
          if (status !== "grace" && status !== "dq") {
            startGrace();
          }
          onApproaching && onApproaching(-Math.round(dist - zone.radiusMeters));
        } else if (dist > zone.radiusMeters - zone.warnMeters) {
          // Approaching boundary
          stopGrace();
          setStatus("approaching");
          setStatus(s => { if(s==="grace"||s==="dq") return s; return "approaching"; });
          onApproaching && onApproaching(Math.round(toEdge));
        } else {
          // Safely inside
          if(status === "grace" || status === "outside") {
            stopGrace();
            setStatus("ok");
            onReturn && onReturn();
          } else {
            setStatus(s => s==="dq" ? s : "ok");
          }
        }
      },
      (err) => {
        console.warn("Geolocation error:", err.message);
        // Don't penalise for GPS errors — silently ignore
      },
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 }
    );

    return () => {
      if(watchId.current) navigator.geolocation.clearWatch(watchId.current);
      stopGrace();
    };
  }, [active, zone?.enabled]);

  return { pos, distToEdge, status, graceSecs };
}

// ── Zone warning banner (shown in player HUD) ─────────────────────────────────
function ZoneBanner({ distToEdge, status, graceSecs, onDismiss }) {
  if(status === "ok" || !status) return null;

  const cfg = {
    approaching: { color:"#FF9500", bg:"#FF950015", border:"#FF950040", icon:"⚠️",  msg:`Approaching boundary — ${distToEdge}m to edge` },
    outside:     { color:"#FF2D55", bg:"#FF2D5515", border:"#FF2D5540", icon:"🚨",  msg:"YOU'VE LEFT THE PLAY ZONE!" },
    grace:       { color:"#FF2D55", bg:"#FF2D5520", border:"#FF2D55",   icon:"🚨",  msg:`RETURN NOW — DQ in ${graceSecs}s` },
    dq:          { color:"#FF2D55", bg:"#FF2D5530", border:"#FF2D55",   icon:"🚫",  msg:"DISQUALIFIED — Left the play zone" },
  }[status] || { color:"#FF9500", bg:"#FF950015", border:"#FF950040", icon:"⚠️", msg:"Check your location" };

  return (
    <div style={{
      background:cfg.bg, border:`2px solid ${cfg.border}`,
      borderRadius:12, padding:"10px 14px",
      display:"flex", alignItems:"center", gap:10,
      animation: status==="grace" ? "flash 1s ease-in-out infinite" : "popIn .3s ease",
    }}>
      <span style={{fontSize:22,flexShrink:0}}>{cfg.icon}</span>
      <div style={{flex:1}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,color:cfg.color}}>
          {cfg.msg}
        </div>
        {status==="grace"&&<div style={{fontSize:10,color:"#888",marginTop:2}}>Return to play zone to avoid disqualification</div>}
        {status==="approaching"&&distToEdge>0&&<div style={{fontSize:10,color:"#888",marginTop:2}}>Head back toward the crawl route</div>}
      </div>
      {status==="approaching"&&<button onClick={onDismiss} style={{background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:16}}>✕</button>}
      {/* Grace countdown ring */}
      {status==="grace"&&(
        <div style={{position:"relative",width:40,height:40,flexShrink:0}}>
          <svg viewBox="0 0 40 40" style={{position:"absolute",inset:0,transform:"rotate(-90deg)"}}>
            <circle cx="20" cy="20" r="16" fill="none" stroke="#2a2a3a" strokeWidth="3"/>
            <circle cx="20" cy="20" r="16" fill="none" stroke="#FF2D55" strokeWidth="3"
              strokeDasharray={`${2*Math.PI*16}`}
              strokeDashoffset={`${2*Math.PI*16*(1-graceSecs/60)}`}
              strokeLinecap="round"/>
          </svg>
          <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Black Han Sans',sans-serif",fontSize:12,color:"#FF2D55"}}>{graceSecs}</div>
        </div>
      )}
    </div>
  );
}

// ── Zone mini-map (SVG radar showing player position relative to boundary) ────
function ZoneMiniMap({ pos, zone, barPositions, status }) {
  if(!zone) return null;
  const MAP_R = 100; // SVG radius
  const cx = 110, cy = 110;

  const playerPx = pos ? {
    x: cx + metresToPx(haversineM(zone.centerLat, pos.lng,  zone.centerLat, zone.centerLng) * (pos.lng  > zone.centerLng  ? 1 : -1), zone.radiusMeters, MAP_R),
    y: cy - metresToPx(haversineM(pos.lat,  zone.centerLng, zone.centerLat, zone.centerLng) * (pos.lat  > zone.centerLat  ? 1 : -1), zone.radiusMeters, MAP_R),
  } : null;

  const zoneColor = status==="ok" ? "#34C759" : status==="approaching" ? "#FF9500" : "#FF2D55";

  return (
    <svg viewBox="0 0 220 220" style={{width:"100%",maxWidth:220,display:"block",margin:"0 auto"}}>
      {/* Background */}
      <circle cx={cx} cy={cy} r={MAP_R+8} fill="#0a0c16"/>
      {/* Grid rings */}
      {[.25,.5,.75,1].map(f=>(
        <circle key={f} cx={cx} cy={cy} r={MAP_R*f} fill="none" stroke="#1a2035" strokeWidth={f===1?0:0.5} strokeDasharray={f===1?"":"3 5"}/>
      ))}
      {/* Zone boundary */}
      <circle cx={cx} cy={cy} r={MAP_R} fill={`${zoneColor}08`} stroke={zoneColor} strokeWidth="2.5" strokeOpacity="0.8"/>
      {/* Warning ring */}
      <circle cx={cx} cy={cy} r={MAP_R - metresToPx(zone.warnMeters, zone.radiusMeters, MAP_R)} fill="none" stroke="#FF9500" strokeWidth="1" strokeOpacity="0.3" strokeDasharray="4 6"/>
      {/* Centre cross */}
      <line x1={cx-8} y1={cy} x2={cx+8} y2={cy} stroke="#2a2a3a" strokeWidth="1"/>
      <line x1={cx} y1={cy-8} x2={cx} y2={cy+8} stroke="#2a2a3a" strokeWidth="1"/>
      <circle cx={cx} cy={cy} r="3" fill="#2a2a3a"/>
      {/* Bar dots */}
      {(barPositions||[]).map((b,i)=>{
        const bx = cx + metresToPx(haversineM(zone.centerLat, b.lng, zone.centerLat, zone.centerLng) * (b.lng > zone.centerLng ? 1 : -1), zone.radiusMeters, MAP_R);
        const by = cy - metresToPx(haversineM(b.lat, zone.centerLng, zone.centerLat, zone.centerLng) * (b.lat > zone.centerLat ? 1 : -1), zone.radiusMeters, MAP_R);
        return(
          <g key={i}>
            <circle cx={bx} cy={by} r="6" fill="#0d0e1a" stroke="#FF9500" strokeWidth="1.5"/>
            <text x={bx} y={by+4} textAnchor="middle" fontSize="7" style={{userSelect:"none"}}>🍺</text>
          </g>
        );
      })}
      {/* Player dot */}
      {playerPx&&(
        <g filter="url(#zoneGlow)">
          <circle cx={playerPx.x} cy={playerPx.y} r={8+Math.sin(Date.now()/500)*2} fill={zoneColor} fillOpacity="0.2"/>
          <circle cx={playerPx.x} cy={playerPx.y} r="7" fill="#0d0e1a" stroke={zoneColor} strokeWidth="2.5"/>
          <text x={playerPx.x} y={playerPx.y+4} textAnchor="middle" fontSize="8" style={{userSelect:"none"}}>📍</text>
        </g>
      )}
      {!pos&&(
        <text x={cx} y={cy+4} textAnchor="middle" fontSize="9" fill="#555" fontFamily="monospace">GPS locating...</text>
      )}
      {/* Labels */}
      <text x={cx} y={cy-MAP_R-4} textAnchor="middle" fontSize="7" fill={zoneColor} fontFamily="monospace">N</text>
      <text x={cx+MAP_R+4} y={cy+3} textAnchor="start" fontSize="7" fill={zoneColor} fontFamily="monospace">E</text>
      <defs><filter id="zoneGlow"><feGaussianBlur stdDeviation="2" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>
      {/* Radius label */}
      <text x={cx+MAP_R/2} y={cy+3} textAnchor="middle" fontSize="7" fill="#555" fontFamily="monospace">{Math.round(zone.radiusMeters/2)}m</text>
    </svg>
  );
}

// ── Zone screen (full view with map, status, and bar list) ────────────────────
function ZoneScreen({ zone, pos, distToEdge, status, graceSecs, onBack, onExempt, exempted }) {
  const zoneColor = status==="ok"?"#34C759":status==="approaching"?"#FF9500":"#FF2D55";
  const barPositions = DEMO_BARS?.map(b=>({lat:b.lat||0,lng:b.lng||0,name:b.n})).filter(b=>b.lat)||[];

  const DEMO_BARS_LOCAL = [
    {lat:51.5254,lng:-0.0801,n:"Simmons Bar"},
    {lat:51.5224,lng:-0.0778,n:"The Edge Bar"},
    {lat:51.5143,lng:-0.1311,n:"Thirst Bar"},
    {lat:51.5124,lng:-0.1390,n:"Little Violet Door"},
    {lat:51.5065,lng:-0.0875,n:"The Iron Tap"},
    {lat:51.5054,lng:-0.0913,n:"Market Porter"},
  ];

  return (
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,letterSpacing:3,color:zoneColor,textAlign:"center"}}>📍 PLAY ZONE</div>

      {/* Status card */}
      <div style={{...S.card,background:`${zoneColor}10`,border:`2px solid ${zoneColor}40`,textAlign:"center"}}>
        <div style={{fontSize:36,marginBottom:6}}>{status==="ok"?"✅":status==="approaching"?"⚠️":status==="grace"?"🚨":"🚫"}</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,color:zoneColor}}>
          {status==="ok"?"IN ZONE":status==="approaching"?"APPROACHING EDGE":status==="grace"?"OUTSIDE — RETURN NOW":"OUTSIDE ZONE"}
        </div>
        {distToEdge!==null&&<div style={{fontSize:12,color:"#888",marginTop:6}}>
          {distToEdge>=0?`${distToEdge}m to boundary`:`${Math.abs(distToEdge)}m outside boundary`}
        </div>}
        {status==="grace"&&<div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:28,color:"#FF2D55",marginTop:8,textShadow:"0 0 20px #FF2D5580"}}>{graceSecs}s</div>}
        {exempted&&<div style={{fontSize:11,color:"#FFCC00",marginTop:6,background:"#FFCC0015",border:"1px solid #FFCC0030",borderRadius:8,padding:"4px 12px"}}>⭐ ZONE EXEMPTION ACTIVE — bartender override</div>}
      </div>

      {/* Zone map */}
      <div style={{...S.card,padding:12}}>
        <div style={{fontSize:9,color:"#555",letterSpacing:3,marginBottom:8,textAlign:"center"}}>ZONE MAP — {zone?.radiusMeters}m RADIUS</div>
        <ZoneMiniMap pos={pos} zone={zone} barPositions={DEMO_BARS_LOCAL} status={status}/>
        <div style={{display:"flex",justifyContent:"space-around",marginTop:8,fontSize:10}}>
          <span style={{color:"#34C759"}}>● Safe zone</span>
          <span style={{color:"#FF9500"}}>● Warning ring ({zone?.warnMeters}m)</span>
          <span style={{color:"#FF2D55"}}>● Boundary</span>
        </div>
      </div>

      {/* Zone info */}
      <div style={{...S.card}}>
        <div style={S.sectionTitle}>ZONE DETAILS</div>
        {[
          {l:"Zone radius",    v:`${zone?.radiusMeters}m`},
          {l:"Warning ring",   v:`${zone?.warnMeters}m from edge`},
          {l:"Grace period",   v:`${zone?.graceSecs}s to return`},
          {l:"Centre point",   v:`${zone?.centerLat?.toFixed(4)}, ${zone?.centerLng?.toFixed(4)}`},
          {l:"Your position",  v:pos?`${pos.lat.toFixed(4)}, ${pos.lng.toFixed(4)}`:"Locating..."},
          {l:"GPS accuracy",   v:pos?`±${Math.round(pos.accuracy)}m`:"—"},
        ].map((r,i)=>(
          <div key={i} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:"1px solid #1a1d2e",fontSize:11}}>
            <span style={{color:"#555"}}>{r.l}</span>
            <span style={{color:"#f0f0f8",fontFamily:"'Space Mono',monospace"}}>{r.v}</span>
          </div>
        ))}
      </div>
      <button style={S.btnGhost} onClick={onBack}>← BACK TO GAME</button>
    </div>
  );
}

// ── Bartender zone override panel (inside BartenderDash safety tab) ───────────
function ZoneOverridePanel({ players, onExempt, onRevoke, exemptions }) {
  const [sel, setSel] = useState(null);
  const [reason, setReason] = useState("");

  return (
    <div style={{display:"flex",flexDirection:"column",gap:10}}>
      <div style={{...S.card,background:"#FFCC0010",border:"1px solid #FFCC0030",fontSize:11,color:"#FFCC00",lineHeight:1.7}}>
        ⭐ Zone exemptions let a player temporarily leave the play area — e.g. medical, accessibility, or leaving early. This overrides the auto-DQ. Use responsibly.
      </div>
      {players.length===0&&<div style={{...S.card,textAlign:"center",color:"#444",fontSize:12}}>No active players</div>}
      {players.map(p=>{
        const isExempt = exemptions?.includes(p.id);
        return(
          <div key={p.id} style={{...S.card,display:"flex",alignItems:"center",gap:10,border:`1px solid ${isExempt?"#FFCC0040":"#1a1d2e"}`,background:isExempt?"#FFCC0008":"#0d0e1a"}}>
            <span style={{fontSize:22}}>{p.avatar}</span>
            <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1}}>{p.name}</div><div style={{fontSize:9,color:isExempt?"#FFCC00":"#555",marginTop:2}}>{isExempt?"⭐ Zone exempt":"In play zone"}</div></div>
            <button onClick={()=>isExempt?onRevoke(p.id):onExempt(p.id)} style={{padding:"7px 14px",border:"none",borderRadius:10,background:isExempt?"#FF2D5520":"#FFCC0020",color:isExempt?"#FF2D55":"#FFCC00",border:`1px solid ${isExempt?"#FF2D5540":"#FFCC0040"}`,fontFamily:"'Black Han Sans',sans-serif",fontSize:11,letterSpacing:1,cursor:"pointer"}}>
              {isExempt?"REVOKE":"EXEMPT"}
            </button>
          </div>
        );
      })}
    </div>
  );
}


// ═══════════════════════════════════════════════════════════════════════════════
// SPEED SAFETY SYSTEM
// ─────────────────────────────────────────────────────────────────────────────
// Uses the GPS Geolocation API's built-in speed property (m/s).
// Three thresholds:
//   WARN  > 10 km/h  (~6 mph) — yellow banner, nudge to stop
//   LOCK  > 20 km/h  (~12 mph) — hard lock overlay, game paused
//   CLEAR < 8  km/h  — re-enables play
//
// Speed is supplied directly by the device GPS chip — no calculation needed.
// Falls back gracefully when GPS is unavailable or denied.
// ═══════════════════════════════════════════════════════════════════════════════

const SPEED_WARN_KMH  = 10;   // yellow warning
const SPEED_LOCK_KMH  = 20;   // hard game lock
const SPEED_CLEAR_KMH = 8;    // hysteresis — must drop below this to unlock
const MS_TO_KMH       = 3.6;  // metres/sec → km/h

function useSpeedMonitor({ active }) {
  const [speedKmh,   setSpeedKmh]   = useState(0);
  const [speedState, setSpeedState] = useState("clear"); // clear | warn | locked
  const watchId    = useRef(null);
  const lockedRef  = useRef(false);

  useEffect(() => {
    if (!active || !navigator.geolocation) return;

    watchId.current = navigator.geolocation.watchPosition(
      (pos) => {
        // pos.coords.speed is in m/s, null if unavailable
        const rawMs  = pos.coords.speed;
        if (rawMs === null || rawMs === undefined) return; // no speed data — ignore
        const kmh = rawMs * MS_TO_KMH;
        setSpeedKmh(Math.round(kmh));

        setSpeedState(prev => {
          if (kmh >= SPEED_LOCK_KMH) {
            lockedRef.current = true;
            return "locked";
          }
          if (kmh >= SPEED_WARN_KMH) {
            return lockedRef.current ? "locked" : "warn";
          }
          if (kmh < SPEED_CLEAR_KMH) {
            lockedRef.current = false;
            return "clear";
          }
          return prev; // hysteresis band — keep current state
        });
      },
      () => {}, // silently ignore GPS errors
      { enableHighAccuracy: true, maximumAge: 2000, timeout: 10000 }
    );

    return () => {
      if (watchId.current) navigator.geolocation.clearWatch(watchId.current);
    };
  }, [active]);

  return { speedKmh, speedState };
}

// ── Speed warning banner (non-blocking, shown in HUD) ──────────────────────────
function SpeedWarnBanner({ speedKmh }) {
  return (
    <div style={{
      display:"flex", alignItems:"center", gap:10,
      padding:"9px 14px",
      background:"#FF950018",
      border:"2px solid #FF9500",
      borderRadius:12,
      animation:"flash 1.5s ease-in-out infinite",
    }}>
      <span style={{fontSize:22, flexShrink:0}}>🚗</span>
      <div style={{flex:1}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif", fontSize:13, letterSpacing:1, color:"#FF9500"}}>
          YOU APPEAR TO BE MOVING
        </div>
        <div style={{fontSize:10, color:"#888", marginTop:2, lineHeight:1.5}}>
          {speedKmh} km/h detected — please stop before playing
        </div>
      </div>
      <div style={{fontFamily:"'Black Han Sans',sans-serif", fontSize:18, color:"#FF9500", flexShrink:0}}>
        {speedKmh}<span style={{fontSize:9, marginLeft:2}}>km/h</span>
      </div>
    </div>
  );
}

// ── Hard lock overlay (full screen, blocks all interaction) ────────────────────
function SpeedLockOverlay({ speedKmh, onAcknowledge }) {
  const [taps,  setTaps]  = useState(0);
  const [timer, setTimer] = useState(null);

  // Require 3 taps of a confirmation button to dismiss
  // (so it can't be dismissed by accident while driving)
  const handleTap = () => {
    const next = taps + 1;
    setTaps(next);
    if (next >= 3) {
      onAcknowledge();
      setTaps(0);
    } else {
      if (timer) clearTimeout(timer);
      setTimer(setTimeout(() => setTaps(0), 3000)); // reset if they stop tapping
    }
  };

  return (
    <div style={{
      position:"fixed", inset:0, zIndex:9000,
      background:"rgba(0,0,0,.97)",
      display:"flex", flexDirection:"column",
      alignItems:"center", justifyContent:"center",
      padding:28, textAlign:"center",
      backdropFilter:"blur(4px)",
    }}>
      {/* Pulsing warning icon */}
      <div style={{
        fontSize:88,
        marginBottom:16,
        filter:"drop-shadow(0 0 30px #FF2D55)",
        animation:"breathe 1s ease-in-out infinite",
      }}>🚗</div>

      <div style={{
        fontFamily:"'Black Han Sans',sans-serif",
        fontSize:32, letterSpacing:4,
        color:"#FF2D55",
        textShadow:"0 0 30px #FF2D5560",
        marginBottom:8,
      }}>
        STOP!
      </div>

      <div style={{
        fontFamily:"'Black Han Sans',sans-serif",
        fontSize:18, letterSpacing:2,
        color:"#f0f0f8", marginBottom:16,
      }}>
        DO NOT PLAY WHILE DRIVING
      </div>

      {/* Speed readout */}
      <div style={{
        background:"#FF2D5520", border:"2px solid #FF2D55",
        borderRadius:16, padding:"14px 28px",
        marginBottom:20,
      }}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif", fontSize:52, color:"#FF2D55", lineHeight:1}}>
          {speedKmh}
        </div>
        <div style={{fontSize:11, color:"#FF2D55", letterSpacing:3, marginTop:4}}>KM/H DETECTED</div>
      </div>

      <div style={{
        fontSize:12, color:"#888", lineHeight:1.8,
        maxWidth:300, marginBottom:28,
      }}>
        CrawlFire is a walking pub crawl game.<br/>
        Playing while driving puts <strong style={{color:"#f0f0f8"}}>you and others at risk.</strong><br/>
        The game is paused until you come to a stop.
      </div>

      {/* Legal / safety note */}
      <div style={{
        background:"#12121a", border:"1px solid #2a2a3a",
        borderRadius:12, padding:"12px 16px",
        fontSize:10, color:"#555", lineHeight:1.8,
        maxWidth:320, marginBottom:28,
      }}>
        ⚖️ Using a mobile device while driving may be illegal in your area.<br/>
        🚶 CrawlFire is designed to be played on foot between bars.<br/>
        🍺 Please drink responsibly and never drink and drive.
      </div>

      {/* Triple-tap dismiss — only usable when stationary */}
      <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:8}}>
        <div style={{fontSize:9, color:"#444", letterSpacing:2}}>
          TAP {3 - taps} MORE TIME{3 - taps !== 1 ? "S" : ""} TO CONFIRM YOU'VE STOPPED
        </div>
        <div style={{display:"flex",gap:6}}>
          {[0,1,2].map(i=>(
            <div key={i} style={{width:10,height:10,borderRadius:"50%",background:i<taps?"#34C759":"#2a2a3a",transition:"background .2s"}}/>
          ))}
        </div>
        <button onClick={handleTap} style={{
          marginTop:4,
          padding:"14px 32px",
          border:`2px solid ${taps>0?"#34C759":"#2a2a3a"}`,
          borderRadius:14,
          background:taps>0?"#34C75920":"transparent",
          color:taps>0?"#34C759":"#444",
          fontFamily:"'Black Han Sans',sans-serif",
          fontSize:15, letterSpacing:2,
          cursor:"pointer", transition:"all .2s",
        }}>
          {taps===0?"I HAVE STOPPED":taps===1?"TAP AGAIN...":"ONE MORE TAP..."}
        </button>
        <div style={{fontSize:9,color:"#333"}}>
          Resets automatically when GPS detects &lt; {SPEED_CLEAR_KMH} km/h
        </div>
      </div>
    </div>
  );
}

// ── Compact speed indicator FAB (shown in HUD, always visible while moving) ───
function SpeedFAB({ speedKmh, speedState }) {
  if (speedState === "clear" || speedKmh < 3) return null;
  const color = speedState === "locked" ? "#FF2D55" : "#FF9500";
  return (
    <div style={{
      position:"fixed", top:70, right:14,
      background:`${color}18`,
      border:`2px solid ${color}`,
      borderRadius:24,
      padding:"5px 12px",
      display:"flex", alignItems:"center", gap:6,
      zIndex:200,
      animation:speedState==="locked"?"glow 1s ease-in-out infinite":"none",
      boxShadow:`0 2px 12px ${color}40`,
      pointerEvents:"none",
    }}>
      <span style={{fontSize:13}}>🚗</span>
      <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color,letterSpacing:1}}>
        {speedKmh} <span style={{fontSize:8}}>km/h</span>
      </span>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// INACTIVITY SYSTEM
// ─────────────────────────────────────────────────────────────────────────────
// Tracks time since last user interaction (tap/swipe/type).
// Warning modal at WARN_SECS, auto-kick at KICK_SECS.
// Flags held by inactive CTF players are dropped.
// Inactive laser-tag players are marked "away" (not killed — fair to them).
// ═══════════════════════════════════════════════════════════════════════════════
const INACTIVITY_WARN_SECS = 1680; // show warning after 28m
const INACTIVITY_KICK_SECS = 1800; // auto-kick after 30m
const INACTIVITY_EVENTS    = ["mousedown","mousemove","touchstart","keydown","scroll","click","pointerdown"];

function useInactivity({ active, onWarn, onKick }) {
  const lastActivity = useRef(Date.now());
  const warned       = useRef(false);
  const timerRef     = useRef(null);

  const resetTimer = useCallback(() => {
    lastActivity.current = Date.now();
    warned.current = false;
  }, []);

  useEffect(() => {
    if (!active) return;

    const onEvent = () => resetTimer();
    INACTIVITY_EVENTS.forEach(e => window.addEventListener(e, onEvent, { passive: true }));

    timerRef.current = setInterval(() => {
      const idle = Math.floor((Date.now() - lastActivity.current) / 1000);
      if (idle >= INACTIVITY_KICK_SECS) {
        onKick();
        resetTimer();
      } else if (idle >= INACTIVITY_WARN_SECS && !warned.current) {
        warned.current = true;
        onWarn(INACTIVITY_KICK_SECS - idle);
      }
    }, 1000);

    return () => {
      INACTIVITY_EVENTS.forEach(e => window.removeEventListener(e, onEvent));
      clearInterval(timerRef.current);
    };
  }, [active, onWarn, onKick, resetTimer]);

  return { resetTimer };
}

function InactivityModal({ secondsLeft, onStayIn, onLeave }) {
  const [secs, setSecs] = useState(secondsLeft);
  useEffect(() => {
    if (secs <= 0) { onLeave(); return; }
    const id = setInterval(() => setSecs(s => { if (s <= 1) { clearInterval(id); return 0; } return s - 1; }), 1000);
    return () => clearInterval(id);
  }, []);
  const danger = secs <= 10;
  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.88)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:9999,animation:"fadeIn .2s ease"}}>
      <div style={{background:"#0d0e1a",border:`2px solid ${danger?"#FF2D55":"#FF9500"}`,borderRadius:20,padding:"32px 28px",maxWidth:320,width:"90%",textAlign:"center",boxShadow:`0 0 60px ${danger?"#FF2D5540":"#FF950040"}`,animation:"popUp .35s cubic-bezier(.34,1.56,.64,1)"}}>
        {/* Countdown ring */}
        <div style={{position:"relative",width:96,height:96,margin:"0 auto 20px"}}>
          <svg viewBox="0 0 96 96" style={{position:"absolute",inset:0,transform:"rotate(-90deg)"}}>
            <circle cx="48" cy="48" r="42" fill="none" stroke="#1a1d2e" strokeWidth="6"/>
            <circle cx="48" cy="48" r="42" fill="none"
              stroke={danger?"#FF2D55":"#FF9500"} strokeWidth="6"
              strokeDasharray={`${2*Math.PI*42}`}
              strokeDashoffset={`${2*Math.PI*42*(1 - secs/INACTIVITY_KICK_SECS)}`}
              strokeLinecap="round"
              style={{transition:"stroke-dashoffset 1s linear, stroke .3s"}}/>
          </svg>
          <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:32,color:danger?"#FF2D55":"#FF9500",lineHeight:1,textShadow:`0 0 16px ${danger?"#FF2D5580":"#FF950080"}`}}>{secs}</div>
            <div style={{fontSize:9,color:"#555",letterSpacing:2,marginTop:2}}>SECS</div>
          </div>
        </div>

        <div style={{fontSize:32,marginBottom:10}}>😴</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,letterSpacing:2,color:"#f0f0f8",marginBottom:8}}>
          STILL THERE?
        </div>
        <div style={{fontSize:12,color:"#666",lineHeight:1.7,marginBottom:20}}>
          You've been inactive for a while.<br/>
          {secs <= 10
            ? <span style={{color:"#FF2D55",fontWeight:"bold"}}>Auto-kicking in {secs}s!</span>
            : "Tap below to stay in the game."}
        </div>

        {/* Streak reminder */}
        <div style={{background:"#FF950015",border:"1px solid #FF950030",borderRadius:10,padding:"8px 14px",marginBottom:18,fontSize:11,color:"#FF9500"}}>
          ⚠️ Inactive players lose held flags &amp; drop from the leaderboard
        </div>

        <button onClick={onStayIn} style={{width:"100%",padding:15,border:"none",borderRadius:12,background:`linear-gradient(135deg,${danger?"#FF2D55":"#FF9500"},${danger?"#FF6B35":"#FFCC00"})`,color:danger?"#fff":"#000",fontFamily:"'Black Han Sans',sans-serif",fontSize:20,letterSpacing:3,cursor:"pointer",marginBottom:10,animation:danger?"glow 1s ease-in-out infinite":"none"}}>
          🎮 I'M STILL HERE!
        </button>
        <button onClick={onLeave} style={{background:"none",border:"none",color:"#444",fontFamily:"'Space Mono',monospace",fontSize:11,cursor:"pointer",padding:6}}>
          Leave the game
        </button>
      </div>
    </div>
  );
}

function PayFlow({pack,onConfirm,onCancel}){
  const [m,setM]=useState(null);
  const pay=method=>{setM(method);window.open(method==="paypal"?ppLink(pack.price,`CrawlFire – ${pack.label}`):vmLink(pack.price,`CrawlFire – ${pack.label}`),"_blank");};
  return(
    <div style={{display:"flex",flexDirection:"column",gap:12}}>
      <div style={{background:"#1a1a26",border:"2px solid #FF2D55",borderRadius:12,padding:"12px 16px",textAlign:"center"}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:"#FFCC00"}}>{pack.emoji} {pack.label}</div>
        <div style={{fontSize:24,fontFamily:"'Black Han Sans',sans-serif",color:"#f0f0f8",marginTop:4}}>{fmt(pack.price)} → 🪙{pack.coins}</div>
      </div>
      <div style={{display:"flex",gap:8}}>
        <button onClick={()=>pay("paypal")} style={{flex:1,padding:12,border:`2px solid ${m==="paypal"?"#003087":"#2a2a3a"}`,borderRadius:10,background:m==="paypal"?"#00308722":"#1a1a26",color:m==="paypal"?"#4fc3ff":"#888",fontFamily:"'Black Han Sans',sans-serif",fontSize:14,cursor:"pointer"}}>🅿️ PayPal</button>
        <button onClick={()=>pay("venmo")}  style={{flex:1,padding:12,border:`2px solid ${m==="venmo"?"#3D95CE":"#2a2a3a"}`,borderRadius:10,background:m==="venmo"?"#3D95CE22":"#1a1a26",color:m==="venmo"?"#4fc3ff":"#888",fontFamily:"'Black Han Sans',sans-serif",fontSize:14,cursor:"pointer"}}>💙 Venmo</button>
      </div>
      {m&&<button onClick={()=>onConfirm(pack.coins)} style={S.btnPrimary}>✅ CONFIRM PAYMENT → GET 🪙{pack.coins}</button>}
      <button onClick={onCancel} style={{background:"none",border:"none",color:"#555",fontFamily:"'Space Mono',monospace",fontSize:11,cursor:"pointer",padding:6}}>Cancel</button>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// STYLES  (shared object)
// ═══════════════════════════════════════════════════════════════════════════════
const S={
  screen:{minHeight:"100vh",background:"#07070e",fontFamily:"'Space Mono',monospace",color:"#f0f0f8",padding:"20px 20px 48px",display:"flex",flexDirection:"column",gap:16,position:"relative"},
  card:{background:"#0d0e1a",border:"1px solid #1a1d2e",borderRadius:14,padding:"16px"},
  btnPrimary:{width:"100%",padding:16,border:"none",borderRadius:12,background:"linear-gradient(135deg,#FF2D55,#FF6B35)",color:"#fff",fontFamily:"'Black Han Sans',sans-serif",fontSize:20,letterSpacing:3,cursor:"pointer"},
  btnGold:{width:"100%",padding:14,border:"none",borderRadius:12,background:"linear-gradient(135deg,#FF9500,#FFCC00)",color:"#000",fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,cursor:"pointer"},
  btnGhost:{background:"none",border:"1px solid #2a2a3a",color:"#666",padding:"7px 14px",borderRadius:8,fontFamily:"'Space Mono',monospace",fontSize:11,cursor:"pointer"},
  input:{width:"100%",background:"#12121a",border:"2px solid #2a2a3a",borderRadius:10,color:"#f0f0f8",fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2,padding:"12px 14px",outline:"none"},
  label:{fontSize:10,letterSpacing:3,color:"#555",marginBottom:4},
  title:{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,letterSpacing:3,color:"#FF2D55",textAlign:"center"},
  sectionTitle:{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:2,color:"#f0f0f8",marginBottom:8},
};

// ═══════════════════════════════════════════════════════════════════════════════
// ─── PLAYER SCREENS ───────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════════════════
// DAILY CHECK-IN SPIN WHEEL
// ─────────────────────────────────────────────────────────────────────────────
// Players get one free spin per day. Prizes land in their inventory and are
// usable in any future crawl. A streak bonus upgrades the prize tier.
//
// PRIZE TIERS:
//   Common   (grey)   — small coin bundles, basic shop items
//   Uncommon (green)  — bigger coins, sweeper, double damage
//   Rare     (blue)   — nuke shots, ghost mode, EMP mines
//   Epic     (purple) — revives, smoke mines, big coin drops
//   Legendary(gold)   — massive coins, mystery boxes, free entry token
//
// STREAK SYSTEM:
//   Day 1–2:  Normal wheel (mostly common/uncommon)
//   Day 3–5:  Boosted wheel (uncommon/rare bump)
//   Day 6:    Streak bonus spin — guaranteed Rare+
//   Day 7:    MEGA spin — guaranteed Epic+ and a streak badge
//   Miss a day: streak resets to 0
//
// PERSISTENCE: stored in window.storage keyed by playerId + date
//   cf:daily:{playerId}  → { lastSpin, streak, totalSpins, prizes[] }
// ═══════════════════════════════════════════════════════════════════════════════

const WHEEL_PRIZES = [
  // ── Common (grey) ──────────────────────────────────────────────────────────
  {id:"coins_25",    e:"🪙", n:"+25 Coins",       tier:"common",    color:"#4a506e", weight:30, reward:{coins:25}},
  {id:"coins_50",    e:"💰", n:"+50 Coins",        tier:"common",    color:"#4a506e", weight:20, reward:{coins:50}},
  {id:"medkit",      e:"💉", n:"Med Kit",          tier:"common",    color:"#4a506e", weight:20, reward:{item:"medkit",qty:1}},
  {id:"sweeper",     e:"🧹", n:"Mine Sweeper",     tier:"uncommon",  color:"#34C759", weight:15, reward:{item:"sweeper",qty:1}},
  // ── Uncommon (green) ───────────────────────────────────────────────────────
  {id:"coins_100",   e:"💰", n:"+100 Coins",       tier:"uncommon",  color:"#34C759", weight:12, reward:{coins:100}},
  {id:"shield",      e:"🛡️", n:"Shield Brew ×2",  tier:"uncommon",  color:"#34C759", weight:10, reward:{item:"shield",qty:2}},
  {id:"double",      e:"⚡", n:"2× Damage",        tier:"uncommon",  color:"#34C759", weight:10, reward:{item:"double",qty:1}},
  {id:"xp_boost",    e:"⭐", n:"+100 XP",          tier:"uncommon",  color:"#34C759", weight:8,  reward:{xp:100}},
  // ── Rare (blue) ────────────────────────────────────────────────────────────
  {id:"coins_250",   e:"💎", n:"+250 Coins",       tier:"rare",      color:"#007AFF", weight:7,  reward:{coins:250}},
  {id:"nuke",        e:"💣", n:"Nuke Shot",        tier:"rare",      color:"#007AFF", weight:6,  reward:{item:"nuke",qty:1}},
  {id:"cloak",       e:"👻", n:"Ghost Mode",       tier:"rare",      color:"#007AFF", weight:5,  reward:{item:"cloak",qty:1}},
  {id:"mine_emp",    e:"⚡💥",n:"EMP Mine",         tier:"rare",      color:"#007AFF", weight:4,  reward:{item:"mine_emp",qty:1}},
  // ── Epic (purple) ──────────────────────────────────────────────────────────
  {id:"revive",      e:"❤️‍🔥",n:"Revive",           tier:"epic",      color:"#BF5AF2", weight:4,  reward:{item:"revive",qty:1}},
  {id:"mine_smoke",  e:"💨💥",n:"Smoke Mine",       tier:"epic",      color:"#BF5AF2", weight:3,  reward:{item:"mine_smoke",qty:1}},
  {id:"coins_500",   e:"🏦", n:"+500 Coins",       tier:"epic",      color:"#BF5AF2", weight:3,  reward:{coins:500}},
  {id:"nuke_x2",     e:"💣💣",n:"Nuke Shot ×2",    tier:"epic",      color:"#BF5AF2", weight:2,  reward:{item:"nuke",qty:2}},
  // ── Legendary (gold) ───────────────────────────────────────────────────────
  {id:"coins_1000",  e:"👑", n:"+1000 Coins",      tier:"legendary", color:"#FFCC00", weight:1,  reward:{coins:1000}},
  {id:"free_entry",  e:"🎟️", n:"Free Entry Token", tier:"legendary", color:"#FFCC00", weight:1,  reward:{item:"free_entry",qty:1}},
  {id:"full_kit",    e:"🎁", n:"Full Kit",          tier:"legendary", color:"#FFCC00", weight:1,  reward:{item:"medkit",qty:2,extra:{item:"nuke",qty:1,also:{item:"revive",qty:1}}}},
];

const TIER_META = {
  common:    {label:"COMMON",    color:"#4a506e", bg:"#4a506e12", glow:"#4a506e40"},
  uncommon:  {label:"UNCOMMON",  color:"#34C759", bg:"#34C75912", glow:"#34C75940"},
  rare:      {label:"RARE",      color:"#007AFF", bg:"#007AFF12", glow:"#007AFF40"},
  epic:      {label:"EPIC",      color:"#BF5AF2", bg:"#BF5AF212", glow:"#BF5AF240"},
  legendary: {label:"LEGENDARY", color:"#FFCC00", bg:"#FFCC0015", glow:"#FFCC0060"},
};

const STREAK_DAYS = [
  {day:1, label:"Day 1", reward:"Normal spin",       icon:"🎰", tier:"common"},
  {day:2, label:"Day 2", reward:"Normal spin",        icon:"🎰", tier:"common"},
  {day:3, label:"Day 3", reward:"Boosted wheel",      icon:"⬆️", tier:"uncommon"},
  {day:4, label:"Day 4", reward:"Rare+ guaranteed",   icon:"💎", tier:"rare"},
  {day:5, label:"Day 5", reward:"Double spin",        icon:"🎰🎰",tier:"rare"},
  {day:6, label:"Day 6", reward:"Epic+ guaranteed",   icon:"🌟", tier:"epic"},
  {day:7, label:"Day 7", reward:"LEGENDARY + badge",  icon:"👑", tier:"legendary"},
];

// ── Daily state helpers ───────────────────────────────────────────────────────
function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;
}

async function loadDailyState(playerId) {
  try {
    const k = `cf:daily:${playerId||"demo"}`;
    const r = await window.storage.get(k, false);
    return r ? JSON.parse(r.value) : {lastSpin:null, streak:0, totalSpins:0, prizes:[]};
  } catch { return {lastSpin:null, streak:0, totalSpins:0, prizes:[]}; }
}

async function saveDailyState(playerId, state) {
  try {
    const k = `cf:daily:${playerId||"demo"}`;
    await window.storage.set(k, JSON.stringify(state), false);
  } catch {}
}

function canSpinToday(lastSpin) {
  return lastSpin !== todayKey();
}

function weightedPick(prizes, streakDay) {
  // Boost rare+ weights based on streak day
  const boost = streakDay >= 7 ? 5 : streakDay >= 6 ? 3 : streakDay >= 4 ? 2 : 1;
  const pool = prizes.map(p => {
    let w = p.weight;
    if (streakDay >= 6 && (p.tier==="legendary")) w *= boost;
    if (streakDay >= 4 && (p.tier==="epic"))       w *= boost;
    if (streakDay >= 3 && (p.tier==="rare"))        w *= 2;
    return {...p, _w: w};
  });
  const total = pool.reduce((s,p) => s+p._w, 0);
  let r = Math.random() * total;
  for (const p of pool) { r -= p._w; if (r <= 0) return p; }
  return pool[pool.length-1];
}

// ── Canvas-based spin wheel ───────────────────────────────────────────────────
function SpinWheelCanvas({ prizes, targetIdx, spinning, onSpinEnd }) {
  const canvasRef  = useRef(null);
  const rafRef     = useRef(null);
  const angleRef   = useRef(0);
  const velRef     = useRef(0);
  const phaseRef   = useRef("idle"); // idle|spin|settle
  const targetRef  = useRef(targetIdx);

  const SEGMENTS   = prizes.length;
  const SEG_ANG    = (2 * Math.PI) / SEGMENTS;

  // Draw wheel
  const draw = useCallback((angle) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx  = canvas.getContext("2d");
    const W    = canvas.width;
    const R    = W / 2 - 4;
    const cx   = W / 2, cy = W / 2;

    ctx.clearRect(0,0,W,W);

    // Outer glow ring
    const grad = ctx.createRadialGradient(cx,cy,R-6,cx,cy,R+4);
    grad.addColorStop(0,"rgba(255,45,85,.15)");
    grad.addColorStop(1,"transparent");
    ctx.fillStyle = grad;
    ctx.fillRect(0,0,W,W);

    prizes.forEach((p, i) => {
      const startA = angle + i * SEG_ANG - Math.PI/2;
      const endA   = startA + SEG_ANG;
      const meta   = TIER_META[p.tier] || TIER_META.common;

      // Segment fill
      ctx.beginPath();
      ctx.moveTo(cx,cy);
      ctx.arc(cx,cy,R,startA,endA);
      ctx.closePath();
      ctx.fillStyle = i%2===0 ? `${meta.color}25` : `${meta.color}15`;
      ctx.fill();
      ctx.strokeStyle = "#1a1d2e";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Emoji label
      const midA  = startA + SEG_ANG/2;
      const er    = R * 0.72;
      const ex    = cx + er * Math.cos(midA);
      const ey    = cy + er * Math.sin(midA);
      ctx.save();
      ctx.translate(ex, ey);
      ctx.rotate(midA + Math.PI/2);
      ctx.font  = SEGMENTS > 14 ? "13px serif" : "16px serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(p.e, 0, 0);
      ctx.restore();

      // Short label
      const lr    = R * 0.45;
      const lx    = cx + lr * Math.cos(midA);
      const ly    = cy + lr * Math.sin(midA);
      ctx.save();
      ctx.translate(lx,ly);
      ctx.rotate(midA + Math.PI/2);
      ctx.font  = "bold 6px monospace";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillStyle = meta.color;
      ctx.fillText(p.n.slice(0,8).toUpperCase(), 0, 0);
      ctx.restore();
    });

    // Centre hub
    ctx.beginPath();
    ctx.arc(cx,cy,22,0,2*Math.PI);
    ctx.fillStyle = "#07080f";
    ctx.fill();
    ctx.strokeStyle = "#FF2D55";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = "#FF2D55";
    ctx.font = "bold 16px serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("🔥", cx, cy+1);

    // Pointer triangle (top)
    ctx.beginPath();
    ctx.moveTo(cx-10, 2);
    ctx.lineTo(cx+10, 2);
    ctx.lineTo(cx, 22);
    ctx.closePath();
    ctx.fillStyle = "#FF2D55";
    ctx.fill();
    ctx.shadowColor = "#FF2D55";
    ctx.shadowBlur  = 8;
    ctx.fill();
    ctx.shadowBlur  = 0;
  }, [prizes, SEG_ANG]);

  // Animate spin
  useEffect(() => {
    if (!spinning) { draw(angleRef.current); return; }

    targetRef.current = targetIdx;
    phaseRef.current  = "spin";

    // Target angle: pointer sits at top (offset by 90°), segment middle
    const targetSegAngle = -(targetIdx * SEG_ANG + SEG_ANG/2) + Math.PI/2;
    // Spin at least 5 full rotations
    const extraSpins = (3 + Math.floor(Math.random()*3)) * 2 * Math.PI;
    const destAngle  = targetSegAngle - (angleRef.current % (2*Math.PI)) + extraSpins
                       + (2*Math.PI * Math.ceil((targetSegAngle - angleRef.current) / (2*Math.PI)));

    const totalDist  = destAngle - angleRef.current;
    const duration   = 4500 + Math.random()*1000; // ms
    const startAngle = angleRef.current;
    const startTime  = performance.now();

    const ease = t => t<0.5 ? 4*t*t*t : 1-Math.pow(-2*t+2,3)/2; // ease-in-out cubic

    const animate = (now) => {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / duration);
      const eased    = ease(progress);
      angleRef.current = startAngle + totalDist * eased;
      draw(angleRef.current);
      if (progress < 1) {
        rafRef.current = requestAnimationFrame(animate);
      } else {
        angleRef.current = startAngle + totalDist;
        draw(angleRef.current);
        onSpinEnd();
      }
    };

    rafRef.current = requestAnimationFrame(animate);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, [spinning, targetIdx, draw, SEG_ANG, onSpinEnd]);

  useEffect(() => { draw(angleRef.current); }, [draw]);

  return (
    <canvas ref={canvasRef} width={320} height={320}
      style={{width:"100%",maxWidth:320,display:"block",margin:"0 auto",borderRadius:"50%",boxShadow:"0 0 40px #FF2D5520"}}/>
  );
}

// ── StreakCalendar ─────────────────────────────────────────────────────────────
function StreakCalendar({ streak }) {
  return (
    <div style={{width:"100%",display:"flex",flexDirection:"column",gap:6}}>
      <div style={{fontSize:9,color:"#555",letterSpacing:3}}>🔥 DAILY STREAK — SPIN EVERY DAY</div>
      <div style={{display:"flex",gap:4}}>
        {STREAK_DAYS.map((d,i) => {
          const done    = streak > i;
          const current = streak === i;
          const meta    = TIER_META[d.tier] || TIER_META.common;
          return (
            <div key={d.day} style={{
              flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:3,
              padding:"6px 2px",
              background: done ? `${meta.color}20` : current ? "#1a1d2e" : "#0a0c14",
              border: `1.5px solid ${done||current ? meta.color+"60" : "#1a1d2e"}`,
              borderRadius: 8,
              opacity: done||current ? 1 : .5,
            }}>
              <div style={{fontSize: done?14:12}}>{done?"✅":d.icon}</div>
              <div style={{fontSize:7,color:done?meta.color:current?"#888":"#555",fontFamily:"'Black Han Sans',sans-serif",letterSpacing:.5}}>D{d.day}</div>
            </div>
          );
        })}
      </div>
      {streak >= 3 && (
        <div style={{fontSize:9,color:"#FF9500",textAlign:"center",padding:"4px 0"}}>
          🔥 {streak} day streak! {streak >= 7 ? "LEGENDARY spin unlocked!" : streak >= 6 ? "Epic spin tomorrow!" : streak >= 4 ? "Rare+ guaranteed!" : "Keep it up!"}
        </div>
      )}
    </div>
  );
}

// ── PrizeToast ─────────────────────────────────────────────────────────────────
function PrizeToast({ prize, onClose }) {
  const meta = TIER_META[prize.tier] || TIER_META.common;
  return (
    <div style={{
      position:"fixed",inset:0,background:"rgba(0,0,0,.88)",
      display:"flex",alignItems:"center",justifyContent:"center",
      zIndex:500, animation:"fadeIn .3s ease",
    }}>
      <div style={{
        background:"#0d0e1a", border:`3px solid ${meta.color}`,
        borderRadius:20, padding:"28px 24px", textAlign:"center",
        maxWidth:300, width:"90%",
        boxShadow:`0 0 60px ${meta.glow}`,
        animation:"popIn .5s cubic-bezier(.17,.67,.29,1.35)",
        display:"flex",flexDirection:"column",alignItems:"center",gap:12,
      }}>
        {/* Tier badge */}
        <div style={{background:meta.bg,border:`1px solid ${meta.color}50`,borderRadius:20,padding:"3px 14px",fontSize:9,color:meta.color,fontFamily:"'Black Han Sans',sans-serif",letterSpacing:2}}>
          {meta.label}
        </div>

        {/* Prize emoji with glow */}
        <div style={{fontSize:72,filter:`drop-shadow(0 0 20px ${meta.color})`,animation:"breathe 1.2s ease-in-out infinite",lineHeight:1}}>
          {prize.e}
        </div>

        {/* Prize name */}
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:26,letterSpacing:2,color:meta.color,textShadow:`0 0 20px ${meta.glow}`}}>
          {prize.n}
        </div>

        {/* Reward detail */}
        <div style={{fontSize:12,color:"#888",lineHeight:1.7}}>
          {prize.reward.coins ? `🪙 ${prize.reward.coins} coins added to your wallet` : `${prize.e} Added to inventory · usable in any crawl`}
        </div>

        {/* Saved for later note */}
        <div style={{background:"#34C75910",border:"1px solid #34C75930",borderRadius:10,padding:"8px 14px",fontSize:10,color:"#34C759",lineHeight:1.6,width:"100%"}}>
          💾 Saved to your inventory · use in the shop during any future crawl
        </div>

        <button onClick={onClose} style={{
          padding:"12px 32px",border:"none",borderRadius:14,cursor:"pointer",
          fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2,
          background:`linear-gradient(135deg,${meta.color},${meta.color}cc)`,
          color: prize.tier==="legendary"||prize.tier==="uncommon" ? "#000" : "#fff",
          boxShadow:`0 4px 16px ${meta.glow}`,width:"100%",
        }}>
          CLAIM REWARD ✓
        </button>
      </div>
    </div>
  );
}

// ── DailySpinScreen ────────────────────────────────────────────────────────────
function DailySpinScreen({ playerId, playerName, playerAvatar, onBack, onPrizeClaimed }) {
  const [dailyState, setDailyState] = useState({lastSpin:null,streak:0,totalSpins:0,prizes:[]});
  const [loading,    setLoading]    = useState(true);
  const [spinning,   setSpinning]   = useState(false);
  const [targetIdx,  setTargetIdx]  = useState(0);
  const [wonPrize,   setWonPrize]   = useState(null);
  const [showToast,  setShowToast]  = useState(false);

  const alreadySpun = dailyState.lastSpin === todayKey();
  const streak      = dailyState.streak || 0;
  const totalSpins  = dailyState.totalSpins || 0;

  // Load saved state on mount
  useEffect(() => {
    loadDailyState(playerId).then(s => {
      // Check streak continuity (if missed a day, reset)
      if (s.lastSpin) {
        const last = new Date(s.lastSpin.replace(/-/g,"/"));
        const today = new Date();
        const diffDays = Math.floor((today - last) / 86400000);
        if (diffDays > 1) s.streak = 0; // missed a day — reset
      }
      setDailyState(s);
      setLoading(false);
    });
  }, [playerId]);

  const doSpin = useCallback(() => {
    if (spinning || alreadySpun) return;

    // Pick the winning prize (weighted by streak)
    const prize   = weightedPick(WHEEL_PRIZES, streak+1);
    const idx     = WHEEL_PRIZES.indexOf(prize);

    setTargetIdx(idx);
    setWonPrize(prize);
    setSpinning(true);
  }, [spinning, alreadySpun, streak]);

  const handleSpinEnd = useCallback(() => {
    setSpinning(false);
    setShowToast(true);
  }, []);

  const handleClaim = useCallback(async () => {
    if (!wonPrize) return;
    setShowToast(false);

    const yesterday = dailyState.lastSpin;
    const wasYesterday = yesterday && (() => {
      const last  = new Date(yesterday.replace(/-/g,"/"));
      const today = new Date();
      return Math.floor((today-last)/86400000) === 1;
    })();

    const newState = {
      lastSpin:   todayKey(),
      streak:     wasYesterday || !yesterday ? streak + 1 : 1,
      totalSpins: totalSpins + 1,
      prizes:     [...(dailyState.prizes||[]), {
        ...wonPrize,
        claimedAt: Date.now(),
        day: todayKey(),
      }].slice(-30), // keep last 30 prizes
    };

    await saveDailyState(playerId, newState);
    setDailyState(newState);
    onPrizeClaimed && onPrizeClaimed(wonPrize);
  }, [wonPrize, dailyState, streak, totalSpins, playerId, onPrizeClaimed]);

  if (loading) return (
    <div style={{...S.screen,alignItems:"center",justifyContent:"center"}}>
      <div style={{fontSize:32,animation:"spin 1s linear infinite"}}>🎰</div>
    </div>
  );

  // Next spin countdown
  const now       = new Date();
  const midnight  = new Date(now); midnight.setHours(24,0,0,0);
  const msLeft    = midnight - now;
  const hLeft     = Math.floor(msLeft/3600000);
  const mLeft     = Math.floor((msLeft%3600000)/60000);

  return (
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>

      {/* Header */}
      <div style={{textAlign:"center"}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:26,letterSpacing:3,color:"#f0f0f8"}}>
          🎰 DAILY SPIN
        </div>
        <div style={{fontSize:11,color:"#555",marginTop:4,lineHeight:1.7}}>
          One free spin per day · prizes carry into any crawl
        </div>
      </div>

      {/* Streak calendar */}
      <StreakCalendar streak={streak}/>

      {/* Stat strip */}
      <div style={{display:"flex",gap:8}}>
        {[
          {v:streak,          l:"DAY STREAK",  e:"🔥", c:"#FF9500"},
          {v:totalSpins,      l:"TOTAL SPINS", e:"🎰", c:"#007AFF"},
          {v:(dailyState.prizes||[]).filter(p=>p.tier==="legendary"||p.tier==="epic").length, l:"EPICS WON",  e:"🌟", c:"#BF5AF2"},
        ].map((s,i)=>(
          <div key={i} style={{flex:1,...S.card,textAlign:"center",padding:"8px 4px"}}>
            <div style={{fontSize:9,color:"#555",letterSpacing:1,marginBottom:3}}>{s.e}</div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:s.c,lineHeight:1}}>{s.v}</div>
            <div style={{fontSize:7,color:"#555",letterSpacing:1,marginTop:2}}>{s.l}</div>
          </div>
        ))}
      </div>

      {/* Wheel */}
      <div style={{position:"relative",display:"flex",flexDirection:"column",alignItems:"center",gap:12}}>
        <SpinWheelCanvas
          prizes={WHEEL_PRIZES}
          targetIdx={targetIdx}
          spinning={spinning}
          onSpinEnd={handleSpinEnd}/>

        {/* Spin button */}
        {!alreadySpun ? (
          <button onClick={doSpin} disabled={spinning} style={{
            padding:"16px 48px",border:"none",borderRadius:50,
            cursor:spinning?"not-allowed":"pointer",
            fontFamily:"'Black Han Sans',sans-serif",fontSize:22,letterSpacing:3,
            background:spinning?"#1a1d2e":"linear-gradient(135deg,#FF2D55,#FF9500)",
            color:spinning?"#555":"#fff",
            boxShadow:spinning?"none":"0 6px 24px #FF2D5550",
            animation:spinning?"none":"glow 2s ease-in-out infinite",
            transition:"all .2s",
            width:"100%",maxWidth:280,
          }}>
            {spinning ? "SPINNING..." : "🎰 SPIN!"}
          </button>
        ) : (
          <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:8,width:"100%",maxWidth:280}}>
            <div style={{...S.card,background:"#34C75910",border:"1px solid #34C75940",textAlign:"center",width:"100%",padding:"12px 16px"}}>
              <div style={{fontSize:11,color:"#34C759",fontFamily:"'Black Han Sans',sans-serif",letterSpacing:1}}>✅ SPIN COMPLETE FOR TODAY</div>
              <div style={{fontSize:10,color:"#555",marginTop:4}}>Next free spin in {hLeft}h {mLeft}m</div>
            </div>
          </div>
        )}
      </div>

      {/* Banner ad below spin wheel */}
      {alreadySpun&&<BannerAd/>}

      {/* Rewarded ad option when already spun */}
      {alreadySpun&&<RewardedAdNotice onWatch={()=>{/* trigger rewarded video */}}/>}

      {/* Prize tier legend */}
      <div style={{...S.card,background:"#0a0c14",border:"1px solid #1e2237",display:"flex",flexDirection:"column",gap:7}}>
        <div style={{fontSize:9,color:"#555",letterSpacing:3}}>PRIZE TIERS</div>
        <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
          {Object.entries(TIER_META).map(([tier,meta])=>(
            <div key={tier} style={{display:"flex",alignItems:"center",gap:4,padding:"3px 10px",borderRadius:20,background:meta.bg,border:`1px solid ${meta.color}30`}}>
              <div style={{width:6,height:6,borderRadius:"50%",background:meta.color,flexShrink:0}}/>
              <span style={{fontSize:9,color:meta.color,fontFamily:"'Black Han Sans',sans-serif",letterSpacing:1}}>{meta.label}</span>
            </div>
          ))}
        </div>
        <div style={{fontSize:9,color:"#444",lineHeight:1.7}}>
          Streak day 3+ boosts Rare odds · Day 6 guarantees Epic+ · Day 7 unlocks the Legendary tier
        </div>
      </div>

      {/* Recent prizes */}
      {(dailyState.prizes||[]).length > 0 && (
        <div style={{display:"flex",flexDirection:"column",gap:6}}>
          <div style={{fontSize:9,color:"#555",letterSpacing:3}}>RECENT PRIZES</div>
          {[...(dailyState.prizes||[])].reverse().slice(0,5).map((p,i)=>{
            const meta=TIER_META[p.tier]||TIER_META.common;
            return(
              <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 12px",background:"#0d0e1a",border:`1px solid ${meta.color}20`,borderRadius:10}}>
                <span style={{fontSize:20,flexShrink:0}}>{p.e}</span>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,color:meta.color,letterSpacing:1}}>{p.n}</div>
                  <div style={{fontSize:9,color:"#555",marginTop:1}}>{p.day}</div>
                </div>
                <div style={{fontSize:8,padding:"2px 7px",borderRadius:8,background:meta.bg,border:`1px solid ${meta.color}30`,color:meta.color}}>{meta.label}</div>
              </div>
            );
          })}
        </div>
      )}

      {/* Prize toast */}
      {showToast && wonPrize && (
        <PrizeToast prize={wonPrize} onClose={handleClaim}/>
      )}
    </div>
  );
}


// ═══════════════════════════════════════════════════════════════════════════════
// PLAYER PROGRESSION SYSTEM — XP · Levels · Ranks · Unlockables
// ─────────────────────────────────────────────────────────────────────────────
// Every action earns XP. XP fills a visible bar. Hitting a level threshold
// unlocks a rank title, a weapon skin colour, and sometimes a free reward.
//
// LEVELS 1–50
// XP sources: kills · tags · flag captures · territory claims · zombie kills
//             daily spin · crawl participation · crew challenges
// ═══════════════════════════════════════════════════════════════════════════════

const XP_PER_LEVEL = [
  0,    // L1  (0 XP to reach)
  100,  // L2
  250,  // L3
  450,  // L4
  700,  // L5
  1000, // L6
  1400, // L7
  1900, // L8
  2500, // L9
  3200, // L10
  4000, // L11
  5000, // L12
  6200, // L13
  7600, // L14
  9200, // L15
  11000,// L16
  13000,// L17
  15500,// L18
  18500,// L19
  22000,// L20
  26000,// L21
  31000,// L22
  37000,// L23
  44000,// L24
  52000,// L25
  61000,// L26
  71000,// L27
  82000,// L28
  94000,// L29
  107000,//L30
  ...Array.from({length:20},(_,i)=>120000+(i+1)*15000), // L31-50
];

const RANK_TITLES = [
  {min:1,  max:4,  rank:"ROOKIE",          icon:"🔰", color:"#4a506e"},
  {min:5,  max:9,  rank:"BRAWLER",         icon:"⚔️",  color:"#34C759"},
  {min:10, max:14, rank:"CRAWLER",         icon:"🍺",  color:"#00C7BE"},
  {min:15, max:19, rank:"HUNTER",          icon:"🎯",  color:"#007AFF"},
  {min:20, max:24, rank:"WARLORD",         icon:"🔥",  color:"#FF9500"},
  {min:25, max:29, rank:"ELITE",           icon:"💀",  color:"#BF5AF2"},
  {min:30, max:34, rank:"CHAMPION",        icon:"🏆",  color:"#FFCC00"},
  {min:35, max:39, rank:"LEGEND",          icon:"⭐",  color:"#FF6B35"},
  {min:40, max:44, rank:"OVERLORD",        icon:"👑",  color:"#FF2D55"},
  {min:45, max:49, rank:"CRAWLFIRE MASTER",icon:"🔱",  color:"#FF2D55"},
  {min:50, max:50, rank:"THE IMMORTAL",    icon:"☠️",  color:"#FF2D55"},
];

const LEVEL_REWARDS = {
  5:  {e:"🎁",n:"Rare Spin",        d:"One guaranteed Rare+ spin"},
  10: {e:"🎯",n:"Precision skin",   d:"Blue weapon effects"},
  15: {e:"💣",n:"Extra mine slot",   d:"Carry 3 mines at once"},
  20: {e:"🏆",n:"Gold name badge",   d:"Gold callsign in HUD"},
  25: {e:"👻",n:"Extended cloak",    d:"Ghost Mode lasts 90s"},
  30: {e:"💎",n:"Epic Spin",         d:"One guaranteed Epic+ spin"},
  35: {e:"🔥",n:"Fire weapon skin",  d:"Red flame effects on shots"},
  40: {e:"⚡",n:"Power Surge",       d:"3× damage for first round"},
  45: {e:"🌟",n:"Legendary Spin",    d:"One guaranteed Legendary spin"},
  50: {e:"☠️",n:"Immortal Badge",    d:"Exclusive cosmetic — max rank"},
};

function getLevel(totalXp) {
  let level = 1;
  let accumulated = 0;
  for (let i = 1; i < XP_PER_LEVEL.length; i++) {
    accumulated += XP_PER_LEVEL[i];
    if (totalXp >= accumulated) level = i + 1;
    else break;
  }
  return Math.min(level, 50);
}

function getLevelProgress(totalXp) {
  let accumulated = 0;
  for (let i = 1; i < XP_PER_LEVEL.length; i++) {
    const prev = accumulated;
    accumulated += XP_PER_LEVEL[i];
    if (totalXp < accumulated) {
      return {
        level: i,
        xpInLevel: totalXp - prev,
        xpNeeded: XP_PER_LEVEL[i],
        pct: ((totalXp - prev) / XP_PER_LEVEL[i]) * 100,
      };
    }
  }
  return { level: 50, xpInLevel: 0, xpNeeded: 1, pct: 100 };
}

function getRank(level) {
  return RANK_TITLES.find(r => level >= r.min && level <= r.max) || RANK_TITLES[0];
}

// ── XP gain constants ──────────────────────────────────────────────────────
const XP_REWARDS = {
  kill:           50,
  tag:            30,
  flagCapture:    75,
  flagSteal:      100,
  territoryClaim: 20,
  zombieKill:     15,
  bossKill:       200,
  dailySpin:      25,
  crawlComplete:  150,
  crewChallenge:  300,
};

// ── XP bar component — shown in HUD and profile ───────────────────────────
function XPBar({ totalXp, compact=false }) {
  const { level, xpInLevel, xpNeeded, pct } = getLevelProgress(totalXp || 0);
  const rank  = getRank(level);
  const reward = LEVEL_REWARDS[level+1];

  if (compact) return (
    <div style={{display:"flex",alignItems:"center",gap:6}}>
      <div style={{
        fontFamily:"'Black Han Sans',sans-serif",fontSize:11,
        color:rank.color,letterSpacing:1,flexShrink:0,
      }}>{rank.icon} Lv.{level}</div>
      <div style={{flex:1,height:4,background:"#1a1d2e",borderRadius:2,overflow:"hidden"}}>
        <div style={{height:"100%",width:`${pct}%`,background:rank.color,borderRadius:2,transition:"width .6s"}}/>
      </div>
      <div style={{fontSize:9,color:"#555",flexShrink:0}}>{xpInLevel}/{xpNeeded}</div>
    </div>
  );

  return (
    <div style={{display:"flex",flexDirection:"column",gap:6}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,color:rank.color,textShadow:`0 0 10px ${rank.color}60`}}>
            {rank.icon} {rank.rank}
          </div>
          <div style={{
            fontFamily:"'Black Han Sans',sans-serif",fontSize:13,
            background:`${rank.color}20`,border:`1px solid ${rank.color}50`,
            borderRadius:20,padding:"2px 10px",color:rank.color,
          }}>LV.{level}</div>
        </div>
        <div style={{fontSize:10,color:"#555"}}>{xpInLevel.toLocaleString()} / {xpNeeded.toLocaleString()} XP</div>
      </div>
      <div style={{height:8,background:"#1a1d2e",borderRadius:4,overflow:"hidden",position:"relative"}}>
        <div style={{
          height:"100%",width:`${pct}%`,
          background:`linear-gradient(90deg,${rank.color},${rank.color}cc)`,
          borderRadius:4,transition:"width .8s cubic-bezier(.17,.67,.29,1.35)",
          boxShadow:`0 0 8px ${rank.color}60`,
        }}/>
      </div>
      {reward && (
        <div style={{fontSize:9,color:"#555",display:"flex",alignItems:"center",gap:5}}>
          <span>Next reward at Lv.{level+1}:</span>
          <span style={{color:rank.color}}>{reward.e} {reward.n}</span>
        </div>
      )}
    </div>
  );
}

// ── Level-up toast ────────────────────────────────────────────────────────────
function LevelUpToast({ level, rank, reward, onClose }) {
  return (
    <div style={{
      position:"fixed",inset:0,background:"rgba(0,0,0,.88)",
      display:"flex",alignItems:"center",justifyContent:"center",
      zIndex:600,animation:"fadeIn .3s ease",
    }}>
      <div style={{
        background:"#0d0e1a",border:`3px solid ${rank.color}`,
        borderRadius:20,padding:"28px 24px",textAlign:"center",
        maxWidth:300,width:"90%",
        boxShadow:`0 0 60px ${rank.color}60`,
        animation:"popIn .5s cubic-bezier(.17,.67,.29,1.35)",
        display:"flex",flexDirection:"column",alignItems:"center",gap:12,
      }}>
        <div style={{fontSize:9,color:rank.color,letterSpacing:4,fontFamily:"'Black Han Sans',sans-serif"}}>LEVEL UP!</div>
        <div style={{fontSize:72,filter:`drop-shadow(0 0 20px ${rank.color})`,animation:"breathe 1.2s ease-in-out infinite"}}>{rank.icon}</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:28,letterSpacing:2,color:rank.color}}>{rank.rank}</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:44,color:"#f0f0f8"}}>LEVEL {level}</div>
        {reward && (
          <div style={{background:`${rank.color}15`,border:`1px solid ${rank.color}40`,borderRadius:12,padding:"10px 16px",width:"100%"}}>
            <div style={{fontSize:9,color:rank.color,letterSpacing:2,marginBottom:5}}>REWARD UNLOCKED</div>
            <div style={{fontSize:24,marginBottom:4}}>{reward.e}</div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:"#f0f0f8"}}>{reward.n}</div>
            <div style={{fontSize:10,color:"#555",marginTop:2}}>{reward.d}</div>
          </div>
        )}
        <button onClick={onClose} style={{
          padding:"12px 32px",border:"none",borderRadius:14,cursor:"pointer",
          background:`linear-gradient(135deg,${rank.color},${rank.color}cc)`,
          color:rank.color==="#FFCC00"||rank.color==="#34C759"?"#000":"#fff",
          fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2,
          boxShadow:`0 4px 16px ${rank.color}50`,width:"100%",
        }}>AWESOME!</button>
      </div>
    </div>
  );
}

// ── useXP — persistent XP tracking hook ──────────────────────────────────────
function useXP(playerId) {
  const [totalXp,  setTotalXp]  = useState(0);
  const [levelUp,  setLevelUp]  = useState(null); // {level, rank, reward}
  const key = `cf:xp:${playerId||"demo"}`;

  useEffect(() => {
    if (!playerId) return;
    window.storage.get(key, false).then(r => {
      if (r) setTotalXp(parseInt(r.value)||0);
    }).catch(()=>{});
  }, [playerId, key]);

  const addXP = useCallback(async (amount, reason) => {
    const oldLevel = getLevel(totalXp);
    const newTotal = totalXp + amount;
    setTotalXp(newTotal);
    try { await window.storage.set(key, String(newTotal), false); } catch {}
    const newLevel = getLevel(newTotal);
    if (newLevel > oldLevel) {
      const rank    = getRank(newLevel);
      const reward  = LEVEL_REWARDS[newLevel] || null;
      setLevelUp({ level:newLevel, rank, reward });
    }
  }, [totalXp, key]);

  const dismissLevelUp = useCallback(() => setLevelUp(null), []);

  return { totalXp, level:getLevel(totalXp), rank:getRank(getLevel(totalXp)), addXP, levelUp, dismissLevelUp };
}


// ═══════════════════════════════════════════════════════════════════════════════
// CREW SYSTEM — persistent squads of 2–6 players
// ═══════════════════════════════════════════════════════════════════════════════

const CREW_CHALLENGES = [
  {id:"cc1",e:"💀",n:"Kill Quota",    desc:"50 kills combined this week",      target:50, xp:300,coins:200},
  {id:"cc2",e:"⚑", n:"Flag Rush",    desc:"Capture 20 flags across any crawls",target:20, xp:400,coins:300},
  {id:"cc3",e:"🗺️",n:"Territory Grab",desc:"Claim 10 new bars between you",   target:10, xp:250,coins:150},
  {id:"cc4",e:"🧟",n:"Zombie Hunters",desc:"Defeat 100 zombies in Dead City",  target:100,xp:350,coins:250},
  {id:"cc5",e:"💰",n:"High Rollers", desc:"Enter 3 Advanced crawls this week", target:3,  xp:500,coins:400},
  {id:"cc6",e:"🔥",n:"On Fire",      desc:"Every member logs in 5 days in a row",target:5,xp:600,coins:500},
];

function useCrewState(playerId){
  const[crew,setCrew]=useState(null);
  const key=`cf:crew:${playerId||"demo"}`;
  useEffect(()=>{if(!playerId)return;window.storage.get(key,false).then(r=>{if(r)try{setCrew(JSON.parse(r.value));}catch{}}).catch(()=>{});},[playerId,key]);
  const saveCrew=useCallback(async c=>{setCrew(c);try{await window.storage.set(key,JSON.stringify(c),false);}catch{}},[key]);
  const createCrew=useCallback(async(name,tag,playerName,playerAvatar)=>{
    const c={id:uid(),name:name.trim().toUpperCase(),tag:tag.trim().toUpperCase().slice(0,4),createdBy:playerId,
      members:[{id:playerId,name:playerName,avatar:playerAvatar||"🍺",xp:0,level:1,kills:0,joinedAt:Date.now()}],
      xp:0,level:1,challenges:CREW_CHALLENGES.slice(0,3).map(ch=>({...ch,progress:0,done:false})),
      weekStart:Date.now(),wins:0,crawls:0};
    await saveCrew(c);return c;
  },[playerId,saveCrew]);
  const leaveCrew=useCallback(async()=>{setCrew(null);try{await window.storage.set(key,"null",false);}catch{}},[key]);
  return{crew,createCrew,saveCrew,leaveCrew};
}

function CrewScreen({playerId,playerName,playerAvatar,totalXp,onBack}){
  const{crew,createCrew,leaveCrew}=useCrewState(playerId);
  const[view,setView]=useState("main");
  const[name,setName]=useState("");
  const[tag,setTag]=useState("");
  const[err,setErr]=useState("");
  const[creating,setCreating]=useState(false);

  const handleCreate=async()=>{
    if(!name.trim()||name.trim().length<2){setErr("Crew name too short");return;}
    if(!tag.trim()||tag.trim().length<2){setErr("Tag must be 2-4 chars");return;}
    setCreating(true);await createCrew(name,tag,playerName,playerAvatar||"🍺");setCreating(false);setView("main");
  };

  if(view==="create")return(<div style={S.screen}>
    <button style={S.btnGhost} onClick={()=>setView("main")}>← BACK</button>
    <div style={{textAlign:"center"}}><div style={{fontSize:48,animation:"breathe 2s ease-in-out infinite"}}>⚔️</div>
      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,letterSpacing:2,color:"#f0f0f8",marginTop:6}}>CREATE A CREW</div>
      <div style={{fontSize:11,color:"#555",marginTop:4,lineHeight:1.7}}>Form a squad · compete together · earn crew XP</div></div>
    <div style={{...S.card,background:"#0a0c14",border:"1px solid #1e2237",display:"flex",flexDirection:"column",gap:10}}>
      <div style={{display:"flex",flexDirection:"column",gap:4}}><label style={{fontSize:9,color:"#555",letterSpacing:2}}>CREW NAME</label>
        <input style={S.input} placeholder="THE NIGHT CRAWLERS" maxLength={24} value={name} onChange={e=>setName(e.target.value.toUpperCase())}/></div>
      <div style={{display:"flex",flexDirection:"column",gap:4}}><label style={{fontSize:9,color:"#555",letterSpacing:2}}>CREW TAG (2–4 chars)</label>
        <input style={S.input} placeholder="NCR" maxLength={4} value={tag} onChange={e=>setTag(e.target.value.toUpperCase())}/>
        <div style={{fontSize:9,color:"#444"}}>Shown as [NCR] next to your name in games</div></div>
      {err&&<div style={{fontSize:10,color:"#FF2D55"}}>{err}</div>}
    </div>
    <button onClick={handleCreate} disabled={creating} style={{...S.btnPrimary,opacity:name.trim()&&tag.trim()?1:.4}}>
      {creating?"CREATING…":"⚔️ FOUND THIS CREW →"}</button>
  </div>);

  if(!crew)return(<div style={S.screen}>
    <button style={S.btnGhost} onClick={onBack}>← BACK</button>
    <div style={{textAlign:"center"}}><div style={{fontSize:64,marginBottom:8,filter:"drop-shadow(0 0 16px #FF2D55)"}}>⚔️</div>
      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,letterSpacing:2,color:"#f0f0f8"}}>CREWS</div>
      <div style={{fontSize:11,color:"#555",marginTop:4,lineHeight:1.8,padding:"0 20px"}}>
        Team up with friends across all game modes. Share XP, territory, and weekly challenges.</div></div>
    <div style={{display:"flex",flexDirection:"column",gap:8}}>
      {[{e:"📈",t:"Shared XP pool",d:"Everyone levels faster together"},
        {e:"⚑",t:"Team territory",d:"Crew bars shown with your tag on the map"},
        {e:"🎯",t:"Weekly challenges",d:"3 rotating challenges — complete for big rewards"},
        {e:"👥",t:"Up to 6 members",d:"Invite friends via crew tag"},
      ].map((f,i)=>(
        <div key={i} style={{...S.card,display:"flex",alignItems:"center",gap:12}}>
          <span style={{fontSize:26,flexShrink:0}}>{f.e}</span>
          <div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:"#f0f0f8"}}>{f.t}</div>
            <div style={{fontSize:10,color:"#555",marginTop:2}}>{f.d}</div></div>
        </div>
      ))}
    </div>
    <button onClick={()=>setView("create")} style={S.btnPrimary}>⚔️ CREATE A CREW →</button>
    <div style={{textAlign:"center",fontSize:11,color:"#555"}}>Or ask a friend for their crew tag to join</div>
  </div>);

  const challengesDone=(crew.challenges||[]).filter(c=>c.done).length;
  return(<div style={S.screen}>
    <button style={S.btnGhost} onClick={onBack}>← BACK</button>
    <div style={{...S.card,background:"linear-gradient(135deg,#FF2D5510,#FF950010)",border:"2px solid #FF2D5530"}}>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:10}}>
        <div style={{width:48,height:48,borderRadius:12,background:"#FF2D55",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:"#fff",letterSpacing:1,flexShrink:0}}>{crew.tag}</div>
        <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,color:"#f0f0f8"}}>{crew.name}</div>
          <div style={{fontSize:10,color:"#555",marginTop:2}}>{crew.members?.length||1} member{(crew.members?.length||1)!==1?"s":""} · {crew.wins||0} wins</div></div>
        <div style={{textAlign:"center"}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:"#FF2D55"}}>{crew.xp||0}</div>
          <div style={{fontSize:7,color:"#555",letterSpacing:1}}>CREW XP</div></div>
      </div>
      <div style={{background:"#07080f",borderRadius:8,padding:"6px 10px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <span style={{fontSize:9,color:"#555",letterSpacing:1}}>CREW TAG</span>
        <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:4,color:"#FF2D55"}}>[{crew.tag}]</span>
        <button onClick={()=>navigator.clipboard?.writeText(crew.tag).catch(()=>{})} style={{background:"none",border:"1px solid #2a2a3a",borderRadius:6,color:"#555",fontSize:9,padding:"3px 8px",cursor:"pointer"}}>COPY</button>
      </div>
    </div>
    <div style={{display:"flex",gap:5}}>
      {[["main","👥 SQUAD"],["challenges","🎯 MISSIONS"],["members","📊 STATS"]].map(([id,label])=>(
        <button key={id} onClick={()=>setView(id)} style={{flex:1,padding:"8px 4px",border:`2px solid ${view===id?"#FF2D55":"#1a1d2e"}`,borderRadius:10,background:view===id?"#FF2D5515":"#0d0e1a",color:view===id?"#FF2D55":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:9,letterSpacing:1,cursor:"pointer"}}>{label}</button>
      ))}
    </div>
    {view==="main"&&(<div style={{display:"flex",flexDirection:"column",gap:8}}>
      {(crew.members||[]).map((m,i)=>{const mr=getRank(m.level||1);return(
        <div key={m.id||i} style={{...S.card,display:"flex",alignItems:"center",gap:10}}>
          <AvatarDisplay avatar={m.avatar} size={28} borderColor={m.id===playerId?mr.color:null}/>
          <div style={{flex:1}}><div style={{display:"flex",alignItems:"center",gap:6}}>
            <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:"#f0f0f8"}}>{m.name}</span>
            {m.id===playerId&&<span style={{fontSize:8,background:"#FF2D5520",border:"1px solid #FF2D5540",borderRadius:10,padding:"1px 6px",color:"#FF2D55"}}>YOU</span>}
          </div>
          <span style={{fontSize:9,color:mr.color,marginTop:2}}>{mr.icon} Lv.{m.level||1} {mr.rank}</span></div>
          <div style={{textAlign:"right"}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#FFCC00"}}>{m.xp||0}</div>
            <div style={{fontSize:7,color:"#555",letterSpacing:1}}>XP</div></div>
        </div>
      );})}
      <button onClick={leaveCrew} style={{...S.btnGhost,fontSize:11,color:"#555",borderColor:"#2a2a3a",textAlign:"center",padding:10}}>Leave Crew</button>
    </div>)}
    {view==="challenges"&&(<div style={{display:"flex",flexDirection:"column",gap:8}}>
      <div style={{fontSize:9,color:"#555",letterSpacing:3}}>WEEKLY CREW CHALLENGES</div>
      {(crew.challenges||CREW_CHALLENGES.slice(0,3)).map(ch=>{
        const pct=Math.min(100,((ch.progress||0)/ch.target)*100);
        return(<div key={ch.id} style={{...S.card,border:`1px solid ${ch.done?"#34C75940":"#1e2237"}`,background:ch.done?"#34C75908":"#0d0e1a"}}>
          <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
            <span style={{fontSize:24,flexShrink:0}}>{ch.e}</span>
            <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,color:ch.done?"#34C759":"#f0f0f8"}}>{ch.n}</div>
              <div style={{fontSize:10,color:"#555",marginTop:2}}>{ch.desc}</div></div>
            {ch.done&&<span style={{fontSize:18}}>✅</span>}
          </div>
          <div style={{height:4,background:"#1a1d2e",borderRadius:2,overflow:"hidden",marginBottom:4}}>
            <div style={{height:"100%",width:`${pct}%`,background:ch.done?"#34C759":"#FF9500",borderRadius:2}}/></div>
          <div style={{display:"flex",justifyContent:"space-between",fontSize:9}}>
            <span style={{color:"#555"}}>{ch.progress||0}/{ch.target}</span>
            <span style={{color:"#FFCC00"}}>🪙{ch.coins} · ⭐{ch.xp}XP</span></div>
        </div>);
      })}
    </div>)}
    {view==="members"&&(<div style={{display:"flex",flexDirection:"column",gap:8}}>
      <div style={{fontSize:9,color:"#555",letterSpacing:3}}>CREW LEADERBOARD</div>
      {[...(crew.members||[])].sort((a,b)=>(b.xp||0)-(a.xp||0)).map((m,i)=>(
        <div key={m.id||i} style={{...S.card,display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:18,width:24,textAlign:"center"}}>{["🥇","🥈","🥉"][i]||`#${i+1}`}</span>
          <span style={{fontSize:20}}>{m.avatar}</span>
          <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,color:m.id===playerId?"#FF2D55":"#f0f0f8"}}>{m.name}</div>
            <div style={{fontSize:9,color:"#555"}}>💀{m.kills||0} kills</div></div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#FFCC00"}}>{m.xp||0} XP</div>
        </div>
      ))}
    </div>)}
  </div>);
}


// ═══════════════════════════════════════════════════════════════════════════════
// SPECTATOR / OBSERVER MODE — free entry, watch before you pay
// ─────────────────────────────────────────────────────────────────────────────
// New players can join as a spectator for free — they see the live map,
// kill feed, territory map and scoreboard but cannot shoot or enter the pot.
// A conversion nudge appears after 3 minutes inviting them to join properly.
// ═══════════════════════════════════════════════════════════════════════════════

function SpectatorView({ game, myId, onJoinProperly, onBack }) {
  const [elapsed,   setElapsed]   = useState(0);
  const [showNudge, setShowNudge] = useState(false);
  const players  = Object.values(game?.players||{});
  const alive    = players.filter(p=>p.alive);
  const events   = (game?.events||[]).slice(-8).reverse();
  const topPlayer= [...players].sort((a,b)=>b.kills-a.kills)[0];

  useEffect(()=>{
    const id=setInterval(()=>{
      setElapsed(e=>{
        if(e>=180) setShowNudge(true);
        return e+1;
      });
    },1000);
    return()=>clearInterval(id);
  },[]);

  const fmt=s=>`${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;

  return(
    <div style={S.screen}>
      {/* Conversion nudge after 3 mins */}
      {showNudge&&(
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.88)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:500,padding:24}}>
          <div style={{background:"#0d0e1a",border:"3px solid #FF2D55",borderRadius:20,padding:"28px 24px",textAlign:"center",maxWidth:300,display:"flex",flexDirection:"column",gap:12,animation:"popIn .4s ease",boxShadow:"0 0 40px #FF2D5520"}}>
            <div style={{fontSize:52}}>🔥</div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,letterSpacing:2,color:"#FF2D55"}}>READY TO PLAY?</div>
            <div style={{fontSize:11,color:"#888",lineHeight:1.8}}>
              You've been watching for 3 minutes. Jump in and start earning kills, coins, and XP!
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              <button onClick={onJoinProperly} style={{...S.btnPrimary,background:"linear-gradient(135deg,#FF2D55,#FF6B35)",fontSize:16}}>🔫 JOIN THE GAME →</button>
              <button onClick={()=>setShowNudge(false)} style={{...S.btnGhost,fontSize:11}}>Keep watching</button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div style={{...S.card,background:"#0a0c14",border:"1px solid #00C7BE30",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:"#00C7BE",letterSpacing:2}}>👁️ SPECTATOR</div>
          <div style={{fontSize:9,color:"#555",marginTop:1}}>Watching · {fmt(elapsed)} · free</div>
        </div>
        <div style={{display:"flex",gap:8"}}>
          <button onClick={onJoinProperly} style={{padding:"7px 14px",border:"none",borderRadius:10,background:"linear-gradient(135deg,#FF2D55,#FF9500)",color:"#fff",fontFamily:"'Black Han Sans',sans-serif",fontSize:11,letterSpacing:1,cursor:"pointer"}}>🔫 JOIN!</button>
          <button onClick={onBack} style={{...S.btnGhost,fontSize:10,padding:"5px 10px"}}>EXIT</button>
        </div>
      </div>

      {/* Live game stats */}
      <div style={{display:"flex",gap:8}}>
        {[{v:alive.length,l:"ALIVE",c:"#34C759"},{v:players.length-alive.length,l:"DEAD",c:"#FF2D55"},{v:alive.length+" left",l:"ACTIVE",c:"#34C759"}].map((s,i)=>(
          <div key={i} style={{flex:1,...S.card,textAlign:"center",padding:"8px 4px"}}>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:s.c,lineHeight:1}}>{s.v}</div>
            <div style={{fontSize:7,color:"#555",letterSpacing:1,marginTop:2}}>{s.l}</div>
          </div>
        ))}
      </div>

      {/* Leader highlight */}
      {topPlayer&&(
        <div style={{...S.card,background:"#FFCC0010",border:"1px solid #FFCC0030",display:"flex",alignItems:"center",gap:12}}>
          <span style={{fontSize:26}}>👑</span>
          <div style={{flex:1}}>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:"#FFCC00"}}>LEADING</div>
            <div style={{fontSize:11,color:"#888",marginTop:1}}>{topPlayer.avatar} {topPlayer.name} · {topPlayer.kills} kills · {topPlayer.hp}hp</div>
          </div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,color:"#FF2D55"}}>{topPlayer.kills}</div>
        </div>
      )}

      {/* Live player list */}
      <div style={{fontSize:9,color:"#555",letterSpacing:3}}>ALL PLAYERS</div>
      {[...players].sort((a,b)=>b.kills-a.kills).map((p,i)=>{
        const hpPct=(p.hp/120)*100;
        return(
          <div key={p.id} style={{display:"flex",alignItems:"center",gap:8,padding:"7px 10px",background:"#0d0e1a",border:"1px solid #1a1d2e",borderRadius:10,opacity:p.alive?1:.45}}>
            <span style={{fontSize:14,width:20,textAlign:"center"}}>{["🥇","🥈","🥉"][i]||`${i+1}.`}</span>
            <AvatarDisplay avatar={p.avatar} size={24}/>
            <div style={{flex:1}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:p.alive?"#f0f0f8":"#555"}}>{p.name}{!p.alive&&" 💀"}</div>
              <div style={{height:3,background:"#1a1d2e",borderRadius:1.5,overflow:"hidden",marginTop:2}}>
                <div style={{height:"100%",width:`${hpPct}%`,background:hpPct>60?"#34C759":hpPct>25?"#FF9500":"#FF2D55",borderRadius:1.5}}/>
              </div>
            </div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:"#FF2D55"}}>{p.kills}</div>
            <div style={{fontSize:10,color:"#FFCC00"}}>🪙{p.coins}</div>
          </div>
        );
      })}

      {/* Live event feed */}
      <div style={{fontSize:9,color:"#555",letterSpacing:3}}>LIVE FEED</div>
      {events.length===0&&<div style={{fontSize:11,color:"#555",textAlign:"center",padding:8}}>No events yet…</div>}
      {events.map((ev,i)=>{
        const msg=ev.type==="kill"?`💀 ${game?.players?.[ev.from]?.name||""} eliminated ${game?.players?.[ev.to]?.name||""}`:ev.msg||"";
        return msg?<div key={ev.id||i} style={{fontSize:10,padding:"4px 10px",borderRadius:6,borderLeft:`3px solid ${ev.type==="kill"?"#FF2D55":"#FF9500"}`,background:"#07080f",color:"#888",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{msg}</div>:null;
      })}

      {/* Join CTA at bottom */}
      <button onClick={onJoinProperly} style={{...S.btnPrimary,background:"linear-gradient(135deg,#FF2D55,#FF9500)",fontSize:16}}>
        🔫 STOP WATCHING · JOIN THE GAME →
      </button>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// FAST ONBOARDING — join-to-playing in under 60 seconds
// ═══════════════════════════════════════════════════════════════════════════════

function FastOnboarding({ onDone, onSpectate, gameCode }) {
  const [name,    setName]    = useState("");
  const [avatar,  setAvatar]  = useState("🍺");
  const [step,    setStep]    = useState(0); // 0=name+avatar, 1=mode
  const QUICK_AVATARS = ["🍺","🎯","💣","⚡","🔥","🐺","👻","🦊","🐯","⚔️","🌙","☠️"];

  if(step===0)return(
    <div style={{...S.screen,gap:14}}>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:52,marginBottom:8,animation:"breathe 2s ease-in-out infinite",filter:"drop-shadow(0 0 16px #FF2D55)"}}>🔥</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:26,letterSpacing:3,color:"#f0f0f8"}}>CRAWLFIRE</div>
        <div style={{fontSize:11,color:"#555",marginTop:4}}>Choose your callsign to get started</div>
      </div>

      {/* Name input */}
      <input style={{...S.input,fontSize:18,textAlign:"center",letterSpacing:2}} placeholder="YOUR CALLSIGN"
        maxLength={12} value={name} onChange={e=>setName(e.target.value.toUpperCase())} autoFocus/>

      {/* Quick avatar row */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(6,1fr)",gap:8}}>
        {QUICK_AVATARS.map(a=>(
          <button key={a} onClick={()=>setAvatar(a)} style={{aspectRatio:1,fontSize:24,borderRadius:10,border:`2px solid ${avatar===a?"#FF2D55":"#2a2a3a"}`,background:avatar===a?"#FF2D5515":"#0d0e1a",cursor:"pointer",transition:"all .1s"}}>
            {a}
          </button>
        ))}
      </div>

      <button onClick={()=>name.trim()&&setStep(1)} disabled={!name.trim()} style={{...S.btnPrimary,opacity:name.trim()?1:.4,fontSize:18}}>
        NEXT →
      </button>

      <div style={{fontSize:9,color:"#333",textAlign:"center"}}>No account needed · just pick a name and play</div>
    </div>
  );

  return(
    <div style={{...S.screen,gap:12}}>
      <div style={{textAlign:"center"}}>
        <AvatarDisplay avatar={avatar} size={56} borderColor="#FF2D55"/>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,color:"#f0f0f8",marginTop:8,letterSpacing:2}}>{name}</div>
        <div style={{fontSize:10,color:"#555",marginTop:2}}>Ready to go! How do you want to play?</div>
      </div>

      {/* Mode choices */}
      <button onClick={()=>onDone(name,avatar,"pay")} style={{...S.card,border:"2px solid #FF2D5540",cursor:"pointer",display:"flex",gap:14,alignItems:"center",background:"#FF2D5508",width:"100%",textAlign:"left"}}>
        <span style={{fontSize:36}}>🔫</span>
        <div style={{flex:1}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#FF2D55",letterSpacing:1}}>JOIN THE FIGHT</div>
          <div style={{fontSize:11,color:"#555",marginTop:2}}>Jump in · compete for XP · earn rare loot</div>
        </div>
        <span style={{color:"#FF2D55",fontSize:18}}>›</span>
      </button>

      <button onClick={()=>onSpectate&&onSpectate(name,avatar)} style={{...S.card,border:"2px solid #00C7BE40",cursor:"pointer",display:"flex",gap:14,alignItems:"center",background:"#00C7BE08",width:"100%",textAlign:"left"}}>
        <span style={{fontSize:36}}>👁️</span>
        <div style={{flex:1}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#00C7BE",letterSpacing:1}}>WATCH FOR FREE</div>
          <div style={{fontSize:11,color:"#555",marginTop:2}}>See live kills · no payment · join any time</div>
        </div>
        <span style={{color:"#00C7BE",fontSize:18}}>›</span>
      </button>

      <button onClick={()=>onDone(name,avatar,"zombie")} style={{...S.card,border:"2px solid #34C75940",cursor:"pointer",display:"flex",gap:14,alignItems:"center",background:"#34C75908",width:"100%",textAlign:"left"}}>
        <span style={{fontSize:36}}>☣️</span>
        <div style={{flex:1}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#34C759",letterSpacing:1}}>FIGHT ZOMBIES</div>
          <div style={{fontSize:11,color:"#555",marginTop:2}}>Solo · free · earn coins for the real game</div>
        </div>
        <span style={{color:"#34C759",fontSize:18}}>›</span>
      </button>

      <button onClick={()=>setStep(0)} style={{...S.btnGhost,fontSize:11}}>← CHANGE NAME</button>
    </div>
  );
}


function SplashScreen({onRole,onCTF}){
  const [mode,setMode]=useState(null); // null | "laser" | "ctf"
  const BG = {position:"absolute",inset:0,background:"radial-gradient(ellipse at 50% 30%,#FF2D5518 0%,transparent 60%),radial-gradient(ellipse at 80% 80%,#FF950012 0%,transparent 50%),repeating-linear-gradient(0deg,transparent,transparent 59px,#ffffff04 60px),repeating-linear-gradient(90deg,transparent,transparent 59px,#ffffff03 60px)",pointerEvents:"none"};
  return(
    <div style={{...S.screen,alignItems:"center",justifyContent:"center",textAlign:"center",gap:24}}>
      <div style={BG}/>
      <div style={{position:"relative",zIndex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:18,width:"100%",maxWidth:360}}>
        <div style={{fontSize:68,filter:"drop-shadow(0 0 24px #FF9500)",animation:"breathe 3s ease-in-out infinite"}}>🍺</div>
        <div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:52,letterSpacing:5,color:"#f0f0f8",textShadow:"0 0 40px #FF2D55,0 0 80px #FF2D5540",lineHeight:1}}>CRAWL<span style={{color:"#FF2D55"}}>FIRE</span></div>
          <div style={{fontSize:10,letterSpacing:4,color:"#555",marginTop:6}}>QR PUB CRAWL GAMES · v2.0</div>
        </div>

        {/* ── GAME MODE PICKER ── */}
        {!mode&&(
          <>
            <div style={{fontSize:11,letterSpacing:3,color:"#555"}}>CHOOSE YOUR GAME MODE</div>
            <div style={{width:"100%",display:"flex",flexDirection:"column",gap:10}}>
              {/* Laser Tag */}
              <button onClick={()=>setMode("laser")} style={{display:"flex",alignItems:"center",gap:16,padding:"18px 16px",border:"2px solid #FF2D5540",borderRadius:16,background:"#FF2D5508",cursor:"pointer",textAlign:"left",transition:"all .15s"}}
                onMouseOver={e=>{e.currentTarget.style.borderColor="#FF2D55";e.currentTarget.style.background="#FF2D5515";}} onMouseOut={e=>{e.currentTarget.style.borderColor="#FF2D5540";e.currentTarget.style.background="#FF2D5508";}}>
                <div style={{fontSize:40,filter:"drop-shadow(0 0 10px #FF2D55)"}}>🎯</div>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,letterSpacing:2,color:"#f0f0f8"}}>QR LASER TAG</div>
                  <div style={{fontSize:11,color:"#888",marginTop:3}}>Wear your QR · shoot enemies · win XP and loot</div>
                  <div style={{display:"flex",gap:5,marginTop:6,flexWrap:"wrap"}}>
                    {["🎯 Solo play","🏪 Coin shop","🎸 Music hunt","🎯 Ranked mode"].map(t=><span key={t} style={{fontSize:9,background:"#FF2D5520",border:"1px solid #FF2D5530",borderRadius:20,padding:"2px 7px",color:"#FF2D55"}}>{t}</span>)}
                  </div>
                </div>
                <div style={{fontSize:22,color:"#FF2D55"}}>›</div>
              </button>
              {/* Capture The Flag */}
              <button onClick={()=>setMode("ctf")} style={{display:"flex",alignItems:"center",gap:16,padding:"18px 16px",border:"2px solid #007AFF40",borderRadius:16,background:"#007AFF08",cursor:"pointer",textAlign:"left",transition:"all .15s"}}
                onMouseOver={e=>{e.currentTarget.style.borderColor="#007AFF";e.currentTarget.style.background="#007AFF15";}} onMouseOut={e=>{e.currentTarget.style.borderColor="#007AFF40";e.currentTarget.style.background="#007AFF08";}}>
                <div style={{fontSize:40,filter:"drop-shadow(0 0 10px #007AFF)"}}>⚑</div>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,letterSpacing:2,color:"#f0f0f8"}}>CAPTURE THE FLAG</div>
                  <div style={{fontSize:11,color:"#888",marginTop:3}}>Teams · bar flags · steal &amp; hold · live feed</div>
                  <div style={{display:"flex",gap:5,marginTop:6,flexWrap:"wrap"}}>
                    {["🔴🔵 Teams","🚩 Bar flags","🔥 Steal bonus","📡 Live feed"].map(t=><span key={t} style={{fontSize:9,background:"#007AFF20",border:"1px solid #007AFF30",borderRadius:20,padding:"2px 7px",color:"#007AFF"}}>{t}</span>)}
                  </div>
                </div>
                <div style={{fontSize:22,color:"#007AFF"}}>›</div>
              </button>

              {/* 🎰 Daily Spin */}
              <button onClick={()=>onRole("daily_spin")} style={{display:"flex",alignItems:"center",gap:16,padding:"18px 16px",border:"2px solid #FFCC0040",borderRadius:16,background:"#FFCC0008",cursor:"pointer",textAlign:"left",transition:"all .15s",position:"relative",overflow:"hidden"}}
                onMouseOver={e=>{e.currentTarget.style.borderColor="#FFCC00";e.currentTarget.style.background="#FFCC0015";}} onMouseOut={e=>{e.currentTarget.style.borderColor="#FFCC0040";e.currentTarget.style.background="#FFCC0008";}}>
                {/* Notification dot — shows when spin is available */}
                <div style={{position:"absolute",top:10,right:12,width:10,height:10,borderRadius:"50%",background:"#FF2D55",boxShadow:"0 0 8px #FF2D55",animation:"pulse 1.5s ease-in-out infinite"}}/>
                <div style={{fontSize:40,animation:"breathe 2s ease-in-out infinite",filter:"drop-shadow(0 0 10px #FFCC00)"}}>🎰</div>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,letterSpacing:2,color:"#f0f0f8"}}>DAILY SPIN</div>
                  <div style={{fontSize:11,color:"#888",marginTop:3}}>Free spin every day · prizes carry into any crawl</div>
                  <div style={{display:"flex",gap:5,marginTop:6,flexWrap:"wrap"}}>
                    {["🎁 Free daily","🔥 Streak bonus","👑 Legendary tier","💰 Coin rewards"].map(t=><span key={t} style={{fontSize:9,background:"#FFCC0020",border:"1px solid #FFCC0030",borderRadius:20,padding:"2px 7px",color:"#FFCC00"}}>{t}</span>)}
                  </div>
                </div>
                <div style={{fontSize:22,color:"#FFCC00"}}>›</div>
              </button>

              {/* ☣️ Dead City — Zombie Hunt */}
              <button onClick={()=>onRole("zombie")} style={{display:"flex",alignItems:"center",gap:16,padding:"18px 16px",border:"2px solid #34C75940",borderRadius:16,background:"#34C75908",cursor:"pointer",textAlign:"left",transition:"all .15s",position:"relative",overflow:"hidden"}}
                onMouseOver={e=>{e.currentTarget.style.borderColor="#34C759";e.currentTarget.style.background="#34C75915";}} onMouseOut={e=>{e.currentTarget.style.borderColor="#34C75940";e.currentTarget.style.background="#34C75908";}}>
                <div style={{position:"absolute",top:0,right:0,background:"#34C759",color:"#000",fontSize:8,fontFamily:"'Black Han Sans',sans-serif",letterSpacing:1,padding:"3px 10px",borderBottomLeftRadius:8}}>SOLO · ANY TIME</div>
                <div style={{fontSize:40,filter:"drop-shadow(0 0 10px #34C759)",animation:"breathe 2s ease-in-out infinite"}}>☣️</div>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,letterSpacing:2,color:"#f0f0f8"}}>DEAD CITY</div>
                  <div style={{fontSize:11,color:"#888",marginTop:3}}>Fight zombies between crawls · earn coins · upgrade gear</div>
                  <div style={{display:"flex",gap:5,marginTop:6,flexWrap:"wrap"}}>
                    {["🧟 7 zombie types","🌊 20 waves","💰 Earn coins","⬆️ Carry upgrades"].map(t=><span key={t} style={{fontSize:9,background:"#34C75920",border:"1px solid #34C75930",borderRadius:20,padding:"2px 7px",color:"#34C759"}}>{t}</span>)}
                  </div>
                </div>
                <div style={{fontSize:22,color:"#34C759"}}>›</div>
              </button>
            </div>
            <div style={{width:"100%",height:"1px",background:"#1a1d2e"}}/>
            {/* Staff roles */}
            <div style={{...S.card,width:"100%",display:"flex",flexDirection:"column",gap:6}}>
              <div style={{fontSize:10,letterSpacing:3,color:"#555",marginBottom:2}}>STAFF & ADMIN</div>
              {[
                {role:"bartender", e:"🍺",label:"BARTENDER",      sub:"Generate loot codes · D&D classes"},
                {role:"musician",  e:"🎸",label:"MUSICIAN",        sub:"Tip QR & earnings"},
                {role:"bar_owner", e:"🏪",label:"BAR PARTNER",     sub:"Revenue dashboard"},
                {role:"operator",  e:"⚡",label:"OPERATOR",        sub:"XP distribution"},
                {role:"territory", e:"🗺️",label:"TERRITORY MAP",   sub:"Claim bars · earn coins · hold your turf"},
                {role:"zombie",    e:"☣️",label:"DEAD CITY",         sub:"Solo zombie hunt · earn coins between crawls"},
                {role:"daily_spin",e:"🎰",label:"DAILY SPIN",        sub:"Free spin · streak bonuses · today's prizes"},
                {role:"crew",      e:"⚔️",label:"MY CREW",           sub:"Squad · weekly challenges · shared XP"},
                {role:"quick_start",e:"⚡",label:"QUICK START",       sub:"Name + avatar · playing in 60 seconds"},
                {role:"scoreboard",e:"📺",label:"LIVE SCOREBOARD",  sub:"City-wide live game scores & stats"},
                {role:"rules",     e:"📋",label:"RULES",            sub:"Code of conduct & fair play"},
                {role:"designer",  e:"🎨",label:"DESIGNER PORTAL",  sub:"Pricing · features · system config"},
              ].map(({role,e,label,sub})=>(
                <button key={role} onClick={()=>onRole(role)} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 12px",border:"1px solid #1a1d2e",borderRadius:10,background:"#0a0a12",cursor:"pointer",transition:"all .15s",textAlign:"left"}}
                  onMouseOver={ev=>{ev.currentTarget.style.borderColor="#555";}} onMouseOut={ev=>{ev.currentTarget.style.borderColor="#1a1d2e";}}>
                  <span style={{fontSize:20}}>{e}</span>
                  <div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:"#aaa"}}>{label}</div><div style={{fontSize:9,color:"#444",marginTop:1}}>{sub}</div></div>
                </button>
              ))}
            </div>
            <div style={{fontSize:10,color:"#333",letterSpacing:1}}>v2.0 · crawlfire.app</div>
          </>
        )}

        {/* ── LASER TAG ROLE PICKER ── */}
        {mode==="laser"&&(
          <>
            <div style={{display:"flex",alignItems:"center",gap:10,width:"100%"}}>
              <button onClick={()=>setMode(null)} style={{...S.btnGhost}}>← BACK</button>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,color:"#FF2D55"}}>🎯 LASER TAG</div>
            </div>
            <div style={{...S.card,width:"100%",display:"flex",flexDirection:"column",gap:8}}>
              <div style={{fontSize:10,letterSpacing:3,color:"#555",marginBottom:2}}>JOIN AS A PLAYER</div>
              {[
                {role:"player",e:"🎯",label:"PLAYER",sub:"Join or host a laser tag crawl"},
              ].map(({role,e,label,sub})=>(
                <button key={role} onClick={()=>onRole(role)} style={{display:"flex",alignItems:"center",gap:12,padding:"14px",border:"2px solid #FF2D5540",borderRadius:12,background:"#FF2D5508",cursor:"pointer",textAlign:"left"}}
                  onMouseOver={ev=>{ev.currentTarget.style.borderColor="#FF2D55";}} onMouseOut={ev=>{ev.currentTarget.style.borderColor="#FF2D5540";}}>
                  <span style={{fontSize:30}}>{e}</span>
                  <div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1,color:"#f0f0f8"}}>{label}</div><div style={{fontSize:11,color:"#555",marginTop:2}}>{sub}</div></div>
                </button>
              ))}
            </div>
          </>
        )}

        {/* ── CTF MODE ENTRY ── */}
        {mode==="ctf"&&(
          <>
            <div style={{display:"flex",alignItems:"center",gap:10,width:"100%"}}>
              <button onClick={()=>setMode(null)} style={{...S.btnGhost}}>← BACK</button>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,color:"#007AFF"}}>⚑ CAPTURE THE FLAG</div>
            </div>
            <div style={{...S.card,width:"100%",display:"flex",flexDirection:"column",gap:10}}>
              {[
                {e:"🔴",t:"Red Wolves",c:"#FF2D55"},{e:"🔵",t:"Blue Sharks",c:"#007AFF"},
                {e:"🟢",t:"Green Vipers",c:"#34C759"},{e:"🟡",t:"Gold Eagles",c:"#FFCC00"},
              ].map(team=><div key={team.e} style={{display:"flex",alignItems:"center",gap:8,background:`${team.c}10`,border:`1px solid ${team.c}40`,borderRadius:10,padding:"8px 12px"}}>
                <span style={{fontSize:20}}>{team.e}</span>
                <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:team.c,letterSpacing:1}}>{team.t}</span>
              </div>)}
            </div>
            <button style={{...S.btnPrimary,width:"100%",background:"linear-gradient(135deg,#007AFF,#BF5AF2)"}} onClick={onCTF}>
              ⚑ ENTER CTF MODE →
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// DIFFICULTY SELECT SCREEN
// ═══════════════════════════════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════════════════════════════
// MINE SYSTEM — plant, arm, trigger, sweep UI components
// ═══════════════════════════════════════════════════════════════════════════════

// ── Mine planting modal — shown when player uses a mine from inventory ────────
function MinePlantModal({ mineType, myId, myName, game, onPlant, onCancel }) {
  const [selBar, setSelBar] = useState(null);
  const bars = BARS_DEMO || [];
  const mt   = MINE_TYPES[mineType] || MINE_TYPES.mine;

  // Derive bar list from game events / demo bars
  const BARS_DEMO = [
    {id:"b1",name:"The Rusty Anchor", e:"⚓"},
    {id:"b2",name:"The Golden Pint",  e:"🍺"},
    {id:"b3",name:"The Neon Flask",   e:"🌈"},
    {id:"b4",name:"The Copper Still", e:"🥃"},
    {id:"b5",name:"The Barrel House", e:"🛢️"},
    {id:"b6",name:"The Iron Tap",     e:"🔩"},
  ];

  // Check if this bar already has a mine from this player
  const myMines = Object.values(game?.mines||{}).filter(m=>m.plantedBy===myId&&!m.triggered&&!m.disabled);

  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.92)",display:"flex",alignItems:"flex-end",justifyContent:"center",zIndex:300}}>
      <div style={{background:"#0d0e1a",border:`2px solid ${mt.color}`,borderTopLeftRadius:20,borderTopRightRadius:20,padding:"20px 18px 44px",width:"100%",maxWidth:440,display:"flex",flexDirection:"column",gap:14,animation:"slideUp .3s ease"}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <span style={{fontSize:36,filter:`drop-shadow(0 0 12px ${mt.color})`}}>{mt.e}</span>
          <div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,color:mt.color}}>PLANT {mt.n.toUpperCase()}</div>
            <div style={{fontSize:10,color:"#666",marginTop:2}}>{mt.desc}</div>
          </div>
        </div>

        {/* Stats */}
        <div style={{display:"flex",gap:8}}>
          <div style={{flex:1,background:`${mt.color}12`,border:`1px solid ${mt.color}30`,borderRadius:10,padding:"10px 12px",textAlign:"center"}}>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:24,color:mt.color}}>{mt.dmg}</div>
            <div style={{fontSize:8,color:"#555",letterSpacing:2,marginTop:2}}>BASE DMG</div>
          </div>
          <div style={{flex:1,background:"#FF950015",border:"1px solid #FF950030",borderRadius:10,padding:"10px 12px",textAlign:"center"}}>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:24,color:"#FF9500"}}>AUTO</div>
            <div style={{fontSize:8,color:"#555",letterSpacing:2,marginTop:2}}>TRIGGER</div>
          </div>
          <div style={{flex:1,background:"#34C75915",border:"1px solid #34C75930",borderRadius:10,padding:"10px 12px",textAlign:"center"}}>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:"#34C759"}}>🧹</div>
            <div style={{fontSize:8,color:"#555",letterSpacing:2,marginTop:2}}>SWEEPABLE</div>
          </div>
        </div>

        <div style={{fontSize:9,color:"#555",letterSpacing:3}}>SELECT BAR TO MINE</div>

        <div style={{display:"flex",flexDirection:"column",gap:6,maxHeight:220,overflowY:"auto"}}>
          {BARS_DEMO.map(bar=>{
            const existingMine=Object.values(game?.mines||{}).find(m=>m.barId===bar.id&&!m.triggered&&!m.disabled);
            const myMineHere=existingMine?.plantedBy===myId;
            return(
              <button key={bar.id} onClick={()=>!existingMine&&setSelBar(bar)} style={{
                display:"flex",alignItems:"center",gap:10,padding:"11px 14px",
                border:`2px solid ${selBar?.id===bar.id?mt.color:existingMine?"#FF2D5540":"#1a1d2e"}`,
                borderRadius:12,background:selBar?.id===bar.id?`${mt.color}15`:existingMine?"#FF2D5508":"#12121a",
                cursor:existingMine?"not-allowed":"pointer",opacity:existingMine?.5:1,textAlign:"left",
              }}>
                <span style={{fontSize:22}}>{bar.e}</span>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,color:selBar?.id===bar.id?mt.color:"#f0f0f8"}}>{bar.name}</div>
                  {existingMine&&<div style={{fontSize:9,color:"#FF2D55",marginTop:2}}>⚠️ {myMineHere?"Your mine":"Enemy mine"} already here</div>}
                </div>
                {selBar?.id===bar.id&&<span style={{color:mt.color,fontSize:16}}>✓</span>}
                {existingMine&&<span style={{fontSize:14}}>💥</span>}
              </button>
            );
          })}
        </div>

        <div style={{display:"flex",gap:8}}>
          <button onClick={onCancel} style={{flex:1,padding:12,border:"1px solid #2a2a3a",borderRadius:12,background:"none",color:"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:2,cursor:"pointer"}}>CANCEL</button>
          <button onClick={()=>selBar&&onPlant(mineType,selBar)} disabled={!selBar} style={{flex:2,padding:13,border:"none",borderRadius:12,cursor:selBar?"pointer":"not-allowed",fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2,background:selBar?`linear-gradient(135deg,${mt.color},${mt.color}cc)`:"#1a1d2e",color:selBar?"#fff":"#555",boxShadow:selBar?`0 4px 16px ${mt.color}40`:"none"}}>
            {mt.e} ARM MINE
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Mine sweeper modal — disarm mines at current bar ─────────────────────────
function MineSweepModal({ myId, myName, game, onSweep, onCancel }) {
  const [selMine, setSelMine] = useState(null);
  const activeMines = Object.values(game?.mines||{}).filter(m=>!m.triggered&&!m.disabled);
  const enemyMines  = activeMines.filter(m=>m.plantedBy!==myId);
  const myMines     = activeMines.filter(m=>m.plantedBy===myId);

  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.92)",display:"flex",alignItems:"flex-end",justifyContent:"center",zIndex:300}}>
      <div style={{background:"#0d0e1a",border:"2px solid #34C759",borderTopLeftRadius:20,borderTopRightRadius:20,padding:"20px 18px 44px",width:"100%",maxWidth:440,display:"flex",flexDirection:"column",gap:14,animation:"slideUp .3s ease"}}>
        <div style={{display:"flex",alignItems:"center",gap:12}}>
          <span style={{fontSize:36,filter:"drop-shadow(0 0 12px #34C759)"}}>🧹</span>
          <div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,color:"#34C759"}}>MINE SWEEPER</div>
            <div style={{fontSize:10,color:"#666",marginTop:2}}>Detects and disarms any active proximity mine</div>
          </div>
        </div>

        {activeMines.length===0?(
          <div style={{textAlign:"center",padding:"20px 0"}}>
            <div style={{fontSize:36,marginBottom:8}}>✅</div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:2,color:"#34C759"}}>NO MINES DETECTED</div>
            <div style={{fontSize:11,color:"#555",marginTop:4}}>The area is clear — no active mines found</div>
          </div>
        ):(
          <>
            {enemyMines.length>0&&<>
              <div style={{fontSize:9,color:"#FF2D55",letterSpacing:3}}>⚠️ ENEMY MINES ({enemyMines.length})</div>
              {enemyMines.map(m=>{
                const mt=MINE_TYPES[m.type]||MINE_TYPES.mine;
                const age=Math.floor((Date.now()-m.plantedAt)/1000);
                return(
                  <button key={m.id} onClick={()=>setSelMine(m.id===selMine?null:m.id)} style={{display:"flex",alignItems:"center",gap:10,padding:"12px 14px",border:`2px solid ${selMine===m.id?"#34C759":"#FF2D5540"}`,borderRadius:12,background:selMine===m.id?"#34C75912":"#FF2D5508",cursor:"pointer",textAlign:"left"}}>
                    <span style={{fontSize:24,animation:"pulse 1.5s ease-in-out infinite"}}>{mt.e}</span>
                    <div style={{flex:1}}>
                      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,color:selMine===m.id?"#34C759":"#f0f0f8"}}>{mt.n}</div>
                      <div style={{fontSize:9,color:"#888",marginTop:2}}>{m.barName} · {mt.dmg} dmg · planted {age<60?`${age}s`:`${Math.floor(age/60)}m`} ago</div>
                    </div>
                    {selMine===m.id&&<span style={{color:"#34C759",fontSize:16}}>🧹</span>}
                  </button>
                );
              })}
            </>}

            {myMines.length>0&&<>
              <div style={{fontSize:9,color:"#FFCC00",letterSpacing:3}}>YOUR MINES ({myMines.length})</div>
              {myMines.map(m=>{
                const mt=MINE_TYPES[m.type]||MINE_TYPES.mine;
                return(
                  <button key={m.id} onClick={()=>setSelMine(m.id===selMine?null:m.id)} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",border:`2px solid ${selMine===m.id?"#FFCC00":"#FFCC0030"}`,borderRadius:12,background:selMine===m.id?"#FFCC0012":"#FFCC0008",cursor:"pointer",textAlign:"left"}}>
                    <span style={{fontSize:22}}>{mt.e}</span>
                    <div style={{flex:1}}>
                      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:"#FFCC00"}}>{mt.n} (yours)</div>
                      <div style={{fontSize:9,color:"#888",marginTop:2}}>{m.barName} · Recall this mine?</div>
                    </div>
                    {selMine===m.id&&<span style={{color:"#FFCC00",fontSize:14}}>✓</span>}
                  </button>
                );
              })}
            </>}
          </>
        )}

        <div style={{display:"flex",gap:8}}>
          <button onClick={onCancel} style={{flex:1,padding:12,border:"1px solid #2a2a3a",borderRadius:12,background:"none",color:"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:2,cursor:"pointer"}}>CLOSE</button>
          {selMine&&<button onClick={()=>onSweep(selMine)} style={{flex:2,padding:13,border:"none",borderRadius:12,background:"linear-gradient(135deg,#34C759,#00C7BE)",color:"#000",fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2,cursor:"pointer",boxShadow:"0 4px 16px #34C75940"}}>
            🧹 DISARM MINE
          </button>}
        </div>
      </div>
    </div>
  );
}

// ── ActiveMinesBanner — shown in PlayScreen when mines are active ─────────────
function ActiveMinesBanner({ game, myId, onOpenSweeper }) {
  const myMines    = Object.values(game?.mines||{}).filter(m=>m.plantedBy===myId&&!m.triggered&&!m.disabled);
  const enemyMines = Object.values(game?.mines||{}).filter(m=>m.plantedBy!==myId&&!m.triggered&&!m.disabled);
  if(!myMines.length&&!enemyMines.length) return null;

  return (
    <div style={{display:"flex",flexDirection:"column",gap:6}}>
      {myMines.length>0&&(
        <div style={{display:"flex",alignItems:"center",gap:8,padding:"8px 12px",background:"#FFCC0012",border:"1px solid #FFCC0040",borderRadius:10}}>
          <span style={{fontSize:16}}>💥</span>
          <div style={{flex:1,fontSize:11,color:"#FFCC00"}}>
            <strong>{myMines.length} mine{myMines.length>1?"s":""} armed</strong> — {myMines.map(m=>`${m.barName}`).join(", ")}
          </div>
        </div>
      )}
      {enemyMines.length>0&&(
        <button onClick={onOpenSweeper} style={{display:"flex",alignItems:"center",gap:8,padding:"8px 12px",background:"#FF2D5512",border:"1px solid #FF2D5540",borderRadius:10,cursor:"pointer",textAlign:"left",width:"100%"}}>
          <span style={{fontSize:16,animation:"pulse 1.5s ease-in-out infinite"}}>⚠️</span>
          <div style={{flex:1,fontSize:11,color:"#FF2D55"}}>
            <strong>{enemyMines.length} enemy mine{enemyMines.length>1?"s":""} detected</strong> — tap to sweep
          </div>
          <span style={{fontSize:12,color:"#FF2D55"}}>🧹</span>
        </button>
      )}
    </div>
  );
}

// ── Mine trigger notification — flashes when you hit a mine ──────────────────
function MineTriggerFlash({ mine, onDismiss }) {
  if (!mine) return null;
  const mt = MINE_TYPES[mine.type] || MINE_TYPES.mine;
  return (
    <div style={{position:"fixed",inset:0,background:"rgba(255,45,85,.15)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:350,animation:"flash .3s ease"}}>
      <div style={{background:"#0d0e1a",border:`3px solid ${mt.color}`,borderRadius:20,padding:"28px 24px",textAlign:"center",maxWidth:300,animation:"popIn .4s ease",boxShadow:`0 0 60px ${mt.color}50`}}>
        <div style={{fontSize:64,marginBottom:10,filter:`drop-shadow(0 0 20px ${mt.color})`,animation:"breathe 1s ease-in-out infinite"}}>{mt.e}</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,letterSpacing:3,color:mt.color}}>MINE TRIGGERED!</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#f0f0f8",marginTop:6}}>{mt.n}</div>
        <div style={{fontSize:28,color:"#FF2D55",marginTop:8,fontFamily:"'Black Han Sans',sans-serif"}}>-{mt.dmg} HP</div>
        {mine.type==="mine_emp"&&<div style={{fontSize:11,color:"#FF9500",marginTop:4}}>-30 coins drained!</div>}
        {mine.type==="mine_smoke"&&<div style={{fontSize:11,color:"#BF5AF2",marginTop:4}}>30s smoke — you're cloaked!</div>}
        <div style={{fontSize:10,color:"#555",marginTop:8}}>Planted by {mine.plantedByName}</div>
        <button onClick={onDismiss} style={{marginTop:14,padding:"10px 24px",border:"none",borderRadius:10,background:mt.color,color:"#fff",fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:2,cursor:"pointer"}}>GOT IT</button>
      </div>
    </div>
  );
}


function DifficultySelect({ onSelect, onBack }) {
  const [chosen, setChosen] = useState("intermediate");
  const [expanded, setExpanded] = useState(null);
  const diff = DIFFICULTY_LEVELS[chosen];

  return (
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>

      <div style={{textAlign:"center"}}>
        <div style={{fontSize:48,marginBottom:6,animation:"breathe 2.5s ease-in-out infinite"}}>🎮</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:24,letterSpacing:3,color:"#f0f0f8"}}>CHOOSE DIFFICULTY</div>
        <div style={{fontSize:11,color:"#555",marginTop:4,lineHeight:1.7}}>
          Difficulty affects HP, damage, map visibility, and XP rewards.
        </div>
      </div>

      {/* Difficulty cards */}
      <div style={{display:"flex",flexDirection:"column",gap:8}}>
        {DIFF_IDS.map(dId => {
          const d     = DIFFICULTY_LEVELS[dId];
          const isSel = chosen === dId;
          const isExp = expanded === dId;
          return (
            <div key={dId}>
              <div onClick={()=>{setChosen(dId);setExpanded(isExp?null:dId);}} style={{
                background: isSel?`${d.color}12`:"#0d0e1a",
                border:     `2px solid ${isSel?d.color:"#1a1d2e"}`,
                borderRadius: 14, padding:"14px 16px", cursor:"pointer",
                transition:"all .15s",
                boxShadow: isSel?`0 0 20px ${d.color}25`:"none",
              }}>
                {/* Header row */}
                <div style={{display:"flex",alignItems:"center",gap:12}}>
                  <div style={{fontSize:32,flexShrink:0,filter:isSel?`drop-shadow(0 0 10px ${d.color}80)`:"none",animation:isSel?"breathe 2s ease-in-out infinite":"none"}}>{d.icon}</div>
                  <div style={{flex:1}}>
                    <div style={{display:"flex",alignItems:"center",gap:8}}>
                      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,color:isSel?d.color:"#f0f0f8"}}>{d.label}</div>
                      {isSel && <span style={{fontSize:8,padding:"2px 8px",borderRadius:10,background:`${d.color}25`,border:`1px solid ${d.color}50`,color:d.color,letterSpacing:1,fontFamily:"'Space Mono',monospace"}}>SELECTED</span>}
                      {d.ranked && <span style={{fontSize:8,padding:"2px 8px",borderRadius:10,background:"#FF2D5525",border:"1px solid #FF2D5550",color:"#FF2D55",letterSpacing:1,fontFamily:"'Space Mono',monospace"}}>RANKED</span>}
                    </div>
                    <div style={{fontSize:11,color:"#888",marginTop:2,fontStyle:"italic"}}>"{d.tagline}"</div>
                  </div>
                  <div style={{color:isSel?d.color:"#555",fontSize:14,flexShrink:0}}>{isExp?"▲":"▼"}</div>
                </div>

                {/* Stat pills row */}
                <div style={{display:"flex",gap:5,flexWrap:"wrap",marginTop:10}}>
                  {[
                    {l:`❤️ ${d.hpBase} HP`},
                    {l:`⚔️ ${Math.round(d.dmgMulti*100)}% dmg`},
                    {l:`⭐ ${Math.round(d.potShare*100)}% XP bonus`},
                    d.respawn?{l:"❤️‍🔥 Free respawn"}:null,
                    d.friendlyFire?{l:"🔥 Friendly fire",warn:true}:null,
                    d.ranked?{l:"🏅 Ranked",special:true}:null,
                    d.shopDiscount>0?{l:`🏪 ${Math.round(d.shopDiscount*100)}% off shop`}:null,
                    d.shopDiscount<0?{l:`🏪 Shop ${Math.round(Math.abs(d.shopDiscount)*100)}% pricier`,warn:true}:null,
                  ].filter(Boolean).map((p,i)=>(
                    <span key={i} style={{fontSize:9,padding:"2px 9px",borderRadius:20,background:p.warn?`#FF2D5515`:p.special?`#FFCC0015`:`${d.color}12`,border:`1px solid ${p.warn?"#FF2D5540":p.special?"#FFCC0040":`${d.color}30`}`,color:p.warn?"#FF2D55":p.special?"#FFCC00":d.color}}>
                      {p.l}
                    </span>
                  ))}
                </div>
              </div>

              {/* Expanded detail panel */}
              {isExp && (
                <div style={{background:`${d.color}06`,border:`1px solid ${d.color}25`,borderTop:"none",borderBottomLeftRadius:14,borderBottomRightRadius:14,padding:"14px 16px",display:"flex",flexDirection:"column",gap:12,animation:"slideUp .2s ease"}}>
                  {/* Perks */}
                  <div>
                    <div style={{fontSize:9,color:"#555",letterSpacing:3,marginBottom:7}}>PERKS</div>
                    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6}}>
                      {d.perks.map((p,i)=>(
                        <div key={i} style={{display:"flex",alignItems:"center",gap:7,padding:"7px 10px",background:"#12121a",borderRadius:8,border:`1px solid ${d.color}20`}}>
                          <span style={{fontSize:18,flexShrink:0}}>{p.e}</span>
                          <span style={{fontSize:10,color:"#f0f0f8",lineHeight:1.4}}>{p.t}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Full rules */}
                  <div>
                    <div style={{fontSize:9,color:"#555",letterSpacing:3,marginBottom:7}}>RULES</div>
                    <div style={{display:"flex",flexDirection:"column",gap:4}}>
                      {d.rules.map((r,i)=>(
                        <div key={i} style={{fontSize:11,color:"#888",padding:"5px 10px",borderRadius:8,background:"#12121a",lineHeight:1.5}}>{r}</div>
                      ))}
                    </div>
                  </div>

                  {/* Restrictions (advanced only) */}
                  {d.restrictions.length>0&&(
                    <div style={{background:"#FF2D5510",border:"1px solid #FF2D5530",borderRadius:10,padding:"10px 14px"}}>
                      <div style={{fontSize:9,color:"#FF2D55",letterSpacing:3,marginBottom:5}}>⚠️ RESTRICTIONS</div>
                      {d.restrictions.map((r,i)=>(
                        <div key={i} style={{fontSize:11,color:"#FF2D55",lineHeight:1.7}}>• {r}</div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Entry price note for advanced */}
      {chosen==="advanced"&&(
        <div style={{...S.card,background:"#FF2D5510",border:"1px solid #FF2D5530",fontSize:11,color:"#FF2D55",lineHeight:1.8}}>
          🔴 Advanced mode charges 1.5× the entry price.<br/>
          Higher difficulty means bigger XP rewards and rarer loot drops.<br/>
          <strong>High risk. High reward.</strong>
        </div>
      )}

      {/* Entry price note for beginner */}
      {chosen==="beginner"&&(
        <div style={{...S.card,background:"#34C75910",border:"1px solid #34C75930",fontSize:11,color:"#34C759",lineHeight:1.8}}>
          💚 Beginner mode is great for first-timers.<br/>
          Lower stakes — perfect for learning the ropes.
        </div>
      )}

      <button style={{...S.btnPrimary,background:`linear-gradient(135deg,${diff.color},${diff.color}cc)`,color:chosen==="intermediate"?"#000":chosen==="beginner"?"#000":"#fff"}} onClick={()=>onSelect(chosen)}>
        {diff.icon} PLAY AS {diff.label} →
      </button>
    </div>
  );
}


function PaymentScreen({onPaid,onBack,difficulty="intermediate"}){
  // Gambling / entry fee removed — game is free to join
  // This screen now serves as the final game join confirmation
  const d = DIFFICULTY_LEVELS[difficulty] || DIFFICULTY_LEVELS.intermediate;
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:52,marginBottom:8,animation:"breathe 2s ease-in-out infinite",
          filter:"drop-shadow(0 0 16px #34C759)"}}>🎮</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:24,letterSpacing:3,
          color:"#34C759"}}>FREE TO PLAY</div>
        <div style={{fontSize:11,color:"#555",marginTop:6,lineHeight:1.8}}>
          CrawlFire is free to join. Earn XP, coins, and loot — no game entry required.
        </div>
      </div>

      <div style={{...S.card,background:"#0a0c14",border:"1px solid #34C75940"}}>
        <div style={{fontSize:9,color:"#555",letterSpacing:3,marginBottom:10}}>GAME MODE</div>
        {[
          {e:"⭐",l:"XP Rewards",v:`+${Math.round(d.potShare*100)}% XP bonus on ${difficulty} mode`},
          {e:"🎒",l:"Loot Drops", v:"Rare items drop more on higher difficulty"},
          {e:"🏅",l:"Rank Points", v:"Competitive wins earn rank progression"},
          {e:"🪙",l:"Coins",       v:"Earn coins for kills, flags, and zone control"},
        ].map((r,i)=>(
          <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"6px 0",
            borderBottom:"1px solid #1a1d2e"}}>
            <span style={{fontSize:18,flexShrink:0}}>{r.e}</span>
            <div>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,
                color:"#f0f0f8"}}>{r.l}</div>
              <div style={{fontSize:10,color:"#555",marginTop:1}}>{r.v}</div>
            </div>
          </div>
        ))}
      </div>

      <button onClick={()=>onPaid()} style={{...S.btnPrimary,
        background:"linear-gradient(135deg,#34C759,#00C7BE)",color:"#000",fontSize:18}}>
        🎮 JOIN GAME — FREE →
      </button>
      <div style={{textAlign:"center",fontSize:10,color:"#444"}}>
        No payment required · Earn XP and loot by playing
      </div>
    </div>
  );
}

function compressPhoto(dataUrl, size=80) {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement("canvas");
      c.width = size; c.height = size;
      const ctx = c.getContext("2d");
      // Crop to square from centre
      const s = Math.min(img.width, img.height);
      const sx = (img.width  - s) / 2;
      const sy = (img.height - s) / 2;
      ctx.drawImage(img, sx, sy, s, s, 0, 0, size, size);
      resolve(c.toDataURL("image/jpeg", 0.75));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

// ── AvatarDisplay — renders either an emoji or a circular photo ───────────────
// Used everywhere an avatar is shown throughout the app
function AvatarDisplay({ avatar, size=32, style={}, borderColor=null }) {
  const isPhoto = avatar && avatar.startsWith("data:");
  if (!isPhoto) {
    return (
      <span style={{
        fontSize: size * 0.75,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: size, height: size,
        flexShrink: 0,
        ...style,
      }}>
        {avatar || "🍺"}
      </span>
    );
  }
  return (
    <div style={{
      width: size, height: size,
      borderRadius: "50%",
      overflow: "hidden",
      flexShrink: 0,
      border: borderColor ? `2px solid ${borderColor}` : "2px solid #2a2a3a",
      boxShadow: borderColor ? `0 0 8px ${borderColor}40` : "none",
      ...style,
    }}>
      <img src={avatar} alt="avatar"
        style={{width:"100%",height:"100%",objectFit:"cover",display:"block"}}/>
    </div>
  );
}

// ── AvatarPicker — the full picker UI ─────────────────────────────────────────
function AvatarPicker({ value, playerName, onChange }) {
  const [mode,       setMode]       = useState("emoji");  // emoji | camera | upload
  const [streaming,  setStreaming]  = useState(false);
  const [stream,     setStream]     = useState(null);
  const [camError,   setCamError]   = useState(null);
  const [flash,      setFlash]      = useState(false);
  const [processing, setProcessing] = useState(false);
  const videoRef  = useRef(null);
  const canvasRef = useRef(null);
  const fileRef   = useRef(null);

  // Stop camera when switching away
  useEffect(() => {
    return () => { if (stream) stream.getTracks().forEach(t => t.stop()); };
  }, [stream]);

  const startCamera = async () => {
    setCamError(null);
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width:{ideal:640}, height:{ideal:640} },
        audio: false,
      });
      setStream(s);
      setStreaming(true);
      if (videoRef.current) {
        videoRef.current.srcObject = s;
        videoRef.current.play();
      }
    } catch(e) {
      setCamError(e.name === "NotAllowedError"
        ? "Camera permission denied. Please allow camera access and try again."
        : "Camera not available on this device. Try uploading a photo instead.");
    }
  };

  const stopCamera = () => {
    if (stream) stream.getTracks().forEach(t => t.stop());
    setStream(null);
    setStreaming(false);
  };

  const takeSelfie = async () => {
    if (!videoRef.current || !canvasRef.current) return;
    setFlash(true);
    setTimeout(() => setFlash(false), 200);
    setProcessing(true);
    const v = videoRef.current;
    const c = canvasRef.current;
    c.width = v.videoWidth; c.height = v.videoHeight;
    c.getContext("2d").drawImage(v, 0, 0);
    const raw = c.toDataURL("image/jpeg", 0.9);
    const compressed = await compressPhoto(raw, 80);
    stopCamera();
    onChange(compressed);
    if (playerName) await saveAvatarPhoto(playerName, compressed);
    setProcessing(false);
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setProcessing(true);
    const reader = new FileReader();
    reader.onload = async (ev) => {
      const compressed = await compressPhoto(ev.target.result, 80);
      onChange(compressed);
      if (playerName) await saveAvatarPhoto(playerName, compressed);
      setProcessing(false);
    };
    reader.readAsDataURL(file);
  };

  const clearPhoto = () => {
    onChange("🍺");
    setMode("emoji");
  };

  const isPhoto = value && value.startsWith("data:");

  return (
    <div style={{display:"flex",flexDirection:"column",gap:10,width:"100%"}}>

      {/* Current avatar preview + mode toggle */}
      <div style={{display:"flex",alignItems:"center",gap:14}}>
        {/* Big avatar preview */}
        <div style={{
          width:72,height:72,borderRadius:"50%",
          border:"2px solid #FF2D55",
          display:"flex",alignItems:"center",justifyContent:"center",
          background:"#0d0e1a",overflow:"hidden",flexShrink:0,
          boxShadow:"0 0 16px #FF2D5530",
        }}>
          {isPhoto
            ? <img src={value} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
            : <span style={{fontSize:36}}>{value||"🍺"}</span>}
        </div>

        {/* Mode buttons */}
        <div style={{flex:1,display:"flex",flexDirection:"column",gap:6}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:"#888",letterSpacing:2}}>AVATAR TYPE</div>
          <div style={{display:"flex",gap:6}}>
            {[
              {id:"emoji",  label:"EMOJI",  icon:"😀"},
              {id:"camera", label:"SELFIE", icon:"📷"},
              {id:"upload", label:"UPLOAD", icon:"🖼️"},
            ].map(m => (
              <button key={m.id} onClick={()=>{setMode(m.id);if(m.id!=="camera")stopCamera();if(m.id==="camera")startCamera();}} style={{
                flex:1,padding:"7px 4px",
                border:`2px solid ${mode===m.id?"#FF2D55":"#2a2a3a"}`,
                borderRadius:8,background:mode===m.id?"#FF2D5515":"#0d0e1a",
                color:mode===m.id?"#FF2D55":"#555",
                fontFamily:"'Black Han Sans',sans-serif",fontSize:9,letterSpacing:1,
                cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:2,
              }}>
                <span style={{fontSize:16}}>{m.icon}</span>
                {m.label}
              </button>
            ))}
          </div>
          {isPhoto&&<button onClick={clearPhoto} style={{fontSize:9,color:"#555",background:"none",border:"1px solid #2a2a3a",borderRadius:8,padding:"4px 0",cursor:"pointer",fontFamily:"'Black Han Sans',sans-serif",letterSpacing:1}}>
            ✕ REMOVE PHOTO
          </button>}
        </div>
      </div>

      {/* ── EMOJI MODE ── */}
      {mode==="emoji"&&(
        <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:7}}>
          {AVATARS.map(a=>(
            <button key={a} onClick={()=>onChange(a)} style={{
              aspectRatio:1,fontSize:24,borderRadius:10,
              border:`2px solid ${value===a?"#FF2D55":"#2a2a3a"}`,
              background:value===a?"#FF2D5515":"#12121a",
              cursor:"pointer",transition:"all .12s",
            }}>
              {a}
            </button>
          ))}
        </div>
      )}

      {/* ── CAMERA MODE ── */}
      {mode==="camera"&&(
        <div style={{display:"flex",flexDirection:"column",gap:8,alignItems:"center"}}>
          {camError&&(
            <div style={{...S.card,background:"#FF2D5510",border:"1px solid #FF2D5540",fontSize:11,color:"#FF2D55",lineHeight:1.7,textAlign:"center"}}>
              ⚠️ {camError}
            </div>
          )}

          {!streaming&&!camError&&(
            <button onClick={startCamera} style={{...S.btnPrimary,width:"100%"}}>
              📷 OPEN CAMERA
            </button>
          )}

          {streaming&&(
            <div style={{position:"relative",width:"100%",maxWidth:260}}>
              {/* Flash effect */}
              {flash&&<div style={{position:"absolute",inset:0,background:"#fff",borderRadius:12,zIndex:10,animation:"flash .15s ease",pointerEvents:"none"}}/>}

              {/* Circular crop overlay */}
              <div style={{position:"relative",borderRadius:12,overflow:"hidden",background:"#000"}}>
                <video ref={videoRef} autoPlay playsInline muted
                  style={{width:"100%",display:"block",transform:"scaleX(-1)"}}/>
                {/* Circle guide overlay */}
                <div style={{
                  position:"absolute",inset:0,
                  background:"radial-gradient(circle 45% at 50% 50%,transparent 44%,rgba(0,0,0,.6) 45%)",
                  pointerEvents:"none",
                }}/>
                <div style={{
                  position:"absolute",
                  top:"50%",left:"50%",transform:"translate(-50%,-50%)",
                  width:"88%",aspectRatio:1,
                  borderRadius:"50%",
                  border:"2px solid #FF2D55",
                  boxShadow:"0 0 0 2000px rgba(0,0,0,.5)",
                  pointerEvents:"none",
                }}/>
              </div>

              {/* Capture + cancel */}
              <div style={{display:"flex",gap:8,marginTop:8}}>
                <button onClick={stopCamera} style={{flex:1,padding:"10px 0",border:"1px solid #2a2a3a",borderRadius:10,background:"#0d0e1a",color:"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:13,cursor:"pointer"}}>
                  CANCEL
                </button>
                <button onClick={takeSelfie} disabled={processing} style={{flex:2,padding:"12px 0",border:"none",borderRadius:10,background:processing?"#1a1d2e":"linear-gradient(135deg,#FF2D55,#FF9500)",color:processing?"#555":"#fff",fontFamily:"'Black Han Sans',sans-serif",fontSize:16,cursor:processing?"not-allowed":"pointer",boxShadow:processing?"none":"0 4px 16px #FF2D5540"}}>
                  {processing?"SAVING…":"📸 SNAP!"}
                </button>
              </div>
              <canvas ref={canvasRef} style={{display:"none"}}/>
            </div>
          )}
        </div>
      )}

      {/* ── UPLOAD MODE ── */}
      {mode==="upload"&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          <input ref={fileRef} type="file" accept="image/*" capture="environment"
            onChange={handleFileUpload} style={{display:"none"}}/>

          <button onClick={()=>fileRef.current?.click()} disabled={processing} style={{
            width:"100%",padding:"18px 0",
            border:"2px dashed #2a2a3a",borderRadius:12,
            background:"#0d0e1a",cursor:processing?"not-allowed":"pointer",
            display:"flex",flexDirection:"column",alignItems:"center",gap:8,
            transition:"all .15s",
          }}
          onMouseOver={e=>{e.currentTarget.style.borderColor="#FF2D55";e.currentTarget.style.background="#FF2D5508";}}
          onMouseOut={e=>{e.currentTarget.style.borderColor="#2a2a3a";e.currentTarget.style.background="#0d0e1a";}}>
            <span style={{fontSize:36}}>{processing?"⏳":"🖼️"}</span>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:1,color:"#888"}}>
              {processing?"PROCESSING…":"TAP TO CHOOSE PHOTO"}
            </div>
            <div style={{fontSize:9,color:"#555",letterSpacing:1}}>
              JPG · PNG · HEIC · GIF — from camera roll or files
            </div>
          </button>

          {isPhoto&&(
            <div style={{fontSize:10,color:"#34C759",textAlign:"center",padding:"4px 0"}}>
              ✅ Photo set — looking good!
            </div>
          )}
        </div>
      )}

      {/* Tip */}
      <div style={{fontSize:9,color:"#444",textAlign:"center",lineHeight:1.7}}>
        Your photo appears on your QR badge, in the HUD, leaderboard,<br/>
        bet cards and the live scoreboard. Saved for future sessions.
      </div>
    </div>
  );
}


function SetupScreen({onJoin,isJoining,pendingCode,onBack}){
  const [name,     setName]     = useState("");
  const [avatar,   setAvatar]   = useState("🍺");
  const [joinCode, setJoinCode] = useState(pendingCode||"");

  // Restore saved photo when name is typed
  useEffect(()=>{
    if(!name.trim()) return;
    loadAvatarPhoto(name.trim()).then(photo=>{
      if(photo) setAvatar(photo);
    });
  },[name]);

  const canJoin = name.trim() && (!isJoining || joinCode.trim().length===6);

  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={S.title}>CREATE YOUR FIGHTER</div>

      {/* Name input first — needed for photo restore */}
      <input style={{...S.input, marginBottom:4}}
        placeholder="YOUR CALLSIGN"
        maxLength={12}
        value={name}
        onChange={e=>setName(e.target.value.toUpperCase())}/>

      {/* Avatar picker — emoji / camera / upload */}
      <AvatarPicker value={avatar} playerName={name.trim()} onChange={setAvatar}/>

      {/* Game code for joining */}
      {isJoining&&<input style={S.input} placeholder="GAME CODE (6 letters)" maxLength={6} value={joinCode} onChange={e=>setJoinCode(e.target.value.toUpperCase())}/>}

      <button
        style={{...S.btnPrimary, opacity:canJoin?1:.4}}
        disabled={!canJoin}
        onClick={()=>onJoin(name.trim(), avatar, joinCode.toUpperCase())}>
        {isJoining?"JOIN GAME →":"LOCK & LOAD →"}
      </button>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ── COIN CHALLENGE SYSTEM (replaces in-game bet system) ───────────────────
// Players can challenge each other to coin wagers using their in-game coin
// balance only. No in-game coins involved. Coins are earned by playing.
const CHALLENGE_AMOUNTS = [25, 50, 100, 200];

function CoinChallengeCard({ game, myId, onChallenge }) {
  const [target,  setTarget]  = useState(null);
  const [amount,  setAmount]  = useState(50);
  const [type,    setType]    = useState("first_kill");
  const players = Object.values(game?.players||{}).filter(p=>p.id!==myId&&p.alive);
  const me      = game?.players?.[myId];
  const myCoins = me?.coins||0;

  const CHALLENGE_TYPES = [
    {id:"first_kill", label:"First Kill",       desc:"Who gets the first elimination?"},
    {id:"survivor",   label:"Last Standing",    desc:"Who survives the longest?"},
    {id:"most_kills", label:"Most Kills",       desc:"Who racks up more kills?"},
  ];

  if (!players.length) return null;

  return(
    <div style={{...S.card,background:"#0a0c14",border:"1px solid #FFCC0030"}}>
      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,
        color:"#FFCC00",letterSpacing:2,marginBottom:10}}>⚔️ COIN CHALLENGE</div>
      <div style={{fontSize:10,color:"#555",marginBottom:10,lineHeight:1.6}}>
        Challenge a player to a coin wager. Coins only — no in-game coins.
      </div>

      {/* Challenge type */}
      <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:10}}>
        {CHALLENGE_TYPES.map(ct=>(
          <button key={ct.id} onClick={()=>setType(ct.id)} style={{
            padding:"5px 10px",borderRadius:8,cursor:"pointer",
            border:`1px solid ${type===ct.id?"#FFCC00":"#2a2a3a"}`,
            background:type===ct.id?"#FFCC0015":"#07080f",
            color:type===ct.id?"#FFCC00":"#555",
            fontFamily:"'Black Han Sans',sans-serif",fontSize:10,letterSpacing:.5,
          }}>{ct.label}</button>
        ))}
      </div>

      {/* Amount selector */}
      <div style={{display:"flex",gap:6,marginBottom:10}}>
        {CHALLENGE_AMOUNTS.map(a=>(
          <button key={a} onClick={()=>setAmount(a)} style={{
            flex:1,padding:"6px 0",borderRadius:8,cursor:"pointer",
            border:`1px solid ${amount===a?"#FFCC00":"#2a2a3a"}`,
            background:amount===a?"#FFCC0015":"#07080f",
            color:amount===a?"#FFCC00":"#555",opacity:a>myCoins?.4:1,
            fontFamily:"'Black Han Sans',sans-serif",fontSize:12,
          }}>🪙{a}</button>
        ))}
      </div>

      {/* Target player */}
      <div style={{display:"flex",flexDirection:"column",gap:6,marginBottom:10}}>
        {players.slice(0,4).map(p=>(
          <button key={p.id} onClick={()=>setTarget(p.id===target?null:p.id)} style={{
            display:"flex",alignItems:"center",gap:8,padding:"7px 10px",
            border:`1px solid ${target===p.id?"#FF2D55":"#1a1d2e"}`,
            borderRadius:8,background:target===p.id?"#FF2D5510":"#07080f",cursor:"pointer",
          }}>
            <span style={{fontSize:16}}>{p.avatar}</span>
            <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,
              color:target===p.id?"#FF2D55":"#f0f0f8"}}>{p.name}</span>
            <span style={{marginLeft:"auto",fontSize:10,color:"#FFCC00"}}>🪙{p.coins}</span>
          </button>
        ))}
      </div>

      <button disabled={!target||amount>myCoins} onClick={()=>{
        if(onChallenge) onChallenge({targetId:target,amount,type});
        setTarget(null);
      }} style={{
        ...S.btnPrimary,
        background:target&&amount<=myCoins
          ?"linear-gradient(135deg,#FFCC00,#FF9500)":"#1a1d2e",
        color:target&&amount<=myCoins?"#000":"#555",fontSize:14,
        opacity:target&&amount<=myCoins?1:.5,
      }}>
        ⚔️ SEND CHALLENGE
      </button>
      <div style={{textAlign:"center",fontSize:9,color:"#333",marginTop:6}}>
        Coins wagered from your in-game balance · no in-game coins
      </div>
    </div>
  );
}


// ─────────────────────────────────────────────────────────────────────────────
// Non-intrusive ad slots at natural pause points:
//   1. WaitingScreen lobby — banner between player list and bets panel
//   2. Between zombie rounds (prep/shop phase) — interstitial with skip
//   3. Game Over screen — banner before the leaderboard
//   4. Daily spin — banner below the wheel before first spin
//
// AD TYPES:
//   banner      — 320×80px inline strip (always visible, no dismiss)
//   card        — full-width sponsored card (dismissable after 3s)
//   interstitial — full-screen with 5s countdown skip (between rounds only)
//
// DEMO ADS — replace with your ad network SDK (Google AdMob, ironSource, etc.)
// In production: swap renderAd() to call AdMob.showBanner() etc.
// Revenue model: CPM banner + rewarded video (player watches = skip countdown)
//
// NOTES:
//   • Never shown during active gameplay (while scanning/shooting)
//   • Dismissed or skipped before any action button is tappable
//   • Clearly labelled "SPONSORED" or "AD" per platform requirements
//   • Players can earn a 🎰 bonus spin by watching a full rewarded ad
// ═══════════════════════════════════════════════════════════════════════════════

// ── Demo ad creative pool ─────────────────────────────────────────────────────
const DEMO_ADS = [
  {
    id:"ad1", type:"banner",
    brand:"🍺 Guinness",
    headline:"THE PERFECT PINT AWAITS",
    sub:"Find your nearest stockist · Drink responsibly",
    cta:"SEE STOCKISTS",
    bg:"linear-gradient(135deg,#1a0a00,#2d1200)",
    border:"#8B4513",
    accent:"#D4A017",
    logo:"🍺",
  },
  {
    id:"ad2", type:"banner",
    brand:"⚡ Red Bull",
    headline:"GIVES YOU CRAWLFIRE WINGS",
    sub:"Official energy partner · Available at all venues",
    cta:"FIND OUT MORE",
    bg:"linear-gradient(135deg,#0d0d1a,#001a33)",
    border:"#FFD700",
    accent:"#FFD700",
    logo:"🐂",
  },
  {
    id:"ad3", type:"card",
    brand:"🎰 Paddy Power",
    headline:"BET ON YOUR FRIENDS",
    sub:"New customer offer · T&Cs apply · 18+ only · BeGambleAware.org",
    cta:"CLAIM OFFER",
    bg:"linear-gradient(135deg,#001a00,#003300)",
    border:"#00AA00",
    accent:"#00FF00",
    logo:"☘️",
  },
  {
    id:"ad4", type:"banner",
    brand:"🚗 Uber",
    headline:"GET HOME SAFE TONIGHT",
    sub:"First ride discount for CrawlFire players · Code: CRAWL10",
    cta:"BOOK A RIDE",
    bg:"linear-gradient(135deg,#0d0014,#0d0014)",
    border:"#1DBF73",
    accent:"#1DBF73",
    logo:"🚗",
  },
  {
    id:"ad5", type:"card",
    brand:"🎸 Ticketmaster",
    headline:"LIVE MUSIC NEAR YOU",
    sub:"Discover gigs happening this weekend in your city",
    cta:"BROWSE EVENTS",
    bg:"linear-gradient(135deg,#1a0020,#0d001a)",
    border:"#E40046",
    accent:"#E40046",
    logo:"🎟️",
  },
  {
    id:"ad6", type:"banner",
    brand:"🍕 Deliveroo",
    headline:"FUEL UP AFTER THE CRAWL",
    sub:"25% off your first order · Free delivery tonight",
    cta:"ORDER NOW",
    bg:"linear-gradient(135deg,#1a0800,#2d0f00)",
    border:"#00CCBC",
    accent:"#00CCBC",
    logo:"🛵",
  },
  {
    id:"ad7", type:"card",
    brand:"📱 CrawlFire Pro",
    headline:"GO PRO — REMOVE ALL ADS",
    sub:"Plus: exclusive weapon skins · priority matchmaking · VIP badge",
    cta:"UPGRADE FOR £2.99/mo",
    bg:"linear-gradient(135deg,#0d0e1a,#1a0020)",
    border:"#FF2D55",
    accent:"#FF2D55",
    logo:"👑",
    isPromo:true,
  },
];

let adIndex = Math.floor(Math.random() * DEMO_ADS.length);
function nextAd(type) {
  const pool = type ? DEMO_ADS.filter(a=>!a.type||a.type===type||a.type==="banner") : DEMO_ADS;
  const ad   = pool[adIndex % pool.length];
  adIndex    = (adIndex + 1) % pool.length;
  return ad;
}

// ── BannerAd — slim 320×80 strip ─────────────────────────────────────────────
function BannerAd({ type="banner", style={} }) {
  const [ad] = useState(()=>nextAd(type));

  return (
    <div style={{
      width:"100%",
      background: ad.bg,
      border: `1px solid ${ad.border}40`,
      borderRadius: 10,
      padding: "10px 12px",
      display: "flex",
      alignItems: "center",
      gap: 10,
      position: "relative",
      overflow: "hidden",
      ...style,
    }}>
      {/* Sponsored label */}
      <div style={{
        position:"absolute",top:3,right:6,
        fontSize:7,color:"#555",letterSpacing:1,
        fontFamily:"'Space Mono',monospace",
      }}>SPONSORED</div>

      {/* Logo */}
      <div style={{fontSize:28,flexShrink:0,filter:`drop-shadow(0 0 6px ${ad.accent}60)`}}>
        {ad.logo}
      </div>

      {/* Copy */}
      <div style={{flex:1,minWidth:0}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:ad.accent,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
          {ad.headline}
        </div>
        <div style={{fontSize:8,color:"#555",marginTop:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",lineHeight:1.4}}>
          {ad.brand} · {ad.sub.slice(0,45)}{ad.sub.length>45?"...":""}
        </div>
      </div>

      {/* CTA */}
      <button style={{
        padding:"5px 10px",border:"none",borderRadius:8,
        background:ad.accent,
        color: ad.isPromo||ad.accent==="#FFD700"||ad.accent==="#00FF00"||ad.accent==="#D4A017" ? "#000" : "#fff",
        fontFamily:"'Black Han Sans',sans-serif",fontSize:9,letterSpacing:1,
        cursor:"pointer",flexShrink:0,whiteSpace:"nowrap",
        boxShadow:`0 2px 8px ${ad.accent}40`,
      }}>
        {ad.cta}
      </button>
    </div>
  );
}

// ── CardAd — full-width sponsored card, dismissable after 3s ─────────────────
function CardAd({ onDismiss, showRewardedOption=false, onWatchAd }) {
  const [ad]       = useState(()=>nextAd("card"));
  const [secs,     setSecs]     = useState(3);
  const [canClose, setCanClose] = useState(false);

  useEffect(()=>{
    const id=setInterval(()=>{
      setSecs(s=>{
        if(s<=1){ setCanClose(true); clearInterval(id); return 0; }
        return s-1;
      });
    },1000);
    return()=>clearInterval(id);
  },[]);

  return(
    <div style={{
      width:"100%",
      background:ad.bg,
      border:`2px solid ${ad.border}50`,
      borderRadius:14,
      padding:"16px 14px",
      display:"flex",flexDirection:"column",gap:10,
      position:"relative",overflow:"hidden",
    }}>
      {/* Sponsored badge */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div style={{fontSize:8,color:"#555",letterSpacing:2,fontFamily:"'Space Mono',monospace"}}>ADVERTISEMENT</div>
        {canClose
          ? <button onClick={onDismiss} style={{background:"none",border:"1px solid #2a2a3a",borderRadius:20,color:"#555",fontSize:11,padding:"2px 10px",cursor:"pointer",fontFamily:"'Black Han Sans',sans-serif",letterSpacing:1}}>✕ CLOSE</button>
          : <div style={{fontSize:10,color:"#555",fontFamily:"'DM Mono',monospace",background:"#1a1d2e",padding:"2px 10px",borderRadius:20}}>Close in {secs}s</div>
        }
      </div>

      {/* Ad content */}
      <div style={{display:"flex",alignItems:"center",gap:12}}>
        <div style={{fontSize:42,filter:`drop-shadow(0 0 12px ${ad.accent}60)`,flexShrink:0}}>
          {ad.logo}
        </div>
        <div style={{flex:1}}>
          <div style={{fontSize:8,color:ad.accent,letterSpacing:2,fontFamily:"'Black Han Sans',sans-serif",marginBottom:3}}>{ad.brand}</div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:17,letterSpacing:1,color:"#f0f0f8",lineHeight:1.2}}>{ad.headline}</div>
          <div style={{fontSize:10,color:"#666",marginTop:4,lineHeight:1.6}}>{ad.sub}</div>
        </div>
      </div>

      {/* CTA + rewarded option */}
      <div style={{display:"flex",gap:8}}>
        <button style={{
          flex:2,padding:"11px 0",border:"none",borderRadius:10,cursor:"pointer",
          background:`linear-gradient(135deg,${ad.accent},${ad.accent}cc)`,
          color:ad.isPromo||ad.accent==="#FFD700"||ad.accent==="#00FF00"||ad.accent==="#D4A017"||ad.accent==="#00CCBC"?"#000":"#fff",
          fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:1,
          boxShadow:`0 4px 14px ${ad.accent}40`,
        }}>
          {ad.cta}
        </button>
        {showRewardedOption&&onWatchAd&&(
          <button onClick={onWatchAd} style={{
            flex:1,padding:"11px 0",border:`1px solid #FFCC0040`,borderRadius:10,cursor:"pointer",
            background:"#FFCC0010",color:"#FFCC00",
            fontFamily:"'Black Han Sans',sans-serif",fontSize:11,letterSpacing:1,
          }}>
            🎰 +BONUS SPIN
          </button>
        )}
      </div>
    </div>
  );
}

// ── InterstitialAd — full screen between rounds, skippable after 5s ───────────
function InterstitialAd({ onSkip, onWatchFull }) {
  const [ad]      = useState(()=>nextAd());
  const [secs,    setSecs]    = useState(5);
  const [canSkip, setCanSkip] = useState(false);
  const [watched, setWatched] = useState(false);

  useEffect(()=>{
    const id=setInterval(()=>{
      setSecs(s=>{
        if(s<=1){
          setCanSkip(true);
          clearInterval(id);
          // Auto-complete rewarded ad after 5s
          setTimeout(()=>setWatched(true),1000);
          return 0;
        }
        return s-1;
      });
    },1000);
    return()=>clearInterval(id);
  },[]);

  return(
    <div style={{
      position:"fixed",inset:0,
      background:"rgba(0,0,0,.96)",
      display:"flex",flexDirection:"column",
      alignItems:"center",justifyContent:"center",
      zIndex:450,padding:24,gap:16,
      animation:"fadeIn .3s ease",
    }}>
      {/* Skip / timer pill */}
      <div style={{position:"absolute",top:16,right:16}}>
        {canSkip
          ? <button onClick={onSkip} style={{padding:"8px 18px",border:"1px solid #2a2a3a",borderRadius:20,background:"#0d0e1a",color:"#f0f0f8",fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,cursor:"pointer"}}>SKIP ›</button>
          : <div style={{padding:"6px 14px",background:"#1a1d2e",borderRadius:20,fontFamily:"'DM Mono',monospace",fontSize:12,color:"#888"}}>Skip in {secs}s</div>
        }
      </div>

      {/* Ad badge */}
      <div style={{fontSize:8,color:"#444",letterSpacing:3,fontFamily:"'Space Mono',monospace"}}>ADVERTISEMENT</div>

      {/* Giant logo */}
      <div style={{fontSize:88,filter:`drop-shadow(0 0 30px ${ad.accent})`,animation:"breathe 2s ease-in-out infinite"}}>
        {ad.logo}
      </div>

      {/* Brand */}
      <div style={{fontSize:11,color:ad.accent,letterSpacing:4,fontFamily:"'Black Han Sans',sans-serif"}}>{ad.brand}</div>

      {/* Headline */}
      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:26,letterSpacing:3,color:"#f0f0f8",textAlign:"center",lineHeight:1.2,textShadow:`0 0 20px ${ad.accent}40`}}>
        {ad.headline}
      </div>

      {/* Sub */}
      <div style={{fontSize:11,color:"#666",textAlign:"center",lineHeight:1.7,maxWidth:280}}>
        {ad.sub}
      </div>

      {/* CTA */}
      <button style={{
        padding:"14px 40px",border:"none",borderRadius:50,cursor:"pointer",
        background:`linear-gradient(135deg,${ad.accent},${ad.accent}cc)`,
        color:ad.isPromo||ad.accent==="#FFD700"||ad.accent==="#00FF00"||ad.accent==="#D4A017"||ad.accent==="#00CCBC"?"#000":"#fff",
        fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,
        boxShadow:`0 6px 24px ${ad.accent}50`,
        marginTop:4,
      }}>
        {ad.cta}
      </button>

      {/* Rewarded bonus */}
      {watched&&onWatchFull&&(
        <button onClick={onWatchFull} style={{
          padding:"10px 28px",border:`2px solid #FFCC0060`,borderRadius:20,cursor:"pointer",
          background:"#FFCC0015",color:"#FFCC00",
          fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:1,
          animation:"popIn .4s ease",boxShadow:"0 0 16px #FFCC0030",
        }}>
          🎰 CLAIM BONUS SPIN (watched full ad)
        </button>
      )}

      {/* Progress bar */}
      {!canSkip&&(
        <div style={{position:"absolute",bottom:0,left:0,right:0,height:3,background:"#1a1d2e"}}>
          <div style={{
            height:"100%",
            background:ad.accent,
            width:`${((5-secs)/5)*100}%`,
            transition:"width 1s linear",
            borderRadius:"0 2px 2px 0",
          }}/>
        </div>
      )}
    </div>
  );
}

// ── RewardedAdNotice — small strip that triggers a rewarded video ──────────────
function RewardedAdNotice({ onWatch }) {
  return(
    <div onClick={onWatch} style={{
      display:"flex",alignItems:"center",gap:10,
      padding:"9px 13px",
      background:"#FFCC0010",border:"1px solid #FFCC0030",
      borderRadius:10,cursor:"pointer",transition:"all .15s",
    }}
    onMouseOver={e=>{e.currentTarget.style.background="#FFCC0018";e.currentTarget.style.borderColor="#FFCC0060";}}
    onMouseOut={e=>{e.currentTarget.style.background="#FFCC0010";e.currentTarget.style.borderColor="#FFCC0030";}}>
      <span style={{fontSize:20,flexShrink:0}}>🎬</span>
      <div style={{flex:1}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:"#FFCC00",letterSpacing:1}}>WATCH AN AD · EARN A BONUS SPIN</div>
        <div style={{fontSize:9,color:"#555",marginTop:1}}>5 second ad · get a free 🎰 daily spin token</div>
      </div>
      <div style={{fontSize:12,color:"#FFCC00",flexShrink:0}}>▶</div>
    </div>
  );
}


// ── BetLobby — shown inside WaitingScreen for the host and players ────────────
// ═══════════════════════════════════════════════════════════════════════════════
// MULTI-CITY LOBBY BROWSER
// ─────────────────────────────────────────────────────────────────────────────
// Shows all active games across all regions, filterable by city.
// Reads from Firebase: lobby/{regionId}_{gameCode}
// Refreshes via real-time subscription — new games appear instantly.
// ═══════════════════════════════════════════════════════════════════════════════

function useLobbyGames() {
  const [games,   setGames]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [error,   setError]   = useState(null);

  useEffect(() => {
    setLoading(true);
    const unsub = subscribe("lobby", data => {
      if (!data) { setGames([]); setLoading(false); return; }
      const list = Object.values(data)
        .filter(g => g.status !== "ended")
        .sort((a,b) => (b.updatedAt||0) - (a.updatedAt||0));
      setGames(list);
      setLoading(false);
    });
    return unsub;
  }, []);

  return { games, loading, error };
}

function LobbyBrowser({ onJoinGame, onHostGame, onBack }) {
  const { games, loading } = useLobbyGames();
  const [selRegion,  setSelRegion]  = useState("all");
  const [selDiff,    setSelDiff]    = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [hostFlow,   setHostFlow]   = useState(false); // show region picker for hosting
  const [joinTarget, setJoinTarget] = useState(null);  // game being joined

  const filtered = games.filter(g => {
    if(selRegion !== "all" && g.regionId !== selRegion) return false;
    if(selDiff   !== "all" && g.difficulty !== selDiff)  return false;
    if(searchTerm && !g.title?.toLowerCase().includes(searchTerm.toLowerCase()) &&
       !g.gameCode?.toUpperCase().includes(searchTerm.toUpperCase())) return false;
    return true;
  });

  const activeRegions = [...new Set(games.map(g=>g.regionId))].filter(Boolean);
  const regionCounts  = Object.fromEntries(
    REGIONS.map(r=>[r.id, games.filter(g=>g.regionId===r.id).length])
  );
  const totalPlayers = games.reduce((s,g)=>s+(g.playerCount||0),0);

  if (hostFlow) return (
    <RegionPicker
      onSelect={(region, gameTitle) => onHostGame(region, gameTitle)}
      onBack={()=>setHostFlow(false)}
    />
  );

  return (
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>

      {/* Header */}
      <div style={{textAlign:"center"}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:24,letterSpacing:3,color:"#f0f0f8"}}>🌍 GLOBAL LOBBY</div>
        <div style={{fontSize:11,color:"#555",marginTop:4}}>
          {loading?"Scanning cities...":`${games.length} active crawl${games.length!==1?"s":""} · ${totalPlayers} players online`}
        </div>
      </div>

      {/* Host button */}
      <button onClick={()=>setHostFlow(true)} style={{...S.card,border:"2px solid #FF2D5540",cursor:"pointer",display:"flex",gap:14,alignItems:"center",background:"#FF2D5508",width:"100%",textAlign:"left"}}>
        <span style={{fontSize:32}}>👑</span>
        <div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1,color:"#FF2D55"}}>HOST A NEW GAME</div>
          <div style={{fontSize:11,color:"#555",marginTop:2}}>Pick your city · set the rules · share the link</div>
        </div>
        <span style={{marginLeft:"auto",color:"#FF2D55",fontSize:18}}>›</span>
      </button>

      {/* Region filter pills */}
      <div style={{display:"flex",gap:6,overflowX:"auto",paddingBottom:4,scrollbarWidth:"none"}}>
        <button onClick={()=>setSelRegion("all")} style={{padding:"6px 14px",borderRadius:20,border:`1px solid ${selRegion==="all"?"#FF2D55":"#2a2a3a"}`,background:selRegion==="all"?"#FF2D5515":"#0d0e1a",color:selRegion==="all"?"#FF2D55":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:10,cursor:"pointer",flexShrink:0}}>
          ALL CITIES{games.length>0&&` (${games.length})`}
        </button>
        {REGIONS.filter(r=>activeRegions.includes(r.id)||(r.id==="london"||r.id==="nyc")).map(r=>(
          <button key={r.id} onClick={()=>setSelRegion(r.id)} style={{padding:"6px 14px",borderRadius:20,border:`1px solid ${selRegion===r.id?"#FF2D55":"#2a2a3a"}`,background:selRegion===r.id?"#FF2D5515":"#0d0e1a",color:selRegion===r.id?"#FF2D55":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:10,cursor:"pointer",flexShrink:0,whiteSpace:"nowrap"}}>
            {r.flag} {r.name}{regionCounts[r.id]>0&&` (${regionCounts[r.id]})`}
          </button>
        ))}
      </div>

      {/* Search + difficulty filter */}
      <div style={{display:"flex",gap:8}}>
        <input value={searchTerm} onChange={e=>setSearchTerm(e.target.value)}
          placeholder="Search by name or code…"
          style={{flex:1,background:"#0d0e1a",border:"1px solid #2a2a3a",borderRadius:10,color:"#f0f0f8",fontFamily:"'Black Han Sans',sans-serif",fontSize:13,padding:"9px 14px",outline:"none"}}/>
        <select value={selDiff} onChange={e=>setSelDiff(e.target.value)}
          style={{background:"#0d0e1a",border:"1px solid #2a2a3a",borderRadius:10,color:"#888",fontFamily:"'Black Han Sans',sans-serif",fontSize:12,padding:"9px 10px",cursor:"pointer",outline:"none"}}>
          <option value="all">ALL LEVELS</option>
          {Object.entries(DIFFICULTY_LEVELS).map(([id,d])=>(
            <option key={id} value={id}>{d.icon} {d.label}</option>
          ))}
        </select>
      </div>

      {/* Game list */}
      {loading && (
        <div style={{textAlign:"center",padding:"30px 0",display:"flex",flexDirection:"column",gap:8,alignItems:"center"}}>
          <div style={{fontSize:32,animation:"spin 1.5s linear infinite"}}>🌍</div>
          <div style={{fontSize:12,color:"#555"}}>Scanning cities…</div>
        </div>
      )}

      {!loading && filtered.length===0 && (
        <div style={{...S.card,textAlign:"center",padding:"28px 16px"}}>
          <div style={{fontSize:36,marginBottom:8}}>🏙️</div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1,color:"#f0f0f8",marginBottom:6}}>
            {games.length===0?"NO ACTIVE CRAWLS":"NO MATCHES"}
          </div>
          <div style={{fontSize:11,color:"#555",lineHeight:1.7,marginBottom:14}}>
            {games.length===0
              ?"Be the first to host a game in your city!"
              :"Try a different filter or search term."}
          </div>
          <button onClick={()=>setHostFlow(true)} style={{...S.btnPrimary}}>👑 HOST A GAME</button>
        </div>
      )}

      {filtered.map(g => {
        const region = REGIONS.find(r=>r.id===g.regionId)||{flag:"🌍",name:g.regionId||"Unknown"};
        const diff   = DIFFICULTY_LEVELS[g.difficulty||"intermediate"]||DIFFICULTY_LEVELS.intermediate;
        const age    = Math.floor((Date.now()-(g.updatedAt||Date.now()))/60000);
        return (
          <div key={`${g.regionId}_${g.gameCode}`} style={{...S.card,border:`1px solid ${diff.color}30`,display:"flex",flexDirection:"column",gap:10}}>
            <div style={{display:"flex",alignItems:"flex-start",gap:10}}>
              <div style={{fontSize:28,flexShrink:0}}>{region.flag}</div>
              <div style={{flex:1}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:15,letterSpacing:1,color:"#f0f0f8"}}>{g.title||`${region.name} Crawl`}</div>
                <div style={{fontSize:10,color:"#555",marginTop:2,display:"flex",gap:8,flexWrap:"wrap"}}>
                  <span>{region.flag} {region.name}</span>
                  <span>🎮 Code: <strong style={{color:"#FF2D55",letterSpacing:1}}>{g.gameCode}</strong></span>
                  <span>👥 {g.playerCount||0} player{g.playerCount!==1?"s":""}</span>
                  {age>0&&<span>🕐 {age}m ago</span>}
                </div>
              </div>
              <span style={{fontSize:8,padding:"3px 8px",borderRadius:10,background:`${diff.color}20`,border:`1px solid ${diff.color}40`,color:diff.color,fontFamily:"'Black Han Sans',sans-serif",letterSpacing:1,whiteSpace:"nowrap",flexShrink:0}}>{diff.icon} {diff.label}</span>
            </div>

            {/* Player count bar */}
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <div style={{flex:1,height:4,background:"#1a1d2e",borderRadius:2,overflow:"hidden"}}>
                <div style={{height:"100%",width:`${Math.min(100,((g.playerCount||0)/20)*100)}%`,background:`linear-gradient(90deg,${diff.color},${diff.color}aa)`,borderRadius:2,transition:"width .4s"}}/>
              </div>
              <span style={{fontSize:9,color:"#555",flexShrink:0}}>{g.playerCount||0}/20</span>
            </div>

            <button onClick={()=>onJoinGame(g.regionId, g.gameCode)} style={{...S.btnPrimary,background:`linear-gradient(135deg,${diff.color},${diff.color}cc)`,color:g.difficulty==="beginner"||g.difficulty==="intermediate"?"#000":"#fff",padding:"11px 0",fontSize:15}}>
              🚪 JOIN THIS CRAWL
            </button>
          </div>
        );
      })}

      {/* Stats footer */}
      {!loading&&games.length>0&&(
        <div style={{...S.card,background:"#0a0c14",display:"flex",justifyContent:"space-around"}}>
          {[
            {v:games.length,         l:"Active Crawls"},
            {v:totalPlayers,         l:"Players Online"},
            {v:activeRegions.length, l:"Cities"},
          ].map((s,i)=>(
            <div key={i} style={{textAlign:"center"}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:"#FF2D55"}}>{s.v}</div>
              <div style={{fontSize:9,color:"#555",letterSpacing:1}}>{s.l}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Region picker — shown when hosting a new game ─────────────────────────────
function RegionPicker({ onSelect, onBack }) {
  const [selRegion, setSelRegion] = useState(null);
  const [gameTitle, setGameTitle] = useState("");
  const [customCity,setCustomCity]= useState("");
  const region = REGIONS.find(r=>r.id===selRegion);

  return (
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,letterSpacing:2,color:"#f0f0f8",textAlign:"center"}}>📍 PICK YOUR CITY</div>
      <div style={{fontSize:11,color:"#555",textAlign:"center"}}>Choose the city where your crawl is happening</div>

      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
        {REGIONS.map(r=>(
          <button key={r.id} onClick={()=>setSelRegion(r.id)} style={{display:"flex",alignItems:"center",gap:10,padding:"12px 14px",border:`2px solid ${selRegion===r.id?"#FF2D55":"#1a1d2e"}`,borderRadius:12,background:selRegion===r.id?"#FF2D5515":"#0d0e1a",cursor:"pointer",textAlign:"left"}}>
            <span style={{fontSize:22,flexShrink:0}}>{r.flag}</span>
            <div>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:selRegion===r.id?"#FF2D55":"#f0f0f8"}}>{r.name}</div>
            </div>
            {selRegion===r.id&&<span style={{marginLeft:"auto",color:"#FF2D55"}}>✓</span>}
          </button>
        ))}
      </div>

      {selRegion==="custom"&&(
        <input value={customCity} onChange={e=>setCustomCity(e.target.value)}
          placeholder="Enter your city name…" maxLength={30}
          style={{...S.input,textAlign:"center"}}/>
      )}

      {selRegion&&(
        <>
          <div style={{fontSize:10,color:"#555",letterSpacing:2}}>GAME NAME (optional)</div>
          <input value={gameTitle} onChange={e=>setGameTitle(e.target.value)}
            placeholder={`${region?.name||""} Friday Night Crawl`} maxLength={40}
            style={S.input}/>
          <button onClick={()=>onSelect(selRegion, gameTitle.trim()||(customCity.trim()||region?.name)+` Crawl`)}
            style={{...S.btnPrimary,width:"100%"}}>
            {region?.flag} HOST IN {(customCity.trim()||region?.name||"").toUpperCase()} →
          </button>
        </>
      )}
    </div>
  );
}


function BetLobby({ game, myId, myName, onPlaceBet, onAcceptBet, onDeclineBet }) {
  const [open,       setOpen]       = useState(false);
  const [step,       setStep]       = useState(1); // 1=type 2=target 3=amount 4=confirm
  const [betType,    setBetType]    = useState(null);
  const [targetId,   setTargetId]   = useState(null);
  const [amtCoins,   setAmtCoins]   = useState(50);
  const [amtCash,    setAmtCash]    = useState(null); // null = coins only
  const [currency,   setCurrency]   = useState("coins");
  const [customText, setCustomText] = useState("");

  const players  = Object.values(game?.players||{}).filter(p=>p.id!==myId);
  const bets     = game?.bets||[];
  const myBets   = bets.filter(b=>b.fromId===myId||b.toId===myId);
  const pending  = myBets.filter(b=>b.status==="pending"&&b.toId===myId);
  const active   = myBets.filter(b=>b.status==="accepted");
  const player   = game?.players?.[myId];
  const target   = game?.players?.[targetId];
  const bt       = BET_TYPES.find(b=>b.id===betType);

  const canAfford = currency==="coins" ? (player?.coins||0)>=amtCoins : true;

  const resetFlow = () => { setOpen(false);setStep(1);setBetType(null);setTargetId(null);setAmtCoins(50);setAmtCash(null);setCurrency("coins");setCustomText(""); };

  const submitBet = () => {
    if(!betType||!targetId) return;
    const totalPool  = currency==="coins" ? amtCoins*2 : 0;
    const rakeCoins  = currency==="coins" ? Math.max(1,Math.round(totalPool*DEV_RAKE_PCT)) : 0;
    const rakeCash   = currency==="cash"  ? parseFloat((amtCash*DEV_RAKE_PCT).toFixed(2))  : 0;
    const winnerGets = currency==="coins" ? totalPool - rakeCoins : amtCoins;
    onPlaceBet({
      id:          uid(),
      type:        betType,
      fromId:      myId,
      fromName:    myName,
      fromAvatar:  player?.avatar||"🍺",
      toId:        targetId,
      toName:      target?.name||"Player",
      toAvatar:    target?.avatar||"🍺",
      amountCoins: currency==="coins"?amtCoins:0,
      amountCash:  currency==="cash"?amtCash:null,
      currency,
      rakeCoins,
      rakeCash,
      winnerGetsCoins: currency==="coins"?winnerGets:0,
      condition:   betType==="custom"?customText:bt?.desc||"",
      betLabel:    bt?.label||"Custom",
      auto:        bt?.auto||false,
      status:      "pending",
      createdAt:   Date.now(),
    });
    resetFlow();
  };

  return (
    <div style={{width:"100%",display:"flex",flexDirection:"column",gap:8}}>
      {/* Header */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:2,color:"#FFCC00"}}>🤝 FRIENDLY BETS</div>
          <div style={{fontSize:9,color:"#555",marginTop:1}}>Opt-in · between consenting players · your call</div>
        </div>
        <button onClick={()=>setOpen(o=>!o)} style={{padding:"6px 14px",border:`1px solid ${open?"#FFCC00":"#2a2a3a"}`,borderRadius:20,background:open?"#FFCC0015":"#0d0e1a",color:open?"#FFCC00":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:11,letterSpacing:1,cursor:"pointer"}}>
          {open?"CLOSE":"+ NEW BET"}
        </button>
      </div>

      {/* Pending bets for you */}
      {pending.map(bet=>(
        <div key={bet.id} style={{background:"#FF950012",border:"2px solid #FF9500",borderRadius:12,padding:"12px 14px",display:"flex",flexDirection:"column",gap:8,animation:"popIn .3s ease"}}>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <span style={{fontSize:20}}>{bet.fromAvatar}</span>
            <div style={{flex:1}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:"#FF9500"}}>{bet.fromName} challenges you!</div>
              <div style={{fontSize:10,color:"#888",marginTop:2}}>{BET_TYPES.find(b=>b.id===bet.type)?.e} {bet.betLabel} — {bet.condition}</div>
            </div>
            <div style={{textAlign:"right"}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:"#FFCC00"}}>
                {bet.currency==="cash"?`$${bet.amountCash}`:`🪙${bet.amountCoins}`}
              </div>
            </div>
          </div>
          <div style={{display:"flex",gap:6}}>
            <button onClick={()=>onDeclineBet(bet.id)} style={{flex:1,padding:"8px 0",border:"1px solid #FF2D5540",borderRadius:10,background:"#FF2D5512",color:"#FF2D55",fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,cursor:"pointer"}}>✕ DECLINE</button>
            <button onClick={()=>onAcceptBet(bet.id)} style={{flex:2,padding:"9px 0",border:"none",borderRadius:10,background:"linear-gradient(135deg,#34C759,#00C7BE)",color:"#000",fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,cursor:"pointer"}}>✓ ACCEPT BET</button>
          </div>
        </div>
      ))}

      {/* Active accepted bets */}
      {active.length>0&&(
        <div style={{display:"flex",flexDirection:"column",gap:5}}>
          <div style={{fontSize:9,color:"#555",letterSpacing:3}}>ACTIVE BETS ({active.length})</div>
          {active.map(bet=>{
            const isFrom=bet.fromId===myId;
            const opponentName=isFrom?bet.toName:bet.fromName;
            const opponentAv  =isFrom?bet.toAvatar:bet.fromAvatar;
            return(
              <div key={bet.id} style={{display:"flex",alignItems:"center",gap:9,padding:"9px 12px",background:"#FFCC0010",border:"1px solid #FFCC0030",borderRadius:10}}>
                <span style={{fontSize:18}}>{BET_TYPES.find(b=>b.id===bet.type)?.e||"🤝"}</span>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,letterSpacing:1,color:"#FFCC00"}}>
                    {bet.betLabel} vs {opponentAv} {opponentName}
                  </div>
                  <div style={{fontSize:9,color:"#555",marginTop:1}}>{bet.condition.slice(0,45)}{bet.condition.length>45?"...":""}</div>
                </div>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:15,color:"#FFCC00"}}>
                  {bet.currency==="cash"?`$${bet.amountCash}`:`🪙${bet.amountCoins}`}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Bet creation flow */}
      {open&&(
        <div style={{background:"#0d0e1a",border:"2px solid #FFCC0040",borderRadius:14,padding:"14px",display:"flex",flexDirection:"column",gap:12,animation:"slideUp .2s ease"}}>

          {/* Progress steps */}
          <div style={{display:"flex",alignItems:"center",gap:0}}>
            {["TYPE","TARGET","AMOUNT","CONFIRM"].map((label,i)=>{
              const done=step>i+1, current=step===i+1;
              return(
                <div key={label} style={{display:"flex",alignItems:"center",flex:i<3?1:"auto"}}>
                  <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2}}>
                    <div style={{width:22,height:22,borderRadius:"50%",background:done?"#34C759":current?"#FFCC00":"#1a1d2e",border:`1px solid ${done?"#34C759":current?"#FFCC00":"#2a2a3a"}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,color:done||current?"#000":"#555",fontFamily:"'Black Han Sans',sans-serif"}}>
                      {done?"✓":i+1}
                    </div>
                    <span style={{fontSize:7,color:current?"#FFCC00":"#555",letterSpacing:1}}>{label}</span>
                  </div>
                  {i<3&&<div style={{flex:1,height:1,background:done?"#34C75950":"#1a1d2e",margin:"0 4px",marginBottom:14}}/>}
                </div>
              );
            })}
          </div>

          {/* Step 1 — pick bet type */}
          {step===1&&(
            <>
              <div style={{fontSize:9,color:"#555",letterSpacing:3}}>WHAT ARE YOU BETTING ON?</div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6}}>
                {BET_TYPES.map(bt=>(
                  <button key={bt.id} onClick={()=>{setBetType(bt.id);setStep(2);}} style={{display:"flex",flexDirection:"column",gap:4,padding:"11px 10px",border:`2px solid ${betType===bt.id?"#FFCC00":"#1a1d2e"}`,borderRadius:11,background:betType===bt.id?"#FFCC0015":"#12121a",cursor:"pointer",textAlign:"left"}}>
                    <span style={{fontSize:22}}>{bt.e}</span>
                    <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,letterSpacing:1,color:betType===bt.id?"#FFCC00":"#f0f0f8"}}>{bt.label}</div>
                    <div style={{fontSize:9,color:"#555",lineHeight:1.3}}>{bt.desc.slice(0,40)}</div>
                    {!bt.auto&&<span style={{fontSize:8,padding:"1px 6px",borderRadius:8,background:"#BF5AF220",border:"1px solid #BF5AF240",color:"#BF5AF2",alignSelf:"flex-start"}}>MANUAL</span>}
                  </button>
                ))}
              </div>
            </>
          )}

          {/* Step 2 — pick target */}
          {step===2&&(
            <>
              <div style={{fontSize:9,color:"#555",letterSpacing:3}}>WHO ARE YOU BETTING AGAINST?</div>
              {players.length===0&&<div style={{fontSize:11,color:"#555",textAlign:"center",padding:12}}>No other players yet — share the game code first!</div>}
              {players.map(p=>(
                <button key={p.id} onClick={()=>{setTargetId(p.id);setStep(3);}} style={{display:"flex",alignItems:"center",gap:10,padding:"12px 14px",border:`2px solid ${targetId===p.id?"#FFCC00":"#1a1d2e"}`,borderRadius:11,background:targetId===p.id?"#FFCC0015":"#12121a",cursor:"pointer",textAlign:"left"}}>
                  <span style={{fontSize:26}}>{p.avatar}</span>
                  <div style={{flex:1}}>
                    <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:1,color:targetId===p.id?"#FFCC00":"#f0f0f8"}}>{p.name}</div>
                    <div style={{fontSize:10,color:"#555"}}>🪙{p.coins} coins</div>
                  </div>
                  {targetId===p.id&&<span style={{color:"#FFCC00",fontSize:18}}>✓</span>}
                </button>
              ))}
              <button onClick={()=>setStep(1)} style={{...S.btnGhost,alignSelf:"flex-start"}}>← BACK</button>
            </>
          )}

          {/* Step 3 — amount + currency */}
          {step===3&&(
            <>
              <div style={{fontSize:9,color:"#555",letterSpacing:3}}>SET THE STAKES</div>

              {/* Currency toggle */}
              <div style={{display:"flex",background:"#0a0a12",border:"1px solid #1a1d2e",borderRadius:10,overflow:"hidden"}}>
                {[["coins","🪙 COINS"],["cash","💵 CASH"]].map(([id,label])=>(
                  <button key={id} onClick={()=>setCurrency(id)} style={{flex:1,padding:"10px 0",border:"none",background:currency===id?"#FFCC0020":"transparent",color:currency===id?"#FFCC00":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,cursor:"pointer",transition:"all .15s"}}>
                    {label}
                  </button>
                ))}
              </div>

              {currency==="coins"&&(
                <>
                  <div style={{fontSize:11,color:"#888"}}>Coins deducted from your inventory at game start</div>
                  <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                    {CHALLENGE_AMOUNTS.map(a=>(
                      <button key={a} onClick={()=>setAmtCoins(a)} style={{flex:1,minWidth:60,padding:"12px 4px",border:`2px solid ${amtCoins===a?"#FFCC00":"#1a1d2e"}`,borderRadius:10,background:amtCoins===a?"#FFCC0015":"#12121a",color:amtCoins===a?"#FFCC00":"#888",fontFamily:"'Black Han Sans',sans-serif",fontSize:17,cursor:"pointer"}}>
                        🪙{a}
                      </button>
                    ))}
                  </div>
                  {/* Custom amount slider */}
                  <div style={{display:"flex",alignItems:"center",gap:10}}>
                    <span style={{fontSize:9,color:"#555",letterSpacing:2,flexShrink:0}}>CUSTOM</span>
                    <input type="range" min={BET_MIN_COINS} max={Math.min(player?.coins||500,500)} step={25} value={amtCoins}
                      onChange={e=>setAmtCoins(parseInt(e.target.value))}
                      style={{flex:1,accentColor:"#FFCC00"}}/>
                    <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#FFCC00",minWidth:48}}>🪙{amtCoins}</span>
                  </div>
                  {!canAfford&&<div style={{fontSize:11,color:"#FF2D55"}}>⚠️ You only have 🪙{player?.coins} — reduce the bet</div>}
                </>
              )}

              {currency==="cash"&&(
                <>
                  <div style={{fontSize:11,color:"#888",lineHeight:1.7}}>💵 Cash bets are settled in person between players after the game. CrawlFire does not process or hold cash — this is a friendly agreement only.</div>
                  <div style={{background:"#FF950015",border:"1px solid #FF950030",borderRadius:10,padding:"9px 12px",fontSize:10,color:"#FF9500",lineHeight:1.7}}>
                    ⚠️ Cash bets are friendly wagers between consenting adults. Ensure all parties agree. CrawlFire is not liable for cash bet disputes.
                  </div>
                  <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                    {CHALLENGE_AMOUNTS.map(a=>(
                      <button key={a} onClick={()=>setAmtCash(a)} style={{flex:1,padding:"12px 4px",border:`2px solid ${amtCash===a?"#34C759":"#1a1d2e"}`,borderRadius:10,background:amtCash===a?"#34C75915":"#12121a",color:amtCash===a?"#34C759":"#888",fontFamily:"'Black Han Sans',sans-serif",fontSize:16,cursor:"pointer"}}>
                        ${a}
                      </button>
                    ))}
                  </div>
                  {/* Custom cash slider */}
                  <div style={{display:"flex",alignItems:"center",gap:10}}>
                    <span style={{fontSize:9,color:"#555",letterSpacing:2,flexShrink:0}}>CUSTOM</span>
                    <input type="range" min={1} max={50} step={1} value={amtCash||1}
                      onChange={e=>setAmtCash(parseInt(e.target.value))}
                      style={{flex:1,accentColor:"#34C759"}}/>
                    <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#34C759",minWidth:36}}>${amtCash||1}</span>
                  </div>
                </>
              )}

              {/* Custom bet text input */}
              {betType==="custom"&&(
                <div style={{display:"flex",flexDirection:"column",gap:6}}>
                  <div style={{fontSize:9,color:"#555",letterSpacing:2}}>DESCRIBE YOUR BET CONDITION</div>
                  <textarea value={customText} onChange={e=>setCustomText(e.target.value.slice(0,120))} placeholder={"e.g. I'll get more kills at The Rusty Anchor than you..."} maxLength={120}
                    style={{background:"#12121a",border:"1px solid #2a2a3a",borderRadius:10,color:"#f0f0f8",fontFamily:"'Space Mono',monospace",fontSize:11,padding:"10px 12px",outline:"none",resize:"none",height:60,lineHeight:1.6,width:"100%"}}/>
                  <div style={{fontSize:9,color:"#444",textAlign:"right"}}>{customText.length}/120</div>
                </div>
              )}

              <div style={{display:"flex",gap:8}}>
                <button onClick={()=>setStep(2)} style={{...S.btnGhost,flex:1}}>← BACK</button>
                <button onClick={()=>setStep(4)} disabled={currency==="coins"?!canAfford:!amtCash} style={{flex:2,padding:12,border:"none",borderRadius:11,background:(currency==="coins"?canAfford:amtCash)?"linear-gradient(135deg,#FFCC00,#FF9500)":"#1a1d2e",color:(currency==="coins"?canAfford:amtCash)?"#000":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:15,letterSpacing:1,cursor:(currency==="coins"?canAfford:amtCash)?"pointer":"not-allowed"}}>
                  REVIEW →
                </button>
              </div>
            </>
          )}

          {/* Step 4 — confirm */}
          {step===4&&bt&&target&&(
            <>
              <div style={{background:"#FFCC0010",border:"1px solid #FFCC0040",borderRadius:12,padding:"14px 16px",display:"flex",flexDirection:"column",gap:10}}>
                <div style={{display:"flex",alignItems:"center",gap:10}}>
                  <span style={{fontSize:28}}>{bt.e}</span>
                  <div style={{flex:1}}>
                    <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:15,color:"#FFCC00",letterSpacing:1}}>{bt.label}</div>
                    <div style={{fontSize:10,color:"#888",marginTop:2}}>{betType==="custom"?customText:bt.desc}</div>
                  </div>
                </div>
                <div style={{display:"flex",gap:8}}>
                  {[
                    {l:"YOU",v:`${player?.avatar} ${myName}`,c:"#FF2D55"},
                    {l:"VS",v:"⚔️",c:"#888"},
                    {l:"THEM",v:`${target.avatar} ${target.name}`,c:"#007AFF"},
                  ].map((x,i)=>(
                    <div key={i} style={{flex:1,textAlign:"center",background:"#12121a",borderRadius:10,padding:"8px 4px"}}>
                      <div style={{fontSize:9,color:x.c,letterSpacing:1,marginBottom:3}}>{x.l}</div>
                      <div style={{fontSize:12,color:"#f0f0f8"}}>{x.v}</div>
                    </div>
                  ))}
                </div>
                {/* Rake-aware breakdown */}
                {(()=>{
                  const totalPool  = currency==="coins"?amtCoins*2:0;
                  const rakeCoins  = currency==="coins"?Math.max(1,Math.round(totalPool*DEV_RAKE_PCT)):0;
                  const rakeCash   = currency==="cash" ?parseFloat((amtCash*DEV_RAKE_PCT).toFixed(2)):0;
                  const winnerGets = currency==="coins"?totalPool-rakeCoins:amtCoins;
                  return(
                    <div style={{textAlign:"center",borderTop:"1px solid #2a2a3a",paddingTop:10,display:"flex",flexDirection:"column",gap:6}}>
                      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:26,color:"#FFCC00"}}>
                        {currency==="cash"?`$${amtCash}`:(`🪙${amtCoins}`)}
                        <span style={{fontSize:11,color:"#888",marginLeft:6}}>each</span>
                      </div>
                      <div style={{display:"flex",flexDirection:"column",gap:3}}>
                        {currency==="coins"&&<>
                          <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:"#888",padding:"3px 10px"}}>
                            <span>Total pot</span><span style={{color:"#FFCC00"}}>🪙{totalPool}</span>
                          </div>
                          <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:"#888",padding:"3px 10px"}}>
                            <span>CrawlFire rake ({DEV_RAKE_LABEL})</span><span style={{color:"#FF9500"}}>-🪙{rakeCoins}</span>
                          </div>
                          <div style={{display:"flex",justifyContent:"space-between",fontSize:11,fontFamily:"'Black Han Sans',sans-serif",padding:"5px 10px",background:"#34C75910",borderRadius:8,border:"1px solid #34C75930"}}>
                            <span style={{color:"#34C759"}}>Winner receives</span><span style={{color:"#34C759"}}>🪙{winnerGets}</span>
                          </div>
                        </>}
                        {currency==="cash"&&<>
                          <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:"#888",padding:"3px 10px"}}>
                            <span>CrawlFire rake ({DEV_RAKE_LABEL})</span><span style={{color:"#FF9500"}}>~🪙{Math.max(1,Math.round(rakeCash*20))} coins</span>
                          </div>
                          <div style={{fontSize:9,color:"#555",padding:"4px 10px",lineHeight:1.6}}>Cash settled in person · rake charged as coins to both players</div>
                        </>}
                      </div>
                      {!bt.auto&&<div style={{fontSize:9,color:"#BF5AF2",marginTop:2}}>⚠️ Custom bet — resolved manually between players</div>}
                      <div style={{fontSize:8,color:"#333",lineHeight:1.6}}>By placing this bet you acknowledge the {DEV_RAKE_LABEL} CrawlFire platform fee</div>
                    </div>
                  );
                })()}
              </div>
              <div style={{display:"flex",gap:8}}>
                <button onClick={()=>setStep(3)} style={{...S.btnGhost,flex:1}}>← BACK</button>
                <button onClick={submitBet} style={{flex:2,padding:12,border:"none",borderRadius:11,background:"linear-gradient(135deg,#FFCC00,#FF9500)",color:"#000",fontFamily:"'Black Han Sans',sans-serif",fontSize:15,letterSpacing:1,cursor:"pointer",boxShadow:"0 4px 16px #FFCC0040"}}>
                  🤝 SEND CHALLENGE
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ── Bet resolution overlay — shown at game over ───────────────────────────────
function BetResolution({ game, myId }) {
  const bets    = (game?.bets||[]).filter(b=>(b.fromId===myId||b.toId===myId)&&b.status==="accepted");
  const players = game?.players||{};
  if(!bets.length) return null;

  const resolve = (bet) => {
    const me    = players[myId];
    const them  = players[bet.fromId===myId?bet.toId:bet.fromId];
    if(!me||!them) return {result:"pending",label:"Pending resolution"};
    switch(bet.type){
      case "first_kill": {
        const firstKillEvt=(game.events||[]).find(e=>e.type==="kill");
        if(!firstKillEvt) return{result:"pending",label:"No kills recorded"};
        const won=firstKillEvt.from===myId;
        return{result:won?"win":"loss",label:won?"You got the first kill! 🎯":"They got the first kill"};
      }
      case "most_kills": {
        const won=me.kills>them.kills;
        const tied=me.kills===them.kills;
        return{result:tied?"tie":won?"win":"loss",label:tied?`Tied at ${me.kills} kills`:`${won?"You":"They"} had more kills (${me.kills} vs ${them.kills})`};
      }
      case "survive": {
        const won=me.alive&&!them.alive;
        const tied=me.alive===them.alive;
        return{result:tied?"tie":won?"win":"loss",label:tied?"Both survived / both eliminated":won?"You outlasted them!":"They outlasted you"};
      }
      case "flag_capture": {
        const myCtf  =(game.ctfPlayers||{})[myId]||{captures:0};
        const thCtf  =(game.ctfPlayers||{})[them.id]||{captures:0};
        const won=myCtf.captures>thCtf.captures;
        const tied=myCtf.captures===thCtf.captures;
        return{result:tied?"tie":won?"win":"loss",label:tied?`Tied (${myCtf.captures} caps each)`:`${won?"You":"They"} captured more flags`};
      }
      case "musician": {
        const myFound =(game.hunt?.players||{})[myId]?.found?.length||0;
        const thFound =(game.hunt?.players||{})[them.id]?.found?.length||0;
        const won=myFound>thFound;
        const tied=myFound===thFound;
        return{result:tied?"tie":won?"win":"loss",label:tied?`Tied (${myFound} musicians each)`:`${won?"You":"They"} found more musicians`};
      }
      default: return{result:"pending",label:"Settle this one in person 🤝"};
    }
  };

  return(
    <div style={{width:"100%",display:"flex",flexDirection:"column",gap:8}}>
      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:3,color:"#FFCC00"}}>🤝 BET RESOLUTION</div>
      {bets.map(bet=>{
        const isFrom=bet.fromId===myId;
        const opponent=players[isFrom?bet.toId:bet.fromId];
        const {result,label}=resolve(bet);
        const rc=result==="win"?"#34C759":result==="loss"?"#FF2D55":result==="tie"?"#FFCC00":"#888";
        return(
          <div key={bet.id} style={{background:`${rc}10`,border:`2px solid ${rc}40`,borderRadius:12,padding:"13px 14px",display:"flex",flexDirection:"column",gap:7}}>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <span style={{fontSize:22}}>{BET_TYPES.find(b=>b.id===bet.type)?.e||"🤝"}</span>
              <div style={{flex:1}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:rc}}>
                  {result==="win"?"🏆 YOU WIN THE BET!":result==="loss"?"💸 YOU LOST THE BET":result==="tie"?"🤝 IT'S A TIE":"⏳ PENDING"}
                </div>
                <div style={{fontSize:10,color:"#888",marginTop:2}}>{bet.betLabel} vs {opponent?.avatar} {opponent?.name}</div>
              </div>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:rc}}>
                {bet.currency==="cash"?`$${bet.amountCash}`:`🪙${bet.amountCoins}`}
              </div>
            </div>
            <div style={{fontSize:10,color:"#888",background:"#12121a",borderRadius:8,padding:"6px 10px"}}>{label}</div>
            {result==="pending"&&<div style={{fontSize:10,color:"#BF5AF2"}}>This bet was custom — agree on the result in person.</div>}
            {result==="win"&&bet.currency==="coins"&&(
              <div style={{display:"flex",flexDirection:"column",gap:3,padding:"6px 10px",background:"#34C75910",border:"1px solid #34C75930",borderRadius:8}}>
                <div style={{display:"flex",justifyContent:"space-between",fontSize:10}}><span style={{color:"#555"}}>Total pot</span><span style={{color:"#FFCC00"}}>🪙{bet.amountCoins*2}</span></div>
                <div style={{display:"flex",justifyContent:"space-between",fontSize:10}}><span style={{color:"#555"}}>CrawlFire rake ({DEV_RAKE_LABEL})</span><span style={{color:"#FF9500"}}>-🪙{bet.rakeCoins||Math.max(1,Math.round(bet.amountCoins*2*DEV_RAKE_PCT))}</span></div>
                <div style={{display:"flex",justifyContent:"space-between",fontSize:11,fontFamily:"'Black Han Sans',sans-serif"}}><span style={{color:"#34C759"}}>You receive</span><span style={{color:"#34C759"}}>🪙{bet.winnerGetsCoins||bet.amountCoins*2-Math.max(1,Math.round(bet.amountCoins*2*DEV_RAKE_PCT))}</span></div>
              </div>
            )}
            {result==="win"&&bet.currency==="cash"&&<div style={{fontSize:10,color:"#34C759"}}>💵 Collect ${bet.amountCash} from {opponent?.name} in person.</div>}
            {result==="loss"&&bet.currency==="cash"&&<div style={{fontSize:10,color:"#FF2D55"}}>💸 Pay ${bet.amountCash} to {opponent?.name} in person.</div>}
            {/* Rake note always shown */}
            <div style={{fontSize:9,color:"#444",textAlign:"right"}}>
              Platform fee: {DEV_RAKE_LABEL} · <span style={{color:"#555"}}>kept by CrawlFire</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}


// ── CROSS-DEVICE LINK SYSTEM ─────────────────────────────────────────────────
const APP_URL=(typeof window!=="undefined"&&window.location?.origin)
  ?window.location.origin+window.location.pathname
  :"https://crawlfire.app";

function buildJoinLink(gameCode,difficulty="intermediate"){
  return `${APP_URL}#join=${gameCode}&diff=${encodeURIComponent(difficulty)}`;
}
function parseJoinLink(){
  if(typeof window==="undefined")return null;
  const hash=window.location.hash.replace("#","");
  if(!hash)return null;
  const params=Object.fromEntries(hash.split("&").map(p=>p.split("=")));
  if(!params.join)return null;
  return{code:params.join.toUpperCase(),difficulty:decodeURIComponent(params.diff||"intermediate")};
}
async function shareOrCopy(text,title="Join my CrawlFire game!"){
  if(navigator?.share){try{await navigator.share({title,text,url:text});return"shared";}catch{}}
  try{await navigator.clipboard.writeText(text);return"copied";}catch{}
  try{const el=document.createElement("textarea");el.value=text;el.style.cssText="position:fixed;opacity:0";document.body.appendChild(el);el.select();document.execCommand("copy");document.body.removeChild(el);return"copied";}catch{}
  return"failed";
}
function buildQRDataUrl(text,size=220){
  try{
    const c=document.createElement("canvas");c.width=size;c.height=size;
    const x=c.getContext("2d");x.fillStyle="#fff";x.fillRect(0,0,size,size);
    let h=0;for(let i=0;i<text.length;i++){h=((h<<5)-h)+text.charCodeAt(i);h|=0;}
    const cs=size/12;
    const corner=(px,py)=>{x.fillStyle="#0d0e1a";x.fillRect(px*cs,py*cs,7*cs,7*cs);x.fillStyle="#fff";x.fillRect((px+1)*cs,(py+1)*cs,5*cs,5*cs);x.fillStyle="#0d0e1a";x.fillRect((px+2)*cs,(py+2)*cs,3*cs,3*cs);};
    corner(0,0);corner(4,0);corner(0,4);
    let s=Math.abs(h);
    for(let r=0;r<12;r++)for(let col=0;col<12;col++){
      if((r<7&&col<7)||(r<7&&col>3&&col<8)||(r>3&&r<8&&col<7))continue;
      s=(s*1664525+1013904223)&0xffffffff;
      if(s%3===0){x.fillStyle="#0d0e1a";x.fillRect(col*cs,r*cs,cs,cs);}
    }
    const code=text.match(/#join=([A-Z0-9]+)/)?.[1]||text.slice(-6).toUpperCase();
    x.fillStyle="#FF2D55";x.font=`bold ${Math.floor(cs*1.3)}px monospace`;
    x.textAlign="center";x.textBaseline="middle";x.fillText(code,size/2,size*.90);
    return c.toDataURL();
  }catch{return"";}
}

// ── ShareCard component — shown inside WaitingScreen ─────────────────────────
function ShareCard({gameCode,difficulty}){
  const [status,setStatus]=useState(null); // null|"copied"|"shared"|"failed"
  const [showQR,setShowQR]=useState(false);
  const [qrUrl,setQrUrl]=useState("");
  const link=buildJoinLink(gameCode,difficulty);

  useEffect(()=>{if(showQR&&!qrUrl)setQrUrl(buildQRDataUrl(link));},[showQR,qrUrl,link]);

  const handleShare=async()=>{
    const result=await shareOrCopy(link);
    setStatus(result);
    setTimeout(()=>setStatus(null),2500);
  };

  return(
    <div style={{width:"100%",display:"flex",flexDirection:"column",gap:10}}>
      <div style={{...S.card,background:"#0a0c14",border:"1px solid #1e2237",display:"flex",flexDirection:"column",gap:10}}>
        <div style={{fontSize:9,color:"#555",letterSpacing:3}}>INVITE FRIENDS — CROSS-DEVICE LINK</div>

        {/* Big game code */}
        <div style={{textAlign:"center"}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:"#555",letterSpacing:3,marginBottom:4}}>GAME CODE</div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:48,letterSpacing:10,color:"#FF2D55",textShadow:"0 0 20px #FF2D5560",lineHeight:1}}>{gameCode}</div>
          <div style={{fontSize:10,color:"#555",marginTop:5}}>Friends type this in OR scan the QR below</div>
        </div>

        {/* Link preview */}
        <div style={{background:"#07080f",border:"1px solid #1e2237",borderRadius:10,padding:"8px 12px",fontSize:10,color:"#555",fontFamily:"'Space Mono',monospace",wordBreak:"break-all",lineHeight:1.6}}>
          {link.length>55?link.slice(0,55)+"...":link}
        </div>

        {/* Action buttons */}
        <div style={{display:"flex",gap:8}}>
          <button onClick={handleShare} style={{flex:2,padding:"12px 0",border:"none",borderRadius:12,cursor:"pointer",fontFamily:"'Black Han Sans',sans-serif",fontSize:15,letterSpacing:1,transition:"all .2s",
            background:status==="copied"?"#34C759":status==="shared"?"#007AFF":status==="failed"?"#FF2D55":"linear-gradient(135deg,#FF2D55,#FF6B35)",
            color:"#fff",boxShadow:status?"none":"0 4px 16px #FF2D5540"}}>
            {status==="copied"?"✅ LINK COPIED!":status==="shared"?"✅ SHARED!":status==="failed"?"❌ COPY FAILED":"📤 SHARE LINK"}
          </button>
          <button onClick={()=>setShowQR(q=>!q)} style={{flex:1,padding:"12px 0",border:`1px solid ${showQR?"#FFCC00":"#2a2a3a"}`,borderRadius:12,cursor:"pointer",fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:1,background:showQR?"#FFCC0015":"transparent",color:showQR?"#FFCC00":"#555"}}>
            {showQR?"HIDE QR":"📷 QR"}
          </button>
        </div>

        {/* QR code panel */}
        {showQR&&(
          <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:8,animation:"slideUp .3s ease"}}>
            <div style={{background:"#fff",borderRadius:14,padding:14,boxShadow:"0 4px 20px rgba(0,0,0,.2)",display:"flex",flexDirection:"column",alignItems:"center",gap:8}}>
              {qrUrl&&<img src={qrUrl} alt="Join QR" style={{width:200,height:200,imageRendering:"pixelated",display:"block"}}/>}
              <div style={{fontFamily:"'Black Han Sans',sans-serif",color:"#0d0e1a",fontSize:12,letterSpacing:3}}>🔥 CRAWLFIRE · JOIN</div>
            </div>
            <div style={{fontSize:10,color:"#555",textAlign:"center",lineHeight:1.7}}>
              Friend opens camera → points at QR → taps link → joins instantly
            </div>
          </div>
        )}

        {/* How to join instructions */}
        <div style={{display:"flex",flexDirection:"column",gap:5}}>
          <div style={{fontSize:9,color:"#555",letterSpacing:2}}>HOW TO JOIN FROM ANOTHER DEVICE</div>
          {[
            {n:"1",t:"Share the link or show the QR code",c:"#FF2D55"},
            {n:"2",t:"Friend opens the link on their phone",c:"#FF9500"},
            {n:"3",t:"They enter their name & avatar",c:"#FFCC00"},
            {n:"4",t:"They appear here instantly",c:"#34C759"},
          ].map(s=>(
            <div key={s.n} style={{display:"flex",alignItems:"center",gap:8}}>
              <div style={{width:20,height:20,borderRadius:"50%",background:`${s.c}20`,border:`1px solid ${s.c}40`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:s.c}}>{s.n}</span>
              </div>
              <span style={{fontSize:11,color:"#888"}}>{s.t}</span>
            </div>
          ))}
        </div>

        {/* Also works on */}
        <div style={{fontSize:9,color:"#444",padding:"6px 10px",background:"#12121a",borderRadius:8,lineHeight:1.7}}>
          📱 Works on any browser · iOS Safari · Android Chrome · Desktop<br/>
          No app install required — link opens the web version directly
        </div>
      </div>
    </div>
  );
}


// ── DeepLinkJoinScreen — shown when player arrives via a join link ────────────
function DeepLinkJoinScreen({code, onJoin, onBack}){
  const [name,setName]=useState("");
  const [avatar,setAvatar]=useState("🎯");
  const [joining,setJoining]=useState(false);
  const handleJoin=()=>{
    if(!name.trim())return;
    setJoining(true);
    onJoin(name.trim().toUpperCase(),avatar);
  };

  // Restore saved photo when name typed
  useEffect(()=>{
    if(!name.trim())return;
    loadAvatarPhoto(name.trim()).then(photo=>{if(photo)setAvatar(photo);});
  },[name]);

  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>

      <div style={{textAlign:"center"}}>
        <div style={{fontSize:48,marginBottom:8,animation:"breathe 2s ease-in-out infinite"}}>🚪</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,letterSpacing:2,color:"#f0f0f8"}}>YOU'VE BEEN INVITED!</div>
        <div style={{fontSize:11,color:"#555",marginTop:4,lineHeight:1.7}}>Someone shared a CrawlFire game link with you.</div>
      </div>

      {/* Game code badge */}
      <div style={{...S.card,background:"#FF2D5510",border:"2px solid #FF2D5540",textAlign:"center"}}>
        <div style={{fontSize:9,color:"#FF2D55",letterSpacing:3,marginBottom:4}}>JOINING GAME</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:40,letterSpacing:8,color:"#FF2D55",textShadow:"0 0 16px #FF2D5560"}}>{code}</div>
      </div>

      {/* Name input */}
      <div style={S.label}>YOUR CALLSIGN</div>
      <input style={S.input} placeholder="ENTER YOUR NAME" maxLength={12}
        value={name} onChange={e=>setName(e.target.value.toUpperCase())}
        onKeyDown={e=>e.key==="Enter"&&handleJoin()}/>

      {/* Avatar picker — full photo/camera/emoji */}
      <div style={S.label}>PICK YOUR AVATAR</div>
      <AvatarPicker value={avatar} playerName={name.trim()} onChange={setAvatar}/>

      <button onClick={handleJoin} disabled={!name.trim()||joining} style={{...S.btnPrimary,opacity:name.trim()&&!joining?1:.4,width:"100%"}}>
        {joining?"⏳ JOINING...":"🚀 JOIN THE GAME →"}
      </button>

      <div style={{fontSize:10,color:"#444",textAlign:"center",lineHeight:1.8}}>
        You'll appear in the host's waiting room instantly.<br/>
        The host will start the game when everyone's ready.
      </div>
    </div>
  );
}


function LobbyChoiceScreen({onHost,onJoin,onBrowse,onBack}){
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={S.title}>🎮 START A CRAWL</div>

      {/* Global lobby browser */}
      <button onClick={onBrowse} style={{...S.card,border:"2px solid #FF2D5540",cursor:"pointer",display:"flex",gap:16,alignItems:"center",background:"#FF2D5508",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",top:0,right:0,background:"#FF2D55",color:"#fff",fontSize:8,letterSpacing:1,fontFamily:"'Black Han Sans',sans-serif",padding:"3px 10px",borderBottomLeftRadius:8}}>NEW</div>
        <span style={{fontSize:36}}>🌍</span>
        <div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1,color:"#FF2D55"}}>GLOBAL LOBBY</div>
          <div style={{fontSize:11,color:"#555",marginTop:3}}>Browse active crawls in any city · join instantly</div>
        </div>
        <span style={{marginLeft:"auto",color:"#FF2D55",fontSize:18}}>›</span>
      </button>

      <button onClick={onHost} style={{...S.card,border:"2px solid #FFCC0040",cursor:"pointer",display:"flex",gap:16,alignItems:"center",background:"#FFCC0008"}}>
        <span style={{fontSize:36}}>👑</span>
        <div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1}}>HOST A GAME</div><div style={{fontSize:11,color:"#555",marginTop:3}}>Pick your city · set the rules · share the link</div></div>
      </button>
      <button onClick={onJoin} style={{...S.card,border:"2px solid #00C7BE40",cursor:"pointer",display:"flex",gap:16,alignItems:"center",background:"#00C7BE08"}}>
        <span style={{fontSize:36}}>🚪</span>
        <div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1}}>JOIN BY CODE</div><div style={{fontSize:11,color:"#555",marginTop:3}}>Enter a 6-letter game code</div></div>
      </button>
    </div>
  );
}

function WaitingScreen({game,myId,isHost,onStart,onBack,onPlaceBet,onAcceptBet,onDeclineBet}){
  const players=Object.values(game?.players||{});
  const me=game?.players?.[myId];
  const code=game?.id||"------";
  const diff=DIFFICULTY_LEVELS[game?.difficulty||"intermediate"]||DIFFICULTY_LEVELS.intermediate;
  return(
    <div style={{...S.screen,alignItems:"center"}}>
      <button style={{...S.btnGhost,alignSelf:"flex-start"}} onClick={onBack}>← BACK</button>

      {/* XP progress bar */}
      {totalXp>0&&<XPBar totalXp={totalXp} compact={true}/>}
      {/* Difficulty badge + Firebase status */}
      <div style={{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap"}}>
        <div style={{display:"flex",alignItems:"center",gap:6,padding:"5px 14px",background:`${diff.color}15`,border:`1px solid ${diff.color}40`,borderRadius:20}}>
          <span style={{fontSize:14}}>{diff.icon}</span>
          <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,letterSpacing:2,color:diff.color}}>{diff.label} MODE</span>
        </div>
        <FirebaseStatus/>
      </div>

      <ShareCard gameCode={game?.code||"------"} difficulty={game?.difficulty||"intermediate"}/>

      {/* Players list */}
      <div style={{...S.card,width:"100%"}}>
        <div style={{...S.label,marginBottom:10}}>PLAYERS JOINED ({players.length})</div>
        {players.map(p=>(
          <div key={p.id} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:"1px solid #1a1d2e"}}>
            <AvatarDisplay avatar={p.avatar} size={34} borderColor={p.id===myId?"#FF2D55":null}/>
            <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:1,flex:1}}>{p.name}</span>
            <span style={{fontSize:11,color:"#FFCC00"}}>🪙{p.coins}</span>
            {p.id===myId&&<Pill label="YOU" color="#FF2D55"/>}
          </div>
        ))}
        {/* Pot preview */}
        {}
        {/* Pre-game tips */}
        <div style={{display:"flex",flexDirection:"column",gap:5,marginTop:8}}>
          <div style={{padding:"8px 12px",background:"#FFCC0008",border:"1px solid #FFCC0030",borderRadius:8,display:"flex",alignItems:"center",gap:8,cursor:"pointer"}} onClick={()=>{}}>
            <span style={{fontSize:16}}>🎰</span>
            <span style={{fontSize:10,color:"#FFCC00",lineHeight:1.5}}>Claim your <strong>daily spin</strong> before the game — prizes land in your inventory!</span>
            <div style={{width:8,height:8,borderRadius:"50%",background:"#FF2D55",animation:"pulse 1.5s ease-in-out infinite",flexShrink:0}}/>
          </div>
          <div style={{padding:"8px 12px",background:"#34C75908",border:"1px solid #34C75930",borderRadius:8,display:"flex",alignItems:"center",gap:8}}>
            <span style={{fontSize:16}}>☣️</span>
            <span style={{fontSize:10,color:"#34C759",lineHeight:1.5}}>Play <strong>Dead City</strong> before the game starts to earn extra coins for the shop!</span>
          </div>
        </div>
      </div>

      {/* ── WAITING ROOM AD BANNER ── */}
      <BannerAd style={{marginTop:4}}/>

      {/* ── REWARDED AD NOTICE ── */}
      <RewardedAdNotice onWatch={()=>{/* wire to rewarded video SDK in prod */}}/>

      {/* ── FRIENDLY BETS ── */}
      {players.length>=1&&me&&(
        <div style={{width:"100%"}}>
          <BetLobby
            game={game}
            myId={myId}
            myName={me.name}
            onPlaceBet={onPlaceBet}
            onAcceptBet={onAcceptBet}
            onDeclineBet={onDeclineBet}
          />
        </div>
      )}

      {isHost?(
        <><div style={{fontSize:11,color:"#555",textAlign:"center"}}>Everyone in? Kick off the crawl!</div>
        <button style={{...S.btnPrimary,opacity:players.length>=2?1:.4}} disabled={players.length<2} onClick={onStart}>🔫 START GAME</button>
        {players.length<2&&<div style={{fontSize:11,color:"#FF9500",textAlign:"center"}}>Need at least 2 players</div>}</>
      ):(
        <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:10}}>
          <div style={{fontSize:36,animation:"spin 2s linear infinite"}}>⏳</div>
          <div style={{fontSize:12,color:"#555"}}>Waiting for host to start...</div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TACTICAL OVERLAY HUD — Call of Duty style, zero screen-switching during play
// ─────────────────────────────────────────────────────────────────────────────
// Replaces the flat PlayScreen layout with a live overlay that never leaves
// the shooting/camera view. All panels slide in from bottom or sides without
// navigating away.
//
// PANELS (all overlaid, tap-to-dismiss):
//   • Mini-map          — bottom-right, always visible, toggleable
//   • Weapon wheel      — hold 🎯 SHOOT → radial weapon selector
//   • Quick inventory   — slide from right, use items without leaving play
//   • Quick shop        — slide from right, buy items without leaving play
//   • Live feed ticker  — thin strip at top, kills / events scroll through
//   • CTF flag status   — bottom strip, which team holds which flag
//   • Zone + speed HUD  — integrated inline, no separate screens
// ═══════════════════════════════════════════════════════════════════════════════

// ── Weapon wheel — radial selector, no screen change ────────────────────────
function WeaponWheel({ weapons, activeId, onSelect, onClose }) {
  const count  = weapons.length;
  const radius = 90;
  const cx = 140, cy = 140;

  return (
    <div style={{
      position:"fixed", inset:0, background:"rgba(0,0,0,.72)",
      display:"flex", alignItems:"center", justifyContent:"center",
      zIndex:300, backdropFilter:"blur(3px)",
      animation:"fadeIn .15s ease",
    }} onClick={onClose}>
      <div style={{position:"relative",width:280,height:280}} onClick={e=>e.stopPropagation()}>
        {/* Centre fire button */}
        <div style={{
          position:"absolute",top:"50%",left:"50%",
          transform:"translate(-50%,-50%)",
          width:56,height:56,borderRadius:"50%",
          background:"#FF2D55",
          display:"flex",alignItems:"center",justifyContent:"center",
          fontSize:24,zIndex:2,
          boxShadow:"0 0 24px #FF2D5560",
        }}>🎯</div>

        {/* Weapon segments */}
        {weapons.map((w,i) => {
          const angle  = (i / count) * 2 * Math.PI - Math.PI / 2;
          const x      = cx + radius * Math.cos(angle) - 30;
          const y      = cy + radius * Math.sin(angle) - 30;
          const active = w.id === activeId;
          return (
            <div key={w.id} onClick={() => { onSelect(w.id); onClose(); }}
              style={{
                position:"absolute", left:x, top:y,
                width:60, height:60,
                borderRadius:"50%",
                background: active ? `${w.color||"#FF2D55"}25` : "#0d0e1a",
                border:`2px solid ${active ? (w.color||"#FF2D55") : "#2a2a3a"}`,
                display:"flex", flexDirection:"column",
                alignItems:"center", justifyContent:"center", gap:2,
                cursor:"pointer",
                boxShadow: active ? `0 0 16px ${w.color||"#FF2D55"}50` : "none",
                transition:"all .12s",
              }}>
              <span style={{fontSize:18}}>{w.e}</span>
              <span style={{fontSize:7,color:active?(w.color||"#FF2D55"):"#888",fontFamily:"'DM Mono',monospace",letterSpacing:.5,textAlign:"center",lineHeight:1}}>
                {w.n.slice(0,6).toUpperCase()}
              </span>
            </div>
          );
        })}

        {/* Connector lines */}
        <svg style={{position:"absolute",inset:0,width:"100%",height:"100%",pointerEvents:"none"}}>
          {weapons.map((_,i) => {
            const angle = (i / count) * 2 * Math.PI - Math.PI / 2;
            return (
              <line key={i}
                x1={cx} y1={cy}
                x2={cx + radius * Math.cos(angle)}
                y2={cy + radius * Math.sin(angle)}
                stroke="#2a2a3a" strokeWidth="1" strokeDasharray="3 3"/>
            );
          })}
        </svg>
      </div>
    </div>
  );
}

// ── Quick inventory panel — slides from right, items usable in-place ──────────
function QuickInventoryPanel({ player, onUseItem, onClose }) {
  const items = SHOP_ITEMS.filter(it => (player?.inventory?.[it.id]||0) > 0);

  return (
    <div style={{
      position:"fixed", top:0, right:0, bottom:0, width:"72%", maxWidth:280,
      background:"#0a0c14", borderLeft:"2px solid #1e2237",
      display:"flex", flexDirection:"column",
      zIndex:250, animation:"slideInRight .25s cubic-bezier(.17,.67,.29,1.1)",
      boxShadow:"-8px 0 32px rgba(0,0,0,.6)",
    }}>
      <div style={{padding:"16px 14px 10px",borderBottom:"1px solid #1e2237",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:2,color:"#FF9500"}}>🎒 INVENTORY</div>
        <button onClick={onClose} style={{background:"none",border:"none",color:"#555",fontSize:20,cursor:"pointer",padding:"0 4px"}}>✕</button>
      </div>
      <div style={{flex:1,overflowY:"auto",padding:"10px 12px",display:"flex",flexDirection:"column",gap:7,scrollbarWidth:"thin"}}>
        {items.length === 0 && (
          <div style={{textAlign:"center",padding:"28px 0",color:"#555",fontSize:11}}>Bag is empty</div>
        )}
        {items.map(it => {
          const qty = player.inventory[it.id]||0;
          return (
            <button key={it.id} onClick={() => onUseItem(it.id)}
              style={{
                display:"flex",alignItems:"center",gap:10,
                padding:"10px 12px",
                background:"#0d0e1a",border:"1px solid #1e2237",
                borderRadius:10,cursor:"pointer",textAlign:"left",
                transition:"all .12s",
              }}
              onMouseOver={e=>{e.currentTarget.style.borderColor="#FF9500";e.currentTarget.style.background="#FF950010";}}
              onMouseOut={e=>{e.currentTarget.style.borderColor="#1e2237";e.currentTarget.style.background="#0d0e1a";}}>
              <span style={{fontSize:22,flexShrink:0}}>{it.e}</span>
              <div style={{flex:1}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,color:"#f0f0f8"}}>{it.n}</div>
                <div style={{fontSize:9,color:"#555",marginTop:1}}>{it.d}</div>
              </div>
              <div style={{
                fontFamily:"'Black Han Sans',sans-serif",fontSize:14,
                color:"#FF9500",background:"#FF950020",
                border:"1px solid #FF950040",borderRadius:20,
                padding:"2px 8px",flexShrink:0,
              }}>×{qty}</div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ── Quick shop panel — slides from right, buy without leaving play ─────────────
function QuickShopPanel({ player, onBuy, onClose }) {
  const [buying, setBuying] = useState(null);

  const handleBuy = async (item) => {
    if ((player?.coins||0) < item.c) return;
    setBuying(item.id);
    await onBuy(item);
    setTimeout(() => setBuying(null), 600);
  };

  return (
    <div style={{
      position:"fixed", top:0, right:0, bottom:0, width:"72%", maxWidth:280,
      background:"#0a0c14", borderLeft:"2px solid #1e2237",
      display:"flex", flexDirection:"column",
      zIndex:250, animation:"slideInRight .25s cubic-bezier(.17,.67,.29,1.1)",
      boxShadow:"-8px 0 32px rgba(0,0,0,.6)",
    }}>
      <div style={{padding:"16px 14px 10px",borderBottom:"1px solid #1e2237",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:2,color:"#FFCC00"}}>🏪 QUICK SHOP</div>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:"#FFCC00"}}>🪙{player?.coins||0}</span>
          <button onClick={onClose} style={{background:"none",border:"none",color:"#555",fontSize:20,cursor:"pointer",padding:"0 4px"}}>✕</button>
        </div>
      </div>
      <div style={{flex:1,overflowY:"auto",padding:"10px 12px",display:"flex",flexDirection:"column",gap:7,scrollbarWidth:"thin"}}>
        {SHOP_ITEMS.map(it => {
          const canAfford = (player?.coins||0) >= it.c;
          const isBuying  = buying === it.id;
          return (
            <button key={it.id} onClick={() => canAfford && handleBuy(it)} disabled={!canAfford}
              style={{
                display:"flex",alignItems:"center",gap:10,
                padding:"10px 12px",
                background:isBuying?"#34C75920":"#0d0e1a",
                border:`1px solid ${isBuying?"#34C759":canAfford?"#1e2237":"#1a1a1a"}`,
                borderRadius:10,cursor:canAfford?"pointer":"not-allowed",
                opacity:canAfford?1:.45,textAlign:"left",transition:"all .12s",
              }}>
              <span style={{fontSize:22,flexShrink:0}}>{it.e}</span>
              <div style={{flex:1}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,color:isBuying?"#34C759":"#f0f0f8"}}>{it.n}</div>
                <div style={{fontSize:9,color:"#555",marginTop:1}}>{it.d}</div>
              </div>
              <div style={{
                fontFamily:"'Black Han Sans',sans-serif",fontSize:12,
                color:canAfford?"#FFCC00":"#555",
                background:canAfford?"#FFCC0015":"transparent",
                border:canAfford?"1px solid #FFCC0030":"none",
                borderRadius:20,padding:"3px 9px",flexShrink:0,
              }}>
                {isBuying?"✅":`🪙${it.c}`}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ── Tactical mini-map — always-on corner map overlay ─────────────────────────
function TacticalMinimap({ game, myId, zoneStatus, bars=[] }) {
  const [expanded, setExpanded] = useState(false);
  const players  = Object.values(game?.players||{});
  const alive    = players.filter(p=>p.alive);
  const me       = game?.players?.[myId];
  const sz       = expanded ? 200 : 110;

  // Deterministic positions for demo (in prod: real lat/lng → normalised)
  const positions = players.map((p,i) => ({
    ...p,
    px: 15 + ((p.id.charCodeAt(0)*37+i*23) % 70),
    py: 15 + ((p.id.charCodeAt(1)*31+i*17) % 70),
  }));

  return (
    <div onClick={() => setExpanded(e => !e)} style={{
      position:"fixed",
      bottom: expanded ? "50%" : 80,
      right:  8,
      transform: expanded ? "translateY(50%)" : "none",
      width:sz, height:sz,
      borderRadius:10,
      background:"rgba(7,8,15,.88)",
      border:`1.5px solid ${zoneStatus==="grace"?"#FF2D55":zoneStatus==="approaching"?"#FF9500":"#1e2237"}`,
      overflow:"hidden",
      zIndex:100,
      cursor:"pointer",
      backdropFilter:"blur(4px)",
      transition:"all .3s cubic-bezier(.17,.67,.29,1.1)",
      boxShadow:"0 4px 20px rgba(0,0,0,.5)",
    }}>
      <svg width={sz} height={sz} viewBox="0 0 100 100">
        {/* Background grid */}
        <rect width="100" height="100" fill="#07080f"/>
        {[20,40,60,80].map(v=><>
          <line key={`h${v}`} x1="0" y1={v} x2="100" y2={v} stroke="#ffffff06" strokeWidth=".5"/>
          <line key={`v${v}`} x1={v} y1="0" x2={v} y2="100" stroke="#ffffff06" strokeWidth=".5"/>
        </>)}

        {/* Zone boundary circle */}
        <circle cx="50" cy="50" r="44" fill="none"
          stroke={zoneStatus==="grace"?"#FF2D55":zoneStatus==="approaching"?"#FF9500":"#34C75930"}
          strokeWidth={zoneStatus!=="ok"?"1.5":"0.5"}
          strokeDasharray={zoneStatus!=="ok"?"4 2":"none"}/>

        {/* Bar dots */}
        {bars.slice(0,8).map((b,i) => {
          const bx = 10 + (i%4)*22, by = 10 + Math.floor(i/4)*40;
          return <rect key={b.id||i} x={bx-4} y={by-4} width={8} height={8} rx="2"
            fill="#FF950030" stroke="#FF950070" strokeWidth=".5"/>;
        })}

        {/* Other players */}
        {positions.filter(p=>p.id!==myId&&p.alive).map(p => (
          <g key={p.id}>
            <circle cx={p.px} cy={p.py} r={4} fill="#FF2D5540" stroke="#FF2D55" strokeWidth="1"/>
            <text x={p.px} y={p.py+10} textAnchor="middle" fontSize="5" fill="#FF2D55aa"
              fontFamily="monospace" style={{userSelect:"none"}}>{p.name.slice(0,4)}</text>
          </g>
        ))}

        {/* Dead players — greyed */}
        {positions.filter(p=>p.id!==myId&&!p.alive).map(p => (
          <text key={p.id} x={p.px} y={p.py} textAnchor="middle" fontSize="8"
            style={{userSelect:"none"}}>💀</text>
        ))}

        {/* Me — always bright */}
        {me&&(()=>{const mp=positions.find(p=>p.id===myId)||{px:50,py:50};return(
          <g>
            <circle cx={mp.px} cy={mp.py} r={6} fill="#34C75930" stroke="#34C759" strokeWidth="1.5"/>
            <text x={mp.px} y={mp.py+4} textAnchor="middle" fontSize="8"
              style={{userSelect:"none"}}>{me.avatar}</text>
          </g>
        );})()}

        {/* Expand hint */}
        {!expanded&&<text x="99" y="99" textAnchor="end" fontSize="5" fill="#555"
          fontFamily="monospace" style={{userSelect:"none"}}>tap</text>}
      </svg>

      {/* Player count badge */}
      <div style={{
        position:"absolute",top:4,left:4,
        background:"rgba(0,0,0,.8)",borderRadius:4,
        padding:"1px 5px",fontSize:7,
        color:alive.length<=1?"#FF2D55":"#34C759",
        fontFamily:"'DM Mono',monospace",letterSpacing:.5,
      }}>
        👥{alive.length}/{players.length}
      </div>
    </div>
  );
}

// ── Live event ticker — thin strip at top of HUD ─────────────────────────────
function LiveTicker({ events, game }) {
  const [pos, setPos]   = useState(0);
  const msgRef = useRef("");

  const msgs = events.map(e => {
    const fn = id => game?.players?.[id]?.name||id;
    if(e.type==="kill")    return `💀 ${fn(e.from)} KILLED ${fn(e.to)}`;
    if(e.type==="hit")     return `🎯 ${fn(e.from)} hit ${fn(e.to)} (${e.dmg}hp)`;
    if(e.type==="tag")     return `⭐ ${fn(e.from)} tagged ${fn(e.to)}`;
    if(e.type==="flag")    return e.msg;
    if(e.type==="mine_trigger") return e.msg;
    if(e.type==="respawn") return e.msg;
    return null;
  }).filter(Boolean);

  const text = msgs.join("   ·   ");
  if(text) msgRef.current = text;

  useEffect(() => {
    if(!msgRef.current) return;
    const id = setInterval(() => setPos(p => (p+1)%(msgRef.current.length*8||1)), 60);
    return () => clearInterval(id);
  }, []);

  if(!msgRef.current) return null;

  return (
    <div style={{
      position:"fixed",top:0,left:0,right:0,
      height:22,zIndex:150,
      background:"rgba(7,8,15,.85)",
      borderBottom:"1px solid #1e2237",
      backdropFilter:"blur(4px)",
      display:"flex",alignItems:"center",
      overflow:"hidden",
      padding:"0 8px",
    }}>
      <div style={{
        background:"#FF2D55",
        color:"#fff",
        fontFamily:"'Black Han Sans',sans-serif",
        fontSize:8,letterSpacing:1,
        padding:"1px 6px",borderRadius:3,
        flexShrink:0,marginRight:8,
      }}>LIVE</div>
      <div style={{flex:1,overflow:"hidden",whiteSpace:"nowrap"}}>
        <div style={{
          display:"inline-block",
          transform:`translateX(${-pos}px)`,
          fontFamily:"'DM Mono',monospace",
          fontSize:9,color:"#FF9500",letterSpacing:.5,
          paddingRight:200,
        }}>
          {msgRef.current}{"   ·   "}{msgRef.current}
        </div>
      </div>
    </div>
  );
}

// ── CTF flag strip — bottom overlay, always visible in CTF mode ──────────────
function CTFFlagStrip({ flags, teams, myTeamId }) {
  if(!flags||!flags.length) return null;
  return (
    <div style={{
      position:"fixed",bottom:0,left:0,right:0,
      background:"rgba(7,8,15,.88)",
      borderTop:"1px solid #1e2237",
      backdropFilter:"blur(4px)",
      display:"flex",gap:0,
      zIndex:90, padding:"4px 8px",
      overflowX:"auto",scrollbarWidth:"none",
    }}>
      {flags.map(flag => {
        const team    = teams?.find(t=>t.id===flag.heldByTeam);
        const isMine  = flag.heldByTeam === myTeamId;
        const color   = team?.color || "#2a2a3a";
        return (
          <div key={flag.id} style={{
            flex:1,minWidth:60,
            display:"flex",flexDirection:"column",alignItems:"center",gap:1,
            padding:"3px 4px",
            borderRadius:6,
            background:isMine?`${color}20`:"transparent",
            border:isMine?`1px solid ${color}40`:"1px solid transparent",
          }}>
            <span style={{fontSize:14,filter:flag.heldByTeam?`drop-shadow(0 0 4px ${color})`:"none"}}>🚩</span>
            <div style={{fontSize:7,color:team?color:"#555",fontFamily:"'DM Mono',monospace",
              letterSpacing:.3,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",maxWidth:50,textAlign:"center"}}>
              {flag.name.split(" ").slice(-1)[0].toUpperCase().slice(0,6)}
            </div>
            {team&&<div style={{fontSize:6,color:color+"aa"}}>{team.e||"⚑"}</div>}
          </div>
        );
      })}
    </div>
  );
}

// ── TacticalHUD — the master overlay that wraps PlayScreen ───────────────────
// All sub-panels slide in without navigating away from the game view.
function TacticalHUD({
  game, myId, shared, fire, buyItem, useItem, plantMine, sweepMine,
  zoneStatus, distToEdge, graceSecs, onZoneScreen, zoneDismissed, onZoneDismiss,
  speedState, speedKmh,
  // CTF
  ctfGame, ctfMyId,
  // Navigation (for things that still need a full screen)
  onFullScreen,
}) {
  const player = game?.players?.[myId];
  const [panel,    setPanel]    = useState(null);  // null|"inventory"|"shop"|"qr"|"loot"
  const [showWheel,setShowWheel]= useState(false);
  const [activeWpn,setActiveWpn]= useState(ZAPPERS?.[0]?.id || "snowball");
  const [scanAnim, setScanAnim] = useState(null);
  const [hitFlash, setHitFlash] = useState(false);

  const events  = (game?.events||[]).slice(-8).reverse();
  const isCTF   = !!ctfGame;
  const ctfMe   = ctfGame?.players?.[ctfMyId];
  const myTeamId= player?.teamId || ctfMe?.teamId;
  const flags   = ctfGame?.flags || [];
  const ctfTeams= ctfGame?.teams || [];

  const hpPct = Math.max(0, ((player?.hp||0)/(player?.maxHp||100))*100);
  const hpC   = hpPct>60?"#34C759":hpPct>25?"#FF9500":"#FF2D55";
  const inv   = Object.values(player?.inventory||{}).reduce((s,n)=>s+(n||0),0);
  const coins = player?.coins||0;

  // WEAPONS list for wheel
  const WEAPONS_LIST = SHOP_ITEMS.filter(it=>["nuke","double","cloak"].includes(it.id))
    .map(it=>({...it,color:"#FF2D55"}))
    .concat(ZAPPERS||[]);

  const handleShoot = async (targetId) => {
    if(!player?.alive || !targetId) return;
    setHitFlash(true);
    setTimeout(()=>setHitFlash(false),180);
    await fire(targetId, activeWpn);
    setScanAnim({result:"zap",name:game?.players?.[targetId]?.name});
    setTimeout(()=>setScanAnim(null),1500);
  };

  const handleBuy = async (item) => {
    await buyItem(item);
  };

  const handleUseItem = async (id) => {
    await useItem(id);
    setPanel(null);
  };

  return (
    <div style={{position:"fixed",inset:0,zIndex:80,pointerEvents:"none"}}>

      {/* ── LIVE TICKER (top) ── */}
      <div style={{pointerEvents:"all"}}>
        <LiveTicker events={events} game={game}/>
      </div>

      {/* ── MAIN HUD BAR (top, below ticker) ── */}
      <div style={{
        position:"fixed",top:22,left:0,right:0,
        padding:"6px 10px",
        background:"rgba(7,8,15,.82)",
        backdropFilter:"blur(6px)",
        borderBottom:"1px solid #1e2237",
        display:"flex",alignItems:"center",gap:8,
        zIndex:120,pointerEvents:"all",
      }}>
        {/* Avatar + name */}
        <AvatarDisplay avatar={player?.avatar} size={28} borderColor={hpC}/>
        <div style={{flex:1,minWidth:0}}>
          <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
            <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:"#f0f0f8",letterSpacing:1}}>
              {player?.name||"PLAYER"}
            </span>
            {player?.kills>0&&<span style={{fontSize:9,color:"#FF2D55"}}>💀{player.kills}</span>}
            {player?.cloaked&&<span style={{fontSize:9,color:"#BF5AF2"}}>👻</span>}
            {player?.doubleDmg>0&&<span style={{fontSize:9,color:"#FF9500"}}>⚡×{player.doubleDmg}</span>}
          </div>
          {/* HP bar inline */}
          <div style={{height:4,background:"rgba(255,255,255,.1)",borderRadius:2,overflow:"hidden",marginTop:3,maxWidth:120}}>
            <div style={{height:"100%",width:`${hpPct}%`,background:hpC,borderRadius:2,transition:"width .3s"}}/>
          </div>
        </div>
        {/* Coins */}
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:"#FFCC00",flexShrink:0}}>🪙{coins}</div>
        {/* Level badge */}
        {(()=>{const lvl=player?.level||1;const rk=getRank(lvl);return(
          <div style={{flexShrink:0,fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:rk.color,background:`${rk.color}15`,border:`1px solid ${rk.color}30`,borderRadius:10,padding:"2px 6px"}}>
            {rk.icon}{lvl}
          </div>
        );})()}
        {/* Kill count */}
        <div style={{textAlign:"center",padding:"3px 8px",background:"#FF2D5515",border:"1px solid #FF2D5530",borderRadius:8,flexShrink:0}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#FF2D55",lineHeight:1}}>{player?.kills||0}</div>
          <div style={{fontSize:6,color:"#555",letterSpacing:1}}>KILLS</div>
        </div>
        {/* Shield if active */}
        {(player?.shield||0)>0&&(
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:"#00C7BE",flexShrink:0}}>🛡️{player.shield}</div>
        )}
      </div>

      {/* ── ZONE BANNER (below top HUD, only when warning) ── */}
      {!zoneDismissed&&zoneStatus&&zoneStatus!=="ok"&&(
        <div style={{position:"fixed",top:62,left:0,right:0,zIndex:119,pointerEvents:"all"}} onClick={onZoneScreen}>
          <ZoneBanner distToEdge={distToEdge} status={zoneStatus} graceSecs={graceSecs}
            onDismiss={e=>{e.stopPropagation();onZoneDismiss();}}/>
        </div>
      )}

      {/* ── SPEED WARNING (inline, non-blocking) ── */}
      {speedState==="warn"&&speedKmh>0&&(
        <div style={{position:"fixed",top:86,left:0,right:0,zIndex:118,pointerEvents:"none"}}>
          <SpeedWarnBanner speedKmh={speedKmh}/>
        </div>
      )}

      {/* ── SCAN ANIMATION ── */}
      {scanAnim&&(
        <div style={{position:"fixed",top:"30%",left:"50%",transform:"translateX(-50%)",
          zIndex:200,pointerEvents:"none",
          fontFamily:"'Black Han Sans',sans-serif",fontSize:20,color:"#FF2D55",
          letterSpacing:2,textShadow:"0 0 20px #FF2D55",animation:"popIn .3s ease"}}>
          💥 {scanAnim.name} HIT!
        </div>
      )}

      {/* ── HIT FLASH ── */}
      {hitFlash&&<div style={{position:"fixed",inset:0,background:"rgba(255,45,85,.18)",pointerEvents:"none",zIndex:130,animation:"flash .15s ease"}}/>}

      {/* ── BOTTOM TACTICAL BAR ── */}
      <div style={{
        position:"fixed",bottom:isCTF?44:8,left:0,right:0,
        padding:"8px 10px",
        background:"rgba(7,8,15,.88)",
        backdropFilter:"blur(8px)",
        borderTop:"1px solid #1e2237",
        display:"flex",alignItems:"center",gap:6,
        zIndex:110,pointerEvents:"all",
      }}>
        {/* QR badge */}
        <button onClick={()=>onFullScreen("qr")} style={{width:40,height:40,borderRadius:10,border:"1px solid #00C7BE40",background:"#00C7BE10",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:1,flexShrink:0}}>
          <span style={{fontSize:16}}>👕</span>
          <span style={{fontSize:6,color:"#00C7BE",fontFamily:"'Black Han Sans',sans-serif",letterSpacing:.5}}>QR</span>
        </button>

        {/* SHOOT — hold for weapon wheel, tap to go scan */}
        <button
          onClick={()=>onFullScreen("scan")}
          onContextMenu={e=>{e.preventDefault();setShowWheel(true);}}
          disabled={!player?.alive}
          style={{
            flex:2,height:52,borderRadius:12,border:"none",cursor:player?.alive?"pointer":"not-allowed",
            background:player?.alive?"linear-gradient(135deg,#FF2D55,#FF6B35)":"#1a1d2e",
            color:player?.alive?"#fff":"#555",
            fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,
            boxShadow:player?.alive?"0 4px 20px #FF2D5550":"none",
            display:"flex",alignItems:"center",justifyContent:"center",gap:8,
          }}>
          <span>{player?.alive?"🎯 SHOOT":"💀 DEAD"}</span>
        </button>

        {/* Weapon selector (quick — tap cycles weapons) */}
        <button onClick={()=>setShowWheel(true)} style={{width:40,height:40,borderRadius:10,border:"1px solid #FF2D5540",background:"#FF2D5510",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:1,flexShrink:0}}>
          <span style={{fontSize:14}}>🔫</span>
          <span style={{fontSize:6,color:"#FF2D55",fontFamily:"'Black Han Sans',sans-serif",letterSpacing:.3}}>WEAPON</span>
        </button>

        {/* Inventory */}
        <button onClick={()=>setPanel(panel==="inventory"?null:"inventory")} style={{width:40,height:40,borderRadius:10,border:`1px solid ${panel==="inventory"?"#FF9500":"#2a2a3a"}`,background:panel==="inventory"?"#FF950020":"#0d0e1a",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:1,flexShrink:0,position:"relative"}}>
          <span style={{fontSize:14}}>🎒</span>
          <span style={{fontSize:6,color:"#FF9500",fontFamily:"'Black Han Sans',sans-serif",letterSpacing:.3}}>BAG</span>
          {inv>0&&<div style={{position:"absolute",top:-3,right:-3,width:14,height:14,borderRadius:"50%",background:"#FF9500",color:"#000",fontFamily:"'Black Han Sans',sans-serif",fontSize:8,display:"flex",alignItems:"center",justifyContent:"center"}}>{inv>9?"9+":inv}</div>}
        </button>

        {/* Shop */}
        <button onClick={()=>setPanel(panel==="shop"?null:"shop")} style={{width:40,height:40,borderRadius:10,border:`1px solid ${panel==="shop"?"#FFCC00":"#2a2a3a"}`,background:panel==="shop"?"#FFCC0015":"#0d0e1a",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:1,flexShrink:0}}>
          <span style={{fontSize:14}}>🏪</span>
          <span style={{fontSize:6,color:"#FFCC00",fontFamily:"'Black Han Sans',sans-serif",letterSpacing:.3}}>SHOP</span>
        </button>
      </div>

      {/* ── CTF FLAG STRIP ── */}
      {isCTF&&<CTFFlagStrip flags={flags} teams={ctfTeams} myTeamId={myTeamId}/>}

      {/* ── TACTICAL MINIMAP ── */}
      <div style={{pointerEvents:"all"}}>
        <TacticalMinimap game={game} myId={myId} zoneStatus={zoneStatus}/>
      </div>

      {/* ── SLIDING PANELS (inventory / shop) ── */}
      {panel&&<div style={{position:"fixed",inset:0,zIndex:240,pointerEvents:"all"}} onClick={()=>setPanel(null)}>
        <div onClick={e=>e.stopPropagation()}>
          {panel==="inventory"&&<QuickInventoryPanel player={player} onUseItem={handleUseItem} onClose={()=>setPanel(null)}/>}
          {panel==="shop"&&<QuickShopPanel player={player} onBuy={handleBuy} onClose={()=>setPanel(null)}/>}
        </div>
      </div>}

      {/* ── WEAPON WHEEL ── */}
      {showWheel&&(
        <div style={{pointerEvents:"all"}}>
          <WeaponWheel
            weapons={SHOP_ITEMS.map(it=>({...it,color:"#FF2D55"}))}
            activeId={activeWpn}
            onSelect={setActiveWpn}
            onClose={()=>setShowWheel(false)}/>
        </div>
      )}

      {/* Dead overlay */}
      {!player?.alive&&(
        <div style={{position:"fixed",bottom:60,left:"50%",transform:"translateX(-50%)",
          background:"#FF2D5520",border:"1px solid #FF2D55",borderRadius:10,
          padding:"8px 18px",fontFamily:"'Black Han Sans',sans-serif",fontSize:13,
          color:"#FF2D55",animation:"flash 1.5s ease infinite",
          zIndex:115,pointerEvents:"none",whiteSpace:"nowrap"}}>
          💀 DEAD — open shop to buy Revive
        </div>
      )}
    </div>
  );
}


function PlayScreen({game,myId,onNav,onSetScreen,shared,zoneStatus,distToEdge,graceSecs,onZoneScreen,zoneDismissed,onZoneDismiss,speedState="clear",speedKmh=0}){
  const player=game?.players?.[myId];
  if(!player)return null;
  const hpPct=Math.max(0,(player.hp/player.maxHp)*100);
  const hpC=hpPct>60?"#34C759":hpPct>25?"#FF9500":"#FF2D55";
  const inv=Object.values(player.inventory||{}).reduce((s,n)=>s+(n||0),0);
  const events=(game.events||[]).slice(-4).reverse();
  const evtLine=e=>{const fn=id=>game.players[id]?.name||id;if(e.type==="hit")return`🎯 ${fn(e.from)}→${fn(e.to)} ${e.dmg}dmg`;if(e.type==="kill")return`💀 ${fn(e.from)} KILLED ${fn(e.to)}!`;if(e.type==="loot")return`🎁 ${fn(e.from)} got ${e.item}`;return null;};
  return(
    <div style={{...S.screen,gap:12}}>
      {/* Header */}
      <div style={{display:"flex",alignItems:"center",gap:10}}>
        <span style={{fontSize:40,filter:"drop-shadow(0 0 8px rgba(255,255,255,.2))"}}>{player.avatar}</span>
        <div style={{flex:1}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:1}}>{player.name}</div>
          <div style={{fontSize:11,color:"#FFCC00"}}>🪙 {player.coins} coins</div>
        </div>
        <div style={{...S.card,textAlign:"center",padding:"8px 14px"}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:26,color:"#FF2D55"}}>{player.kills}</div>
          <div style={{fontSize:8,letterSpacing:2,color:"#555"}}>KILLS</div>
        </div>
      </div>
      {/* HP */}
      <div style={S.card}>
        <div style={{display:"flex",justifyContent:"space-between",fontSize:12,marginBottom:6}}><span>HP</span><span style={{color:hpC}}>{player.hp}/{player.maxHp}</span></div>
        <HPBar hp={player.hp} max={player.maxHp}/>
        <div style={{display:"flex",gap:8,marginTop:6,flexWrap:"wrap"}}>
          {player.shield>0&&<span style={{fontSize:10,color:"#00C7BE"}}>🛡️{player.shield}</span>}
          {player.doubleDmg>0&&<span style={{fontSize:10,color:"#FF9500"}}>⚡×2({player.doubleDmg})</span>}
          {player.cloaked&&<span style={{fontSize:10,color:"#BF5AF2"}}>👻 CLOAKED</span>}
        </div>
      </div>
      {!player.alive&&<div style={{background:"#FF2D5520",border:"1px solid #FF2D55",borderRadius:10,padding:12,textAlign:"center",fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:"#FF2D55",animation:"flash 1s ease infinite"}}>💀 DEAD — Buy a Revive (🪙60)</div>}
      {/* Difficulty badge */}
      {(()=>{const dKey=game?.difficulty||"intermediate";const d=DIFFICULTY_LEVELS[dKey]||DIFFICULTY_LEVELS.intermediate;return(
        <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
          <div style={{display:"flex",alignItems:"center",gap:5,padding:"4px 12px",background:`${d.color}12`,border:`1px solid ${d.color}30`,borderRadius:20}}>
            <span style={{fontSize:12}}>{d.icon}</span>
            <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:10,letterSpacing:2,color:d.color}}>{d.label}</span>
          </div>
          {d.friendlyFire&&<span style={{fontSize:9,padding:"3px 9px",borderRadius:20,background:"#FF2D5520",border:"1px solid #FF2D5540",color:"#FF2D55"}}>🔥 FRIENDLY FIRE ON</span>}
          {d.ranked&&<span style={{fontSize:9,padding:"3px 9px",borderRadius:20,background:"#FFCC0020",border:"1px solid #FFCC0040",color:"#FFCC00"}}>🏅 RANKED</span>}
          {player.alive&&!player.usedFreeRespawn&&d.respawn&&<span style={{fontSize:9,padding:"3px 9px",borderRadius:20,background:"#34C75920",border:"1px solid #34C75940",color:"#34C759"}}>❤️‍🔥 Free respawn ready</span>}
          {player.alive&&player.usedFreeRespawn&&d.respawn&&<span style={{fontSize:9,padding:"3px 9px",borderRadius:20,background:"#55555520",border:"1px solid #55555540",color:"#555"}}>❤️‍🔥 Respawn used</span>}
        </div>
      );})()}
      {/* Zone warning banner */}
      {!zoneDismissed&&zoneStatus&&zoneStatus!=="ok"&&(
        <div onClick={onZoneScreen} style={{cursor:"pointer"}}>
          <ZoneBanner distToEdge={distToEdge} status={zoneStatus} graceSecs={graceSecs} onDismiss={e=>{e.stopPropagation();onZoneDismiss();}}/>
        </div>
      )}
      {/* Speed warning banner (non-blocking yellow nudge) */}
      {zoneStatus==="ok"&&speedState==="warn"&&speedKmh>0&&(
        <SpeedWarnBanner speedKmh={speedKmh}/>
      )}
      {/* Active mines banner */}
      <ActiveMinesBanner game={game} myId={myId} onOpenSweeper={()=>onSetScreen("inventory")}/>
      {/* Actions */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>
        {[
          {e:"👕",l:"MY QR",  sc:"qr",  border:"#00C7BE",disabled:false},
          {e:"🎯",l:"SHOOT",  sc:"scan", border:"#FF2D55",disabled:!player.alive},
          {e:"🎒",l:`BAG(${inv})`,sc:"inventory",border:"#FF9500",disabled:false},
          {e:"🏪",l:"SHOP",   sc:"shop", border:"#FFCC00",disabled:false},
        ].map(({e,l,sc,border,disabled})=>(
          <button key={sc} onClick={()=>onSetScreen(sc)} disabled={disabled} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:4,padding:"10px 2px",borderRadius:12,border:`2px solid ${disabled?"#2a2a3a":border}`,background:"#0d0e1a",color:disabled?"#333":"#f0f0f8",fontFamily:"'Space Mono',monospace",fontSize:10,cursor:disabled?"not-allowed":"pointer"}}>
            <span style={{fontSize:20}}>{e}</span>{l}
          </button>
        ))}
      </div>
      {/* Loot code quick-entry */}
      <LootEntry game={game} myId={myId} shared={shared}/>
      {/* Feed */}
      <div style={{display:"flex",flexDirection:"column",gap:4}}>
        {events.map((e,i)=>{const l=evtLine(e);return l?<div key={i} style={{padding:"6px 10px",borderRadius:8,fontSize:11,borderLeft:`2px solid ${e.type==="kill"?"#FF9500":"#FF2D55"}`,background:"#0d0e1a",color:e.type==="kill"?"#ffcc77":"#ff8899",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{l}</div>:null;})}
      </div>
      {/* Leaderboard FAB */}
      <button onClick={()=>onSetScreen("leaderboard")} style={{position:"fixed",bottom:20,right:20,background:"#FF9500",border:"none",borderRadius:"50%",width:48,height:48,fontSize:20,cursor:"pointer",boxShadow:"0 4px 16px #FF950044",zIndex:50}}>🏆</button>
      {/* Music Hunt FAB */}
      <button onClick={()=>onSetScreen("hunt")} style={{position:"fixed",bottom:20,left:20,background:"#BF5AF2",border:"none",borderRadius:"50%",width:48,height:48,fontSize:20,cursor:"pointer",boxShadow:"0 4px 16px #BF5AF244",zIndex:50}}>🎵</button>
      {/* Rules FAB */}
      <button onClick={()=>onSetScreen("rules")} style={{position:"fixed",bottom:78,left:20,background:"#1a1d2e",border:"1px solid #2a2a3a",borderRadius:"50%",width:40,height:40,fontSize:16,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,.4)",zIndex:50}}>📋</button>
      {/* Zone FAB — colour reflects current zone status */}
      <button onClick={onZoneScreen} style={{position:"fixed",bottom:128,left:20,background:zoneStatus==="ok"||!zoneStatus?"#1a1d2e":zoneStatus==="approaching"?"#FF950020":"#FF2D5520",border:`1px solid ${zoneStatus==="ok"||!zoneStatus?"#2a2a3a":zoneStatus==="approaching"?"#FF9500":"#FF2D55"}`,borderRadius:"50%",width:40,height:40,fontSize:16,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,.4)",zIndex:50,animation:zoneStatus==="grace"?"glow 1s ease-in-out infinite":"none"}}>📍</button>
      {/* Territory FAB */}
      <button onClick={()=>onSetScreen("territory")} style={{position:"fixed",bottom:178,left:20,background:"#FFCC0015",border:"1px solid #FFCC0040",borderRadius:"50%",width:40,height:40,fontSize:16,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,.4)",zIndex:50}}>🏴</button>
      {/* Scoreboard FAB */}
      <button onClick={()=>onSetScreen("scoreboard")} style={{position:"fixed",bottom:228,left:20,background:"#FF2D5515",border:"1px solid #FF2D5540",borderRadius:"50%",width:40,height:40,fontSize:16,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,.4)",zIndex:50}}>📺</button>
      {/* Dead City / Zombie FAB */}
      <button onClick={()=>onSetScreen("zombie")} style={{position:"fixed",bottom:278,left:20,background:"#34C75915",border:"1px solid #34C75940",borderRadius:"50%",width:40,height:40,fontSize:16,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,.4)",zIndex:50,animation:"breathe 3s ease-in-out infinite"}}>☣️</button>
      {/* Daily Spin FAB — pulsing dot shows spin available */}
      <button onClick={()=>onSetScreen("daily_spin")} style={{position:"fixed",bottom:328,left:20,background:"#FFCC0015",border:"1px solid #FFCC0040",borderRadius:"50%",width:40,height:40,fontSize:16,cursor:"pointer",boxShadow:"0 2px 8px rgba(0,0,0,.4)",zIndex:50,position:"fixed"}}>
        🎰
        <div style={{position:"absolute",top:-2,right:-2,width:10,height:10,borderRadius:"50%",background:"#FF2D55",animation:"pulse 1.5s ease-in-out infinite",border:"2px solid #07080f"}}/>
      </button>
    </div>
  );
}

function LootEntry({game,myId,shared}){
  const [code,setCode]=useState("");
  const [msg,setMsg]=useState(null);
  const [scanning,setScanning]=useState(false); // simulated camera scan state
  const [hsPayload,setHsPayload]=useState(null); // pending handshake claim

  const redeem=async(codeStr)=>{
    const target=(codeStr||code).toUpperCase();
    // Check if it's a handshake QR payload (CF:CODE:SIG format)
    if(target.startsWith("CF:")) {
      const parsed=verifyHandshakePayload(target);
      if(!parsed){setMsg({ok:false,t:"Invalid handshake QR"});setTimeout(()=>setMsg(null),2000);return;}
      // Look up the code in storage
      const c=(await rd(KEYS.codes))||{};
      const entry=c[parsed.code];
      if(!entry){setMsg({ok:false,t:"Handshake code not found"});setTimeout(()=>setMsg(null),2000);return;}
      if(entry.used){setMsg({ok:false,t:"Already claimed"});setTimeout(()=>setMsg(null),2000);return;}
      if(entry.expiresAt&&Date.now()>entry.expiresAt){setMsg({ok:false,t:"⏰ QR expired — ask bartender for new one"});setTimeout(()=>setMsg(null),3000);return;}
      // Show claim sheet
      setHsPayload({...entry,...parsed});
      setCode("");return;
    }
    // Normal text code path
    const c=(await rd(KEYS.codes))||{};
    const entry=c[target];
    if(!entry){setMsg({ok:false,t:"Invalid code"});setTimeout(()=>setMsg(null),2000);return;}
    if(entry.used){setMsg({ok:false,t:"Already used"});setTimeout(()=>setMsg(null),2000);return;}
    c[target]={...entry,used:true,usedBy:myId,usedAt:Date.now()};
    await wr(KEYS.codes,c);
    await shared.mutGame(g=>{
      const p=g.players[myId];if(!p)return g;
      let u={...p};
      const id=entry.itemId;
      if(id==="coins50")u.coins=(p.coins||0)+50;
      else if(id==="coins100")u.coins=(p.coins||0)+100;
      else u.inventory={...p.inventory,[id]:(p.inventory[id]||0)+1};
      return{...g,players:{...g.players,[myId]:u},events:[...(g.events||[]),{id:uid(),type:"loot",from:myId,item:id,ts:Date.now()}].slice(-30)};
    });
    setMsg({ok:true,t:`✅ Got ${entry.itemEmoji} ${entry.itemName}!`});
    setCode(""); setTimeout(()=>setMsg(null),3000);
  };

  const claimHandshake=async(payload)=>{
    const c=(await rd(KEYS.codes))||{};
    if(!c[payload.code]||c[payload.code].used){setMsg({ok:false,t:"Already claimed"});setHsPayload(null);setTimeout(()=>setMsg(null),2000);return;}
    c[payload.code]={...c[payload.code],used:true,usedBy:myId,usedAt:Date.now(),claimed:true};
    await wr(KEYS.codes,c);
    // Also write claim signal so bartender screen updates
    try{await window.storage.set(`hs:${payload.code}`,JSON.stringify({claimed:true,ts:Date.now()}),true);}catch{}
    await shared.mutGame(g=>{
      const p=g.players[myId];if(!p)return g;
      let u={...p};
      const id=payload.itemId;
      if(id==="coins50"||id==="coins100")u.coins=(p.coins||0)+(id==="coins100"?100:50);
      else u.inventory={...p.inventory,[id]:(p.inventory[id]||0)+1};
      return{...g,players:{...g.players,[myId]:u},events:[...(g.events||[]),{id:uid(),type:"loot",from:myId,item:id,ts:Date.now()}].slice(-30)};
    });
    setHsPayload(null);
    setMsg({ok:true,t:`🤝 ${payload.itemEmoji||"🎁"} ${payload.itemName} claimed from ${payload.barName}!`});
    setTimeout(()=>setMsg(null),4000);
  };

  // Simulate "scan with camera" — in prod replace with a real QR scanner lib
  const simulateScan=()=>{
    setScanning(true);
    setTimeout(()=>{
      // Simulate finding a CF: code — in real app this comes from camera stream
      setScanning(false);
      setMsg({ok:false,t:"📸 Point camera at bartender's screen (demo: type CF: code manually)"});
      setTimeout(()=>setMsg(null),3000);
    },1500);
  };

  return(
    <div style={{display:"flex",flexDirection:"column",gap:6}}>
      <div style={{display:"flex",gap:6}}>
        <input style={{...S.input,flex:1,fontSize:12,letterSpacing:2,padding:"9px 12px"}} placeholder="LOOT CODE OR SCAN QR 🤝" value={code} onChange={e=>setCode(e.target.value.toUpperCase())} maxLength={16}/>
        {/* Camera scan button */}
        <button onClick={simulateScan} title="Scan bartender QR" style={{background:scanning?"#00C7BE20":"#0d0e1a",border:`1px solid ${scanning?"#00C7BE":"#2a2a3a"}`,borderRadius:10,padding:"9px 12px",fontSize:16,cursor:"pointer",transition:"all .15s",animation:scanning?"pulse .6s ease-in-out infinite":"none"}}>
          {scanning?"⏳":"📷"}
        </button>
        <button onClick={()=>redeem()} style={{background:"#FFCC00",border:"none",borderRadius:10,padding:"9px 14px",fontSize:16,cursor:"pointer"}}>🎁</button>
      </div>
      {msg&&<div style={{fontSize:11,padding:"6px 10px",borderRadius:8,background:msg.ok?"#34C75920":"#FF2D5520",border:`1px solid ${msg.ok?"#34C759":"#FF2D55"}`,color:msg.ok?"#34C759":"#FF2D55"}}>{msg.t}</div>}
      {/* Handshake claim sheet */}
      {hsPayload&&<HandshakeClaim payload={hsPayload} onClaim={claimHandshake} onDismiss={()=>setHsPayload(null)}/>}
    </div>
  );
}

function QRScreen({player,onBack}){
  const qr=genQR(player.id,200);
  return(
    <div style={{...S.screen,alignItems:"center"}}>
      <button style={{...S.btnGhost,alignSelf:"flex-start"}} onClick={onBack}>← BACK</button>
      <div style={S.title}>YOUR T-SHIRT QR</div>
      <div style={{fontSize:11,color:"#555"}}>Print or display on your back</div>
      <div style={{background:"#fff",borderRadius:16,padding:20,display:"flex",flexDirection:"column",alignItems:"center",gap:8}}>
        <img src={qr} alt="QR" style={{width:200,height:200,imageRendering:"pixelated"}}/>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#000",letterSpacing:2}}>{player.avatar} {player.name}</div>
        <div style={{fontSize:11,color:"#555",letterSpacing:3}}>{player.id}</div>
      </div>
      <div style={{...S.card,fontSize:12,color:"#555",textAlign:"center",lineHeight:1.7}}>💡 Screenshot &amp; print, or hold phone facing outward on your back</div>
    </div>
  );
}

function ScanScreen({game,myId,onFire,onBack}){
  const player=game?.players?.[myId];
  const others=Object.values(game?.players||{}).filter(p=>p.id!==myId);
  const [weapon,setWeapon]=useState(WEAPONS[0]);
  const [result,setResult]=useState(null);
  const [manual,setManual]=useState("");
  const fire=async id=>{
    if(result)return;
    const tgt=game.players[id];
    if(!tgt)return;
    if(tgt.cloaked){setResult({type:"cloaked",name:tgt.name});setTimeout(()=>{setResult(null);onBack();},1500);return;}
    const r=await onFire(id,weapon);
    setResult({type:r.result,name:tgt.name,dmg:r.dmg});
    setTimeout(()=>{setResult(null);onBack();},1400);
  };
  return(
    <div style={{...S.screen,gap:12}}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={S.title}>🎯 TAKE YOUR SHOT</div>
      <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
        {WEAPONS.map(w=><button key={w} onClick={()=>setWeapon(w)} style={{padding:"5px 10px",borderRadius:20,border:`1px solid ${weapon===w?"#FF2D55":"#2a2a3a"}`,background:weapon===w?"#FF2D5515":"#0d0e1a",color:weapon===w?"#FF2D55":"#666",fontFamily:"'Space Mono',monospace",fontSize:10,cursor:"pointer"}}>{w}</button>)}
      </div>
      {result&&(
        <div style={{padding:14,borderRadius:12,textAlign:"center",fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,animation:"popIn .3s ease",background:result.type==="kill"?"#FF2D5520":result.type==="cloaked"?"#BF5AF220":"#FF950020",border:`1px solid ${result.type==="kill"?"#FF2D55":result.type==="cloaked"?"#BF5AF2":"#FF9500"}`,color:result.type==="kill"?"#FF2D55":result.type==="cloaked"?"#BF5AF2":"#FF9500"}}>
          {result.type==="kill"?`💀 KILLED ${result.name}!`:result.type==="cloaked"?`👻 ${result.name} CLOAKED — MISS!`:`💥 HIT ${result.name} for ${result.dmg} dmg!`}
        </div>
      )}
      <div style={{display:"flex",flexDirection:"column",gap:8}}>
        {others.length===0&&<div style={{...S.card,textAlign:"center",color:"#444",fontSize:12}}>No other players yet</div>}
        {others.map(t=>(
          <button key={t.id} onClick={()=>fire(t.id)} disabled={!!result||!t.alive} style={{...S.card,display:"flex",alignItems:"center",gap:10,cursor:t.alive&&!result?"pointer":"not-allowed",opacity:t.alive?1:.4,border:`2px solid ${t.cloaked?"#BF5AF2":"#2a2a3a"}`,textAlign:"left"}}>
            <span style={{fontSize:28}}>{t.avatar}</span>
            <div style={{flex:1}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1}}>{t.name}</div>
              <HPBar hp={t.hp} max={t.maxHp}/>
              <div style={{fontSize:10,color:"#555",marginTop:4}}>{t.alive?(t.cloaked?"👻 CLOAKED":`${t.hp} HP · ${t.kills} kills`):"💀 DEAD"}</div>
            </div>
            {t.alive&&!t.cloaked&&<div style={{background:"#FF2D55",color:"#fff",fontFamily:"'Black Han Sans',sans-serif",fontSize:11,padding:"5px 10px",borderRadius:8}}>FIRE</div>}
          </button>
        ))}
      </div>
      <div style={{display:"flex",gap:8}}>
        <input style={{...S.input,flex:1,fontSize:12,padding:"9px 12px"}} placeholder="ENEMY ID (manual)" value={manual} onChange={e=>setManual(e.target.value.toUpperCase())} maxLength={6}/>
        <button onClick={()=>{if(manual.trim())fire(manual.trim());}} style={{...S.btnGold,width:"auto",padding:"0 16px",fontSize:14}}>FIRE!</button>
      </div>
    </div>
  );
}

function ShopScreen({game,myId,onBuy,onTopUp,onBack}){
  const player=game?.players?.[myId];
  const [bought,setBought]=useState(null);
  const [showTopUp,setShowTopUp]=useState(false);
  const [topUpPack,setTopUpPack]=useState(null);
  const buy=async item=>{
    if(!player||player.coins<item.c)return;
    await onBuy(item);setBought(item.id);setTimeout(()=>setBought(null),800);
  };
  if(showTopUp&&topUpPack)return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={()=>{setShowTopUp(false);setTopUpPack(null);}}>← BACK</button>
      <div style={S.title}>💳 TOP UP COINS</div>
      <PayFlow pack={topUpPack} onConfirm={async coins=>{await onTopUp(coins);setShowTopUp(false);setTopUpPack(null);}} onCancel={()=>{setShowTopUp(false);setTopUpPack(null);}}/>
    </div>
  );
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div style={S.title}>🏪 COIN SHOP</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:"#FFCC00",background:"#0d0e1a",border:"1px solid #2a2a3a",padding:"6px 14px",borderRadius:10}}>🪙 {player?.coins||0}</div>
      </div>
      {SHOP_ITEMS.map(item=>{const can=player?.coins>=item.c,jb=bought===item.id;return(
        <div key={item.id} style={{...S.card,display:"flex",alignItems:"center",gap:10,opacity:can?1:.4,border:`1px solid ${jb?"#00C7BE":"#1a1d2e"}`}}>
          <span style={{fontSize:26}}>{item.e}</span>
          <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1}}>{item.n}</div><div style={{fontSize:10,color:"#555"}}>{item.d}</div></div>
          <button onClick={()=>buy(item)} disabled={!can} style={{background:jb?"#00C7BE":"#FFCC00",border:"none",borderRadius:8,color:"#000",fontFamily:"'Black Han Sans',sans-serif",fontSize:12,padding:"7px 12px",cursor:can?"pointer":"not-allowed"}}>{jb?"✓":`🪙${item.c}`}</button>
        </div>
      );})}
      <div style={{...S.card,borderColor:"#FFCC0030"}}>
        <div style={{...S.label,marginBottom:8}}>NEED MORE COINS?</div>
        {COIN_PACKS.map(p=>(
          <div key={p.id} onClick={()=>{setTopUpPack(p);setShowTopUp(true);}} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:"1px solid #1a1d2e",cursor:"pointer"}}>
            <span style={{fontSize:22}}>{p.emoji}</span>
            <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12}}>{p.label}</div><div style={{fontSize:10,color:"#555"}}>{p.desc}</div></div>
            <div style={{textAlign:"right"}}><div style={{fontSize:11,color:"#FFCC00"}}>🪙{p.coins}</div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:15,color:"#00C7BE"}}>{fmt(p.price)}</div></div>
          </div>
        ))}
      </div>
    </div>
  );
}

function InventoryScreen({game,myId,onUse,onBack}){
  const player=game?.players?.[myId];
  const items=Object.entries(player?.inventory||{}).filter(([,n])=>n>0);
  const def=id=>SHOP_ITEMS.find(x=>x.id===id)||{e:"❓",n:id,d:""};
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={S.title}>🎒 INVENTORY</div>
      {items.length===0&&<div style={{...S.card,textAlign:"center",color:"#444",fontSize:12}}>Empty — buy from the shop or redeem a loot code!</div>}
      {items.map(([id,count])=>{const d=def(id);return(
        <div key={id} style={{...S.card,display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:26}}>{d.e}</span>
          <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1}}>{d.n}{count>1?` ×${count}`:""}</div><div style={{fontSize:10,color:"#555"}}>{d.d}</div></div>
          <button onClick={()=>onUse(id)} style={{background:"#00C7BE",border:"none",borderRadius:8,color:"#000",fontFamily:"'Black Han Sans',sans-serif",fontSize:12,padding:"7px 12px",cursor:"pointer"}}>USE</button>
        </div>
      );})}
    </div>
  );
}

function HuntScreen({hunt,game,myId,onScanMusician,onBack}){
  const player=hunt?.players?.[myId]||{found:[],rewards:[],coins:0};
  const musicians=hunt?.musicians||[];
  const found=player.found||[];
  const [scanId,setScanId]=useState(null);
  const [reward,setReward]=useState(null);
  const [tipAmt,setTipAmt]=useState(null);
  const [tipMethod,setTipMethod]=useState(null);
  const doTip=method=>{setTipMethod(method);const m=musicians.find(x=>x.id===scanId);window.open(method==="paypal"?ppLink(tipAmt,`Tip for ${m?.name} 🎵`):vmLink(tipAmt,`Tip for ${m?.name} 🎵`),"_blank");};
  const confirmTip=async()=>{const m=musicians.find(x=>x.id===scanId);await onScanMusician(scanId,tipAmt*100);setReward(m?.reward);setScanId(null);setTipAmt(null);setTipMethod(null);};
  const skipTip=async()=>{const m=musicians.find(x=>x.id===scanId);await onScanMusician(scanId,0);setReward(m?.reward);setScanId(null);};
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={S.title}>🎵 MUSIC HUNT</div>
      <div style={{...S.card}}>
        <div style={{display:"flex",justifyContent:"space-between",fontSize:11,marginBottom:6}}><span style={{color:"#555",letterSpacing:1}}>MUSICIANS FOUND</span><span style={{color:"#FFCC00"}}>{found.length}/{musicians.length}</span></div>
        <div style={{height:6,background:"#2a2a3a",borderRadius:3,overflow:"hidden"}}><div style={{height:"100%",width:`${musicians.length?found.length/musicians.length*100:0}%`,background:"linear-gradient(90deg,#FFCC00,#FF9500)",borderRadius:3,transition:"width .6s"}}/></div>
        {found.length===musicians.length&&musicians.length>0&&<div style={{marginTop:8,textAlign:"center",fontSize:11,color:"#FFCC00"}}>🏆 ALL MUSICIANS FOUND!</div>}
      </div>
      {musicians.map(m=>{
        const isFound=found.includes(m.id);
        const rm=RARITY[m.reward?.rarity||"common"];
        return(
          <div key={m.id} style={{...S.card,border:`2px solid ${isFound?rm.c:"#1a1d2e"}`,boxShadow:isFound?`0 0 16px ${rm.c}30`:"none"}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:10}}>
              <span style={{fontSize:30,filter:isFound?`drop-shadow(0 0 6px ${rm.c})`:"none"}}>{m.av}</span>
              <div style={{flex:1}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:isFound?rm.c:"#f0f0f8"}}>{isFound?m.name:"???"}</div>
                <div style={{fontSize:10,color:"#555",marginTop:2}}>{m.bar}{isFound?` · ${m.area}`:""}</div>
              </div>
              <Pill label={isFound?"FOUND":"HIDDEN"} color={isFound?rm.c:"#555"}/>
            </div>
            <div style={{fontSize:11,color:isFound?"#aaa":"#444",fontStyle:"italic",marginBottom:isFound?0:8}}>{isFound?m.hint:m.hidden?"🔒 Find them to reveal the clue":`🔓 ${m.hint}`}</div>
            {isFound&&<div style={{marginTop:8,display:"flex",alignItems:"center",gap:8,background:`${rm.c}10`,border:`1px solid ${rm.c}30`,borderRadius:8,padding:"8px 10px"}}>
              <span style={{fontSize:22}}>{m.reward?.e}</span>
              <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,color:rm.c}}>{m.reward?.n}</div><div style={{fontSize:10,color:"#555"}}>{m.reward?.d}</div></div>
              <Pill label={(RARITY[m.reward?.rarity]||RARITY.common).label||"?"} color={rm.c}/>
            </div>}
            {!isFound&&!m.hidden&&!found.includes(m.id)&&<button onClick={()=>setScanId(m.id)} style={{...S.btnGold,fontSize:13,padding:"9px 0"}}>📸 SCAN TO FIND</button>}
          </div>
        );
      })}
      {/* Tip modal */}
      {scanId&&!reward&&(()=>{const m=musicians.find(x=>x.id===scanId);return(
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.9)",display:"flex",alignItems:"flex-end",justifyContent:"center",zIndex:200}}>
          <div style={{background:"#0d0e1a",border:"1px solid #2a2a3a",borderTopLeftRadius:20,borderTopRightRadius:20,padding:"28px 20px 44px",width:"100%",maxWidth:420,animation:"slideUp .3s ease"}}>
            <div style={{textAlign:"center",marginBottom:16}}>
              <div style={{fontSize:44}}>{m.av}</div>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,letterSpacing:2}}>{m.name}</div>
              <div style={{fontSize:11,color:"#555"}}>{m.inst} · {m.bar}</div>
              <div style={{fontSize:12,color:"#888",marginTop:8,lineHeight:1.7}}>You found a hidden musician! 🎉<br/>Tip them to unlock your reward.</div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:12}}>
              {[1,2,5].map(a=><button key={a} onClick={()=>setTipAmt(a)} style={{padding:"12px 4px",borderRadius:10,border:`2px solid ${tipAmt===a?"#FFCC00":"#2a2a3a"}`,background:tipAmt===a?"#FFCC0015":"#1a1a26",color:tipAmt===a?"#FFCC00":"#888",fontFamily:"'Black Han Sans',sans-serif",fontSize:20,cursor:"pointer"}}>${a}<div style={{fontSize:9,color:tipAmt===a?"#FFCC0080":"#444",marginTop:2}}>TIP</div></button>)}
            </div>
            {tipAmt&&(<div style={{display:"flex",gap:8,marginBottom:10}}>
              <button onClick={()=>doTip("paypal")} style={{flex:1,padding:11,border:`2px solid ${tipMethod==="paypal"?"#003087":"#2a2a3a"}`,borderRadius:10,background:tipMethod==="paypal"?"#00308722":"#1a1a26",color:tipMethod==="paypal"?"#4fc3ff":"#888",fontFamily:"'Black Han Sans',sans-serif",fontSize:13,cursor:"pointer"}}>🅿️ PayPal</button>
              <button onClick={()=>doTip("venmo")}  style={{flex:1,padding:11,border:`2px solid ${tipMethod==="venmo"?"#3D95CE":"#2a2a3a"}`,borderRadius:10,background:tipMethod==="venmo"?"#3D95CE22":"#1a1a26",color:tipMethod==="venmo"?"#4fc3ff":"#888",fontFamily:"'Black Han Sans',sans-serif",fontSize:13,cursor:"pointer"}}>💙 Venmo</button>
            </div>)}
            {tipMethod&&tipAmt&&<button onClick={confirmTip} style={{...S.btnGold,marginBottom:8}}>CONFIRM TIP — CLAIM REWARD 🎁</button>}
            <button onClick={skipTip} style={{width:"100%",background:"none",border:"none",color:"#444",fontFamily:"'Space Mono',monospace",fontSize:11,cursor:"pointer",padding:6}}>Skip tip — just say hi</button>
          </div>
        </div>
      );})()}
      {/* Reward pop */}
      {reward&&(()=>{const rm=RARITY[reward.rarity||"common"];return(
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.85)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:300}} onClick={()=>setReward(null)}>
          <div style={{background:"#0d0e1a",border:`2px solid ${rm.c}`,borderRadius:20,padding:"36px 28px",textAlign:"center",maxWidth:280,boxShadow:`0 0 60px ${rm.c}40`,animation:"popIn .4s cubic-bezier(.34,1.56,.64,1)"}}>
            <div style={{fontSize:64,marginBottom:10,filter:`drop-shadow(${rm.g})`}}>{reward.e}</div>
            <div style={{fontSize:10,letterSpacing:4,color:rm.c,marginBottom:6}}>{(rm.label||"").toUpperCase()}</div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:24,letterSpacing:2,marginBottom:6}}>{reward.n}</div>
            <div style={{fontSize:12,color:"#888",marginBottom:20,lineHeight:1.6}}>{reward.d}</div>
            <button onClick={()=>setReward(null)} style={{...S.btnPrimary,background:`linear-gradient(135deg,${rm.c},${rm.c}99)`}}>CLAIM REWARD →</button>
          </div>
        </div>
      );})()}
    </div>
  );
}

function LeaderboardScreen({game,myId,onBack}){
  const players=Object.values(game?.players||{}).sort((a,b)=>(b.kills-a.kills)||(b.hp-a.hp));
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={S.title}>🏆 LEADERBOARD</div>
      {game?.pot>0&&<div style={{...S.card,textAlign:"center",background:"#FFCC0010",border:"1px solid #FFCC0030"}}>
        <div style={{fontSize:10,color:"#FFCC00",letterSpacing:2}}>XP POOL</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:36,color:"#FFCC00"}}>{fmt(game.pot)}</div>
        <div style={{fontSize:11,color:"#555"}}>Winner takes all · paid at 23:59</div>
      </div>}
      {players.map((p,i)=>(
        <div key={p.id} style={{...S.card,display:"flex",alignItems:"center",gap:10,border:`1px solid ${p.id===myId?"#FF9500":"#1a1d2e"}`,background:p.id===myId?"#FF950010":"#0d0e1a"}}>
          <div style={{fontSize:20,width:28,textAlign:"center"}}>{["🥇","🥈","🥉"][i]||`#${i+1}`}</div>
          <span style={{fontSize:26}}>{p.avatar}</span>
          <div style={{flex:1}}>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1}}>{p.name}{p.id===myId&&<span style={{fontSize:9,color:"#FF9500",marginLeft:6}}>YOU</span>}</div>
            <div style={{fontSize:10,color:"#555",marginTop:2}}>{p.kills} kills · {Math.max(0,p.hp)} HP · 🪙{p.coins}</div>
          </div>
          {!p.alive&&<span style={{fontSize:18}}>💀</span>}
        </div>
      ))}
    </div>
  );
}

// ─── AUTO-PAY ENGINE ──────────────────────────────────────────────────────────
const sleep = ms => new Promise(r => setTimeout(r, ms));

function PayoutEngine({pot, winner, players, onComplete}) /* pot = XP pool */ {
  const [stage,    setStage]    = useState("countdown"); // countdown|processing|breakdown|done
  const [count,    setCount]    = useState(5);
  const [log,      setLog]      = useState([]);
  const [txId,     setTxId]     = useState(null);
  const [method,   setMethod]   = useState(null);
  const addLog = (msg, type="info") => setLog(l => [...l, {msg, type, ts: Date.now()}]);
  const totalPot   = pot || 0;
  const platformCut = Math.round(totalPot * 0.30 * 100) / 100;
  const winnerPay   = Math.round(totalPot * 0.70 * 100) / 100;
  const playerCount = Object.keys(players||{}).length;

  // Countdown then auto-run
  useEffect(() => {
    if (stage !== "countdown") return;
    if (count <= 0) { runPayout(); return; }
    const id = setTimeout(() => setCount(c => c - 1), 1000);
    return () => clearTimeout(id);
  }, [count, stage]);

  const runPayout = async () => {
    setStage("processing");
    addLog("🔐 Initiating secure payout...", "info");
    await sleep(600);
    addLog(`🏦 Connecting to Stripe Connect...`, "info");
    await sleep(900);
    addLog("✅ Stripe authenticated", "success");
    await sleep(400);
    addLog(`🏆 Winner: ${winner?.avatar} ${winner?.name}`, "info");
    await sleep(500);
    addLog(`💰 XP pool: ${fmt(totalPot)} (${playerCount} players)`, "info");
    await sleep(400);
    addLog(`📊 Platform fee: ${fmt(platformCut)} (30%)`, "info");
    await sleep(400);
    addLog(`💸 Winner payout: ${fmt(winnerPay)} (70%)`, "success");
    await sleep(600);
    // Simulate payment method detection
    const m = Math.random() > 0.5 ? "PayPal" : "Venmo";
    setMethod(m);
    addLog(`📱 Routing via ${m}...`, "info");
    await sleep(800);
    const tx = uid();
    setTxId(tx);
    addLog(`✅ TRANSFER COMPLETE — TX: ${tx}`, "success");
    await sleep(300);
    addLog(`📧 Receipt sent to ${winner?.name}`, "success");
    setStage("breakdown");
  };

  const skip = () => { setCount(0); };

  if (stage === "countdown") return (
    <div style={{...S.card, background:"#0a0a12", border:"2px solid #FFCC0040", textAlign:"center", padding:24, display:"flex", flexDirection:"column", gap:14, alignItems:"center"}}>
      <div style={{fontSize:10, letterSpacing:3, color:"#555"}}>AUTO-PAY INITIATING IN</div>
      <div style={{fontFamily:"'Black Han Sans',sans-serif", fontSize:72, color:"#FFCC00", textShadow:"0 0 30px #FFCC0060", lineHeight:1, animation:"breathe 1s ease-in-out infinite"}}>{count}</div>
      <div style={{fontSize:11, color:"#555"}}>Winner payment processing automatically</div>
      <div style={{display:"flex", gap:8, width:"100%"}}>
        <button onClick={skip} style={{...S.btnGold, flex:1, padding:12, fontSize:14}}>⚡ PAY NOW</button>
        <button onClick={onComplete} style={{...S.btnGhost, flex:1, padding:12}}>SKIP</button>
      </div>
    </div>
  );

  if (stage === "processing") return (
    <div style={{...S.card, background:"#0a0a12", border:"2px solid #34C75940", display:"flex", flexDirection:"column", gap:10}}>
      <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:4}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif", fontSize:14, letterSpacing:2, color:"#34C759"}}>⚡ PROCESSING PAYOUT</div>
        <div style={{display:"flex", alignItems:"center", gap:5}}>
          <div style={{width:6, height:6, borderRadius:"50%", background:"#34C759", animation:"pulse 1s ease-in-out infinite"}}/>
          <span style={{fontSize:9, color:"#34C759", letterSpacing:1}}>LIVE</span>
        </div>
      </div>
      <div style={{maxHeight:180, overflowY:"auto", display:"flex", flexDirection:"column", gap:4}}>
        {log.map((l,i) => (
          <div key={i} style={{display:"flex", gap:8, fontFamily:"'Space Mono',monospace", fontSize:10}}>
            <span style={{color:"#333", flexShrink:0}}>{new Date(l.ts).toLocaleTimeString("en-US",{hour12:false,hour:"2-digit",minute:"2-digit",second:"2-digit"})}</span>
            <span style={{color:l.type==="success"?"#34C759":l.type==="error"?"#FF2D55":"#888"}}>{l.msg}</span>
          </div>
        ))}
        {log.length === 0 && <div style={{fontSize:11,color:"#333",textAlign:"center",padding:12}}>Initialising...</div>}
      </div>
    </div>
  );

  if (stage === "breakdown" || stage === "done") return (
    <div style={{display:"flex", flexDirection:"column", gap:12, width:"100%"}}>
      {/* Success banner */}
      <div style={{...S.card, background:"#34C75918", border:"2px solid #34C759", textAlign:"center", padding:20, animation:"popIn .4s ease"}}>
        <div style={{fontSize:40, marginBottom:6}}>✅</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif", fontSize:22, letterSpacing:3, color:"#34C759"}}>PAYMENT SENT!</div>
        <div style={{fontSize:12, color:"#888", marginTop:4}}>{fmt(winnerPay)} → {winner?.avatar} {winner?.name} via {method}</div>
        {txId && <div style={{fontSize:9, color:"#555", marginTop:6, fontFamily:"'Space Mono',monospace", letterSpacing:1}}>TX: {txId}</div>}
      </div>

      {/* Money breakdown */}
      <div style={{...S.card, display:"flex", flexDirection:"column", gap:0}}>
        <div style={{fontSize:10, letterSpacing:3, color:"#555", marginBottom:10}}>XP POOL BREAKDOWN</div>

        {/* Visual split bar */}
        <div style={{height:12, borderRadius:6, overflow:"hidden", display:"flex", marginBottom:10}}>
          <div style={{flex:70, background:"linear-gradient(90deg,#FFCC00,#FF9500)", position:"relative", display:"flex", alignItems:"center", justifyContent:"center"}}>
            <span style={{fontSize:8, color:"#000", fontWeight:"bold", letterSpacing:1}}>WINNER 70%</span>
          </div>
          <div style={{flex:30, background:"linear-gradient(90deg,#FF2D55,#FF6B35)", display:"flex", alignItems:"center", justifyContent:"center"}}>
            <span style={{fontSize:8, color:"#fff", fontWeight:"bold", letterSpacing:1}}>PLATFORM 30%</span>
          </div>
        </div>

        {[
          {e:"🏆", l:"XP pool collected",      v:fmt(totalPot),     c:"#f0f0f8", sub:`${playerCount} players × game entry`},
          {e:"💸", l:"Winner payout (70%)",      v:fmt(winnerPay),    c:"#FFCC00", sub:`Sent to ${winner?.name} via ${method}`},
          {e:"⚡", l:"Platform fee (30%)",        v:fmt(platformCut),  c:"#FF2D55", sub:"Covers hosting, Stripe, & prize guarantee"},
        ].map((row, i) => (
          <div key={i} style={{display:"flex", alignItems:"center", gap:10, padding:"9px 0", borderBottom:i<2?"1px solid #1a1d2e":"none"}}>
            <span style={{fontSize:20}}>{row.e}</span>
            <div style={{flex:1}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif", fontSize:13, letterSpacing:1}}>{row.l}</div>
              <div style={{fontSize:10, color:"#555", marginTop:1}}>{row.sub}</div>
            </div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif", fontSize:18, color:row.c}}>{row.v}</div>
          </div>
        ))}
      </div>

      {/* Payout log */}
      <div style={{...S.card, background:"#0a0a12"}}>
        <div style={{fontSize:10, letterSpacing:2, color:"#555", marginBottom:8}}>PAYOUT LOG</div>
        <div style={{maxHeight:140, overflowY:"auto", display:"flex", flexDirection:"column", gap:3}}>
          {log.map((l,i) => (
            <div key={i} style={{display:"flex", gap:8, fontFamily:"'Space Mono',monospace", fontSize:9}}>
              <span style={{color:"#333", flexShrink:0}}>{new Date(l.ts).toLocaleTimeString("en-US",{hour12:false,hour:"2-digit",minute:"2-digit",second:"2-digit"})}</span>
              <span style={{color:l.type==="success"?"#34C759":l.type==="error"?"#FF2D55":"#555"}}>{l.msg}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return null;
}

// ═══════════════════════════════════════════════════════════════════════════════
// SAFE RIDE BOOST SYSTEM — End-of-night responsible drinking reward
// ─────────────────────────────────────────────────────────────────────────────
// After the game ends players can claim a Safe Ride Boost by verifying they
// are booking a rideshare home. The verification is a short confirmation flow —
// no API key required for the demo, but structured for Uber/Lyft deep link
// integration in production.
//
// REWARDS (stack — player gets all of these):
//   🪙 +150 bonus coins  → carry into next game or spend in shop
//   ⭐ +75 XP            → counts toward level progression
//   🎰 +1 free spin slot → credited to tomorrow's daily spin
//   🎖️ Safe Rider badge   → shown on profile for 7 days
//   🔓 Unlock next game   → 10% discount on next entry fee (stored)
//
// SPONSORSHIP HOOK:
//   The "SPONSORED BY UBER" banner and deep link are designed to be sold as a
//   sponsorship placement. Uber's safety team pays $5,000–15,000/month to own
//   this screen. Lyft is the alternative. Both have active nightlife safety
//   marketing budgets. The screen is already built — just swap the logo.
//
// STORAGE KEY: cf:saferide:{playerId}:{date}  — one claim per player per night
// ═══════════════════════════════════════════════════════════════════════════════

const SAFE_RIDE_REWARDS = {
  coins:     150,
  xp:        75,
  freeSpins: 1,
  discountPct: 10,
};

const SAFE_RIDE_TIPS = [
  "You just played laser tag in a bar — you've earned a safe ride home. 🏆",
  "Every CrawlFire champion knows the real power move is getting home safe.",
  "Your crew needs you for next week's crawl. Ride safe tonight.",
  "The game's over but the night isn't — keep it legendary, not regrettable.",
  "Real players look out for each other. Share your ride code with a friend.",
];

// ── useSafeRideClaim — tracks if player has claimed tonight ──────────────────
function useSafeRideClaim(playerId) {
  const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  const key   = `cf:saferide:${playerId||"demo"}:${today}`;
  const [claimed, setClaimed] = useState(false);

  useEffect(() => {
    window.storage.get(key, false)
      .then(r => { if(r && r.value === "1") setClaimed(true); })
      .catch(() => {});
  }, [key]);

  const claim = useCallback(async () => {
    try { await window.storage.set(key, "1", false); } catch {}
    setClaimed(true);
  }, [key]);

  return { claimed, claim };
}

// ── SafeRideBoostCard — the main component shown on GameOverScreen ────────────
function SafeRideBoostCard({ playerId, playerName, onClaim, onOpenRide }) {
  const { claimed, claim } = useSafeRideClaim(playerId);
  const [step,      setStep]      = useState("prompt");  // prompt|verify|claimed
  const [tipIdx]                  = useState(Math.floor(Math.random()*SAFE_RIDE_TIPS.length));
  const [countdown, setCountdown] = useState(3);
  const [counting,  setCounting]  = useState(false);

  // Countdown before confirming
  useEffect(() => {
    if (!counting) return;
    if (countdown <= 0) { doConfirm(); return; }
    const id = setTimeout(() => setCountdown(c => c - 1), 1000);
    return () => clearTimeout(id);
  }, [counting, countdown]);

  const doConfirm = useCallback(async () => {
    await claim();
    if (onClaim) onClaim(SAFE_RIDE_REWARDS);
    setStep("claimed");
  }, [claim, onClaim]);

  const handleBookRide = () => {
    // Deep link to Uber — in production this is a sponsored affiliate link
    // Uber deeplink: uber://?action=setPickup&pickup=my_location
    // Lyft deeplink: lyft://ridetype?id=lyft
    // For demo, open Uber on mobile, fall back to uber.com
    const uberUrl = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent)
      ? "uber://?action=setPickup"
      : "https://m.uber.com/ul/?action=setPickup&pickup=my_location";
    window.open(uberUrl, "_blank");
    // Start the confirm countdown after opening ride app
    setCounting(true);
    if (onOpenRide) onOpenRide();
  };

  // Already claimed today
  if (claimed && step !== "claimed") {
    return (
      <div style={{...S.card, background:"#34C75910", border:"1px solid #34C75940",
        display:"flex", alignItems:"center", gap:10}}>
        <span style={{fontSize:22}}>🎖️</span>
        <div style={{flex:1}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif", fontSize:12,
            color:"#34C759", letterSpacing:1}}>SAFE RIDER — CLAIMED ✓</div>
          <div style={{fontSize:10, color:"#555", marginTop:2}}>
            Already claimed tonight's Safe Ride Boost
          </div>
        </div>
      </div>
    );
  }

  // Claimed just now — celebration state
  if (step === "claimed") {
    return (
      <div style={{...S.card,
        background:"linear-gradient(135deg,#34C75918,#00C7BE10)",
        border:"2px solid #34C759",
        display:"flex", flexDirection:"column", alignItems:"center",
        gap:10, textAlign:"center", padding:20,
        animation:"popIn .4s cubic-bezier(.17,.67,.29,1.35)",
      }}>
        <div style={{fontSize:52, animation:"breathe 1.5s ease-in-out infinite",
          filter:"drop-shadow(0 0 14px #34C759)"}}>🎖️</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif", fontSize:18,
          letterSpacing:2, color:"#34C759"}}>SAFE RIDER BOOST CLAIMED!</div>
        <div style={{fontSize:10, color:"#888", lineHeight:1.8}}>
          {SAFE_RIDE_TIPS[tipIdx]}
        </div>
        {/* Reward pills */}
        <div style={{display:"flex", gap:6, flexWrap:"wrap", justifyContent:"center", marginTop:4}}>
          {[
            {e:"🪙", label:`+${SAFE_RIDE_REWARDS.coins} Coins`,  col:"#FFCC00"},
            {e:"⭐", label:`+${SAFE_RIDE_REWARDS.xp} XP`,        col:"#007AFF"},
            {e:"🎰", label:"+1 Free Spin",                        col:"#BF5AF2"},
            {e:"🏷️", label:`${SAFE_RIDE_REWARDS.discountPct}% Off Next Entry`, col:"#34C759"},
          ].map((r,i) => (
            <div key={i} style={{
              display:"flex", alignItems:"center", gap:4,
              padding:"4px 10px", borderRadius:20,
              background:`${r.col}15`, border:`1px solid ${r.col}40`,
              fontFamily:"'DM Mono',monospace", fontSize:10, color:r.col,
            }}>
              {r.e} {r.label}
            </div>
          ))}
        </div>
        <div style={{fontSize:9, color:"#444", letterSpacing:1, marginTop:2}}>
          Coins and XP added · Free spin unlocks at midnight · Discount applied at next entry
        </div>
      </div>
    );
  }

  // Verify step — player has tapped "Book Ride", countdown running
  if (step === "verify") {
    return (
      <div style={{...S.card, background:"#0a0c14", border:"2px solid #34C759",
        display:"flex", flexDirection:"column", gap:12, textAlign:"center"}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif", fontSize:15,
          letterSpacing:2, color:"#34C759"}}>🚗 BOOKING YOUR RIDE?</div>
        <div style={{fontSize:11, color:"#888", lineHeight:1.8}}>
          Once you've confirmed your Uber, tap below to collect your Safe Ride Boost.
        </div>
        {/* Countdown indicator */}
        {counting && (
          <div style={{textAlign:"center"}}>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",
              fontSize:32, color:"#34C759"}}>
              {countdown > 0 ? countdown : "✓"}
            </div>
            <div style={{fontSize:9, color:"#555", letterSpacing:1}}>
              {countdown > 0 ? "Auto-confirming..." : "Confirming..."}
            </div>
          </div>
        )}
        <button onClick={doConfirm} style={{
          ...S.btnPrimary,
          background:"linear-gradient(135deg,#34C759,#00C7BE)",
          color:"#000",
        }}>
          ✓ YES, I BOOKED MY RIDE — CLAIM BOOST
        </button>
        <button onClick={()=>setStep("prompt")} style={{
          ...S.btnGhost, fontSize:11, color:"#555",
        }}>← GO BACK</button>
      </div>
    );
  }

  // Default prompt state
  return (
    <div style={{...S.card, background:"#07080f",
      border:"2px solid #34C75940",
      display:"flex", flexDirection:"column", gap:12,
      position:"relative", overflow:"hidden",
    }}>
      {/* Sponsor badge */}
      <div style={{
        position:"absolute", top:0, right:0,
        background:"#1a1d2e", borderBottomLeftRadius:8,
        padding:"3px 10px",
        fontSize:7, color:"#444", letterSpacing:2,
        fontFamily:"'DM Mono',monospace",
      }}>
        PROMOTED · UBER
      </div>

      {/* Header */}
      <div style={{display:"flex", alignItems:"center", gap:12, paddingTop:4}}>
        <div style={{
          width:44, height:44, borderRadius:12,
          background:"linear-gradient(135deg,#000,#1a1a1a)",
          border:"1px solid #34C75940",
          display:"flex", alignItems:"center", justifyContent:"center",
          fontSize:22, flexShrink:0,
        }}>🚗</div>
        <div style={{flex:1}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",
            fontSize:15, letterSpacing:1, color:"#f0f0f8"}}>
            SAFE RIDE BOOST
          </div>
          <div style={{fontSize:10, color:"#555", marginTop:2}}>
            Get home safe · Earn free rewards
          </div>
        </div>
      </div>

      {/* What you earn */}
      <div style={{background:"#0d0e1a", borderRadius:10, padding:"10px 12px"}}>
        <div style={{fontSize:9, color:"#444", letterSpacing:2,
          marginBottom:8, fontFamily:"'Black Han Sans',sans-serif"}}>
          BOOK A RIDESHARE HOME TONIGHT AND GET:
        </div>
        <div style={{display:"flex", flexDirection:"column", gap:6}}>
          {[
            {e:"🪙", t:`${SAFE_RIDE_REWARDS.coins} Bonus Coins`,    s:"Carry into your next game"},
            {e:"⭐", t:`${SAFE_RIDE_REWARDS.xp} XP`,                s:"Counts toward your rank"},
            {e:"🎰", t:"1 Free Spin",                                s:"Unlocks in tomorrow's daily wheel"},
            {e:"🏷️", t:`${SAFE_RIDE_REWARDS.discountPct}% Off`,     s:"Discount on your next game entry"},
            {e:"🎖️", t:"Safe Rider Badge",                          s:"Displayed on your profile for 7 days"},
          ].map((r,i) => (
            <div key={i} style={{display:"flex", alignItems:"center", gap:8}}>
              <span style={{fontSize:16, flexShrink:0}}>{r.e}</span>
              <div>
                <span style={{fontFamily:"'Black Han Sans',sans-serif",
                  fontSize:12, color:"#34C759"}}>{r.t}</span>
                <span style={{fontSize:10, color:"#555"}}> — {r.s}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main CTA */}
      <button onClick={handleBookRide} style={{
        display:"flex", alignItems:"center", justifyContent:"center", gap:10,
        padding:"14px 16px", border:"none", borderRadius:12, cursor:"pointer",
        background:"linear-gradient(135deg,#000000,#1a1a1a)",
        boxShadow:"0 0 20px rgba(52,199,89,.2), inset 0 1px 0 rgba(255,255,255,.06)",
      }}>
        <span style={{fontSize:22}}>⬛</span>
        <div style={{textAlign:"left"}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",
            fontSize:16, letterSpacing:2, color:"#FFFFFF"}}>BOOK UBER →</div>
          <div style={{fontSize:9, color:"#888", marginTop:1}}>
            Opens Uber app · Come back to confirm
          </div>
        </div>
      </button>

      {/* Lyft alternative */}
      <button onClick={()=>{
        const lyftUrl=/iPhone|iPad|iPod|Android/i.test(navigator.userAgent)
          ?"lyft://ridetype?id=lyft":"https://www.lyft.com/ride";
        window.open(lyftUrl,"_blank");
        setCounting(true); setStep("verify");
      }} style={{
        display:"flex", alignItems:"center", justifyContent:"center", gap:10,
        padding:"11px 16px", border:"1px solid #FF00BF30", borderRadius:12,
        cursor:"pointer", background:"#FF00BF08",
      }}>
        <span style={{fontSize:18}}>🩷</span>
        <div style={{textAlign:"left"}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",
            fontSize:13, letterSpacing:1, color:"#FF00BF"}}>USE LYFT INSTEAD</div>
          <div style={{fontSize:9, color:"#888", marginTop:1}}>
            Same rewards apply
          </div>
        </div>
      </button>

      {/* "Already have a ride" option */}
      <button onClick={()=>{
        setStep("verify");
        // Start countdown immediately — they already have a plan
        setCounting(true);
      }} style={{
        background:"none", border:"none", cursor:"pointer",
        fontSize:10, color:"#444", textDecoration:"underline", padding:"4px 0",
      }}>
        I already have a designated driver / pre-booked ride →
      </button>

      <div style={{fontSize:8, color:"#2a2d3e", lineHeight:1.6, textAlign:"center"}}>
        CrawlFire promotes responsible drinking. This is not affiliated with or endorsed
        by Uber Technologies Inc. or Lyft Inc. unless a sponsorship agreement is active.
        Reward is self-reported. One claim per player per night.
      </div>
    </div>
  );
}


function GameOverScreen({game,myId,onPlayAgain}){
  const winner  = game?.players?.[game?.winner];
  const isWin   = game?.winner === myId;
  const sorted  = Object.values(game?.players||{}).sort((a,b)=>(b.kills-a.kills)||(b.hp-a.hp));
  const [payoutDone, setPayoutDone] = useState(false);
  const [tab, setTab] = useState("results"); // results | payout
  const hasPot  = (game?.pot || 0) > 0;

  // Auto-switch to payout tab if winner
  useEffect(() => { if (isWin && hasPot) setTab("payout"); }, []);

  return(
    <div style={{...S.screen, alignItems:"center", justifyContent:"flex-start", textAlign:"center", gap:16, paddingTop:24}}>
      {/* Header */}
      <div style={{display:"flex", flexDirection:"column", alignItems:"center", gap:8}}>
        <div style={{fontSize:60, animation:"breathe 2s ease-in-out infinite", filter:`drop-shadow(0 0 20px ${isWin?"#FFCC00":"#FF2D55"})`}}>{isWin?"👑":"💀"}</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif", fontSize:36, letterSpacing:4, color:isWin?"#FFCC00":"#FF2D55", textShadow:`0 0 30px ${isWin?"#FFCC00":"#FF2D55"}60`}}>{isWin?"YOU WIN!":"GAME OVER"}</div>
        {winner && !isWin && <div style={{fontSize:13, color:"#888"}}>{winner.avatar} {winner.name} wins the pot!</div>}
      </div>

      {/* Tab bar */}
      {hasPot && (
        <div style={{display:"flex", gap:6, width:"100%"}}>
          {[["results","🏆 RESULTS"],["payout","💸 PAYOUT"]].map(([id,label])=>(
            <button key={id} onClick={()=>setTab(id)} style={{flex:1, padding:10, border:`2px solid ${tab===id?"#FFCC00":"#1a1d2e"}`, borderRadius:10, background:tab===id?"#FFCC0015":"#0d0e1a", color:tab===id?"#FFCC00":"#555", fontFamily:"'Black Han Sans',sans-serif", fontSize:14, letterSpacing:2, cursor:"pointer"}}>
              {label}{id==="payout"&&isWin&&!payoutDone&&<span style={{width:8,height:8,borderRadius:"50%",background:"#FF2D55",display:"inline-block",marginLeft:6,verticalAlign:"middle",animation:"pulse 1.2s ease-in-out infinite"}}/>}
            </button>
          ))}
        </div>
      )}

      {/* Results tab */}
      {(tab === "results" || !hasPot) && (<>
        {hasPot && (
          <div style={{...S.card, background:"#FFCC0010", border:"1px solid #FFCC0040", width:"100%", padding:"14px 16px"}}>
            <div style={{fontSize:9, letterSpacing:3, color:"#FFCC00", marginBottom:4}}>XP POOL</div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif", fontSize:32, color:"#FFCC00"}}>{fmt(game.pot)}</div>
            <div style={{fontSize:10, color:"#555", marginTop:3}}>{isWin ? "→ Paying out to you now" : `→ Going to ${winner?.name}`}</div>
          </div>
        )}
        {/* ── GAME OVER AD CARD ── */}
        {(()=>{
          const [dismissed,setDismissed]=React.useState(false);
          return dismissed ? null : (
            <CardAd onDismiss={()=>setDismissed(true)} showRewardedOption={true}/>
          );
        })()}
        {/* Zombie coins earned badge */}
        {player&&(player.zombieCoins||0)>0&&(
          <div style={{...S.card,background:"#34C75910",border:"1px solid #34C75930",display:"flex",alignItems:"center",gap:10}}>
            <span style={{fontSize:24}}>☣️</span>
            <div style={{flex:1}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:"#34C759"}}>DEAD CITY BONUS</div>
              <div style={{fontSize:11,color:"#555",marginTop:2}}>Zombie kills earned you 🪙{player.zombieCoins} coins before the crawl</div>
            </div>
          </div>
        )}

        {/* Challenge fee summary */}
        {(()=>{
          const accepted=(game?.bets||[]).filter(b=>b.status==="accepted");
          const betRakeCoins=accepted.reduce((s,b)=>s+(b.rakeCoins||0),0);
          const betRakeCash =accepted.reduce((s,b)=>s+(b.rakeCash||0),0);
          if(!accepted.length)return null;
          return(
            <div style={{...S.card,background:"#FF950010",border:"1px solid #FF950030",display:"flex",flexDirection:"column",gap:5}}>
              <div style={{fontSize:9,color:"#FF9500",letterSpacing:3}}>BET PLATFORM FEES</div>
              {betRakeCoins>0&&<div style={{display:"flex",justifyContent:"space-between",fontSize:10}}><span style={{color:"#888"}}>Coin rake ({DEV_RAKE_LABEL} · {accepted.length} bet{accepted.length>1?"s":""})</span><span style={{color:"#FF9500"}}>🪙{betRakeCoins} → CrawlFire</span></div>}
              {betRakeCash>0&&<div style={{display:"flex",justifyContent:"space-between",fontSize:10}}><span style={{color:"#888"}}>Cash rake ({DEV_RAKE_LABEL})</span><span style={{color:"#FF9500"}}>${betRakeCash.toFixed(2)} → CrawlFire</span></div>}
              <div style={{fontSize:9,color:"#444"}}>{DEV_RAKE_LABEL} rake on all accepted bets · disclosed at bet placement</div>
            </div>
          );
        })()}
        {/* Bet resolution */}
        {game?.bets?.filter(b=>b.status==="accepted").length>0&&myId&&(
          <BetResolution game={game} myId={myId}/>
        )}
        <div style={{width:"100%", display:"flex", flexDirection:"column", gap:6}}>
          {sorted.map((p,i) => (
            <div key={p.id} style={{...S.card, display:"flex", alignItems:"center", gap:10, border:`1px solid ${p.id===game?.winner?"#FFCC00":"#1a1d2e"}`, background:p.id===game?.winner?"#FFCC0008":"#0d0e1a"}}>
              <span style={{fontSize:18,width:24}}>{["🥇","🥈","🥉"][i]||`#${i+1}`}</span>
              <AvatarDisplay avatar={p.avatar} size={28} borderColor={p.id===game?.winner?"#FFCC00":null}/>
              <div style={{flex:1,textAlign:"left"}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1}}>{p.name}</div>
                <div style={{fontSize:10,color:"#555"}}>{p.kills} kills · {Math.max(0,p.hp)} HP · 🪙{p.coins}</div>
              </div>
              {p.id===game?.winner && <span style={{fontSize:18}}>👑</span>}
            </div>
          ))}
        </div>
        {/* ── SAFE RIDE BOOST ── */}
        <SafeRideBoostCard
          playerId={myId}
          playerName={player?.name||"PLAYER"}
          onClaim={(rewards) => {
            // Apply rewards to player state
            if(window._crawlfire_addXP) window._crawlfire_addXP(rewards.xp,"safeRide");
            if(window._crawlfire_addCoins) window._crawlfire_addCoins(rewards.coins);
            if(window._crawlfire_addFreeSpin) window._crawlfire_addFreeSpin(rewards.freeSpins);
            // Store discount for next entry
            try { window.storage.set(
              `cf:nextgame:discount:${myId||"demo"}`,
              String(rewards.discountPct), false
            ); } catch {}
          }}
          onOpenRide={() => {
            // Track that player opened ride app — for analytics/sponsorship reporting
            console.log("[CrawlFire] Safe ride CTA tapped by", myId);
          }}
        />

        <button style={S.btnPrimary} onClick={onPlayAgain}>PLAY AGAIN →</button>
      </>)}

      {/* Payout tab */}
      {tab === "payout" && hasPot && (
        <div style={{width:"100%"}}>
          {!payoutDone ? (
            <PayoutEngine
              pot={game.pot}
              winner={winner}
              players={game.players}
              onComplete={() => { setPayoutDone(true); }}
            />
          ) : (
            <div style={{display:"flex",flexDirection:"column",gap:12,width:"100%"}}>
              <div style={{...S.card,background:"#34C75918",border:"2px solid #34C759",textAlign:"center",padding:16}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2,color:"#34C759"}}>✅ PAYOUT COMPLETE</div>
                <div style={{fontSize:11,color:"#888",marginTop:4}}>{fmt(Math.round(game.pot*0.7*100)/100)} sent to {winner?.name}</div>
              </div>
              {/* Safe ride boost on payout screen too */}
              <SafeRideBoostCard playerId={myId} playerName={winner?.name||"CHAMPION"}/>
              <button style={S.btnPrimary} onClick={onPlayAgain}>PLAY AGAIN →</button>
            </div>
          )}
          {payoutDone && null}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ─── BARTENDER SCREENS ────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════
const LOOT_ITEMS=[
  {id:"medkit",    e:"💉", n:"Med Kit",        d:"+30 HP",             rarity:"common"},
  {id:"shield",    e:"🛡️", n:"Shield Brew",    d:"+30 shield",         rarity:"common"},
  {id:"double",    e:"⚡", n:"2× Damage",      d:"3 shots 2× dmg",    rarity:"rare"},
  {id:"nuke",      e:"💣", n:"Nuke Shot",      d:"+50 dmg shot",      rarity:"rare"},
  {id:"cloak",     e:"👻", n:"Ghost Mode",     d:"60s invisible",     rarity:"epic"},
  {id:"revive",    e:"❤️‍🔥",n:"Revive",         d:"Rise from dead",    rarity:"epic"},
  {id:"coins50",   e:"🪙", n:"+50 Coins",      d:"Coin bonus",        rarity:"common"},
  {id:"coins100",  e:"💰", n:"+100 Coins",     d:"Big coin bonus",    rarity:"rare"},
  {id:"mine",      e:"💥", n:"Proximity Mine", d:"Auto 35 dmg at bar",rarity:"rare"},
  {id:"sweeper",   e:"🧹", n:"Mine Sweeper",   d:"Disarm enemy mines", rarity:"uncommon"},
  {id:"mine_emp",  e:"⚡💥",n:"EMP Mine",       d:"30 coins + 20 dmg", rarity:"epic"},
  {id:"mine_smoke",e:"💨💥",n:"Smoke Mine",     d:"15 dmg + 30s cloak",rarity:"rare"},
];
const RARITY_C={common:"#34C759",rare:"#007AFF",epic:"#BF5AF2"};
function genCode(barName){const p=barName.split(" ").map(w=>w[0]).join("").toUpperCase().slice(0,3);return`${p}-${Math.random().toString(36).slice(2,6).toUpperCase()}`;}

// ═══════════════════════════════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════════════════════════════
// TEAM COMMS
// ═══════════════════════════════════════════════════════════════════════════════

function useChat({ myId, myName, myAvatar, myTeam, myTeamColor, active }) {
  const [msgs,setMsgs]=useState([]);
  const [unread,setUnread]=useState(0);
  const [channel,setChannel]=useState("all");
  const pollRef=useRef(null);
  const lastTs=useRef(0);
  const chatOpen=useRef(false);
  const storageKey=ch=>`cf:chat:${ch}`;
  const fetchMsgs=useCallback(async ch=>{try{const r=await window.storage.get(storageKey(ch),true);if(!r)return[];return JSON.parse(r.value);}catch{return[];}},[]);
  const writeMsgs=useCallback(async(ch,messages)=>{try{await window.storage.set(storageKey(ch),JSON.stringify(messages.slice(-100)),true);}catch{}},[]);

  useEffect(()=>{
    if(!active)return;
    // Real-time chat subscriptions
    const handleNew = (msgs_all, msgs_team) => {
      const combined=[...(msgs_all||[]),...(msgs_team||[])].sort((a,b)=>a.ts-b.ts);
      const newMsgs=combined.filter(m=>m.ts>lastTs.current);
      if(newMsgs.length>0){
        lastTs.current=Math.max(...combined.map(m=>m.ts));
        setMsgs(combined.slice(-60));
        if(!chatOpen.current) setUnread(u=>u+newMsgs.filter(m=>m.from!==myId).length);
      }
    };
    let latestAll=[], latestTeam=[];
    const u1=subscribe(`cf:chat:all`,  v=>{ latestAll =v||[]; handleNew(latestAll,latestTeam); });
    const u2=myTeam&&myTeam!=="all"
      ? subscribe(`cf:chat:${myTeam}`, v=>{ latestTeam=v||[]; handleNew(latestAll,latestTeam); })
      : ()=>{};
    return()=>{ u1(); u2(); };
  },[active,myTeam,myId]);

  const send=useCallback(async(text,type="text")=>{
    if(!text.trim())return;
    const msg={id:uid(),from:myId,name:myName||"PLAYER",avatar:myAvatar||"🍺",team:myTeam||"all",teamColor:myTeamColor||"#00C7BE",channel,msg:text.trim().slice(0,200),type,ts:Date.now()};
    const existing=await fetchMsgs(channel);
    await writeMsgs(channel,[...existing,msg]);
    setMsgs(prev=>[...prev.filter(m=>m.id!==msg.id),msg].sort((a,b)=>a.ts-b.ts).slice(-60));
    lastTs.current=msg.ts;
  },[myId,myName,myAvatar,myTeam,myTeamColor,channel,fetchMsgs,writeMsgs]);

  const sendPing=useCallback(async ping=>{await send(ping.msg,"ping");},[send]);
  const markRead=useCallback(()=>{setUnread(0);chatOpen.current=true;},[]);
  const onClose=useCallback(()=>{chatOpen.current=false;},[]);
  return{msgs,unread,channel,setChannel,send,sendPing,markRead,onClose};
}

function TeamComms({myId,myName,myAvatar,myTeam,myTeamColor,onClose}){
  const{msgs,channel,setChannel,send,sendPing,markRead}=useChat({myId,myName,myAvatar,myTeam,myTeamColor,active:true});
  const[text,setText]=useState("");
  const[subTab,setSubTab]=useState("chat");
  const listRef=useRef(null);
  const inputRef=useRef(null);
  const teamColor=myTeamColor||"#00C7BE";
  const chanMeta=CHANNEL_NAMES[channel]||{label:channel.toUpperCase(),icon:"📡",color:"#00C7BE"};
  const channels=["all",...(myTeam&&myTeam!=="all"?[myTeam]:[])];

  useEffect(()=>{markRead();},[markRead]);
  useEffect(()=>{if(listRef.current)listRef.current.scrollTop=listRef.current.scrollHeight;},[msgs,channel]);

  const handleSend=()=>{if(!text.trim())return;send(text);setText("");inputRef.current?.focus();};
  const visibleMsgs=msgs.filter(m=>m.channel===channel);

  return(
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.93)",display:"flex",flexDirection:"column",zIndex:400,fontFamily:"'DM Mono',monospace"}}>
      {/* Header */}
      <div style={{background:"#0c0e1a",borderBottom:"1px solid #181c2e",padding:"12px 16px",display:"flex",alignItems:"center",gap:10,flexShrink:0}}>
        <div style={{fontSize:18}}>{chanMeta.icon}</div>
        <div style={{flex:1}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:15,letterSpacing:2,color:chanMeta.color}}>{chanMeta.label}</div>
          <div style={{fontSize:9,color:"#4a506e",letterSpacing:2,marginTop:1}}>TEAM COMMS · LIVE</div>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:5}}>
          <div style={{width:7,height:7,borderRadius:"50%",background:"#34C759",animation:"pulse 2s ease-in-out infinite"}}/>
          <span style={{fontSize:9,color:"#34C759",letterSpacing:1}}>LIVE</span>
        </div>
        <button onClick={onClose} style={{background:"none",border:"1px solid #1e2237",borderRadius:8,color:"#4a506e",padding:"5px 10px",cursor:"pointer",fontSize:13}}>✕</button>
      </div>

      {/* Channel + tab bar */}
      <div style={{display:"flex",background:"#0a0c14",borderBottom:"1px solid #181c2e",flexShrink:0,overflowX:"auto",scrollbarWidth:"none"}}>
        {channels.map(ch=>{
          const meta=CHANNEL_NAMES[ch]||{label:ch.toUpperCase(),icon:"📡",color:"#00C7BE"};
          return(
            <button key={ch} onClick={()=>setChannel(ch)} style={{flex:1,padding:"9px 8px",border:"none",borderBottom:`2px solid ${channel===ch?meta.color:"transparent"}`,background:"transparent",color:channel===ch?meta.color:"#4a506e",fontSize:9,letterSpacing:1.5,cursor:"pointer",whiteSpace:"nowrap",minWidth:70}}>
              {meta.icon} {meta.label.split(" ")[0]}
            </button>
          );
        })}
        <button onClick={()=>setSubTab(s=>s==="pings"?"chat":"pings")} style={{padding:"9px 12px",border:"none",borderBottom:`2px solid ${subTab==="pings"?"#FF9500":"transparent"}`,background:"transparent",color:subTab==="pings"?"#FF9500":"#4a506e",fontSize:9,letterSpacing:1,cursor:"pointer",flexShrink:0}}>
          ⚡ PINGS
        </button>
      </div>

      {/* Chat messages */}
      {subTab==="chat"&&(<>
        <div ref={listRef} style={{flex:1,overflowY:"auto",padding:"10px 14px",display:"flex",flexDirection:"column",gap:6,scrollbarWidth:"thin",scrollbarColor:"#1e2237 transparent"}}>
          {visibleMsgs.length===0&&(
            <div style={{textAlign:"center",padding:"40px 20px",display:"flex",flexDirection:"column",alignItems:"center",gap:8}}>
              <div style={{fontSize:36}}>📡</div>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:2,color:"#2a2d3e"}}>CHANNEL CLEAR</div>
              <div style={{fontSize:10,color:"#1e2237"}}>Be the first to send a message</div>
            </div>
          )}
          {visibleMsgs.map((m,i)=>{
            const isMe=m.from===myId;
            const isPing=m.type==="ping";
            const prev=visibleMsgs[i-1];
            const showAv=!prev||prev.from!==m.from;
            return(
              <div key={m.id} style={{display:"flex",flexDirection:"column",alignItems:isMe?"flex-end":"flex-start",gap:1}}>
                {showAv&&!isMe&&(
                  <div style={{display:"flex",alignItems:"center",gap:5,marginBottom:2,marginLeft:32}}>
                    <span style={{fontSize:9,color:m.teamColor||"#4a506e",letterSpacing:1}}>{m.name}</span>
                    {m.team&&m.team!=="all"&&<span style={{fontSize:8,padding:"1px 5px",borderRadius:8,background:`${m.teamColor}20`,border:`1px solid ${m.teamColor}40`,color:m.teamColor}}>{m.team.toUpperCase()}</span>}
                  </div>
                )}
                <div style={{display:"flex",alignItems:"flex-end",gap:6,flexDirection:isMe?"row-reverse":"row",maxWidth:"85%"}}>
                  {showAv&&!isMe&&<div style={{width:26,height:26,borderRadius:"50%",background:`${m.teamColor||"#00C7BE"}20`,border:`1px solid ${m.teamColor||"#00C7BE"}40`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>{m.avatar}</div>}
                  {!showAv&&!isMe&&<div style={{width:26,flexShrink:0}}/>}
                  <div style={{padding:"9px 12px",borderRadius:isMe?"14px 14px 4px 14px":"14px 14px 14px 4px",background:isMe?`linear-gradient(135deg,${teamColor},${teamColor}cc)`:isPing?"#FF950020":"#181c2e",border:isPing?"1px solid #FF950040":"none",maxWidth:"100%"}}>
                    {isPing&&<div style={{fontSize:8,color:"#FF9500",letterSpacing:1.5,marginBottom:3}}>⚡ QUICK PING</div>}
                    <div style={{fontSize:13,color:"#eceef8",lineHeight:1.5,wordBreak:"break-word"}}>{m.msg}</div>
                    <div style={{fontSize:8,color:isMe?"rgba(255,255,255,.5)":"#2a2d3e",marginTop:3,textAlign:isMe?"right":"left"}}>{new Date(m.ts).toLocaleTimeString("en-US",{hour12:false,hour:"2-digit",minute:"2-digit"})}</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <div style={{padding:"10px 14px",background:"#0c0e1a",borderTop:"1px solid #181c2e",display:"flex",gap:8,flexShrink:0}}>
          <input ref={inputRef} value={text} onChange={e=>setText(e.target.value.slice(0,200))} onKeyDown={e=>e.key==="Enter"&&handleSend()}
            placeholder="Type a message..." style={{flex:1,background:"#07080f",border:"1px solid #1e2237",borderRadius:10,color:"#eceef8",fontFamily:"'DM Mono',monospace",fontSize:13,padding:"10px 14px",outline:"none"}}
            onFocus={e=>e.target.style.borderColor=teamColor} onBlur={e=>e.target.style.borderColor="#1e2237"}/>
          <button onClick={handleSend} disabled={!text.trim()} style={{padding:"10px 16px",border:"none",borderRadius:10,background:text.trim()?`linear-gradient(135deg,${teamColor},${teamColor}aa)`:"#1e2237",color:text.trim()?"#fff":"#2a2d3e",cursor:text.trim()?"pointer":"default",fontSize:16,flexShrink:0}}>➤</button>
        </div>
      </>)}

      {/* Pings grid */}
      {subTab==="pings"&&(
        <div style={{flex:1,overflowY:"auto",padding:"12px 14px",display:"flex",flexDirection:"column",gap:8}}>
          <div style={{fontSize:9,color:"#4a506e",letterSpacing:3,marginBottom:2}}>ONE-TAP PINGS — sent to {chanMeta.label}</div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            {QUICK_PINGS.map(ping=>(
              <button key={ping.id} onClick={async()=>{await sendPing(ping);setSubTab("chat");}}
                style={{display:"flex",alignItems:"center",gap:10,padding:"13px 12px",border:"1px solid #1e2237",borderRadius:12,background:"#0c0e1a",cursor:"pointer",textAlign:"left",transition:"all .15s"}}
                onMouseOver={e=>{e.currentTarget.style.borderColor=teamColor;e.currentTarget.style.background=`${teamColor}10`;}}
                onMouseOut={e=>{e.currentTarget.style.borderColor="#1e2237";e.currentTarget.style.background="#0c0e1a";}}>
                <span style={{fontSize:24,flexShrink:0}}>{ping.e}</span>
                <div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:"#eceef8"}}>{ping.label}</div><div style={{fontSize:9,color:"#4a506e",marginTop:2,lineHeight:1.4}}>{ping.msg.slice(0,28)}</div></div>
              </button>
            ))}
          </div>
          <div style={{fontSize:9,color:"#FF9500",letterSpacing:3,marginTop:4}}>OPERATOR ALERTS</div>
          {[{e:"🚨",l:"ZONE ALERT",m:"🚨 Player outside play zone — alert bartender"},{e:"🆘",l:"NEED HELP",m:"🆘 HELP at my location — urgent!"},{e:"🎉",l:"GAME WIN",m:"🎉 We got them — game almost won!"},{e:"🛑",l:"HOLD FIRE",m:"🛑 Hold fire — friendly nearby!"}].map(p=>(
            <button key={p.e} onClick={async()=>{await send(p.m,"ping");setSubTab("chat");}}
              style={{display:"flex",alignItems:"center",gap:10,padding:"11px 14px",border:"1px solid #FF950030",borderRadius:12,background:"#FF950010",cursor:"pointer",textAlign:"left",transition:"all .15s"}}
              onMouseOver={e=>e.currentTarget.style.borderColor="#FF9500"} onMouseOut={e=>e.currentTarget.style.borderColor="#FF950030"}>
              <span style={{fontSize:22,flexShrink:0}}>{p.e}</span>
              <div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:"#FF9500"}}>{p.l}</div><div style={{fontSize:9,color:"#4a506e",marginTop:1}}>{p.m.slice(0,40)}</div></div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function ChatFAB({unread,teamColor,onClick}){
  return(
    <button onClick={onClick} style={{position:"fixed",bottom:20,right:20,width:52,height:52,borderRadius:"50%",border:"none",background:`linear-gradient(135deg,${teamColor||"#00C7BE"},${teamColor||"#00C7BE"}99)`,color:"#fff",fontSize:22,cursor:"pointer",boxShadow:`0 4px 20px ${teamColor||"#00C7BE"}60`,display:"flex",alignItems:"center",justifyContent:"center",zIndex:60,transition:"all .2s"}}>
      💬
      {unread>0&&<div style={{position:"absolute",top:-2,right:-2,minWidth:18,height:18,borderRadius:9,background:"#FF2D55",color:"#fff",fontSize:10,fontFamily:"'Black Han Sans',sans-serif",display:"flex",alignItems:"center",justifyContent:"center",padding:"0 4px",border:"2px solid #07080f",animation:"popIn .3s ease"}}>{unread>9?"9+":unread}</div>}
    </button>
  );
}


// ═══════════════════════════════════════════════════════════════════════════════
// TERRITORY SYSTEM — "Claim & Conquer"
// ─────────────────────────────────────────────────────────────────────────────
// Runs BETWEEN crawl nights — passive engagement layer.
//
// HOW IT WORKS:
//   • Every partner bar is a territory tile on the world map
//   • Players "claim" a bar by scanning in (GPS check or QR at the door)
//   • Owned bars earn passive CrawlCoins every hour (like Atlas Earth rent)
//   • The player with the most claims at a bar holds the title
//   • Titles: Scout → Regular → Local Legend → Warlord → Overlord
//   • Warlords earn a bonus multiplier on loot codes at their bar
//   • Territories can be "raided" during live crawl events — winner steals the crown
//   • Global map shows every claimed bar, owner avatar, and title
//   • Leaderboards: most bars owned per city, country, globally
//   • Daily login bonus + hourly passive coins give Atlas Earth–style retention
//
// FIREBASE SCHEMA:
//   territory/
//     {barId}/
//       ownerId       ← player who currently holds it
//       ownerName
//       ownerAvatar
//       title         ← "Warlord" etc.
//       claimedAt
//       visitCount
//       earnings      ← lifetime coins earned from this bar
//     players/
//       {playerId}/
//         bars[]      ← barIds owned
//         totalCoins
//         lastClaim
//         streak
//         rank        ← global rank
// ═══════════════════════════════════════════════════════════════════════════════

// ── Territory data ────────────────────────────────────────────────────────────
const TERRITORY_TITLES = [
  { id:"scout",     label:"Scout",        icon:"🔍", minVisits:1,  coinRate:1,  color:"#4a506e" },
  { id:"regular",   label:"Regular",      icon:"🍺", minVisits:3,  coinRate:2,  color:"#34C759" },
  { id:"legend",    label:"Local Legend", icon:"⭐", minVisits:8,  coinRate:4,  color:"#007AFF" },
  { id:"warlord",   label:"Warlord",      icon:"⚔️", minVisits:20, coinRate:8,  color:"#FF9500" },
  { id:"overlord",  label:"Overlord",     icon:"👑", minVisits:50, coinRate:15, color:"#FF2D55" },
];

const COIN_RATE_MINS = 60; // earn coins every 60 minutes per owned bar

// Demo bar territory data (in prod: live from Firebase territory/ path)
function makeDemoTerritoryBars() {
  const DEMO_BARS = [
    {id:"b1",n:"The Rusty Anchor",  e:"⚓",lat:51.525,lng:-0.080,city:"london",    tier:"gold",  owner:{id:"p1",name:"GINTONIC",  av:"🎯",title:"overlord",  visits:52,coins:1240}},
    {id:"b2",n:"The Golden Pint",   e:"🍺",lat:51.522,lng:-0.078,city:"london",    tier:"gold",  owner:{id:"p2",name:"BEERCAT",   av:"💣",title:"warlord",   visits:23,coins:890}},
    {id:"b3",n:"The Neon Flask",    e:"🌈",lat:51.514,lng:-0.131,city:"london",    tier:"silver",owner:{id:"p3",name:"ALEHEAD",   av:"⚡",title:"legend",    visits:10,coins:440}},
    {id:"b4",n:"The Copper Still",  e:"🥃",lat:51.512,lng:-0.139,city:"london",    tier:"silver",owner:null},
    {id:"b5",n:"The Barrel House",  e:"🛢️",lat:51.509,lng:-0.131,city:"london",    tier:"bronze",owner:{id:"p4",name:"HOPHEAD",   av:"🔥",title:"regular",   visits:4, coins:120}},
    {id:"b6",n:"The Iron Tap",      e:"🔩",lat:51.518,lng:-0.088,city:"london",    tier:"gold",  owner:{id:"p5",name:"MALTMAGE",  av:"🐺",title:"legend",    visits:11,coins:520}},
    {id:"b7",n:"The Fox & Hound",   e:"🦊",lat:51.521,lng:-0.095,city:"london",    tier:"silver",owner:null},
    {id:"b8",n:"The Dragon's Den",  e:"🐉",lat:51.516,lng:-0.102,city:"london",    tier:"gold",  owner:{id:"p1",name:"GINTONIC",  av:"🎯",title:"overlord",  visits:61,coins:1880}},
    {id:"b9",n:"The Rising Sun",    e:"☀️",lat:51.508,lng:-0.119,city:"london",    tier:"bronze",owner:{id:"p6",name:"SUNSEEKER",  av:"👻",title:"scout",     visits:1, coins:15}},
    {id:"b10",n:"The Black Swan",   e:"🦢",lat:51.505,lng:-0.091,city:"london",    tier:"silver",owner:{id:"p3",name:"ALEHEAD",   av:"⚡",title:"regular",   visits:5, coins:210}},
    // NYC
    {id:"b11",n:"The Dead Rabbit",  e:"🐇",lat:40.703,lng:-74.012,city:"nyc",     tier:"gold",  owner:{id:"p7",name:"QUEENS",   av:"🦁",title:"warlord",   visits:25,coins:1100}},
    {id:"b12",n:"McSorley's",       e:"🍀",lat:40.727,lng:-73.989,city:"nyc",     tier:"gold",  owner:null},
    // Berlin
    {id:"b13",n:"Zum Schmutzigen",  e:"🇩🇪",lat:52.499,lng:13.441,city:"berlin",  tier:"silver",owner:{id:"p8",name:"BERLINER",  av:"🐯",title:"legend",    visits:14,coins:660}},
  ];
  return DEMO_BARS;
}

function getTitleForVisits(visits) {
  return [...TERRITORY_TITLES].reverse().find(t => visits >= t.minVisits) || TERRITORY_TITLES[0];
}

// ── useTerritory hook ─────────────────────────────────────────────────────────
function useTerritory(myId) {
  const [bars,        setBars]        = useState(makeDemoTerritoryBars);
  const [myStats,     setMyStats]     = useState({coins:0,ownedBars:[],streak:0,lastClaim:null,totalEarned:0});
  const [passiveTick, setPassiveTick] = useState(0);
  const [claimAnim,   setClaimAnim]   = useState(null);

  // Passive coin drip every 60s in demo (every hour in prod)
  useEffect(() => {
    const id = setInterval(() => {
      if (!myId) return;
      setMyStats(s => {
        const myBars = bars.filter(b => b.owner?.id === myId);
        if (!myBars.length) return s;
        const earned = myBars.reduce((sum, b) => {
          const t = getTitleForVisits(b.owner?.visits||0);
          return sum + (t.coinRate || 1);
        }, 0);
        return {...s, coins: s.coins + earned, totalEarned: s.totalEarned + earned};
      });
      setPassiveTick(t => t + 1);
    }, 60000); // 60s demo tick (= 1 hour in prod)
    return () => clearInterval(id);
  }, [bars, myId]);

  const claimBar = useCallback((barId, playerName, playerAvatar) => {
    setBars(prev => prev.map(b => {
      if (b.id !== barId) return b;
      const newVisits = (b.owner?.id === myId ? (b.owner?.visits||0) : 0) + 1;
      const title = getTitleForVisits(newVisits);
      const newOwner = {id:myId, name:playerName, av:playerAvatar, title:title.id, visits:newVisits, coins:0};
      return {...b, owner:newOwner};
    }));
    setMyStats(s => ({
      ...s,
      ownedBars: [...new Set([...s.ownedBars, barId])],
      lastClaim: Date.now(),
      streak: s.streak + 1,
    }));
    setClaimAnim(barId);
    setTimeout(() => setClaimAnim(null), 2000);
    // In prod: wr(`territory/${barId}`, newOwner)
  }, [myId]);

  const raidBar = useCallback((barId, playerName, playerAvatar) => {
    // Raid: challenger must have visited 3+ times to raid (prevents single-tap griefing)
    claimBar(barId, playerName, playerAvatar);
  }, [claimBar]);

  return { bars, myStats, claimBar, raidBar, claimAnim, passiveTick };
}

// ── Territory world map ───────────────────────────────────────────────────────

// ═══════════════════════════════════════════════════════════════════════════════
// ZOMBIE HUNT — "Dead City" Mode
// ─────────────────────────────────────────────────────────────────────────────
// A Pokémon GO × Call of Duty Zombies hybrid for solo between-crawl play.
// GPS spawns zombie hordes near your real location. You use your phone camera
// and tap/swipe to fight them. Surviving earns CrawlCoins, XP, and weapon
// upgrades that carry into live crawl events.
//
// ZOMBIE TYPES (escalating difficulty like CoD Zombies rounds):
//   🧟 Walker    — slow, low HP, common. Basic threat.
//   🏃 Runner    — fast, medium HP. Rushes you.
//   💥 Exploder  — low HP but explodes on death for AoE damage.
//   🛡️ Armoured  — high HP, reduced damage from front, must flank.
//   👹 Boss      — rare, very high HP, multiple attack patterns.
//   🌫️ Smoker    — debuffs visibility (like Ghost Mode reversal).
//   🧲 Horde     — spawns in clusters of 5-10, overwhelm tactics.
//
// WAVE SYSTEM: Rounds 1-5 easy, 6-10 medium, 11+ hard. Boss every 5 rounds.
// COIN REWARDS: scale with round number. Boss kill = big coin drop.
// WEAPONS: use your CrawlFire weapons (Stout Shot etc.) + zombie-only gear.
// PERKS: "Juggernog" (max HP boost), "Speed Cola" (faster reload), etc.
// EASTER EGGS: hidden clues in bar territory that unlock zombie boss locations.
// ═══════════════════════════════════════════════════════════════════════════════

// ── Zombie data ───────────────────────────────────────────────────────────────
const ZOMBIE_TYPES = {
  walker:   {id:"walker",   e:"🧟", n:"Walker",   hp:50,  maxHp:50,  dmg:8,  speed:1,  xp:10, coins:5,  color:"#34C759", desc:"Slow and relentless"},
  runner:   {id:"runner",   e:"🏃", n:"Runner",   hp:40,  maxHp:40,  dmg:15, speed:3,  xp:15, coins:8,  color:"#FF9500", desc:"Sprints at full pace"},
  exploder: {id:"exploder", e:"💥", n:"Exploder",  hp:30,  maxHp:30,  dmg:25, speed:2,  xp:20, coins:12, color:"#FF6B35", desc:"Explodes on death — dodge!"},
  armoured: {id:"armoured", e:"🛡️", n:"Armoured",  hp:120, maxHp:120, dmg:12, speed:1,  xp:30, coins:20, color:"#007AFF", desc:"Heavy armour — aim for the back"},
  smoker:   {id:"smoker",   e:"🌫️", n:"Smoker",    hp:60,  maxHp:60,  dmg:10, speed:2,  xp:25, coins:15, color:"#BF5AF2", desc:"Clouds your vision"},
  boss:     {id:"boss",     e:"👹", n:"MEGA BOSS", hp:500, maxHp:500, dmg:30, speed:2,  xp:100,coins:100,color:"#FF2D55", desc:"End of round boss — all weapons!"},
};

const ZOMBIE_WEAPONS = [
  {id:"beer_bottle",  e:"🍺",  n:"Beer Bottle",    dmg:20,  ammo:999, reload:0.5, type:"melee",  unlock:0},
  {id:"dart",         e:"🎯",  n:"Dart Gun",        dmg:35,  ammo:12,  reload:2,   type:"ranged", unlock:0},
  {id:"taser",        e:"⚡",  n:"Taser",           dmg:50,  ammo:6,   reload:3,   type:"ranged", unlock:3},
  {id:"flare",        e:"🔦",  n:"Flare Cannon",    dmg:80,  ammo:4,   reload:4,   type:"ranged", unlock:5},
  {id:"freeze_ray",   e:"❄️",  n:"Freeze Ray",      dmg:40,  ammo:8,   reload:3,   type:"ranged", unlock:8,  special:"Slows zombies 50%"},
  {id:"mega_pint",    e:"🍻",  n:"Mega Pint",       dmg:120, ammo:2,   reload:6,   type:"ranged", unlock:10, special:"AoE blast — hits all zombies"},
  {id:"nuke_grenade", e:"💣",  n:"Nuke Grenade",    dmg:999, ammo:1,   reload:99,  type:"special",unlock:15, special:"One-shot everything in round"},
];

const ZOMBIE_PERKS = [
  {id:"juggernog",   e:"🛡️",  n:"Juggernog",       cost:200, effect:"maxHp+50",    desc:"+50 max HP"},
  {id:"speedcola",   e:"⚡",  n:"Speed Cola",       cost:150, effect:"reloadSpeed", desc:"50% faster reload"},
  {id:"doubletap",   e:"💥",  n:"Double Tap",       cost:175, effect:"doubleDmg",   desc:"2× weapon damage"},
  {id:"phd",         e:"🌊",  n:"PhD Flopper",      cost:250, effect:"explodeImmune",desc:"Immune to Exploder blasts"},
  {id:"deadshot",    e:"🎯",  n:"Deadshot",         cost:200, effect:"crit",         desc:"30% crit chance"},
  {id:"staminup",    e:"🏃",  n:"Stamin-Up",        cost:125, effect:"moveSpeed",    desc:"Move 25% faster"},
];

const ZOMBIE_SPECIAL_LOCATIONS = [
  {id:"mystery_box",  e:"📦", n:"Mystery Box",   desc:"Random powerful weapon · 950 coins", coins:950},
  {id:"pack_punch",   e:"⚗️", n:"Pack-a-Punch",  desc:"Upgrade any weapon to MAX",          coins:2500},
  {id:"perk_machine", e:"🎰", n:"Perk Machine",  desc:"Buy a perk",                         coins:0},
  {id:"ammo_crate",   e:"🔫", n:"Ammo Crate",    desc:"Refill all weapons · free",          coins:0},
];

// ── Zombie spawn generator ─────────────────────────────────────────────────────
function spawnWave(round) {
  const types = Object.values(ZOMBIE_TYPES);
  const count = Math.min(3 + round * 2, 20);
  const isBossRound = round % 5 === 0;
  const zombies = [];

  if (isBossRound) {
    zombies.push({...ZOMBIE_TYPES.boss, id:"boss_"+uid(), hp:500+round*50, maxHp:500+round*50});
  }

  for (let i=0; i<(isBossRound?count/2:count); i++) {
    // Weight: harder types more common at higher rounds
    const roll = Math.random();
    let type;
    if      (round >= 15 && roll < 0.15) type = ZOMBIE_TYPES.armoured;
    else if (round >= 10 && roll < 0.25) type = ZOMBIE_TYPES.smoker;
    else if (round >= 6  && roll < 0.35) type = ZOMBIE_TYPES.exploder;
    else if (round >= 3  && roll < 0.45) type = ZOMBIE_TYPES.runner;
    else                                  type = ZOMBIE_TYPES.walker;

    const hpBoost = 1 + (round * 0.1);
    zombies.push({
      ...type,
      id: type.id+"_"+uid(),
      hp: Math.round(type.hp * hpBoost),
      maxHp: Math.round(type.maxHp * hpBoost),
      // Position on play field (% coords for the battle arena)
      x: 10 + Math.random() * 80,
      y: 10 + Math.random() * 40,
      vx: (Math.random()-0.5) * 0.5,
      vy: 0.2 + Math.random() * 0.3,
      stunned: false,
      stunTimer: 0,
    });
  }
  return zombies;
}

// ── Battle arena component ─────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════
// WEBXR AR SYSTEM — immersive-ar with plane detection + hit testing
// ─────────────────────────────────────────────────────────────────────────────
// Uses WebXR Device API (navigator.xr) for true AR:
//   • immersive-ar session — device provides camera passthrough automatically
//   • plane-detection feature — detects real floor/table surfaces
//   • hit-test feature — raycasts from screen tap into real world
//   • DOM overlay — renders React HUD on top of the XR canvas
//   • viewer reference space — tracks device orientation for zombie placement
//
// BROWSER SUPPORT (as of 2025):
//   ✅ Android Chrome 81+    — full support
//   ✅ Samsung Internet 13+  — full support
//   ⚠️  iOS Safari 17+       — partial (no plane detection yet, uses DOM overlay)
//   ❌ Desktop browsers      — fallback to camera stream mode
//
// FALLBACK CHAIN:
//   WebXR immersive-ar → getUserMedia camera stream → classic dark arena
// ═══════════════════════════════════════════════════════════════════════════════

// ── Zombie 3D positions in XR world space ────────────────────────────────────
// Each zombie gets an anchor: {x, y, z} in metres relative to device origin.
// We project these into screen space each frame for hit-testing & rendering.
function worldToScreen(pose, xrPos, projMatrix) {
  // Simple projection: convert XR world coords to normalised screen coords
  // In production, use XRView.projectionMatrix + viewMatrix for accuracy.
  // Here we use a fast approximation good enough for emoji overlay.
  if (!pose) return null;
  const vx = xrPos.x - pose.transform.position.x;
  const vz = xrPos.z - pose.transform.position.z;
  const vy = xrPos.y - pose.transform.position.y;
  const dist = Math.hypot(vx, vy, vz);
  if (dist < 0.1 || dist > 12) return null; // too close or too far
  // Project onto screen percentage
  const q = pose.transform.orientation;
  // Yaw: forward direction of headset
  const fwdX = 2*(q.x*q.z + q.w*q.y);
  const fwdZ = 1 - 2*(q.x*q.x + q.y*q.y);
  const rightX = 1 - 2*(q.y*q.y + q.z*q.z);
  const rightZ = 2*(q.x*q.z - q.w*q.y);
  // Dot products
  const forwardDot = vx*fwdX + vz*fwdZ;
  const rightDot   = vx*rightX + vz*rightZ;
  if (forwardDot < 0.05) return null; // behind viewer
  const screenX = 50 + (rightDot   / forwardDot) * 60;
  const screenY = 55 - (vy         / forwardDot) * 80;
  const scale   = Math.max(0.3, Math.min(2.5, 1.8 / dist));
  return { x: screenX, y: screenY, scale, dist };
}

// ── useWebXR — manages the full XR lifecycle ─────────────────────────────────
function useWebXR({ zombies, onPlaceZombie }) {
  const canvasRef      = useRef(null);
  const xrSessionRef   = useRef(null);
  const hitTestSrcRef  = useRef(null);
  const rafHandleRef   = useRef(null);
  const planesRef      = useRef([]);
  const reticleRef     = useRef(null); // floating placement indicator

  const [xrMode,       setXrMode]       = useState("none"); // none|checking|xr|camera|classic
  const [xrReady,      setXrReady]      = useState(false);
  const [xrSupported,  setXrSupported]  = useState(null);  // null=checking, true/false
  const [xrError,      setXrError]      = useState(null);
  const [viewerPose,   setViewerPose]   = useState(null);
  const [detectedPlanes, setDetectedPlanes] = useState([]);
  const [reticlePos,   setReticlePos]   = useState(null); // {x%,y%} of hit-test reticle
  const [zombieScreenPos, setZombieScreenPos] = useState({}); // {zombieId: {x,y,scale}}
  const videoRef       = useRef(null);   // fallback camera stream
  const [camStream,    setCamStream]     = useState(null);

  // Check WebXR support on mount
  useEffect(() => {
    if (!navigator.xr) { setXrSupported(false); return; }
    navigator.xr.isSessionSupported("immersive-ar")
      .then(ok => setXrSupported(ok))
      .catch(()  => setXrSupported(false));
  }, []);

  // ── Start WebXR session ───────────────────────────────────────────────────
  const startXR = useCallback(async () => {
    setXrError(null);
    setXrMode("checking");

    // Try full WebXR immersive-ar first
    if (navigator.xr && xrSupported) {
      try {
        const session = await navigator.xr.requestSession("immersive-ar", {
          requiredFeatures: ["local"],
          optionalFeatures: [
            "plane-detection",
            "hit-test",
            "dom-overlay",
            "light-estimation",
          ],
          domOverlay: canvasRef.current
            ? { root: canvasRef.current.parentElement || document.body }
            : undefined,
        });

        xrSessionRef.current = session;
        session.addEventListener("end", () => {
          setXrMode("none");
          setXrReady(false);
          setViewerPose(null);
          setZombieScreenPos({});
        });

        // Set up GL context on canvas
        const canvas  = canvasRef.current;
        if (canvas) {
          const gl = canvas.getContext("webgl", { xrCompatible: true });
          if (gl) await session.updateRenderState({ baseLayer: new XRWebGLLayer(session, gl) });
        }

        // Reference spaces
        const localSpace    = await session.requestReferenceSpace("local");
        const viewerSpace   = await session.requestReferenceSpace("viewer");

        // Hit-test source (for reticle placement)
        let hitTestSource = null;
        if (session.requestHitTestSource) {
          try {
            hitTestSource = await session.requestHitTestSource({ space: viewerSpace });
            hitTestSrcRef.current = hitTestSource;
          } catch {}
        }

        setXrMode("xr");
        setXrReady(true);

        // ── XR render loop ──────────────────────────────────────────────────
        const onXRFrame = (time, frame) => {
          rafHandleRef.current = session.requestAnimationFrame(onXRFrame);
          const pose = frame.getViewerPose(localSpace);
          if (!pose) return;

          // Update viewer pose for zombie projection
          setViewerPose(pose);

          // Update zombie screen positions
          const newPos = {};
          zombies.forEach(z => {
            if (z.hp <= 0) return;
            const wp = z.worldPos || { x: (z.x-50)*0.05, y: -0.5, z: -(1.5 + (100-z.y)*0.04) };
            const sp = worldToScreen(pose, wp, null);
            if (sp) newPos[z.id] = sp;
          });
          setZombieScreenPos(newPos);

          // Hit-test reticle
          if (hitTestSource && frame.getHitTestResults) {
            const results = frame.getHitTestResults(hitTestSource);
            if (results.length > 0) {
              const hitPose = results[0].getPose(localSpace);
              if (hitPose) {
                const sp = worldToScreen(pose, hitPose.transform.position, null);
                setReticlePos(sp ? { x: sp.x, y: sp.y } : null);
              }
            } else {
              setReticlePos(null);
            }
          }

          // Plane detection
          if (frame.detectedPlanes) {
            const planes = [];
            frame.detectedPlanes.forEach(plane => {
              if (plane.orientation === "horizontal") planes.push(plane);
            });
            if (planes.length !== planesRef.current.length) {
              planesRef.current = planes;
              setDetectedPlanes([...planes]);
            }
          }
        };

        rafHandleRef.current = session.requestAnimationFrame(onXRFrame);
        return;
      } catch(e) {
        console.warn("WebXR session failed:", e.message);
        setXrError(`WebXR: ${e.message} — trying camera mode`);
      }
    }

    // ── Fallback 1: getUserMedia camera stream ────────────────────────────
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { facingMode:"environment", width:{ideal:1280}, height:{ideal:720} },
        audio: false,
      });
      setCamStream(s);
      if (videoRef.current) {
        videoRef.current.srcObject = s;
        await videoRef.current.play();
      }
      setXrMode("camera");
      setXrReady(true);
      return;
    } catch(e) {
      setXrError(e.name==="NotAllowedError"
        ? "Camera permission denied — playing in classic mode"
        : "Camera unavailable — playing in classic mode");
    }

    // ── Fallback 2: classic dark arena ────────────────────────────────────
    setXrMode("classic");
    setXrReady(true);
  }, [xrSupported, zombies]);

  // ── Stop XR ──────────────────────────────────────────────────────────────
  const stopXR = useCallback(async () => {
    if (rafHandleRef.current && xrSessionRef.current) {
      xrSessionRef.current.cancelAnimationFrame(rafHandleRef.current);
    }
    if (xrSessionRef.current) {
      try { await xrSessionRef.current.end(); } catch {}
      xrSessionRef.current = null;
    }
    if (camStream) camStream.getTracks().forEach(t => t.stop());
    setCamStream(null);
    setXrMode("none");
    setXrReady(false);
    setViewerPose(null);
    setZombieScreenPos({});
    setReticlePos(null);
    setDetectedPlanes([]);
  }, [camStream]);

  // Cleanup on unmount
  useEffect(() => () => { stopXR(); }, []);

  return {
    canvasRef, videoRef,
    xrMode, xrReady, xrSupported, xrError,
    viewerPose, zombieScreenPos, reticlePos, detectedPlanes,
    startXR, stopXR,
  };
}

// ── useARCamera — thin wrapper so ZombieBattleArena API stays the same ────────
function useARCamera() {
  // Kept for backwards compatibility — now delegates to useWebXR
  const videoRef  = useRef(null);
  const [arMode,  setArMode]  = useState(false);
  const [arReady, setArReady] = useState(false);
  const [arError, setArError] = useState(null);
  const [stream,  setStream]  = useState(null);

  const startAR = useCallback(async () => {
    setArError(null);
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video:{ facingMode:"environment", width:{ideal:1280}, height:{ideal:720} },
        audio:false,
      });
      setStream(s);
      if(videoRef.current){ videoRef.current.srcObject=s; await videoRef.current.play(); }
      setArReady(true); setArMode(true);
    } catch(e) {
      setArError(e.name==="NotAllowedError"
        ?"Camera permission denied — classic mode active"
        :"Camera unavailable — classic mode active");
      setArMode(false);
    }
  },[]);

  const stopAR = useCallback(()=>{
    if(stream) stream.getTracks().forEach(t=>t.stop());
    setStream(null); setArReady(false); setArMode(false);
  },[stream]);

  useEffect(()=>()=>{ if(stream) stream.getTracks().forEach(t=>t.stop()); },[stream]);

  return { videoRef, arReady, arMode, arError, startAR, stopAR, setArMode };
}

// ── ZombieBattleArena — AR camera overlay + classic fallback ─────────────────
function ZombieBattleArena({ playerHp, playerMaxHp, zombies, activeWeapon, onShoot, onDodge, hitAnim, dodgeAnim, roundNum }) {
  const areaRef   = useRef(null);
  const [shooting,setShooting]   = useState(false);
  const [shotFx,  setShotFx]     = useState(null);  // {x,y} muzzle flash position
  const [missAnim,setMissAnim]   = useState(null);  // {x,y} miss splash
  const { videoRef, arReady, arMode, arError, startAR, stopAR, setArMode } = useARCamera();

  const zombieColor = (z) => ZOMBIE_TYPES[z.type||z.id.split("_")[0]]?.color || "#34C759";

  const handleTap = (e, zombie) => {
    e.stopPropagation();
    if(!zombie || zombie.hp<=0) return;
    // Muzzle flash at tap position
    const rect = areaRef.current?.getBoundingClientRect();
    if(rect) setShotFx({x:e.clientX-rect.left, y:e.clientY-rect.top});
    setTimeout(()=>setShotFx(null), 180);
    setShooting(true);
    setTimeout(()=>setShooting(false), 200);
    onShoot(zombie.id);
  };

  const handleAreaTap = (e) => {
    // Miss — show splash at tap point
    const rect = areaRef.current?.getBoundingClientRect();
    if(rect) setMissAnim({x:e.clientX-rect.left, y:e.clientY-rect.top});
    setTimeout(()=>setMissAnim(null), 400);
  };

  // AR zombie sizing — boss fills more of the screen, walkers are smaller
  const getZombieSize = (z, isAR) => {
    const isBoss = z.id.startsWith("boss");
    if(isAR) return isBoss ? 110 : 56 + Math.random()*20;
    return isBoss ? 52 : 32;
  };

  // Perspective scale — zombies near the bottom appear larger (ground level)
  const perspectiveScale = (y) => 0.6 + (y/100)*0.7;

  return (
    <div ref={areaRef}
      style={{
        position:"relative", width:"100%",
        height: arMode ? "100vw" : 300,
        maxHeight: arMode ? 480 : 300,
        background: arMode ? "#000" : "linear-gradient(180deg,#0a0c18 0%,#0d1020 40%,#080c14 100%)",
        border:`2px solid ${arMode?"#34C75940":"#1e2237"}`,
        borderRadius:14, overflow:"hidden", cursor:"crosshair",
        boxShadow: arMode ? "0 0 40px rgba(52,199,89,.15)" : "inset 0 0 40px rgba(255,45,85,.08)",
      }}
      onClick={handleAreaTap}>

      {/* ── AR CAMERA LAYER ── */}
      {arMode && (
        <>
          {/* Live camera feed — the "real world" */}
          <video ref={videoRef} autoPlay playsInline muted
            style={{
              position:"absolute", inset:0,
              width:"100%", height:"100%",
              objectFit:"cover",
              zIndex:0,
            }}/>

          {/* AR atmospheric overlay — green tinted fog like a zombie apocalypse */}
          <div style={{
            position:"absolute", inset:0, zIndex:1,
            background:"linear-gradient(180deg,rgba(0,30,0,.25) 0%,rgba(0,0,0,.1) 50%,rgba(0,20,0,.35) 100%)",
            pointerEvents:"none",
          }}/>

          {/* Scanline effect over camera */}
          <div style={{
            position:"absolute", inset:0, zIndex:1,
            backgroundImage:"repeating-linear-gradient(0deg,transparent,transparent 3px,rgba(0,0,0,.06) 4px)",
            pointerEvents:"none",
          }}/>

          {/* Ground shadow plane — makes zombies feel grounded */}
          <div style={{
            position:"absolute", bottom:0, left:0, right:0, height:"30%",
            background:"linear-gradient(0deg,rgba(0,0,0,.4) 0%,transparent 100%)",
            zIndex:1, pointerEvents:"none",
          }}/>

          {/* AR reticle crosshair */}
          <div style={{
            position:"absolute", top:"50%", left:"50%",
            transform:"translate(-50%,-50%)",
            width:50, height:50, zIndex:3, pointerEvents:"none",
          }}>
            {[0,90,180,270].map(rot=>(
              <div key={rot} style={{
                position:"absolute", width:12, height:3,
                background:"#34C759", borderRadius:1.5,
                top:"50%", left:"50%",
                transform:`translate(-50%,-50%) rotate(${rot}deg) translateX(18px)`,
                boxShadow:"0 0 4px #34C75980",
              }}/>
            ))}
            <div style={{
              position:"absolute", top:"50%", left:"50%",
              transform:"translate(-50%,-50%)",
              width:6, height:6, borderRadius:"50%",
              background:"#34C759", boxShadow:"0 0 6px #34C759",
            }}/>
          </div>
        </>
      )}

      {/* ── CLASSIC MODE background ── */}
      {!arMode && <>
        <div style={{position:"absolute",inset:0,backgroundImage:"radial-gradient(ellipse at 20% 80%,#FF2D5508 0%,transparent 50%),radial-gradient(ellipse at 80% 20%,#BF5AF208 0%,transparent 50%)",pointerEvents:"none"}}/>
        <div style={{position:"absolute",bottom:0,left:0,right:0,height:80,backgroundImage:"linear-gradient(0deg,#0d1020 0%,transparent 100%),repeating-linear-gradient(90deg,transparent,transparent 29px,#ffffff04 30px)",backgroundSize:"30px 30px",pointerEvents:"none"}}/>
      </>}

      {/* ── ROUND + HP HUD (always on top) ── */}
      <div style={{position:"absolute",top:8,left:8,zIndex:10,display:"flex",flexDirection:"column",gap:4}}>
        <div style={{background:"rgba(0,0,0,.7)",border:`1px solid ${arMode?"#34C75960":"#FF2D5540"}`,backdropFilter:"blur(4px)",borderRadius:8,padding:"3px 10px",fontSize:9,color:arMode?"#34C759":"#FF2D55",fontFamily:"'Black Han Sans',sans-serif",letterSpacing:1}}>
          {arMode?"📡 AR ":""}ROUND {roundNum} {roundNum%5===0?"⚠️ BOSS":""}
        </div>
      </div>
      <div style={{position:"absolute",top:8,right:8,width:82,zIndex:10}}>
        <div style={{background:"rgba(0,0,0,.7)",backdropFilter:"blur(4px)",borderRadius:8,padding:"4px 8px"}}>
          <div style={{fontSize:8,color:"#34C759",textAlign:"right",marginBottom:2}}>❤️ {playerHp}/{playerMaxHp}</div>
          <div style={{height:4,background:"rgba(0,0,0,.5)",borderRadius:2,overflow:"hidden"}}>
            <div style={{height:"100%",width:`${(playerHp/playerMaxHp)*100}%`,background:playerHp>50?"#34C759":playerHp>25?"#FF9500":"#FF2D55",borderRadius:2,transition:"width .3s"}}/>
          </div>
        </div>
      </div>

      {/* ── WEBXR TOGGLE BUTTON ── */}
      {(()=>{
        // Check if WebXR is available — show different label
        const hasXR = typeof navigator !== "undefined" && !!navigator.xr;
        return(
          <div style={{position:"absolute",bottom:8,right:8,zIndex:10,display:"flex",flexDirection:"column",gap:4,alignItems:"flex-end"}}>
            {!arMode ? (
              <button onClick={e=>{e.stopPropagation();startAR();}} style={{
                padding:"6px 12px",borderRadius:20,cursor:"pointer",
                border:`1px solid ${hasXR?"#34C75960":"#007AFF60"}`,
                background:"rgba(0,0,0,.75)",backdropFilter:"blur(6px)",
                color:hasXR?"#34C759":"#007AFF",
                fontFamily:"'Black Han Sans',sans-serif",fontSize:9,letterSpacing:1,
                boxShadow:`0 2px 10px rgba(${hasXR?"52,199,89":"0,122,255"},.25)`,
              }}>
                {hasXR?"🥽 WEBXR":"📷 AR MODE"}
              </button>
            ) : (
              <div style={{display:"flex",flexDirection:"column",gap:3,alignItems:"flex-end"}}>
                <button onClick={e=>{e.stopPropagation();stopAR();}} style={{
                  padding:"5px 12px",border:"1px solid #FF2D5560",borderRadius:20,
                  background:"rgba(0,0,0,.75)",backdropFilter:"blur(6px)",
                  color:"#FF2D55",fontFamily:"'Black Han Sans',sans-serif",fontSize:9,letterSpacing:1,cursor:"pointer",
                }}>✕ EXIT AR</button>
                {/* Plane detection indicator */}
                <div style={{
                  padding:"3px 8px",borderRadius:10,
                  background:"rgba(0,0,0,.7)",backdropFilter:"blur(4px)",
                  fontSize:8,color:"#FFCC00",fontFamily:"'Space Mono',monospace",letterSpacing:.5,
                  display:"flex",alignItems:"center",gap:4,
                }}>
                  <div style={{width:5,height:5,borderRadius:"50%",background:"#34C759",animation:"pulse 1.5s ease-in-out infinite"}}/>
                  {hasXR?"WebXR Active":"Camera AR"}
                </div>
              </div>
            )}
            {arError&&<div style={{fontSize:8,color:"#FF9500",textAlign:"right",maxWidth:130,lineHeight:1.5,background:"rgba(0,0,0,.75)",padding:"3px 8px",borderRadius:6,backdropFilter:"blur(4px)"}}>{arError}</div>}
          </div>
        );
      })()}

      {/* ── HIT FLASH ── */}
      {hitAnim&&<div style={{position:"absolute",inset:0,background:"rgba(255,45,85,.3)",animation:"flash .2s ease",pointerEvents:"none",borderRadius:12,zIndex:8}}/>}

      {/* ── DODGE TEXT ── */}
      {dodgeAnim&&<div style={{position:"absolute",top:"35%",left:"50%",transform:"translate(-50%,-50%)",fontFamily:"'Black Han Sans',sans-serif",fontSize:26,color:"#34C759",letterSpacing:3,animation:"popIn .4s ease",pointerEvents:"none",zIndex:9,textShadow:"0 0 16px #34C759"}}>DODGE!</div>}

      {/* ── MUZZLE FLASH at shot position ── */}
      {shotFx&&<div style={{
        position:"absolute",left:shotFx.x,top:shotFx.y,
        transform:"translate(-50%,-50%)",
        width:40,height:40,zIndex:15,pointerEvents:"none",
        display:"flex",alignItems:"center",justifyContent:"center",
      }}>
        <div style={{fontSize:28,filter:"drop-shadow(0 0 10px #FF9500)",animation:"popIn .15s ease"}}>✨</div>
      </div>}

      {/* ── MISS SPLASH ── */}
      {missAnim&&<div style={{
        position:"absolute",left:missAnim.x,top:missAnim.y,
        transform:"translate(-50%,-50%)",
        zIndex:12,pointerEvents:"none",
        fontFamily:"'Black Han Sans',sans-serif",fontSize:11,
        color:"rgba(255,255,255,.5)",letterSpacing:1,
        animation:"popIn .3s ease",
      }}>MISS</div>}

      {/* ── ZOMBIES ── */}
      {zombies.map(z=>{
        const zc      = zombieColor(z);
        const isTagged= z.hp<=0;
        const hpPct   = (z.hp/z.maxHp)*100;
        const isBoss  = z.id.startsWith("boss");
        const sz      = arMode
          ? (isBoss ? 100 : Math.round(36 + (z.y/100)*40)) * perspectiveScale(z.y)
          : (isBoss ? 52 : 32);

        // AR shadow/glow — makes zombie feel like it's standing on real ground
        const arShadow = arMode
          ? `drop-shadow(0 ${Math.round(sz*0.12)}px ${Math.round(sz*0.08)}px rgba(0,0,0,.8)) drop-shadow(0 0 ${isBoss?20:10}px ${zc}80)`
          : `drop-shadow(0 0 ${isBoss?12:6}px ${zc})`;

        return(
          <div key={z.id} onClick={e=>!isTagged&&handleTap(e,z)}
            style={{
              position:"absolute",
              left:`${z.x}%`, top:`${z.y}%`,
              transform:"translate(-50%,-50%)",
              display:"flex",flexDirection:"column",alignItems:"center",
              cursor:isTagged?"default":"crosshair",
              transition:z.stunned?"none":"top .5s linear, left .5s linear",
              opacity:isTagged?0:1,
              zIndex:isBoss?20:Math.round(z.y)+5,
            }}>
            {/* HP bar */}
            {!isTagged&&<div style={{width:isBoss?70:Math.round(sz*1.1),height:3,background:"rgba(0,0,0,.6)",borderRadius:1.5,overflow:"hidden",marginBottom:3,border:"1px solid rgba(255,255,255,.1)"}}>
              <div style={{height:"100%",width:`${hpPct}%`,background:hpPct>60?zc:hpPct>25?"#FF9500":"#FF2D55",borderRadius:1.5}}/>
            </div>}

            {/* Zombie emoji — the AR "model" */}
            <div style={{
              fontSize: sz,
              filter: isTagged ? "grayscale(1) opacity(.2)" : arShadow,
              animation: isTagged ? "none"
                : z.stunned ? "pulse 0.3s ease-in-out infinite"
                : isBoss ? "breathe 1s ease-in-out infinite"
                : "float 2s ease-in-out infinite",
              animationDelay:`${(z.x*0.03).toFixed(1)}s`,
              // Perspective: slight shrink at top, normal at bottom
              transform: arMode ? `scaleX(${z.x>50?1:-1})` : "none",
              lineHeight:1,
            }}>
              {z.e}
            </div>

            {/* Ground shadow in AR mode */}
            {arMode&&!isTagged&&<div style={{
              width:Math.round(sz*0.7),height:8,
              background:"rgba(0,0,0,.4)",
              borderRadius:"50%",
              filter:"blur(4px)",
              marginTop:-4,
              flexShrink:0,
            }}/>}

            {/* Zombie name tag */}
            {!isTagged&&<div style={{
              fontSize:arMode?9:7,
              color:arMode?"#fff":zc,
              fontFamily:"'DM Mono',monospace",
              marginTop:arMode?4:2,
              letterSpacing:.5,
              background:arMode?"rgba(0,0,0,.6)":"transparent",
              padding:arMode?"2px 5px":"0",
              borderRadius:arMode?4:0,
              border:arMode?`1px solid ${zc}60`:"none",
            }}>
              {isBoss?z.n:`${z.n} ${Math.round(z.hp)}`}
            </div>}

            {/* AR "targeting ring" when you hover/tap near zombie */}
            {arMode&&!isTagged&&isBoss&&<div style={{
              position:"absolute",
              width:sz+24,height:sz+24,
              borderRadius:"50%",
              border:`2px solid ${zc}40`,
              top:"50%",left:"50%",
              transform:"translate(-50%,-50%)",
              animation:"pulse 2s ease-in-out infinite",
              pointerEvents:"none",
            }}/>}
          </div>
        );
      })}

      {/* ── WAVE CLEAR ── */}
      {zombies.length>0&&zombies.every(z=>z.hp<=0)&&(
        <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",background:"rgba(0,0,0,.55)",zIndex:20,backdropFilter:arMode?"blur(2px)":"none"}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:30,color:"#34C759",letterSpacing:3,textShadow:"0 0 24px #34C75980",animation:"popIn .5s ease",textAlign:"center"}}>
            WAVE CLEAR! ✅
            {arMode&&<div style={{fontSize:11,color:"#34C759aa",letterSpacing:2,marginTop:6}}>AREA SECURED</div>}
          </div>
        </div>
      )}

      {/* ── WEAPON RETICLE FLASH ── */}
      {shooting&&<div style={{position:"absolute",inset:0,pointerEvents:"none",border:`3px solid ${arMode?"#34C75960":"#FF2D5540"}`,borderRadius:12,animation:"flash .15s ease",zIndex:8}}/>}
    </div>
  );
}

// ── Main ZombieHunt component ─────────────────────────────────────────────────
function ZombieHunt({ myId, myName, myAvatar, onBack, onCoinsEarned }) {
  const [phase,       setPhase]      = useState("map");     // map|prep|battle|shop|dead|victory
  const [round,       setRound]      = useState(1);
  const [zombies,     setZombies]    = useState([]);
  const [playerHp,    setPlayerHp]   = useState(100);
  const [playerMaxHp, setPlayerMaxHp]= useState(100);
  const [coins,       setCoins]      = useState(500);
  const [xp,          setXp]         = useState(0);
  const [kills,       setKills]      = useState(0);
  const [totalCoins,  setTotalCoins] = useState(0);
  const [weapon,      setWeapon]     = useState(ZOMBIE_WEAPONS[0]);
  const [ammo,        setAmmo]       = useState(ZOMBIE_WEAPONS[0].ammo);
  const [perks,       setPerks]      = useState([]);
  const [hitAnim,     setHitAnim]    = useState(false);
  const [dodgeAnim,   setDodgeAnim]  = useState(false);
  const [killFeed,    setKillFeed]   = useState([]);
  const [mapSpawns,   setMapSpawns]  = useState(()=>generateMapSpawns());
  const [selSpawn,    setSelSpawn]   = useState(null);
  const [activeLocation,setActiveLocation]=useState(null);

  function generateMapSpawns() {
    const W=360,H=300;
    const spawns=[];
    // Zombie hordes scattered on the map
    for(let i=0;i<8;i++){
      const zombieCount=1+Math.floor(Math.random()*5);
      const types=Object.keys(ZOMBIE_TYPES);
      spawns.push({
        id:"spawn_"+i,
        x:8+Math.random()*84,
        y:8+Math.random()*84,
        zombieCount,
        mainType:types[Math.floor(Math.random()*types.length)],
        threat:zombieCount>3?"HIGH":zombieCount>1?"MED":"LOW",
        coins:zombieCount*15+Math.floor(Math.random()*30),
        cleared:false,
      });
    }
    // Special locations
    ZOMBIE_SPECIAL_LOCATIONS.slice(0,3).forEach((loc,i)=>{
      spawns.push({
        id:"loc_"+i, x:15+i*30, y:70,
        special:true,...loc,
        cleared:false,
      });
    });
    return spawns;
  }

  // Zombie movement tick — zombies advance toward player
  useEffect(()=>{
    if(phase!=="battle"||playerHp<=0)return;
    const id=setInterval(()=>{
      setZombies(prev=>{
        let dmgTaken=0;
        const next=prev.map(z=>{
          if(z.hp<=0)return z;
          // Move toward player (bottom-centre)
          const tx=50, ty=95;
          const dx=tx-z.x, dy=ty-z.y;
          const dist=Math.hypot(dx,dy);
          const speed=(z.speed||1)*0.4*(z.stunned?0.3:1);
          if(dist<8){
            // Attack player
            const hasPHD=perks.find(p=>p.id==="phd");
            const actualDmg=z.id.startsWith("exploder")&&hasPHD?0:z.dmg;
            dmgTaken+=actualDmg;
            return{...z,x:tx+(dx/dist)*8,y:ty+(dy/dist)*8};
          }
          const newX=z.x+(dx/dist)*speed;
          const newY=z.y+(dy/dist)*speed;
          const stunTimer=Math.max(0,(z.stunTimer||0)-1);
          return{...z,x:newX,y:newY,stunned:stunTimer>0,stunTimer};
        });
        if(dmgTaken>0){
          setHitAnim(true);setTimeout(()=>setHitAnim(false),300);
          setPlayerHp(hp=>{
            const nh=Math.max(0,hp-dmgTaken);
            if(nh<=0)setPhase("dead");
            return nh;
          });
        }
        return next;
      });
    },600);
    return()=>clearInterval(id);
  },[phase,playerHp,perks]);

  // Check wave clear
  useEffect(()=>{
    if(phase!=="battle")return;
    const alive=zombies.filter(z=>z.hp>0);
    if(zombies.length>0&&alive.length===0){
      setTimeout(()=>{
        const earned=round*25+(kills>5?kills*5:0);
        setCoins(c=>c+earned);
        setTotalCoins(t=>t+earned);
        setXp(x=>x+round*30);
        addFeed(`✅ Wave ${round} clear! +${earned} coins`,"#34C759");
        setTimeout(()=>{
          if(round>=20){setPhase("victory");}
          else{setRound(r=>r+1);setPhase("shop");}
        },2000);
      },1000);
    }
  },[zombies,phase,round,kills]);

  const startBattle=()=>{
    setZombies(spawnWave(round));
    setPhase("battle");
    setAmmo(weapon.ammo);
  };

  const shoot=(zombieId)=>{
    if(ammo<=0){addFeed("🔫 OUT OF AMMO — reload!","#FF2D55");return;}
    const hasDblTap=perks.find(p=>p.id==="doubletap");
    const hasDeadshot=perks.find(p=>p.id==="deadshot");
    const dmgMulti=(hasDblTap?2:1);
    const crit=hasDeadshot&&Math.random()<0.3;
    const baseDmg=weapon.dmg*(crit?1.5:1)*dmgMulti;

    setAmmo(a=>a-1);
    setZombies(prev=>prev.map(z=>{
      if(z.id!==zombieId)return z;
      const newHp=Math.max(0,z.hp-baseDmg);
      const killed=newHp<=0;
      const frozen=weapon.id==="freeze_ray"&&!killed;
      if(killed){
        const zt=ZOMBIE_TYPES[z.id.split("_")[0]]||ZOMBIE_TYPES.walker;
        const coinEarn=zt.coins+(round*2);
        const xpEarn=zt.xp;
        setKills(k=>k+1);
        setCoins(c=>c+coinEarn);
        setTotalCoins(t=>t+coinEarn);
        setXp(x=>x+xpEarn);
        addFeed(`💀 ${z.n} down! +${coinEarn}🪙 +${xpEarn}XP`,zt.id==="boss"?"#FF2D55":"#34C759");
        // Exploder AoE
        if(z.id.startsWith("exploder")){
          const hasPHD=perks.find(p=>p.id==="phd");
          if(!hasPHD){
            setPlayerHp(hp=>Math.max(0,hp-z.dmg));
            setHitAnim(true);setTimeout(()=>setHitAnim(false),400);
            addFeed("💥 Exploder detonated! Take cover!","#FF6B35");
          }
        }
      }
      return{...z,hp:newHp,stunned:frozen,stunTimer:frozen?4:0};
    }));
  };

  const dodge=()=>{
    setDodgeAnim(true);setTimeout(()=>setDodgeAnim(false),600);
    // Dodge reduces next hit damage by 70%
    addFeed("🏃 Dodge roll!","#007AFF");
  };

  const reload=()=>{
    const hasSpeedCola=perks.find(p=>p.id==="speedcola");
    const t=hasSpeedCola?weapon.reload*500:weapon.reload*1000;
    addFeed("🔄 Reloading...","#FF9500");
    setTimeout(()=>{setAmmo(weapon.ammo);addFeed("✅ Ready!","#34C759");},t);
  };

  const buyPerk=(perk)=>{
    if(coins<perk.cost||perks.find(p=>p.id===perk.id))return;
    setCoins(c=>c-perk.cost);
    setPerks(p=>[...p,perk]);
    if(perk.id==="juggernog"){setPlayerMaxHp(m=>m+50);setPlayerHp(h=>h+50);}
    addFeed(`${perk.e} ${perk.n} activated!`,"#BF5AF2");
  };

  const buyWeapon=(w)=>{
    if(w.unlock>0&&round<w.unlock)return;
    setWeapon(w);setAmmo(w.ammo);
    addFeed(`🔫 Equipped ${w.n}`,"#007AFF");
  };

  const addFeed=(msg,color="#888")=>{
    setKillFeed(kf=>[{id:uid(),msg,color,ts:Date.now()},...kf].slice(0,5));
  };

  const handleMapSelect=(spawn)=>{
    setSelSpawn(spawn);
  };

  const startFromMap=(spawn)=>{
    setActiveLocation(spawn);
    setSelSpawn(null);
    setPhase("prep");
  };

  // ── MAP VIEW ──────────────────────────────────────────────────────────────
  if(phase==="map")return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>

      {/* Header */}
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:48,animation:"breathe 2s ease-in-out infinite",filter:"drop-shadow(0 0 20px #FF2D55)"}}>☣️</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:24,letterSpacing:3,color:"#FF2D55"}}>DEAD CITY</div>
        <div style={{fontSize:11,color:"#555",marginTop:4}}>Zombies have overrun the city. Fight back. Earn coins.</div>
      </div>

      {/* Player stats */}
      <div style={{...S.card,background:"#0a0c14",border:"1px solid #FF2D5530",display:"flex",gap:14,alignItems:"center"}}>
        <span style={{fontSize:28}}>{myAvatar||"🍺"}</span>
        <div style={{flex:1}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:"#f0f0f8"}}>{myName||"SURVIVOR"}</div>
          <div style={{fontSize:9,color:"#555",marginTop:2,display:"flex",gap:8}}>
            <span style={{color:"#FFCC00"}}>🪙{totalCoins} earned today</span>
            <span style={{color:"#34C759"}}>💀 {kills} kills</span>
            <span style={{color:"#007AFF"}}>⭐ {xp} XP</span>
          </div>
        </div>
        <div style={{textAlign:"center"}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,color:"#FF2D55"}}>{round}</div>
          <div style={{fontSize:8,color:"#555",letterSpacing:1}}>ROUND</div>
        </div>
      </div>

      {/* Zombie world map */}
      <div style={{background:"#07080f",border:"2px solid #FF2D5530",borderRadius:14,overflow:"hidden",position:"relative"}}>
        <svg viewBox="0 0 360 300" style={{width:"100%",display:"block"}}>
          <defs>
            <radialGradient id="zglow" cx="50%" cy="50%" r="60%">
              <stop offset="0%" stopColor="#FF2D55" stopOpacity=".06"/>
              <stop offset="100%" stopColor="#FF2D55" stopOpacity="0"/>
            </radialGradient>
          </defs>
          <rect width="360" height="300" fill="#07080f"/>
          <rect width="360" height="300" fill="url(#zglow)"/>
          {/* Spooky city grid */}
          {Array.from({length:7},(_,i)=><line key={`h${i}`} x1="0" y1={i*50} x2="360" y2={i*50} stroke="#FF2D55" strokeOpacity=".04" strokeWidth=".5"/>)}
          {Array.from({length:8},(_,i)=><line key={`v${i}`} x1={i*51} y1="0" x2={i*51} y2="300" stroke="#FF2D55" strokeOpacity=".04" strokeWidth=".5"/>)}

          {/* Zombie spawns */}
          {mapSpawns.map(spawn=>{
            const bx=(spawn.x/100)*340+10, by=(spawn.y/100)*280+10;
            const isSel=selSpawn?.id===spawn.id;
            const threatColor=spawn.cleared?"#2a2a3a":spawn.threat==="HIGH"?"#FF2D55":spawn.threat==="MED"?"#FF9500":"#34C759";
            if(spawn.special)return(
              <g key={spawn.id} onClick={()=>handleMapSelect(spawn)} style={{cursor:"pointer"}}>
                <circle cx={bx} cy={by} r={16} fill="#FFCC0018" stroke="#FFCC0040" strokeWidth={isSel?2.5:1.5}/>
                <text x={bx} y={by+5} textAnchor="middle" fontSize="14" style={{userSelect:"none"}}>{spawn.e}</text>
                <text x={bx} y={by+24} textAnchor="middle" fontSize="7" fill="#FFCC00" fontFamily="monospace" style={{userSelect:"none"}}>{spawn.n?.slice(0,8).toUpperCase()}</text>
              </g>
            );
            return(
              <g key={spawn.id} onClick={()=>handleMapSelect(spawn)} style={{cursor:"pointer"}}>
                {/* Threat pulse */}
                {!spawn.cleared&&<circle cx={bx} cy={by} r={20+spawn.zombieCount*3} fill={`${threatColor}08`}/>}
                <circle cx={bx} cy={by} r={14} fill={`${threatColor}15`} stroke={isSel?threatColor:`${threatColor}60`} strokeWidth={isSel?2.5:1.5}/>
                <text x={bx} y={by+5} textAnchor="middle" fontSize={spawn.cleared?12:14} style={{userSelect:"none",opacity:spawn.cleared?.4:1}}>
                  {spawn.cleared?"✅":"🧟"}
                </text>
                <text x={bx} y={by+24} textAnchor="middle" fontSize="7" fill={spawn.cleared?"#2a2a3a":threatColor} fontFamily="monospace" style={{userSelect:"none"}}>
                  {spawn.cleared?"CLEAR":`×${spawn.zombieCount}`}
                </text>
                {/* Threat badge */}
                {!spawn.cleared&&<circle cx={bx+11} cy={by-11} r={5} fill={threatColor}/>}
                {!spawn.cleared&&<text x={bx+11} y={by-8} textAnchor="middle" fontSize="6" fill="#000" fontWeight="bold" style={{userSelect:"none"}}>{spawn.zombieCount}</text>}
              </g>
            );
          })}

          {/* Player position */}
          <g>
            <circle cx={180} cy={250} r={14} fill="#07080f" stroke="#34C759" strokeWidth="2.5"/>
            <text x={180} y={254} textAnchor="middle" fontSize="12" style={{userSelect:"none"}}>{myAvatar||"🎯"}</text>
            <circle cx={180} cy={250} r={20} fill="none" stroke="#34C759" strokeOpacity=".3" strokeWidth="1" strokeDasharray="4 4"/>
          </g>

          {/* Legend */}
          <g transform="translate(8,8)">
            {[["#FF2D55","HIGH"],["#FF9500","MED"],["#34C759","LOW"],["#FFCC00","SPECIAL"]].map(([c,l],i)=>(
              <g key={l} transform={`translate(0,${i*13})`}>
                <circle cx="5" cy="5" r="4" fill={`${c}20`} stroke={c} strokeWidth="1"/>
                <text x="13" y="9" fontSize="7" fill={c} fontFamily="monospace" style={{userSelect:"none"}}>{l}</text>
              </g>
            ))}
          </g>
        </svg>

        {/* Selected spawn info */}
        {selSpawn&&(
          <div style={{position:"absolute",bottom:8,left:8,right:8,background:"#0d0e1a",border:`2px solid ${selSpawn.special?"#FFCC00":"#FF2D55"}40`,borderRadius:10,padding:10,animation:"slideUp .2s ease"}}>
            <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:8}}>
              <span style={{fontSize:22}}>{selSpawn.e||"🧟"}</span>
              <div style={{flex:1}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:"#f0f0f8"}}>{selSpawn.special?selSpawn.n:`${selSpawn.zombieCount} Zombies · ${selSpawn.threat} THREAT`}</div>
                <div style={{fontSize:10,color:"#555",marginTop:1}}>{selSpawn.special?selSpawn.desc:`+${selSpawn.coins} coins if cleared`}</div>
              </div>
              <button onClick={()=>setSelSpawn(null)} style={{background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:14}}>✕</button>
            </div>
            {!selSpawn.cleared&&<button onClick={()=>startFromMap(selSpawn)} style={{width:"100%",padding:"10px 0",border:"none",borderRadius:10,background:selSpawn.special?"linear-gradient(135deg,#FFCC00,#FF9500)":"linear-gradient(135deg,#FF2D55,#FF6B35)",color:selSpawn.special?"#000":"#fff",fontFamily:"'Black Han Sans',sans-serif",fontSize:15,letterSpacing:1,cursor:"pointer"}}>
              {selSpawn.special?`${selSpawn.e} USE (${selSpawn.coins>0?`🪙${selSpawn.coins}`:"FREE"})`:"☣️ ENGAGE HORDE →"}
            </button>}
          </div>
        )}
      </div>

      {/* AR Mode tip */}
      <div style={{...S.card,background:"#34C75908",border:"1px solid #34C75930",display:"flex",alignItems:"flex-start",gap:10}}>
        <span style={{fontSize:22,flexShrink:0}}>📷</span>
        <div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:"#34C759"}}>AR MODE AVAILABLE</div>
          <div style={{fontSize:10,color:"#555",marginTop:3,lineHeight:1.6}}>
            Tap <strong style={{color:"#34C759"}}>📷 AR MODE</strong> during battle to fight zombies through your real camera — they appear in your actual environment like Pokémon GO.
          </div>
        </div>
      </div>

      <div style={{fontSize:9,color:"#444",textAlign:"center",lineHeight:1.7}}>
        Tap a horde to engage · Earn coins from kills · Coins carry into crawl events<br/>
        GPS-spawned zombies appear near your real location in production
      </div>
    </div>
  );

  // ── PREP / SHOP ──────────────────────────────────────────────────────────────
  // Interstitial ad between zombie rounds (shop phase only, not first prep)
  const [showInterstitial,setShowInterstitial]=useState(phase==="shop");

  if(phase==="prep"||phase==="shop")return(
    <div style={S.screen}>
      {/* Interstitial ad between waves */}
      {showInterstitial&&phase==="shop"&&(
        <InterstitialAd
          onSkip={()=>setShowInterstitial(false)}
          onWatchFull={()=>{
            // Grant bonus spin token via daily state
            setShowInterstitial(false);
            // In prod: trigger rewarded ad complete callback
          }}
        />
      )}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2,color:"#FF2D55"}}>
          {phase==="shop"?"🏪 BETWEEN WAVES":"⚔️ PREPARE TO FIGHT"}
        </div>
        <div style={{...S.card,background:"#FFCC0015",border:"1px solid #FFCC0040",padding:"5px 12px"}}>
          <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#FFCC00"}}>🪙{coins}</span>
        </div>
      </div>

      {phase==="shop"&&<div style={{...S.card,background:"#34C75915",border:"1px solid #34C75940",textAlign:"center"}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#34C759"}}>✅ WAVE {round-1} CLEARED!</div>
        <div style={{fontSize:11,color:"#555",marginTop:3}}>Round {round} loading — buy upgrades before you continue</div>
      </div>}

      {/* Weapons */}
      <div style={{fontSize:9,color:"#555",letterSpacing:3}}>🔫 SELECT WEAPON</div>
      <div style={{display:"flex",flexDirection:"column",gap:6}}>
        {ZOMBIE_WEAPONS.filter(w=>round>=w.unlock).map(w=>{
          const isCurr=weapon.id===w.id;
          return(
            <div key={w.id} onClick={()=>buyWeapon(w)} style={{...S.card,display:"flex",alignItems:"center",gap:10,border:`2px solid ${isCurr?"#FF2D55":"#1a1d2e"}`,background:isCurr?"#FF2D5510":"#0d0e1a",cursor:"pointer"}}>
              <span style={{fontSize:24,flexShrink:0}}>{w.e}</span>
              <div style={{flex:1}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:isCurr?"#FF2D55":"#f0f0f8"}}>{w.n}</div>
                <div style={{fontSize:9,color:"#555",marginTop:1,display:"flex",gap:6}}>
                  <span>⚔️{w.dmg} dmg</span><span>📦{w.ammo} ammo</span><span>🔄{w.reload}s</span>
                  {w.special&&<span style={{color:"#BF5AF2"}}>{w.special}</span>}
                </div>
              </div>
              {isCurr&&<span style={{fontSize:10,color:"#FF2D55",flexShrink:0}}>EQUIPPED</span>}
            </div>
          );
        })}
      </div>

      {/* Perks */}
      <div style={{fontSize:9,color:"#555",letterSpacing:3}}>🎰 PERKS</div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
        {ZOMBIE_PERKS.map(p=>{
          const owned=perks.find(pp=>pp.id===p.id);
          const canAfford=coins>=p.cost;
          return(
            <button key={p.id} onClick={()=>!owned&&buyPerk(p)} disabled={owned||!canAfford} style={{display:"flex",flexDirection:"column",gap:4,padding:"10px",border:`1px solid ${owned?"#34C75940":canAfford?"#BF5AF240":"#1a1d2e"}`,borderRadius:10,background:owned?"#34C75910":canAfford?"#BF5AF210":"#07080f",cursor:owned||!canAfford?"not-allowed":"pointer",opacity:canAfford||owned?1:.5}}>
              <div style={{display:"flex",alignItems:"center",gap:6}}>
                <span style={{fontSize:20}}>{p.e}</span>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:owned?"#34C759":"#BF5AF2",letterSpacing:1}}>{p.n}</div>
              </div>
              <div style={{fontSize:9,color:"#555",lineHeight:1.4}}>{p.desc}</div>
              {!owned&&<div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,color:canAfford?"#FFCC00":"#555"}}>🪙{p.cost}</div>}
              {owned&&<div style={{fontSize:9,color:"#34C759"}}>✅ ACTIVE</div>}
            </button>
          );
        })}
      </div>

      {/* Banner ad at bottom of prep screen */}
      <BannerAd/>

      <button onClick={startBattle} style={{...S.btnPrimary,background:"linear-gradient(135deg,#FF2D55,#FF6B35)",boxShadow:"0 4px 20px #FF2D5540",width:"100%",fontSize:18}}>
        ☣️ FIGHT ROUND {round} →
      </button>
    </div>
  );

  // ── BATTLE ────────────────────────────────────────────────────────────────────
  // WebXR state (shared between hook and fullscreen session)
  const [xrLaunching, setXrLaunching] = useState(false);
  const [xrSession,   setXrSession]   = useState(null);  // active XRSession ref
  const [xrPlanes,    setXrPlanes]    = useState(0);      // detected floor planes
  const [showXRLaunch,setShowXRLaunch]= useState(false);  // pre-launch prompt

  // Launch full WebXR immersive-ar session (separate from arena inline AR)
  const launchWebXR = useCallback(async () => {
    if(!navigator.xr){ alert("WebXR not supported on this browser. Try Chrome on Android."); return; }
    setXrLaunching(true);
    try {
      const supported = await navigator.xr.isSessionSupported("immersive-ar");
      if(!supported){ setXrLaunching(false); alert("Immersive AR not supported on this device."); return; }
      const session = await navigator.xr.requestSession("immersive-ar", {
        requiredFeatures:["local"],
        optionalFeatures:["plane-detection","hit-test","dom-overlay","anchors"],
        domOverlay: { root: document.getElementById("xr-overlay") || document.body },
      });
      setXrSession(session);
      session.addEventListener("end", ()=>{ setXrSession(null); setXrLaunching(false); setXrPlanes(0); });

      // Minimal render loop — just track plane count and viewer pose
      const refSpace = await session.requestReferenceSpace("local");
      const tick = (time, frame) => {
        session.requestAnimationFrame(tick);
        if(frame.detectedPlanes){
          let h=0; frame.detectedPlanes.forEach(p=>{ if(p.orientation==="horizontal")h++; });
          setXrPlanes(h);
        }
      };
      session.requestAnimationFrame(tick);
    } catch(e) {
      setXrLaunching(false);
      alert(`WebXR failed: ${e.message}`);
    }
  },[]);

  const endWebXR = useCallback(async()=>{
    if(xrSession){ try{ await xrSession.end(); }catch{} }
    setXrSession(null); setXrLaunching(false); setXrPlanes(0);
  },[xrSession]);

  if(phase==="battle")return(
    <div style={{...S.screen, padding:"8px 0 0", gap:6}}>

      {/* ── WebXR Active Overlay ── */}
      {xrSession&&(
        <div id="xr-overlay" style={{
          position:"fixed",inset:0,zIndex:9999,
          background:"rgba(0,0,0,.0)", // transparent — XR compositor handles camera
          pointerEvents:"all",
          display:"flex",flexDirection:"column",
        }}>
          {/* HUD inside XR overlay */}
          <div style={{position:"absolute",top:16,left:16,right:16,display:"flex",justifyContent:"space-between",alignItems:"flex-start",zIndex:1}}>
            <div style={{background:"rgba(0,0,0,.75)",backdropFilter:"blur(8px)",border:"1px solid #34C75960",borderRadius:10,padding:"6px 12px"}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:"#34C759",letterSpacing:1}}>
                🥽 WEBXR · ☣️ ROUND {round}
              </div>
              <div style={{fontSize:8,color:"#555",marginTop:2}}>
                {xrPlanes>0?`✅ ${xrPlanes} floor${xrPlanes>1?"s":""} detected`:"🔍 Scanning for surfaces…"}
              </div>
            </div>
            <button onClick={endWebXR} style={{
              padding:"7px 14px",border:"1px solid #FF2D5560",borderRadius:20,
              background:"rgba(0,0,0,.75)",backdropFilter:"blur(8px)",
              color:"#FF2D55",fontFamily:"'Black Han Sans',sans-serif",fontSize:11,letterSpacing:1,cursor:"pointer",
            }}>✕ EXIT XR</button>
          </div>

          {/* HP bar inside XR */}
          <div style={{position:"absolute",bottom:120,left:16,right:16,zIndex:1}}>
            <div style={{background:"rgba(0,0,0,.75)",backdropFilter:"blur(8px)",borderRadius:10,padding:"8px 12px"}}>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:10,color:"#888",marginBottom:4}}>
                <span>❤️ HP</span>
                <span style={{color:playerHp>50?"#34C759":playerHp>25?"#FF9500":"#FF2D55"}}>{playerHp}/{playerMaxHp}</span>
              </div>
              <div style={{height:6,background:"rgba(255,255,255,.1)",borderRadius:3,overflow:"hidden"}}>
                <div style={{height:"100%",width:`${(playerHp/playerMaxHp)*100}%`,background:playerHp>50?"#34C759":playerHp>25?"#FF9500":"#FF2D55",borderRadius:3,transition:"width .3s"}}/>
              </div>
            </div>
          </div>

          {/* Zombie tap targets in XR — full screen tappable zones */}
          {zombies.filter(z=>z.hp>0).map((z,i)=>{
            const cols=3, row=Math.floor(i/cols), col=i%cols;
            const zc=ZOMBIE_TYPES[z.type||z.id.split("_")[0]]?.color||"#34C759";
            const isBoss=z.id.startsWith("boss");
            return(
              <div key={z.id} onClick={()=>shoot(z.id)} style={{
                position:"absolute",
                left:`${10+(col*30)}%`,
                top:`${25+(row*22)}%`,
                transform:"translate(-50%,-50%)",
                display:"flex",flexDirection:"column",alignItems:"center",
                cursor:"crosshair",zIndex:1,
              }}>
                <div style={{width:isBoss?70:50,height:3,background:"rgba(0,0,0,.5)",borderRadius:1.5,overflow:"hidden",marginBottom:4,border:"1px solid rgba(255,255,255,.15)"}}>
                  <div style={{height:"100%",width:`${(z.hp/z.maxHp)*100}%`,background:zc,borderRadius:1.5}}/>
                </div>
                <div style={{fontSize:isBoss?80:48,filter:`drop-shadow(0 0 16px ${zc}) drop-shadow(0 4px 8px rgba(0,0,0,.9))`,animation:isBoss?"breathe 1s ease-in-out infinite":"float 2s ease-in-out infinite"}}>
                  {z.e}
                </div>
                <div style={{background:"rgba(0,0,0,.7)",backdropFilter:"blur(4px)",border:`1px solid ${zc}60`,borderRadius:8,padding:"2px 8px",fontSize:9,color:"#fff",marginTop:3,fontFamily:"'DM Mono',monospace",letterSpacing:.5}}>
                  {isBoss?z.n:`${z.n} ${Math.round(z.hp)}`}
                </div>
              </div>
            );
          })}

          {/* All dead in XR */}
          {zombies.length>0&&zombies.every(z=>z.hp<=0)&&(
            <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",justifyContent:"center",zIndex:2,background:"rgba(0,0,0,.3)",backdropFilter:"blur(4px)"}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:36,color:"#34C759",letterSpacing:4,textShadow:"0 0 30px #34C759",animation:"popIn .5s ease",textAlign:"center"}}>
                WAVE CLEAR! ✅<br/>
                <span style={{fontSize:14,letterSpacing:2}}>AREA SECURED</span>
              </div>
            </div>
          )}

          {/* Instructions */}
          <div style={{position:"absolute",bottom:16,left:16,right:16,textAlign:"center",zIndex:1}}>
            <div style={{fontSize:9,color:"rgba(255,255,255,.4)",fontFamily:"'DM Mono',monospace",letterSpacing:1}}>
              {xrPlanes>0?"TAP ZOMBIES TO SHOOT · DODGE INCOMING ATTACKS":"POINT PHONE AT FLOOR TO DETECT SURFACES"}
            </div>
          </div>
        </div>
      )}

      {/* ── WebXR Launch Prompt ── */}
      {showXRLaunch&&!xrSession&&(
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.9)",zIndex:400,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:16,padding:24,animation:"fadeIn .3s ease"}}>
          <div style={{fontSize:72,animation:"breathe 2s ease-in-out infinite",filter:"drop-shadow(0 0 24px #34C759)"}}>🥽</div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:24,letterSpacing:3,color:"#34C759",textAlign:"center"}}>WEBXR MODE</div>
          <div style={{fontSize:11,color:"#888",textAlign:"center",lineHeight:1.8,maxWidth:300}}>
            Zombies will appear in your <strong style={{color:"#f0f0f8"}}>real environment</strong> using your device's AR camera.<br/><br/>
            Point your phone at a flat floor surface. When surfaces are detected the zombies will spawn on them.
          </div>
          <div style={{...S.card,background:"#34C75910",border:"1px solid #34C75930",width:"100%",maxWidth:300,fontSize:10,color:"#888",lineHeight:1.7}}>
            ✅ <strong>Android Chrome 81+</strong> — full plane detection<br/>
            ✅ <strong>Samsung Internet 13+</strong> — full support<br/>
            ⚠️ <strong>iOS Safari 17+</strong> — AR without planes<br/>
            ❌ <strong>Desktop</strong> — falls back to camera mode
          </div>
          <div style={{display:"flex",gap:10,width:"100%",maxWidth:300}}>
            <button onClick={()=>setShowXRLaunch(false)} style={{flex:1,padding:12,border:"1px solid #2a2a3a",borderRadius:12,background:"none",color:"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:14,cursor:"pointer"}}>CANCEL</button>
            <button onClick={()=>{setShowXRLaunch(false);launchWebXR();}} disabled={xrLaunching} style={{flex:2,padding:13,border:"none",borderRadius:12,background:"linear-gradient(135deg,#34C759,#00C7BE)",color:"#000",fontFamily:"'Black Han Sans',sans-serif",fontSize:15,letterSpacing:1,cursor:"pointer",boxShadow:"0 4px 16px #34C75940"}}>
              {xrLaunching?"LAUNCHING…":"🥽 ENTER WEBXR"}
            </button>
          </div>
        </div>
      )}

      {/* Battle header */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"0 14px"}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:"#FF2D55",letterSpacing:2}}>
          ☣️ ROUND {round}{round%5===0&&" — BOSS!"}
        </div>
        <div style={{display:"flex",gap:6,alignItems:"center"}}>
          <div style={{...S.card,padding:"4px 10px",background:"#FFCC0015",border:"1px solid #FFCC0030"}}>
            <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:"#FFCC00"}}>🪙{coins}</span>
          </div>
          <div style={{...S.card,padding:"4px 10px",background:"#FF2D5515",border:"1px solid #FF2D5530"}}>
            <span style={{fontSize:12,color:"#FF2D55"}}>💀{kills}</span>
          </div>
          {/* WebXR launch button */}
          <button onClick={e=>{e.stopPropagation();setShowXRLaunch(true);}} style={{
            padding:"5px 10px",border:"1px solid #34C75960",borderRadius:20,
            background:"#34C75910",color:"#34C759",
            fontFamily:"'Black Han Sans',sans-serif",fontSize:9,letterSpacing:1,cursor:"pointer",
          }}>🥽</button>
        </div>
      </div>

      {/* Battle arena */}
      <ZombieBattleArena
        playerHp={playerHp} playerMaxHp={playerMaxHp}
        zombies={zombies} activeWeapon={weapon}
        onShoot={shoot} onDodge={dodge}
        hitAnim={hitAnim} dodgeAnim={dodgeAnim}
        roundNum={round}/>

      {/* Kill feed */}
      <div style={{display:"flex",flexDirection:"column",gap:2,minHeight:40,padding:"0 12px"}}>
        {killFeed.slice(0,3).map(kf=>(
          <div key={kf.id} style={{fontSize:10,padding:"3px 10px",borderRadius:6,borderLeft:`3px solid ${kf.color}`,background:"#07080f",color:"#888",fontFamily:"'DM Mono',monospace",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{kf.msg}</div>
        ))}
      </div>

      {/* Weapon + controls */}
      <div style={{...S.card,background:"#0a0c14",border:"1px solid #1e2237",display:"flex",flexDirection:"column",gap:8,margin:"0 12px"}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:26}}>{weapon.e}</span>
          <div style={{flex:1}}>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:"#f0f0f8"}}>{weapon.n}</div>
            <div style={{fontSize:10,color:ammo>2?"#34C759":ammo>0?"#FF9500":"#FF2D55"}}>
              {ammo>0?`📦 ${ammo} rounds`:"🔫 EMPTY — Reload!"}
            </div>
          </div>
          <div style={{display:"flex",gap:6}}>
            <button onClick={dodge} style={{padding:"8px 14px",border:"1px solid #007AFF40",borderRadius:10,background:"#007AFF15",color:"#007AFF",fontFamily:"'Black Han Sans',sans-serif",fontSize:12,cursor:"pointer"}}>🏃 DODGE</button>
            <button onClick={reload} disabled={ammo>=weapon.ammo} style={{padding:"8px 14px",border:`1px solid ${ammo<weapon.ammo?"#FF950040":"#1a1d2e"}`,borderRadius:10,background:ammo<weapon.ammo?"#FF950015":"transparent",color:ammo<weapon.ammo?"#FF9500":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:12,cursor:ammo<weapon.ammo?"pointer":"not-allowed"}}>🔄 RELOAD</button>
          </div>
        </div>
        <div style={{fontSize:9,color:"#444",textAlign:"center"}}>TAP zombies to shoot · Dodge incoming attacks · Tap RELOAD when empty</div>
      </div>
    </div>
  );

  // ── DEAD ─────────────────────────────────────────────────────────────────────
  if(phase==="dead")return(
    <div style={{...S.screen,alignItems:"center",textAlign:"center",gap:14}}>
      <div style={{fontSize:72,animation:"breathe 2s ease-in-out infinite",filter:"drop-shadow(0 0 20px #FF2D55)"}}>💀</div>
      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:36,letterSpacing:3,color:"#FF2D55",textShadow:"0 0 30px #FF2D5560"}}>YOU DIED</div>
      <div style={{fontSize:12,color:"#555"}}>Survived to round {round} · {kills} kills</div>
      <div style={{...S.card,background:"#FFCC0010",border:"1px solid #FFCC0040",textAlign:"center",width:"100%"}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:32,color:"#FFCC00"}}>🪙 {totalCoins}</div>
        <div style={{fontSize:11,color:"#555",marginTop:3}}>Coins earned this session — added to your wallet</div>
      </div>
      {/* Ad on death screen — player is captive, natural pause */}
      <BannerAd/>

      <div style={{display:"flex",gap:8,width:"100%"}}>
        <button onClick={()=>{setPhase("map");setRound(1);setPlayerHp(100);setPlayerMaxHp(100);setKills(0);setTotalCoins(0);setPerks([]);setMapSpawns(generateMapSpawns());}} style={{...S.btnPrimary,flex:1,background:"linear-gradient(135deg,#FF2D55,#FF6B35)"}}>🔄 TRY AGAIN</button>
        <button onClick={()=>{onCoinsEarned&&onCoinsEarned(totalCoins);onBack();}} style={{flex:1,padding:13,border:"1px solid #34C75940",borderRadius:12,background:"#34C75915",color:"#34C759",fontFamily:"'Black Han Sans',sans-serif",fontSize:15,cursor:"pointer"}}>✅ CASH OUT</button>
      </div>
    </div>
  );

  // ── VICTORY ──────────────────────────────────────────────────────────────────
  if(phase==="victory")return(
    <div style={{...S.screen,alignItems:"center",textAlign:"center",gap:14}}>
      <div style={{fontSize:72,animation:"breathe 1.5s ease-in-out infinite",filter:"drop-shadow(0 0 24px #FFCC00)"}}>🏆</div>
      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:32,letterSpacing:3,color:"#FFCC00",textShadow:"0 0 30px #FFCC0080"}}>CITY SAVED!</div>
      <div style={{fontSize:12,color:"#555"}}>Completed all 20 rounds · Legend status unlocked!</div>
      <div style={{...S.card,background:"#FFCC0015",border:"2px solid #FFCC0050",textAlign:"center",width:"100%"}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:40,color:"#FFCC00"}}>🪙 {totalCoins+500}</div>
        <div style={{fontSize:11,color:"#555",marginTop:3}}>+500 bonus coins for saving the city</div>
      </div>
      <button onClick={()=>{onCoinsEarned&&onCoinsEarned(totalCoins+500);onBack();}} style={{...S.btnPrimary,background:"linear-gradient(135deg,#FFCC00,#FF9500)",color:"#000",width:"100%",fontSize:18}}>
        🏠 RETURN TO BASE
      </button>
    </div>
  );

  return null;
}

function TerritoryMap({ myId, myName, myAvatar, onBack }) {
  const { bars, myStats, claimBar, raidBar, claimAnim, passiveTick } = useTerritory(myId);
  const [selBar,      setSelBar]      = useState(null);
  const [cityFilter,  setCityFilter]  = useState("london");
  const [view,        setView]        = useState("map");    // map | leaderboard | myturf
  const [claimFlash,  setClaimFlash]  = useState(false);

  const cityBars  = bars.filter(b => b.city === cityFilter);
  const myBars    = bars.filter(b => b.owner?.id === myId);
  const selData   = bars.find(b => b.id === selBar);
  const CITIES    = [{id:"london",flag:"🇬🇧",name:"London"},{id:"nyc",flag:"🇺🇸",name:"New York"},{id:"berlin",flag:"🇩🇪",name:"Berlin"}];

  // Leaderboard
  const players = {};
  bars.forEach(b => {
    if (!b.owner) return;
    if (!players[b.owner.id]) players[b.owner.id] = {id:b.owner.id,name:b.owner.name,av:b.owner.av,bars:0,topTitle:TERRITORY_TITLES[0]};
    players[b.owner.id].bars++;
    const t = getTitleForVisits(b.owner.visits||0);
    if (t.minVisits > players[b.owner.id].topTitle.minVisits) players[b.owner.id].topTitle = t;
  });
  const leaderboard = Object.values(players).sort((a,b)=>b.bars-a.bars);

  // Map layout for demo — normalise to SVG coords
  const W=360, H=380;
  const CITY_BOUNDS = {
    london: {minLat:51.504,maxLat:51.527,minLng:-0.141,maxLng:-0.076},
    nyc:    {minLat:40.700,maxLat:40.730,minLng:-74.016,maxLng:-73.985},
    berlin: {minLat:52.495,maxLat:52.505,minLng:13.435,maxLng:13.450},
  };
  const toSVG = (lat,lng) => {
    const b = CITY_BOUNDS[cityFilter] || CITY_BOUNDS.london;
    const x = ((lng - b.minLng)/(b.maxLng - b.minLng)) * (W * 0.85) + W * 0.075;
    const y = ((b.maxLat - lat)/(b.maxLat - b.minLat)) * (H * 0.85) + H * 0.075;
    return {x, y};
  };

  const handleClaim = (bar) => {
    if (!myId || !myName) return;
    if (bar.owner?.id === myId) return; // already own it
    setClaimFlash(true);
    setTimeout(() => setClaimFlash(false), 800);
    claimBar(bar.id, myName, myAvatar);
    setSelBar(null);
  };

  const handleRaid = (bar) => {
    if (!myId || !myName) return;
    raidBar(bar.id, myName, myAvatar);
    setSelBar(null);
  };

  return (
    <div style={S.screen}>
      {/* Claim flash */}
      {claimFlash && <div style={{position:"fixed",inset:0,background:"rgba(255,204,0,.15)",zIndex:300,pointerEvents:"none",animation:"flash .5s ease"}}/>}

      {/* Header */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,color:"#f0f0f8"}}>🗺️ TERRITORY MAP</div>
          <div style={{fontSize:9,color:"#555",letterSpacing:2,marginTop:1}}>CLAIM BARS · EARN COINS · HOLD YOUR TURF</div>
        </div>
        <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      </div>

      {/* My stats strip */}
      {myId && (
        <div style={{...S.card,background:"#0a0c14",border:"1px solid #FFCC0030",display:"flex",gap:10,alignItems:"center"}}>
          <div style={{flex:1,display:"flex",gap:14}}>
            {[
              {v:myStats.coins,        l:"COINS",     c:"#FFCC00"},
              {v:myBars.length,        l:"BARS OWNED",c:"#FF2D55"},
              {v:myStats.streak,       l:"STREAK",    c:"#34C759"},
              {v:`+${myBars.reduce((s,b)=>{const t=getTitleForVisits(b.owner?.visits||0);return s+(t.coinRate||1);},0)}/hr`, l:"EARNING",c:"#00C7BE"},
            ].map((s,i)=>(
              <div key={i} style={{textAlign:"center"}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:s.c,lineHeight:1}}>{s.v}</div>
                <div style={{fontSize:7,color:"#555",letterSpacing:1,marginTop:2}}>{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* View tabs */}
      <div style={{display:"flex",gap:5}}>
        {[["map","🗺️ MAP"],["leaderboard","🏆 BOARD"],["myturf","👑 MY TURF"]].map(([id,label])=>(
          <button key={id} onClick={()=>setView(id)} style={{flex:1,padding:"8px 4px",border:`2px solid ${view===id?"#FF2D55":"#1a1d2e"}`,borderRadius:10,background:view===id?"#FF2D5515":"#0d0e1a",color:view===id?"#FF2D55":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:10,letterSpacing:1,cursor:"pointer"}}>
            {label}
          </button>
        ))}
      </div>

      {/* ── MAP VIEW ── */}
      {view==="map"&&(
        <>
          {/* City selector */}
          <div style={{display:"flex",gap:6,overflowX:"auto",scrollbarWidth:"none"}}>
            {CITIES.map(c=>(
              <button key={c.id} onClick={()=>{setCityFilter(c.id);setSelBar(null);}} style={{padding:"6px 14px",borderRadius:20,border:`1px solid ${cityFilter===c.id?"#FF2D55":"#2a2a3a"}`,background:cityFilter===c.id?"#FF2D5515":"#0d0e1a",color:cityFilter===c.id?"#FF2D55":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:10,cursor:"pointer",flexShrink:0,whiteSpace:"nowrap"}}>
                {c.flag} {c.name} <span style={{color:"#555"}}>({bars.filter(b=>b.city===c.id).filter(b=>b.owner).length}/{bars.filter(b=>b.city===c.id).length})</span>
              </button>
            ))}
          </div>

          {/* SVG territory map */}
          <div style={{background:"#07080f",border:"1px solid #1e2237",borderRadius:14,overflow:"hidden",position:"relative"}}>
            <svg viewBox={`0 0 ${W} ${H}`} style={{width:"100%",display:"block"}}>
              {/* Background */}
              <rect width={W} height={H} fill="#07080f"/>
              <defs>
                <radialGradient id="tglow" cx="50%" cy="50%" r="60%">
                  <stop offset="0%" stopColor="#FF2D55" stopOpacity="0.04"/>
                  <stop offset="100%" stopColor="#FF2D55" stopOpacity="0"/>
                </radialGradient>
              </defs>
              <rect width={W} height={H} fill="url(#tglow)"/>

              {/* Grid */}
              {Array.from({length:8},(_,i)=><line key={`h${i}`} x1="0" y1={i*(H/7)} x2={W} y2={i*(H/7)} stroke="#00C7BE" strokeOpacity=".04" strokeWidth=".5"/>)}
              {Array.from({length:8},(_,i)=><line key={`v${i}`} x1={i*(W/7)} y1="0" x2={i*(W/7)} y2={H} stroke="#00C7BE" strokeOpacity=".04" strokeWidth=".5"/>)}

              {/* Territory hexagon tiles */}
              {cityBars.map(bar => {
                const {x,y} = toSVG(bar.lat, bar.lng);
                const owned = !!bar.owner;
                const mine  = bar.owner?.id === myId;
                const title = bar.owner ? getTitleForVisits(bar.owner.visits||0) : null;
                const tColor = title?.color || "#2a2a3a";
                const isAnim = claimAnim === bar.id;
                const isSel  = selBar === bar.id;
                const sz = 18;

                // Hex points
                const hex = Array.from({length:6},(_,i)=>{
                  const angle = (Math.PI/3)*i - Math.PI/6;
                  return `${x+sz*Math.cos(angle)},${y+sz*Math.sin(angle)}`;
                }).join(" ");

                return (
                  <g key={bar.id} onClick={()=>setSelBar(selBar===bar.id?null:bar.id)} style={{cursor:"pointer"}}>
                    {/* Glow ring */}
                    {owned && <polygon points={hex} fill="none" stroke={tColor} strokeWidth={isSel?3:1.5} strokeOpacity={isSel?1:.5}/>}
                    {!owned && <polygon points={hex} fill="#0a0c14" stroke="#2a2a3a" strokeWidth="1" strokeDasharray="3 3"/>}

                    {/* Fill */}
                    <polygon points={hex} fill={owned?`${tColor}18`:"transparent"}/>

                    {/* Claim animation */}
                    {isAnim && <polygon points={hex} fill={tColor} fillOpacity=".4"><animate attributeName="fill-opacity" values=".4;0" dur="1s" fill="freeze"/></polygon>}

                    {/* Bar emoji */}
                    <text x={x} y={y+(owned?-2:4)} textAnchor="middle" fontSize={owned?13:14} dominantBaseline="middle" style={{userSelect:"none"}}>{owned&&mine?"🏴":(owned?bar.owner?.av||"🍺":bar.e)}</text>

                    {/* Title badge for owned bars */}
                    {owned && title && (
                      <text x={x} y={y+10} textAnchor="middle" fontSize="8" fill={tColor} fontFamily="monospace" style={{userSelect:"none"}}>{title.icon}</text>
                    )}

                    {/* Bar name below */}
                    <text x={x} y={y+sz+8} textAnchor="middle" fontSize="6" fill={owned?tColor:"#2a2a3a"} fontFamily="monospace" style={{userSelect:"none"}} fontWeight={mine?"bold":"normal"}>
                      {bar.n.split(" ").slice(-1)[0].slice(0,8).toUpperCase()}
                    </text>
                  </g>
                );
              })}

              {/* Legend */}
              <g transform="translate(8,8)">
                {TERRITORY_TITLES.slice(0,3).map((t,i)=>(
                  <g key={t.id} transform={`translate(0,${i*14})`}>
                    <rect width="10" height="10" rx="2" fill={`${t.color}30`} stroke={t.color} strokeWidth="1"/>
                    <text x="14" y="8" fontSize="7" fill={t.color} fontFamily="monospace" style={{userSelect:"none"}}>{t.icon} {t.label}</text>
                  </g>
                ))}
              </g>

              {/* Unclaimed badge */}
              <g transform={`translate(${W-60},8)`}>
                <polygon points="0,6 5,0 10,6 8,13 2,13" fill="none" stroke="#2a2a3a" strokeWidth="1" strokeDasharray="2 2"/>
                <text x="14" y="8" fontSize="7" fill="#555" fontFamily="monospace" style={{userSelect:"none"}}>Unclaimed</text>
              </g>
            </svg>

            {/* Bar detail panel */}
            {selData && (
              <div style={{position:"absolute",bottom:8,left:8,right:8,background:"#0d0e1a",border:`2px solid ${selData.owner?getTitleForVisits(selData.owner.visits||0).color:"#2a2a3a"}`,borderRadius:12,padding:12,animation:"slideUp .2s ease"}}>
                <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
                  <span style={{fontSize:24}}>{selData.e}</span>
                  <div style={{flex:1}}>
                    <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:"#f0f0f8"}}>{selData.n}</div>
                    {selData.owner?(
                      <div style={{fontSize:10,color:getTitleForVisits(selData.owner.visits||0).color,marginTop:2}}>
                        {getTitleForVisits(selData.owner.visits||0).icon} {selData.owner.av} {selData.owner.name} · {selData.owner.title}
                      </div>
                    ):(
                      <div style={{fontSize:10,color:"#555",marginTop:2}}>Unclaimed — be the first!</div>
                    )}
                  </div>
                  <button onClick={()=>setSelBar(null)} style={{background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:16}}>✕</button>
                </div>

                {/* Title progress */}
                {selData.owner && (()=>{
                  const currentT = getTitleForVisits(selData.owner.visits||0);
                  const nextT    = TERRITORY_TITLES[TERRITORY_TITLES.indexOf(currentT)+1];
                  return nextT ? (
                    <div style={{marginBottom:8}}>
                      <div style={{display:"flex",justifyContent:"space-between",fontSize:9,color:"#555",marginBottom:3}}>
                        <span>{currentT.icon} {currentT.label}</span><span>{nextT.icon} {nextT.label} in {nextT.minVisits-(selData.owner.visits||0)} visits</span>
                      </div>
                      <div style={{height:4,background:"#1a1d2e",borderRadius:2,overflow:"hidden"}}>
                        <div style={{height:"100%",width:`${Math.min(100,((selData.owner.visits||0)/nextT.minVisits)*100)}%`,background:currentT.color,borderRadius:2}}/>
                      </div>
                    </div>
                  ) : null;
                })()}

                {/* Action buttons */}
                <div style={{display:"flex",gap:8}}>
                  {!selData.owner && myId && (
                    <button onClick={()=>handleClaim(selData)} style={{flex:1,padding:"10px 0",border:"none",borderRadius:10,background:"linear-gradient(135deg,#34C759,#00C7BE)",color:"#000",fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:1,cursor:"pointer"}}>
                      🏴 CLAIM THIS BAR
                    </button>
                  )}
                  {selData.owner?.id===myId && (
                    <div style={{flex:1,padding:"10px 0",border:"1px solid #34C75940",borderRadius:10,background:"#34C75910",color:"#34C759",fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,textAlign:"center"}}>
                      ✅ YOUR TERRITORY
                    </div>
                  )}
                  {selData.owner && selData.owner.id!==myId && myId && (
                    <button onClick={()=>handleRaid(selData)} style={{flex:1,padding:"10px 0",border:"none",borderRadius:10,background:"linear-gradient(135deg,#FF2D55,#FF6B35)",color:"#fff",fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:1,cursor:"pointer"}}>
                      ⚔️ RAID THIS BAR
                    </button>
                  )}
                  {!myId && (
                    <div style={{flex:1,textAlign:"center",fontSize:11,color:"#555",padding:8}}>Join a game to claim bars</div>
                  )}
                </div>
                {selData.owner && selData.owner.id!==myId && (
                  <div style={{fontSize:9,color:"#555",marginTop:6,textAlign:"center"}}>Raiding replaces the current owner · needs GPS check at door in prod</div>
                )}
              </div>
            )}
          </div>

          {/* Coin earning explainer */}
          <div style={{...S.card,background:"#0a0c14",border:"1px solid #FFCC0020",display:"flex",flexDirection:"column",gap:6}}>
            <div style={{fontSize:9,color:"#FFCC00",letterSpacing:3}}>💰 HOW EARNINGS WORK</div>
            <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
              {TERRITORY_TITLES.map(t=>(
                <div key={t.id} style={{display:"flex",alignItems:"center",gap:5,padding:"4px 10px",borderRadius:20,background:`${t.color}12`,border:`1px solid ${t.color}30`}}>
                  <span style={{fontSize:12}}>{t.icon}</span>
                  <span style={{fontSize:9,color:t.color,fontFamily:"'Black Han Sans',sans-serif"}}>{t.label}</span>
                  <span style={{fontSize:9,color:"#555"}}>+{t.coinRate}/hr</span>
                </div>
              ))}
            </div>
            <div style={{fontSize:9,color:"#444",lineHeight:1.6}}>
              Coins earn passively every hour per bar you own. Use them in the shop during live crawls. Raid enemy bars to steal their title and their earnings.
            </div>
          </div>
        </>
      )}

      {/* ── LEADERBOARD VIEW ── */}
      {view==="leaderboard"&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          <div style={{fontSize:9,color:"#555",letterSpacing:3}}>GLOBAL TERRITORY LEADERBOARD</div>
          {leaderboard.map((p,i)=>{
            const isMe = p.id===myId;
            return(
              <div key={p.id} style={{...S.card,display:"flex",alignItems:"center",gap:10,border:`1px solid ${isMe?"#FFCC00":"#1a1d2e"}`,background:isMe?"#FFCC0010":"#0d0e1a"}}>
                <div style={{fontSize:20,width:28,textAlign:"center"}}>{["🥇","🥈","🥉"][i]||`#${i+1}`}</div>
                <span style={{fontSize:22}}>{p.av}</span>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:isMe?"#FFCC00":"#f0f0f8"}}>{p.name}{isMe&&<span style={{fontSize:9,color:"#FFCC00",marginLeft:5}}>YOU</span>}</div>
                  <div style={{fontSize:10,color:"#555",marginTop:2,display:"flex",gap:8}}>
                    <span>🏴 {p.bars} bar{p.bars!==1?"s":""}</span>
                    <span style={{color:p.topTitle.color}}>{p.topTitle.icon} {p.topTitle.label}</span>
                  </div>
                </div>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:p.topTitle.color}}>{p.topTitle.icon}</div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── MY TURF VIEW ── */}
      {view==="myturf"&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {myBars.length===0?(
            <div style={{...S.card,textAlign:"center",padding:"28px 16px"}}>
              <div style={{fontSize:36,marginBottom:8}}>🏴</div>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1,color:"#f0f0f8",marginBottom:6}}>NO BARS CLAIMED YET</div>
              <div style={{fontSize:11,color:"#555",lineHeight:1.7}}>Go to the Map tab and claim your first bar. Visit bars during crawl nights to build your title.</div>
            </div>
          ):(
            <>
              <div style={{...S.card,background:"#FFCC0010",border:"1px solid #FFCC0030",textAlign:"center"}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:32,color:"#FFCC00"}}>🪙{myStats.coins}</div>
                <div style={{fontSize:10,color:"#555",marginTop:3}}>Lifetime coins earned</div>
                <div style={{fontSize:11,color:"#34C759",marginTop:6}}>+{myBars.reduce((s,b)=>{const t=getTitleForVisits(b.owner?.visits||0);return s+(t.coinRate||1);},0)} coins/hr from {myBars.length} bar{myBars.length!==1?"s":""}</div>
              </div>
              {myBars.map(bar=>{
                const title = getTitleForVisits(bar.owner?.visits||0);
                const nextT = TERRITORY_TITLES[TERRITORY_TITLES.indexOf(title)+1];
                return(
                  <div key={bar.id} style={{...S.card,border:`1px solid ${title.color}30`}}>
                    <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
                      <span style={{fontSize:22}}>{bar.e}</span>
                      <div style={{flex:1}}>
                        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13}}>{bar.n}</div>
                        <div style={{fontSize:10,color:title.color,marginTop:2}}>{title.icon} {title.label} · {bar.owner?.visits||0} visits</div>
                      </div>
                      <div style={{textAlign:"right"}}>
                        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:"#FFCC00"}}>+{title.coinRate}/hr</div>
                      </div>
                    </div>
                    {nextT&&(
                      <div>
                        <div style={{display:"flex",justifyContent:"space-between",fontSize:9,color:"#555",marginBottom:3}}>
                          <span>Next: {nextT.icon} {nextT.label}</span>
                          <span>{nextT.minVisits-(bar.owner?.visits||0)} more visits</span>
                        </div>
                        <div style={{height:4,background:"#1a1d2e",borderRadius:2,overflow:"hidden"}}>
                          <div style={{height:"100%",width:`${Math.min(100,((bar.owner?.visits||0)/nextT.minVisits)*100)}%`,background:title.color,borderRadius:2,transition:"width .6s"}}/>
                        </div>
                      </div>
                    )}
                    {!nextT&&<div style={{fontSize:9,color:title.color,textAlign:"center",padding:4}}>👑 MAX RANK ACHIEVED</div>}
                  </div>
                );
              })}
            </>
          )}
        </div>
      )}
    </div>
  );
}


// RULES SCREEN
// ═══════════════════════════════════════════════════════════════════════════════
function RulesScreen({onBack}){
  const [cat,setCat]=useState("ALL");
  const cats=["ALL","SAFETY","CONDUCT","FAIR PLAY"];
  const filtered=cat==="ALL"?CONDUCT_RULES:CONDUCT_RULES.filter(r=>r.category===cat);
  const sc=s=>s.includes("INSTANT")?"#FF2D55":s.includes("BAN")?"#FF2D55":"#FF9500";
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:44,marginBottom:6}}>📋</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:26,letterSpacing:3,color:"#f0f0f8"}}>RULES OF PLAY</div>
        <div style={{fontSize:11,color:"#555",marginTop:4,lineHeight:1.7}}>CrawlFire is played in real bars with real people.<br/>Everyone's safety and enjoyment depends on fair play.</div>
      </div>
      <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
        {cats.map(c=><button key={c} onClick={()=>setCat(c)} style={{padding:"6px 14px",borderRadius:20,border:`1px solid ${cat===c?"#FF2D55":"#2a2a3a"}`,background:cat===c?"#FF2D5515":"#0d0e1a",color:cat===c?"#FF2D55":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:11,letterSpacing:1,cursor:"pointer"}}>{c}</button>)}
      </div>
      {filtered.map(rule=>(
        <div key={rule.id} style={{...S.card,border:`1px solid ${rule.color}30`,display:"flex",flexDirection:"column",gap:10}}>
          <div style={{display:"flex",alignItems:"flex-start",gap:10}}>
            <div style={{fontSize:24,flexShrink:0,filter:`drop-shadow(0 0 6px ${rule.color}60)`}}>{rule.icon}</div>
            <div style={{flex:1}}>
              <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:4,flexWrap:"wrap"}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:1,color:"#f0f0f8"}}>{rule.title}</div>
                <span style={{fontSize:8,letterSpacing:1.5,padding:"2px 8px",borderRadius:20,background:`${sc(rule.severity)}18`,border:`1px solid ${sc(rule.severity)}40`,color:sc(rule.severity),fontFamily:"'Space Mono',monospace",whiteSpace:"nowrap"}}>{rule.severity}</span>
              </div>
              <div style={{fontSize:11,color:"#888",lineHeight:1.7}}>{rule.body}</div>
            </div>
          </div>
          <div style={{display:"flex",alignItems:"center",gap:6,padding:"5px 10px",background:`${rule.color}08`,borderRadius:8,border:`1px solid ${rule.color}20`}}>
            <span style={{fontSize:10,color:rule.color,letterSpacing:1,fontFamily:"'Space Mono',monospace"}}>{rule.category}</span>
            <div style={{flex:1,height:1,background:`${rule.color}20`}}/>
            <span style={{fontSize:9,color:"#444"}}>Rule {rule.id.toUpperCase()}</span>
          </div>
        </div>
      ))}
      <div style={{...S.card,background:"#0a1a0a",border:"1px solid #34C75930",textAlign:"center",padding:"18px 16px"}}>
        <div style={{fontSize:20,marginBottom:8}}>✅</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:2,color:"#34C759",marginBottom:6}}>BY PLAYING YOU AGREE</div>
        <div style={{fontSize:11,color:"#555",lineHeight:1.8}}>Joining a CrawlFire game means you accept these rules.<br/>Bartenders have authority to issue warnings and disqualify players.<br/>Bar staff decisions are final and binding.</div>
      </div>
      <button style={S.btnGhost} onClick={onBack}>← BACK TO GAME</button>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// DQ CONFIRM MODAL
// ═══════════════════════════════════════════════════════════════════════════════
function DQConfirmModal({player,onConfirm,onCancel}){
  const [reason,setReason]=useState(null);
  const [notes,setNotes]=useState("");
  const [step,setStep]=useState(1);
  const sev=reason?.severity;
  const btnC=sev==="instant"?"linear-gradient(135deg,#FF2D55,#FF6B35)":"linear-gradient(135deg,#FF9500,#FFCC00)";
  const btnTxt=sev==="instant"?"#fff":"#000";
  return(
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.9)",display:"flex",alignItems:"flex-end",justifyContent:"center",zIndex:500}}>
      <div style={{background:"#0d0e1a",border:`2px solid ${sev==="instant"?"#FF2D55":"#FF9500"}`,borderTopLeftRadius:20,borderTopRightRadius:20,padding:"24px 20px 44px",width:"100%",maxWidth:440,display:"flex",flexDirection:"column",gap:14,animation:"slideUp .3s ease"}}>
        {step===1&&(<>
          <div style={{display:"flex",alignItems:"center",gap:12,padding:"12px 14px",background:"#FF2D5510",border:"1px solid #FF2D5530",borderRadius:12}}>
            <span style={{fontSize:30}}>{player.avatar}</span>
            <div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,color:"#FF2D55"}}>DISQUALIFY</div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1,color:"#f0f0f8"}}>{player.name}</div></div>
          </div>
          <div style={{fontSize:10,color:"#555",letterSpacing:2}}>SELECT REASON</div>
          <div style={{display:"flex",flexDirection:"column",gap:6,maxHeight:280,overflowY:"auto"}}>
            {DQ_REASONS.map(r=>(
              <button key={r.id} onClick={()=>setReason(r)} style={{display:"flex",alignItems:"center",gap:10,padding:"11px 14px",border:`2px solid ${reason?.id===r.id?(r.severity==="instant"?"#FF2D55":"#FF9500"):"#2a2a3a"}`,borderRadius:11,background:reason?.id===r.id?(r.severity==="instant"?"#FF2D5510":"#FF950010"):"#12121a",cursor:"pointer",textAlign:"left"}}>
                <span style={{fontSize:20,flexShrink:0}}>{r.icon}</span>
                <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:reason?.id===r.id?(r.severity==="instant"?"#FF2D55":"#FF9500"):"#f0f0f8"}}>{r.label}</div></div>
                <span style={{fontSize:8,letterSpacing:1,padding:"2px 8px",borderRadius:20,background:r.severity==="instant"?"#FF2D5520":"#FF950020",border:`1px solid ${r.severity==="instant"?"#FF2D5540":"#FF950040"}`,color:r.severity==="instant"?"#FF2D55":"#FF9500",whiteSpace:"nowrap",fontFamily:"'Space Mono',monospace"}}>{r.severity==="instant"?"INSTANT DQ":"WARNING"}</span>
              </button>
            ))}
          </div>
          <div style={{display:"flex",gap:8}}>
            <button onClick={onCancel} style={{...S.btnGhost,flex:1,padding:12}}>CANCEL</button>
            <button onClick={()=>setStep(2)} disabled={!reason} style={{flex:2,padding:12,border:"none",borderRadius:12,background:reason?(sev==="instant"?"linear-gradient(135deg,#FF2D55,#FF6B35)":"linear-gradient(135deg,#FF9500,#FFCC00)"):"#2a2a3a",color:reason?(sev==="instant"?"#fff":"#000"):"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2,cursor:reason?"pointer":"not-allowed"}}>NEXT →</button>
          </div>
        </>)}
        {step===2&&(<>
          <div style={{textAlign:"center"}}>
            <div style={{fontSize:48,marginBottom:8,animation:"breathe 1.5s ease-in-out infinite"}}>{sev==="instant"?"🚫":"⚠️"}</div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,letterSpacing:3,color:sev==="instant"?"#FF2D55":"#FF9500"}}>{sev==="instant"?"CONFIRM DQ":"ISSUE WARNING"}</div>
            <div style={{fontSize:13,color:"#888",marginTop:4}}>{player.avatar} {player.name}</div>
            <div style={{fontSize:11,marginTop:6,background:sev==="instant"?"#FF2D5515":"#FF950015",border:`1px solid ${sev==="instant"?"#FF2D5540":"#FF950040"}`,borderRadius:8,padding:"6px 12px",color:sev==="instant"?"#FF2D55":"#FF9500"}}>{reason?.icon} {reason?.label}</div>
          </div>
          <div>
            <div style={{fontSize:10,color:"#555",letterSpacing:2,marginBottom:6}}>NOTES (optional)</div>
            <textarea value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Describe what happened..." maxLength={200} style={{width:"100%",background:"#12121a",border:"1px solid #2a2a3a",borderRadius:10,color:"#f0f0f8",fontFamily:"'Space Mono',monospace",fontSize:11,padding:"10px 12px",outline:"none",resize:"none",height:70,lineHeight:1.6}}/>
          </div>
          {sev==="instant"&&<div style={{...S.card,background:"#FF2D5510",border:"1px solid #FF2D5540",fontSize:11,color:"#FF2D55",lineHeight:1.7}}>⚠️ This will immediately remove {player.name} from the active game. Their game entry is forfeited. This action is logged.</div>}
          {sev==="warn"&&<div style={{...S.card,background:"#FF950010",border:"1px solid #FF950040",fontSize:11,color:"#FF9500",lineHeight:1.7}}>A formal warning will be logged. A second warning from any bartender is an automatic DQ.</div>}
          <div style={{display:"flex",gap:8}}>
            <button onClick={()=>setStep(1)} style={{...S.btnGhost,flex:1,padding:12}}>← BACK</button>
            <button onClick={()=>onConfirm({player,reason,notes,ts:Date.now()})} style={{flex:2,padding:13,border:"none",borderRadius:12,background:btnC,color:btnTxt,fontFamily:"'Black Han Sans',sans-serif",fontSize:17,letterSpacing:2,cursor:"pointer",boxShadow:`0 4px 16px ${sev==="instant"?"#FF2D5540":"#FF950040"}`}}>
              {sev==="instant"?"🚫 CONFIRM DQ":"⚠️ ISSUE WARNING"}
            </button>
          </div>
        </>)}
      </div>
    </div>
  );
}


// ═══════════════════════════════════════════════════════════════════════════════
// BARTENDER HANDSHAKE SYSTEM
// ─────────────────────────────────────────────────────────────────────────────
// Bartender taps one button → a QR appears on their screen for 30 seconds.
// Player points their camera at it → item is claimed instantly, no typing needed.
// QR encodes a signed payload: {code, itemId, barId, expiresAt, sig}
// ═══════════════════════════════════════════════════════════════════════════════

const HANDSHAKE_EXPIRY_SECS = 30;

function makeHandshakePayload(code, item, barName) {
  const expiresAt = Date.now() + HANDSHAKE_EXPIRY_SECS * 1000;
  // Simple sig = first 8 chars of base36 hash — enough for demo integrity
  const raw = `${code}|${item.id}|${expiresAt}`;
  let h = 0;
  for (let i = 0; i < raw.length; i++) { h = ((h << 5) - h) + raw.charCodeAt(i); h |= 0; }
  const sig = Math.abs(h).toString(36).slice(0, 8).toUpperCase();
  return { code, itemId: item.id, itemEmoji: item.e, itemName: item.n, rarity: item.rarity, barName, expiresAt, sig, raw: `CF:${code}:${sig}` };
}

function verifyHandshakePayload(raw) {
  try {
    const parts = raw.split(":");
    if (parts[0] !== "CF" || parts.length < 3) return null;
    return { code: parts[1], sig: parts[2] };
  } catch { return null; }
}

// ── Bartender side: displays the QR for player to scan ───────────────────────
function HandshakeDisplay({ item, barName, onExpired, onClose }) {
  const [payload]       = useState(() => makeHandshakePayload(uid() + uid().slice(0,2), item, barName));
  const [secsLeft,      setSecsLeft]      = useState(HANDSHAKE_EXPIRY_SECS);
  const [qrDataUrl,     setQrDataUrl]     = useState("");
  const [claimed,       setClaimed]       = useState(false);
  const claimedRef      = useRef(false);

  // Generate QR from payload
  useEffect(() => {
    const qr = genQR(payload.raw, 220);
    setQrDataUrl(qr);
  }, [payload.raw]);

  // Countdown
  useEffect(() => {
    const id = setInterval(() => {
      setSecsLeft(s => {
        if (s <= 1) {
          clearInterval(id);
          if (!claimedRef.current) onExpired();
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [onExpired]);

  // Poll for claim (simulated — in prod: Firebase listener on the code key)
  useEffect(() => {
    const id = setInterval(async () => {
      try {
        const stored = await window.storage.get(`hs:${payload.code}`, true);
        if (stored) {
          const data = JSON.parse(stored.value);
          if (data.claimed && !claimedRef.current) {
            claimedRef.current = true;
            setClaimed(true);
            setTimeout(onClose, 2500);
          }
        }
      } catch {}
    }, 500);
    return () => clearInterval(id);
  }, [payload.code, onClose]);

  const pct = secsLeft / HANDSHAKE_EXPIRY_SECS;
  const ringColor = pct > 0.5 ? "#34C759" : pct > 0.25 ? "#FF9500" : "#FF2D55";
  const circumference = 2 * Math.PI * 52;

  if (claimed) return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.92)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:600}}>
      <div style={{textAlign:"center",animation:"popIn .4s ease"}}>
        <div style={{fontSize:72,marginBottom:12,filter:"drop-shadow(0 0 24px #34C759)"}}>✅</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:28,letterSpacing:3,color:"#34C759"}}>CLAIMED!</div>
        <div style={{fontSize:14,color:"#888",marginTop:8}}>{item.e} {item.n} delivered to player</div>
      </div>
    </div>
  );

  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.95)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",zIndex:600,padding:20}}>
      <button onClick={onClose} style={{position:"absolute",top:20,right:20,...S.btnGhost}}>✕ CLOSE</button>

      {/* Item badge */}
      <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:20,background:`${RARITY_C[item.rarity]}15`,border:`1px solid ${RARITY_C[item.rarity]}40`,borderRadius:12,padding:"8px 16px"}}>
        <span style={{fontSize:24}}>{item.e}</span>
        <div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1,color:RARITY_C[item.rarity]}}>{item.n}</div>
          <div style={{fontSize:9,color:RARITY_C[item.rarity],letterSpacing:2,textTransform:"uppercase"}}>{item.rarity}</div>
        </div>
      </div>

      {/* QR + countdown ring */}
      <div style={{position:"relative",width:240,height:240,display:"flex",alignItems:"center",justifyContent:"center"}}>
        {/* Countdown SVG ring */}
        <svg style={{position:"absolute",inset:0,width:"100%",height:"100%",transform:"rotate(-90deg)"}} viewBox="0 0 120 120">
          <circle cx="60" cy="60" r="52" fill="none" stroke="#1a1d2e" strokeWidth="5"/>
          <circle cx="60" cy="60" r="52" fill="none" stroke={ringColor} strokeWidth="5"
            strokeDasharray={circumference}
            strokeDashoffset={circumference * (1 - pct)}
            strokeLinecap="round"
            style={{transition:"stroke-dashoffset .9s linear, stroke .5s"}}/>
        </svg>
        {/* QR image */}
        <div style={{background:"#fff",borderRadius:14,padding:10,zIndex:1,boxShadow:`0 0 30px ${ringColor}40`}}>
          {qrDataUrl && <img src={qrDataUrl} alt="Handshake QR" style={{width:160,height:160,imageRendering:"pixelated",display:"block"}}/>}
        </div>
      </div>

      {/* Timer */}
      <div style={{marginTop:16,display:"flex",flexDirection:"column",alignItems:"center",gap:4}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:44,color:ringColor,lineHeight:1,textShadow:`0 0 20px ${ringColor}60`}}>{secsLeft}</div>
        <div style={{fontSize:10,letterSpacing:3,color:"#555"}}>SECONDS TO SCAN</div>
      </div>

      {/* Instruction */}
      <div style={{marginTop:16,textAlign:"center",fontSize:12,color:"#666",lineHeight:1.7,maxWidth:260}}>
        Player points their camera here.<br/>
        Item claimed instantly — no typing needed.<br/>
        QR expires automatically after {HANDSHAKE_EXPIRY_SECS} seconds.
      </div>

      {/* Code as fallback */}
      <div style={{marginTop:12,background:"#0d0e1a",border:"1px solid #2a2a3a",borderRadius:10,padding:"8px 16px",display:"flex",flex:"column",alignItems:"center",gap:8}}>
        <div style={{fontSize:9,color:"#555",letterSpacing:2}}>FALLBACK CODE</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:"#FF9500",letterSpacing:4}}>{payload.code}</div>
      </div>
    </div>
  );
}

// ── Player side: scan result / claim UI (shown in LootEntry after camera scan) ─
function HandshakeClaim({ payload, onClaim, onDismiss }) {
  const item = LOOT_ITEMS.find(x => x.id === payload.itemId) || { e:"❓", n: payload.itemId, rarity:"common" };
  const expired = Date.now() > payload.expiresAt;
  const rc = RARITY_C[item.rarity] || "#888";

  return (
    <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.9)",display:"flex",alignItems:"flex-end",justifyContent:"center",zIndex:500}}>
      <div style={{background:"#0d0e1a",border:`2px solid ${expired?"#555":rc}`,borderTopLeftRadius:20,borderTopRightRadius:20,padding:"24px 20px 44px",width:"100%",maxWidth:440,display:"flex",flexDirection:"column",gap:14,animation:"slideUp .3s ease",textAlign:"center",boxShadow:`0 -20px 60px ${expired?"#00000060":rc+"40"}`}}>
        {expired ? (
          <>
            <div style={{fontSize:44}}>⏰</div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,letterSpacing:2,color:"#555"}}>QR EXPIRED</div>
            <div style={{fontSize:12,color:"#444",lineHeight:1.7}}>This loot code has expired. Ask the bartender to generate a new one.</div>
            <button onClick={onDismiss} style={S.btnGhost}>DISMISS</button>
          </>
        ) : (
          <>
            <div style={{fontSize:52,filter:`drop-shadow(0 0 16px ${rc})`,animation:"breathe 1.5s ease-in-out infinite"}}>{item.e}</div>
            <div>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:10,letterSpacing:4,color:rc,marginBottom:4}}>{item.rarity.toUpperCase()} · FROM {payload.barName?.toUpperCase()}</div>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:28,letterSpacing:2,color:"#f0f0f8"}}>{item.n}</div>
            </div>
            <div style={{background:`${rc}12`,border:`1px solid ${rc}30`,borderRadius:10,padding:"8px 14px",fontSize:11,color:"#888",lineHeight:1.6}}>
              🍺 Compliments of <strong style={{color:"#f0f0f8"}}>{payload.barName}</strong><br/>
              Tap below to add to your inventory
            </div>
            <button onClick={()=>onClaim(payload)} style={{...S.btnPrimary,background:`linear-gradient(135deg,${rc},${rc}aa)`,color:item.rarity==="common"||item.rarity==="uncommon"?"#000":"#fff",fontSize:18,letterSpacing:3}}>
              🎁 CLAIM {item.n.toUpperCase()}
            </button>
            <button onClick={onDismiss} style={{background:"none",border:"none",color:"#444",fontFamily:"'Space Mono',monospace",fontSize:11,cursor:"pointer",padding:6}}>Cancel</button>
          </>
        )}
      </div>
    </div>
  );
}


// ═══════════════════════════════════════════════════════════════════════════════
// BARTENDER CLASS SYSTEM
// ═══════════════════════════════════════════════════════════════════════════════

// ── Single class card (compact) ───────────────────────────────────────────────
function ClassCard({ cls, selected, onClick, compact }) {
  const isSelected = selected;
  return (
    <div onClick={onClick} style={{
      background: isSelected ? `${cls.color}15` : "#0d0e1a",
      border: `2px solid ${isSelected ? cls.color : "#1a1d2e"}`,
      borderRadius: 14, padding: compact ? "12px 14px" : "16px",
      cursor: onClick ? "pointer" : "default",
      transition: "all .15s",
      boxShadow: isSelected ? `0 0 20px ${cls.color}30` : "none",
      display: "flex", flexDirection: "column", gap: compact ? 6 : 10,
    }}>
      <div style={{display:"flex",alignItems:"center",gap:10}}>
        <div style={{fontSize:compact?28:36,filter:`drop-shadow(0 0 8px ${cls.color}80)`,flexShrink:0,animation:isSelected?"breathe 2s ease-in-out infinite":"none"}}>{cls.icon}</div>
        <div style={{flex:1}}>
          <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:compact?15:18,letterSpacing:2,color:cls.color}}>{cls.name}</div>
            {isSelected && <span style={{fontSize:8,padding:"2px 8px",borderRadius:10,background:`${cls.color}25`,border:`1px solid ${cls.color}50`,color:cls.color,letterSpacing:1,fontFamily:"'Space Mono',monospace"}}>ACTIVE</span>}
          </div>
          <div style={{fontSize:10,color:"#888",marginTop:2,fontStyle:"italic"}}>"{cls.tagline}"</div>
        </div>
      </div>
      {!compact && <div style={{fontSize:11,color:"#666",lineHeight:1.7}}>{cls.lore}</div>}
      {/* Stat badges */}
      <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
        {cls.lootBonus    && <span style={{fontSize:9,padding:"2px 8px",borderRadius:10,background:"#FFCC0015",border:"1px solid #FFCC0030",color:"#FFCC00"}}>🎁 {cls.lootBonus}</span>}
        {cls.damageBonus  && <span style={{fontSize:9,padding:"2px 8px",borderRadius:10,background:"#FF2D5515",border:"1px solid #FF2D5530",color:"#FF2D55"}}>⚔️ {cls.damageBonus}</span>}
        {cls.defenseBonus && <span style={{fontSize:9,padding:"2px 8px",borderRadius:10,background:"#34C75915",border:"1px solid #34C75930",color:"#34C759"}}>🛡️ {cls.defenseBonus}</span>}
        {cls.special      && <span style={{fontSize:9,padding:"2px 8px",borderRadius:10,background:`${cls.color}12`,border:`1px solid ${cls.color}30`,color:cls.color}}>✨ {cls.special}</span>}
      </div>
      {/* Abilities preview */}
      {!compact && (
        <div style={{display:"flex",flexDirection:"column",gap:5,marginTop:2}}>
          <div style={{fontSize:8,letterSpacing:3,color:"#555"}}>ABILITIES</div>
          {cls.abilities.map(ab=>(
            <div key={ab.id} style={{display:"flex",alignItems:"flex-start",gap:8,padding:"7px 10px",background:"#12121a",borderRadius:8,border:`1px solid ${cls.color}15`}}>
              <span style={{fontSize:18,flexShrink:0}}>{ab.icon}</span>
              <div style={{flex:1}}>
                <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
                  <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,letterSpacing:1,color:"#f0f0f8"}}>{ab.name}</span>
                  <span style={{fontSize:8,padding:"1px 6px",borderRadius:8,background:ab.type==="passive"?"#34C75920":"#FF950020",border:`1px solid ${ab.type==="passive"?"#34C75940":"#FF950040"}`,color:ab.type==="passive"?"#34C759":"#FF9500",letterSpacing:1}}>{ab.type.toUpperCase()}{ab.cd>0?` · ${ab.cd}s cd`:""}</span>
                </div>
                <div style={{fontSize:10,color:"#555",marginTop:2,lineHeight:1.5}}>{ab.desc}</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Class select screen (shown after login if no class chosen) ─────────────────
function ClassSelectScreen({ bartender, onSelect, onBack }) {
  const [sel, setSel]     = useState(bartender.classId || null);
  const [detail, setDetail] = useState(null);
  const chosen = sel ? BARTENDER_CLASSES[sel] : null;

  return (
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>

      <div style={{textAlign:"center",padding:"8px 0 4px"}}>
        <div style={{fontSize:11,color:"#555",letterSpacing:3}}>CHOOSE YOUR CLASS</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:24,letterSpacing:3,color:"#f0f0f8",marginTop:4}}>BARTENDER CLASS</div>
        <div style={{fontSize:11,color:"#666",marginTop:4,lineHeight:1.7}}>
          Your class gives you unique abilities that affect the game for your players.<br/>
          Switch at any time from your dashboard.
        </div>
      </div>

      {/* Class grid */}
      <div style={{display:"flex",flexDirection:"column",gap:8}}>
        {CLASS_IDS.map(cid=>{
          const cls=BARTENDER_CLASSES[cid];
          return(
            <div key={cid} style={{cursor:"pointer"}} onClick={()=>{setSel(cid);setDetail(cid);}}>
              <ClassCard cls={cls} selected={sel===cid} compact={detail!==cid}/>
              {detail===cid && sel===cid && (
                <div style={{background:`${cls.color}08`,border:`1px solid ${cls.color}30`,borderTop:"none",borderBottomLeftRadius:14,borderBottomRightRadius:14,padding:"12px 14px",display:"flex",flexDirection:"column",gap:8,marginTop:-2}}>
                  {cls.abilities.map(ab=>(
                    <div key={ab.id} style={{display:"flex",alignItems:"flex-start",gap:8,padding:"8px 10px",background:"#12121a",borderRadius:8}}>
                      <span style={{fontSize:20,flexShrink:0}}>{ab.icon}</span>
                      <div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,color:cls.color,letterSpacing:1}}>{ab.name}</div><div style={{fontSize:10,color:"#555",marginTop:2,lineHeight:1.5}}>{ab.desc}</div></div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {chosen && (
        <button style={{...S.btnPrimary,background:`linear-gradient(135deg,${chosen.color},${chosen.color}aa)`,color:chosen.color==="#FFCC00"||chosen.color==="#34C759"?"#000":"#fff",position:"sticky",bottom:12}} onClick={()=>onSelect(sel)}>
          {chosen.icon} PLAY AS {chosen.name} →
        </button>
      )}
    </div>
  );
}

// ── Ability use panel (inside BartenderDash) ──────────────────────────────────
function AbilityUsePanel({ bartender, cls, players, onAbilityUsed }) {
  const [cooldowns,  setCooldowns]  = useState({});
  const [activeAb,   setActiveAb]   = useState(null);
  const [targetSel,  setTargetSel]  = useState(null);
  const [result,     setResult]     = useState(null);

  const useAbility = (ability, targetId) => {
    if (cooldowns[ability.id]) return;
    // Apply cooldown
    if (ability.cd > 0) {
      setCooldowns(c => ({...c, [ability.id]: ability.cd}));
      const tick = setInterval(() => {
        setCooldowns(c => {
          const next = {...c, [ability.id]: (c[ability.id]||1) - 1};
          if (next[ability.id] <= 0) { clearInterval(tick); delete next[ability.id]; }
          return next;
        });
      }, 1000);
    }
    const target = players.find(p=>p.id===targetId);
    // Simulate ability effect
    const effects = {
      markertarget: `🎯 ${target?.name||"all"} marked — HP & location visible to your team for 3 min`,
      poisondose:   `🍵 Cursed loot code generated — next enemy to claim gets 15 dmg`,
      vanish:       `💨 This bar hidden from enemy map for 5 min`,
      taunt:        `😜 ${target?.name||"random enemy"}'s next scan will miss`,
      inspireally:  `⚡ ${target?.name||"player"} gets 2× damage on next shot`,
      rallycry:     `📣 +10 coins sent to all allied players`,
      fortify:      `🏰 CTF flag at this bar locked for 3 min — cannot be stolen`,
      warhorn:      `📯 WAR HORN sent — all allied players alerted to regroup here`,
      laststand:    `💪 ${target?.name||"player"} revived to 40 HP`,
      holylight:    `💛 All Med Kits now heal 40 HP`,
      resurrect:    `❤️ ${target?.name||"player"} fully resurrected with 50 HP + 50 coins`,
      sanctify:     `🌟 2-min Safe Zone active around this bar`,
      smite:        `⚡ 25 dmg dealt to ${target?.name||"target"}`,
      tracker:      `🐾 ${target?.name||"enemy"} location revealed to your team for 2 min`,
      ambush:       `🌿 Loot Trap placed — next enemy at this bar takes 20 dmg`,
      supplydrop:   `📦 Random shop item sent to all allied players at this bar`,
      hex:          `🔮 ${target?.name||"enemy"} hexed — -5 dmg on all weapons for 5 min`,
      portal:       `🌀 ${target?.name||"ally"}'s map position spoofed for 2 min`,
      soulpact:     `💀 30 coins sacrificed — ${target?.name||"player"} receives full inventory`,
      pickpocket:   `👋 20 coins stolen from ${target?.name||"enemy"} to your ally`,
      forgery:      `📋 Duplicate loot code generated for ${target?.name||"ally"}`,
      smokebomb:    `💨 ${target?.name||"ally"} invisible on enemy map for 90s`,
      growthspell:  `🌱 XP pool +$0.25 per future code — active`,
      naturelore:   `🍃 All allied players +25% coins for 10 min`,
      wildshape:    `🐺 Wild Flag active — any team can score +50 pts`,
      regenerate:   `💚 All allies regenerating +5 HP/30s for 3 min`,
    };
    const effect = effects[ability.id] || `${ability.icon} ${ability.name} activated!`;
    setResult({ability, effect, ts:Date.now()});
    setActiveAb(null); setTargetSel(null);
    onAbilityUsed && onAbilityUsed({abilityId:ability.id, effect, targetId, ts:Date.now()});
    setTimeout(()=>setResult(null), 4000);
  };

  const needsTarget = ab => ["markertarget","taunt","inspireally","laststand","resurrect","smite","tracker","hex","portal","soulpact","pickpocket","forgery","smokebomb"].includes(ab.id);

  return(
    <div style={{display:"flex",flexDirection:"column",gap:10}}>
      {/* Class header */}
      <div style={{...S.card,background:`${cls.color}10`,border:`2px solid ${cls.color}30`,display:"flex",alignItems:"center",gap:12}}>
        <div style={{fontSize:36,filter:`drop-shadow(0 0 10px ${cls.color})`,animation:"breathe 2.5s ease-in-out infinite"}}>{cls.icon}</div>
        <div style={{flex:1}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,color:cls.color}}>{cls.name}</div>
          <div style={{fontSize:10,color:"#888",marginTop:2,fontStyle:"italic"}}>"{cls.tagline}"</div>
        </div>
      </div>

      {/* Result flash */}
      {result&&(
        <div style={{...S.card,background:`${cls.color}15`,border:`2px solid ${cls.color}`,animation:"popIn .4s ease",textAlign:"center"}}>
          <div style={{fontSize:22,marginBottom:6}}>{result.ability.icon}</div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:2,color:cls.color}}>{result.ability.name.toUpperCase()} ACTIVATED</div>
          <div style={{fontSize:11,color:"#888",marginTop:5,lineHeight:1.6}}>{result.effect}</div>
        </div>
      )}

      {/* Abilities list */}
      <div style={{fontSize:9,color:"#555",letterSpacing:3}}>CLASS ABILITIES</div>
      {cls.abilities.map(ab=>{
        const cd       = cooldowns[ab.id]||0;
        const onCd     = cd>0;
        const isActive = activeAb===ab.id;
        const pct      = onCd ? (cd/ab.cd)*100 : 0;
        return(
          <div key={ab.id} style={{...S.card,border:`1px solid ${isActive?cls.color:onCd?"#1a1d2e":"#2a2a3a"}`,background:isActive?`${cls.color}10`:onCd?"#0a0a0a":"#0d0e1a",transition:"all .2s"}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:isActive?10:0}}>
              <div style={{fontSize:24,filter:onCd?"grayscale(1)":"none",flexShrink:0}}>{ab.icon}</div>
              <div style={{flex:1}}>
                <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap"}}>
                  <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,color:onCd?"#555":"#f0f0f8"}}>{ab.name}</span>
                  <span style={{fontSize:8,padding:"1px 7px",borderRadius:8,background:ab.type==="passive"?"#34C75920":"#FF950020",border:`1px solid ${ab.type==="passive"?"#34C75940":"#FF950040"}`,color:ab.type==="passive"?"#34C759":"#FF9500",letterSpacing:1}}>
                    {ab.type==="passive"?"PASSIVE":"ACTIVE"}{ab.cd>0?` · ${ab.cd}s`:""}
                  </span>
                </div>
                <div style={{fontSize:10,color:"#555",marginTop:2,lineHeight:1.4}}>{ab.desc.slice(0,60)}...</div>
              </div>
              {ab.type==="active"&&(
                <button onClick={()=>onCd?null:setActiveAb(isActive?null:ab.id)} disabled={onCd} style={{
                  padding:"8px 14px",border:"none",borderRadius:10,cursor:onCd?"not-allowed":"pointer",
                  background:onCd?"#1a1d2e":isActive?cls.color:`${cls.color}25`,
                  color:onCd?"#333":isActive?"#fff":cls.color,
                  fontFamily:"'Black Han Sans',sans-serif",fontSize:11,letterSpacing:1,
                  flexShrink:0,transition:"all .15s",
                }}>
                  {onCd?`${cd}s`:"USE"}
                </button>
              )}
            </div>

            {/* Cooldown bar */}
            {onCd&&ab.cd>0&&(
              <div style={{height:3,background:"#1a1d2e",borderRadius:2,overflow:"hidden",marginTop:6}}>
                <div style={{height:"100%",width:`${pct}%`,background:`${cls.color}80`,borderRadius:2,transition:"width 1s linear"}}/>
              </div>
            )}

            {/* Target selector (expanded) */}
            {isActive&&!onCd&&(
              <div style={{display:"flex",flexDirection:"column",gap:6,animation:"slideUp .2s ease"}}>
                <div style={{fontSize:9,color:"#555",letterSpacing:2}}>{needsTarget(ab)?"SELECT TARGET":"CONFIRM USE"}</div>
                {needsTarget(ab)&&players.length>0&&(
                  <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
                    {players.map(p=>(
                      <button key={p.id} onClick={()=>setTargetSel(p.id===targetSel?null:p.id)} style={{padding:"5px 10px",borderRadius:20,border:`1px solid ${targetSel===p.id?cls.color:"#2a2a3a"}`,background:targetSel===p.id?`${cls.color}20`:"#12121a",color:targetSel===p.id?cls.color:"#888",fontFamily:"'Space Mono',monospace",fontSize:9,cursor:"pointer"}}>
                        {p.avatar} {p.name}
                      </button>
                    ))}
                  </div>
                )}
                <button onClick={()=>useAbility(ab,targetSel||players[0]?.id)}
                  disabled={needsTarget(ab)&&!targetSel&&players.length>0}
                  style={{...S.btnPrimary,background:`linear-gradient(135deg,${cls.color},${cls.color}aa)`,color:cls.color==="#FFCC00"||cls.color==="#34C759"?"#000":"#fff",padding:"11px 0",fontSize:14,opacity:needsTarget(ab)&&!targetSel&&players.length>0?.4:1}}>
                  {ab.icon} ACTIVATE {ab.name.toUpperCase()}
                </button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}


// ═══════════════════════════════════════════════════════════════════════════════
// SIGN-UP SYSTEM — Bartender · Musician · Bar Partner
// ─────────────────────────────────────────────────────────────────────────────
// All three roles have a dedicated sign-up flow. New accounts are written to
// window.storage so they persist across sessions. In production, swap the
// storage calls for Firebase Auth + Firestore writes.
//
// STORAGE KEYS:
//   cf:signups:bartenders  — array of bartender accounts
//   cf:signups:musicians   — array of musician accounts
//   cf:signups:barpartners — array of bar partner accounts
// ═══════════════════════════════════════════════════════════════════════════════

// ── Signup storage helpers ────────────────────────────────────────────────────
async function loadSignups(type) {
  try {
    const r = await window.storage.get(`cf:signups:${type}`, false);
    return r ? JSON.parse(r.value) : [];
  } catch { return []; }
}
async function saveSignup(type, account) {
  try {
    const existing = await loadSignups(type);
    // Prevent duplicate usernames
    if (existing.find(a => a.username === account.username)) return { error: "Username already taken" };
    await window.storage.set(`cf:signups:${type}`, JSON.stringify([...existing, account]), false);
    return { ok: true };
  } catch(e) { return { error: e.message }; }
}
async function findSignup(type, username, password) {
  const list = await loadSignups(type);
  return list.find(a => a.username.toLowerCase() === username.toLowerCase() && a.password === password) || null;
}

// ── Field components ──────────────────────────────────────────────────────────
function SignupField({ label, value, onChange, placeholder, type="text", maxLength=50, hint="" }) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{display:"flex",flexDirection:"column",gap:4}}>
      <label style={{fontSize:9,color:"#555",letterSpacing:2,fontFamily:"'Black Han Sans',sans-serif"}}>{label}</label>
      <input
        type={type} value={value} maxLength={maxLength}
        placeholder={placeholder}
        onChange={e => onChange(e.target.value)}
        onFocus={()=>setFocused(true)} onBlur={()=>setFocused(false)}
        style={{
          background:"#0d0e1a",
          border:`1.5px solid ${focused?"#FF2D55":"#2a2a3a"}`,
          borderRadius:10, color:"#f0f0f8",
          fontFamily:"'Space Mono',monospace", fontSize:13,
          padding:"11px 14px", outline:"none",
          transition:"border-color .15s",
        }}/>
      {hint&&<div style={{fontSize:9,color:"#444",lineHeight:1.5}}>{hint}</div>}
    </div>
  );
}

function SignupSelect({ label, value, onChange, options }) {
  return (
    <div style={{display:"flex",flexDirection:"column",gap:4}}>
      <label style={{fontSize:9,color:"#555",letterSpacing:2,fontFamily:"'Black Han Sans',sans-serif"}}>{label}</label>
      <select value={value} onChange={e=>onChange(e.target.value)}
        style={{background:"#0d0e1a",border:"1.5px solid #2a2a3a",borderRadius:10,color:"#f0f0f8",fontFamily:"'Space Mono',monospace",fontSize:13,padding:"11px 14px",outline:"none",cursor:"pointer"}}>
        {options.map(([val,lab])=><option key={val} value={val}>{lab}</option>)}
      </select>
    </div>
  );
}

// ── Step progress indicator ───────────────────────────────────────────────────
function SignupSteps({ steps, current, color="#FF2D55" }) {
  return (
    <div style={{display:"flex",alignItems:"center",gap:0,marginBottom:4}}>
      {steps.map((label,i)=>{
        const done=current>i, active=current===i;
        return(
          <div key={label} style={{display:"flex",alignItems:"center",flex:i<steps.length-1?1:"auto"}}>
            <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:2}}>
              <div style={{width:24,height:24,borderRadius:"50%",
                background:done?color:active?`${color}30`:"#1a1d2e",
                border:`1.5px solid ${done||active?color:"#2a2a3a"}`,
                display:"flex",alignItems:"center",justifyContent:"center",
                fontSize:9,color:done?"#fff":active?color:"#555",
                fontFamily:"'Black Han Sans',sans-serif",
              }}>{done?"✓":i+1}</div>
              <span style={{fontSize:7,color:active?color:"#555",letterSpacing:.5,whiteSpace:"nowrap"}}>{label}</span>
            </div>
            {i<steps.length-1&&<div style={{flex:1,height:1,background:done?`${color}60`:"#1a1d2e",margin:"0 4px",marginBottom:14}}/>}
          </div>
        );
      })}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// BARTENDER SIGN-UP
// ═══════════════════════════════════════════════════════════════════════════════
function BartenderSignup({ onDone, onBack }) {
  const [step,     setStep]    = useState(0);
  const [form,     setForm]    = useState({
    username:"", password:"", confirmPassword:"",
    barName:"", barAddress:"", barCity:"", barPostcode:"",
    contactName:"", contactEmail:"", contactPhone:"",
    classId:"", agreeTerms:false,
  });
  const [errors,   setErrors]  = useState({});
  const [submitting,setSubmitting]=useState(false);
  const [done,     setDone]    = useState(false);

  const set = (k,v) => setForm(f=>({...f,[k]:v}));

  const STEPS = ["ACCOUNT","YOUR BAR","CONTACT","CLASS","CONFIRM"];

  const validate = (s) => {
    const e = {};
    if(s===0){
      if(!form.username.trim()||form.username.length<3) e.username="At least 3 characters";
      if(!form.password||form.password.length<6) e.password="At least 6 characters";
      if(form.password!==form.confirmPassword) e.confirmPassword="Passwords don't match";
    }
    if(s===1){
      if(!form.barName.trim()) e.barName="Bar name required";
      if(!form.barAddress.trim()) e.barAddress="Address required";
      if(!form.barCity.trim()) e.barCity="City required";
    }
    if(s===2){
      if(!form.contactName.trim()) e.contactName="Name required";
      if(!form.contactEmail.includes("@")) e.contactEmail="Valid email required";
    }
    if(s===3){
      if(!form.classId) e.classId="Pick a class";
    }
    if(s===4){
      if(!form.agreeTerms) e.agreeTerms="You must agree to the terms";
    }
    return e;
  };

  const next = () => {
    const e=validate(step);
    setErrors(e);
    if(Object.keys(e).length===0) setStep(s=>s+1);
  };

  const submit = async () => {
    const e=validate(4); setErrors(e);
    if(Object.keys(e).length>0) return;
    setSubmitting(true);
    const username = form.username.toLowerCase().trim();
    const account = {
      username, password:form.password,
      barName:form.barName.trim(), barAddress:form.barAddress.trim(),
      barCity:form.barCity.trim(), barPostcode:form.barPostcode.trim(),
      contactName:form.contactName.trim(), contactEmail:form.contactEmail.trim(),
      contactPhone:form.contactPhone.trim(),
      emoji:"🍺", tier:"bronze", earned:0, pending:0,
      crawls:0, codes:0, refs:0, streak:0,
      refCode:username.slice(0,6).toUpperCase()+(Math.floor(Math.random()*90)+10),
      classId:form.classId,
      joinedAt:Date.now(),
    };
    const result = await saveSignup("bartenders", account);
    if(result.error){ setErrors({submit:result.error}); setSubmitting(false); return; }
    setDone(true); setSubmitting(false);
    setTimeout(()=>onDone(account), 1800);
  };

  if(done) return(
    <div style={{...S.screen,alignItems:"center",justifyContent:"center",textAlign:"center",gap:16}}>
      <div style={{fontSize:72,animation:"breathe 1.5s ease-in-out infinite",filter:"drop-shadow(0 0 20px #34C759)"}}>🍺</div>
      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:26,letterSpacing:2,color:"#34C759"}}>YOU'RE IN!</div>
      <div style={{fontSize:12,color:"#555",lineHeight:1.8}}>Welcome to CrawlFire, {form.barName}!<br/>Your account is ready. Logging you in…</div>
    </div>
  );

  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={step===0?onBack:()=>setStep(s=>s-1)}>← BACK</button>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:36,marginBottom:4}}>🍺</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,letterSpacing:2,color:"#f0f0f8"}}>BARTENDER SIGN-UP</div>
        <div style={{fontSize:10,color:"#555",marginTop:2}}>Join the CrawlFire venue network</div>
      </div>

      <SignupSteps steps={STEPS} current={step} color="#FF9500"/>

      {/* ── Step 0: Account ── */}
      {step===0&&(<>
        <SignupField label="USERNAME" value={form.username} onChange={v=>set("username",v)} placeholder="yourbarname" maxLength={20} hint="Used to log in — no spaces"/>
        {errors.username&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.username}</div>}
        <SignupField label="PASSWORD" value={form.password} onChange={v=>set("password",v)} placeholder="••••••••" type="password"/>
        {errors.password&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.password}</div>}
        <SignupField label="CONFIRM PASSWORD" value={form.confirmPassword} onChange={v=>set("confirmPassword",v)} placeholder="••••••••" type="password"/>
        {errors.confirmPassword&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.confirmPassword}</div>}
      </>)}

      {/* ── Step 1: Bar details ── */}
      {step===1&&(<>
        <SignupField label="BAR NAME" value={form.barName} onChange={v=>set("barName",v)} placeholder="The Rusty Anchor"/>
        {errors.barName&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.barName}</div>}
        <SignupField label="ADDRESS" value={form.barAddress} onChange={v=>set("barAddress",v)} placeholder="123 High Street"/>
        {errors.barAddress&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.barAddress}</div>}
        <SignupField label="CITY" value={form.barCity} onChange={v=>set("barCity",v)} placeholder="London"/>
        {errors.barCity&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.barCity}</div>}
        <SignupField label="POSTCODE / ZIP" value={form.barPostcode} onChange={v=>set("barPostcode",v)} placeholder="EC1A 1BB" maxLength={10}/>
      </>)}

      {/* ── Step 2: Contact ── */}
      {step===2&&(<>
        <SignupField label="YOUR NAME" value={form.contactName} onChange={v=>set("contactName",v)} placeholder="Jane Smith"/>
        {errors.contactName&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.contactName}</div>}
        <SignupField label="EMAIL" value={form.contactEmail} onChange={v=>set("contactEmail",v)} placeholder="jane@thebar.co.uk" type="email"/>
        {errors.contactEmail&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.contactEmail}</div>}
        <SignupField label="PHONE (optional)" value={form.contactPhone} onChange={v=>set("contactPhone",v)} placeholder="+44 7700 900000" type="tel"/>
      </>)}

      {/* ── Step 3: Class selection ── */}
      {step===3&&(<>
        <div style={{fontSize:10,color:"#888",lineHeight:1.7}}>
          Your class gives you special abilities during crawl events. You can change it later from your dashboard.
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
          {CLASS_IDS.map(cid=>{
            const cls=BARTENDER_CLASSES[cid];
            return(
              <button key={cid} onClick={()=>set("classId",cid)} style={{
                display:"flex",flexDirection:"column",alignItems:"center",gap:5,
                padding:"12px 8px",
                border:`2px solid ${form.classId===cid?cls.color:"#1a1d2e"}`,
                borderRadius:12,background:form.classId===cid?`${cls.color}15`:"#0d0e1a",
                cursor:"pointer",transition:"all .15s",
              }}>
                <span style={{fontSize:26,filter:form.classId===cid?`drop-shadow(0 0 8px ${cls.color})`:"none"}}>{cls.icon}</span>
                <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:form.classId===cid?cls.color:"#888",letterSpacing:1}}>{cls.name}</span>
                <span style={{fontSize:8,color:"#555",textAlign:"center",lineHeight:1.3}}>{cls.tagline.slice(0,30)}</span>
              </button>
            );
          })}
        </div>
        {errors.classId&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.classId}</div>}
      </>)}

      {/* ── Step 4: Confirm & terms ── */}
      {step===4&&(<>
        <div style={{...S.card,background:"#0a0c14",border:"1px solid #1e2237",display:"flex",flexDirection:"column",gap:6}}>
          <div style={{fontSize:9,color:"#555",letterSpacing:3}}>YOUR APPLICATION</div>
          {[
            {l:"Bar",      v:`${form.barName}, ${form.barCity}`},
            {l:"Username", v:form.username},
            {l:"Class",    v:BARTENDER_CLASSES[form.classId]?.name||"—"},
            {l:"Contact",  v:form.contactEmail},
          ].map((r,i)=>(
            <div key={i} style={{display:"flex",justifyContent:"space-between",fontSize:11,padding:"4px 0",borderBottom:"1px solid #1a1d2e"}}>
              <span style={{color:"#555"}}>{r.l}</span>
              <span style={{color:"#f0f0f8"}}>{r.v}</span>
            </div>
          ))}
        </div>
        <div style={{display:"flex",alignItems:"flex-start",gap:10,padding:"8px 0",cursor:"pointer"}} onClick={()=>set("agreeTerms",!form.agreeTerms)}>
          <div style={{width:20,height:20,borderRadius:5,border:`2px solid ${form.agreeTerms?"#34C759":"#2a2a3a"}`,background:form.agreeTerms?"#34C759":"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:2}}>
            {form.agreeTerms&&<span style={{fontSize:12,color:"#000"}}>✓</span>}
          </div>
          <div style={{fontSize:11,color:"#888",lineHeight:1.7}}>
            I agree to the CrawlFire <span style={{color:"#FF2D55"}}>Partner Terms</span> and confirm this bar is licensed to serve alcohol. I am 18 or over.
          </div>
        </div>
        {errors.agreeTerms&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.agreeTerms}</div>}
        {errors.submit&&<div style={{fontSize:11,color:"#FF2D55",textAlign:"center"}}>{errors.submit}</div>}
      </>)}

      {step<4
        ? <button onClick={next} style={{...S.btnPrimary,background:"linear-gradient(135deg,#FF9500,#FFCC00)",color:"#000"}}>
            NEXT →
          </button>
        : <button onClick={submit} disabled={submitting} style={{...S.btnPrimary,background:submitting?"#1a1d2e":"linear-gradient(135deg,#34C759,#00C7BE)",color:submitting?"#555":"#000"}}>
            {submitting?"SUBMITTING…":"🍺 CREATE ACCOUNT"}
          </button>
      }
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// MUSICIAN SIGN-UP
// ═══════════════════════════════════════════════════════════════════════════════
function MusicianSignup({ onDone, onBack }) {
  const [step,      setStep]     = useState(0);
  const [form,      setForm]     = useState({
    username:"", password:"", confirmPassword:"",
    stageName:"", genre:"", bio:"",
    contactEmail:"", contactPhone:"",
    instagram:"", spotify:"",
    baseRate:"", agreeTerms:false,
  });
  const [errors,    setErrors]   = useState({});
  const [submitting,setSubmitting]=useState(false);
  const [done,      setDone]     = useState(false);

  const set = (k,v) => setForm(f=>({...f,[k]:v}));
  const STEPS = ["ACCOUNT","ARTIST","RATES","CONFIRM"];

  const GENRES = [["","Select genre"],["acoustic","🎸 Acoustic"],["jazz","🎷 Jazz"],["electronic","🎛️ Electronic"],["pop","🎤 Pop"],["rock","🤘 Rock"],["rnb","🎵 R&B"],["classical","🎻 Classical"],["folk","🪕 Folk"],["dj","🎧 DJ"],["other","🎼 Other"]];

  const validate = (s) => {
    const e={};
    if(s===0){
      if(!form.username.trim()||form.username.length<3) e.username="At least 3 characters";
      if(!form.password||form.password.length<6) e.password="At least 6 characters";
      if(form.password!==form.confirmPassword) e.confirmPassword="Passwords don't match";
    }
    if(s===1){
      if(!form.stageName.trim()) e.stageName="Stage name required";
      if(!form.genre) e.genre="Genre required";
      if(!form.contactEmail.includes("@")) e.contactEmail="Valid email required";
    }
    if(s===3){
      if(!form.agreeTerms) e.agreeTerms="You must agree to the terms";
    }
    return e;
  };

  const next=()=>{ const e=validate(step); setErrors(e); if(!Object.keys(e).length) setStep(s=>s+1); };

  const submit = async () => {
    const e=validate(3); setErrors(e);
    if(Object.keys(e).length) return;
    setSubmitting(true);
    const account = {
      username:form.username.toLowerCase().trim(),
      password:form.password,
      stageName:form.stageName.trim(),
      genre:form.genre,
      bio:form.bio.trim(),
      contactEmail:form.contactEmail.trim(),
      contactPhone:form.contactPhone.trim(),
      instagram:form.instagram.trim(),
      spotify:form.spotify.trim(),
      baseRate:parseFloat(form.baseRate)||0,
      musicianId:"m_"+uid(),
      tips:0, events:0, totalEarned:0,
      joinedAt:Date.now(),
    };
    const result=await saveSignup("musicians",account);
    if(result.error){ setErrors({submit:result.error}); setSubmitting(false); return; }
    setDone(true); setSubmitting(false);
    setTimeout(()=>onDone(account),1800);
  };

  if(done) return(
    <div style={{...S.screen,alignItems:"center",justifyContent:"center",textAlign:"center",gap:16}}>
      <div style={{fontSize:72,animation:"breathe 1.5s ease-in-out infinite",filter:"drop-shadow(0 0 20px #BF5AF2)"}}>🎸</div>
      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:26,letterSpacing:2,color:"#BF5AF2"}}>WELCOME, {form.stageName.toUpperCase()}!</div>
      <div style={{fontSize:12,color:"#555",lineHeight:1.8}}>Your musician profile is live. Logging you in…</div>
    </div>
  );

  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={step===0?onBack:()=>setStep(s=>s-1)}>← BACK</button>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:36,marginBottom:4}}>🎸</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,letterSpacing:2,color:"#f0f0f8"}}>MUSICIAN SIGN-UP</div>
        <div style={{fontSize:10,color:"#555",marginTop:2}}>Get booked · earn tips · play the crawl</div>
      </div>

      <SignupSteps steps={STEPS} current={step} color="#BF5AF2"/>

      {step===0&&(<>
        <SignupField label="USERNAME" value={form.username} onChange={v=>set("username",v)} placeholder="djstatic"/>
        {errors.username&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.username}</div>}
        <SignupField label="PASSWORD" value={form.password} onChange={v=>set("password",v)} placeholder="••••••••" type="password"/>
        {errors.password&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.password}</div>}
        <SignupField label="CONFIRM PASSWORD" value={form.confirmPassword} onChange={v=>set("confirmPassword",v)} placeholder="••••••••" type="password"/>
        {errors.confirmPassword&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.confirmPassword}</div>}
      </>)}

      {step===1&&(<>
        <SignupField label="STAGE NAME" value={form.stageName} onChange={v=>set("stageName",v)} placeholder="DJ Static"/>
        {errors.stageName&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.stageName}</div>}
        <SignupSelect label="GENRE" value={form.genre} onChange={v=>set("genre",v)} options={GENRES}/>
        {errors.genre&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.genre}</div>}
        <SignupField label="BIO (optional)" value={form.bio} onChange={v=>set("bio",v.slice(0,200))} placeholder="Tell bars what makes your sound special…" maxLength={200}/>
        <SignupField label="EMAIL" value={form.contactEmail} onChange={v=>set("contactEmail",v)} placeholder="you@email.com" type="email"/>
        {errors.contactEmail&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.contactEmail}</div>}
        <SignupField label="INSTAGRAM (optional)" value={form.instagram} onChange={v=>set("instagram",v)} placeholder="@djstatic"/>
        <SignupField label="SPOTIFY LINK (optional)" value={form.spotify} onChange={v=>set("spotify",v)} placeholder="open.spotify.com/artist/…"/>
      </>)}

      {step===2&&(<>
        <div style={{...S.card,background:"#BF5AF210",border:"1px solid #BF5AF230",fontSize:11,color:"#888",lineHeight:1.8}}>
          Set your base rate per event. Bars see this when booking you. You also earn tips from players during crawls — these are separate and paid out weekly.
        </div>
        <SignupField label="BASE RATE PER EVENT (£)" value={form.baseRate} onChange={v=>set("baseRate",v)} placeholder="50" type="number" hint="Minimum £0 (tips only) · Maximum £500"/>
        <div style={{...S.card,background:"#0a0c14",border:"1px solid #1e2237",fontSize:10,color:"#555",lineHeight:1.8}}>
          💡 Most CrawlFire musicians start at £50–£100/event plus tips.<br/>
          Players tip via QR during the crawl — you keep 100% of tips.
        </div>
      </>)}

      {step===3&&(<>
        <div style={{...S.card,background:"#0a0c14",border:"1px solid #1e2237",display:"flex",flexDirection:"column",gap:6}}>
          <div style={{fontSize:9,color:"#555",letterSpacing:3}}>YOUR PROFILE</div>
          {[
            {l:"Stage Name", v:form.stageName},
            {l:"Genre",      v:GENRES.find(([v])=>v===form.genre)?.[1]||form.genre},
            {l:"Base Rate",  v:form.baseRate?`£${form.baseRate}/event`:"Tips only"},
            {l:"Email",      v:form.contactEmail},
          ].map((r,i)=>(
            <div key={i} style={{display:"flex",justifyContent:"space-between",fontSize:11,padding:"4px 0",borderBottom:"1px solid #1a1d2e"}}>
              <span style={{color:"#555"}}>{r.l}</span>
              <span style={{color:"#f0f0f8"}}>{r.v}</span>
            </div>
          ))}
        </div>
        <div style={{display:"flex",alignItems:"flex-start",gap:10,padding:"8px 0",cursor:"pointer"}} onClick={()=>set("agreeTerms",!form.agreeTerms)}>
          <div style={{width:20,height:20,borderRadius:5,border:`2px solid ${form.agreeTerms?"#34C759":"#2a2a3a"}`,background:form.agreeTerms?"#34C759":"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:2}}>
            {form.agreeTerms&&<span style={{fontSize:12,color:"#000"}}>✓</span>}
          </div>
          <div style={{fontSize:11,color:"#888",lineHeight:1.7}}>
            I agree to the CrawlFire <span style={{color:"#BF5AF2"}}>Musician Terms</span>. I understand tips are processed via CrawlFire and paid weekly. I am 18 or over.
          </div>
        </div>
        {errors.agreeTerms&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.agreeTerms}</div>}
        {errors.submit&&<div style={{fontSize:11,color:"#FF2D55",textAlign:"center"}}>{errors.submit}</div>}
      </>)}

      {step<3
        ? <button onClick={next} style={{...S.btnPrimary,background:"linear-gradient(135deg,#BF5AF2,#7B5EA7)",color:"#fff"}}>NEXT →</button>
        : <button onClick={submit} disabled={submitting} style={{...S.btnPrimary,background:submitting?"#1a1d2e":"linear-gradient(135deg,#34C759,#00C7BE)",color:submitting?"#555":"#000"}}>
            {submitting?"SUBMITTING…":"🎸 CREATE PROFILE"}
          </button>
      }
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// BAR PARTNER SIGN-UP
// ═══════════════════════════════════════════════════════════════════════════════
function BarPartnerSignup({ onDone, onBack }) {
  const [step,      setStep]     = useState(0);
  const [form,      setForm]     = useState({
    username:"", password:"", confirmPassword:"",
    venueName:"", venueType:"", capacity:"", address:"", city:"", postcode:"",
    contactName:"", contactEmail:"", contactPhone:"",
    licenceNumber:"", vatNumber:"",
    referralCode:"", plan:"standard",
    agreeTerms:false, agreeAge:false,
  });
  const [errors,    setErrors]   = useState({});
  const [submitting,setSubmitting]=useState(false);
  const [done,      setDone]     = useState(false);
  const [refValid,  setRefValid]  = useState(null);

  const set = (k,v) => setForm(f=>({...f,[k]:v}));
  const STEPS = ["ACCOUNT","VENUE","LEGAL","PLAN","CONFIRM"];
  const VENUE_TYPES=[["","Select type"],["pub","🍺 Pub / Bar"],["club","🎶 Nightclub"],["restaurant","🍽️ Restaurant Bar"],["hotel","🏨 Hotel Bar"],["rooftop","🌇 Rooftop Bar"],["sport","🏟️ Sports Bar"],["other","📍 Other"]];
  const PLANS=[
    {id:"standard",label:"STANDARD",price:"Free",perks:["5% revenue share","Listed in app","Loot code tools","Basic analytics"]},
    {id:"pro",label:"PRO",price:"£49/mo",perks:["3% revenue share","Priority listing","Advanced analytics","Dedicated support","Featured in lobby"]},
    {id:"enterprise",label:"ENTERPRISE",price:"£149/mo",perks:["2% revenue share","White-label option","Custom branding","API access","Account manager"]},
  ];

  const checkRef=async(v)=>{
    set("referralCode",v.toUpperCase());
    if(v.length<6){ setRefValid(null); return; }
    const bars=await loadSignups("bartenders");
    const all=[...BAR_ACCOUNTS,...bars];
    const m=all.find(b=>b.refCode===v.toUpperCase());
    setRefValid(m?m.barName||m.venueName:false);
  };

  const validate=(s)=>{
    const e={};
    if(s===0){
      if(!form.username.trim()||form.username.length<3) e.username="At least 3 characters";
      if(!form.password||form.password.length<6) e.password="At least 6 characters";
      if(form.password!==form.confirmPassword) e.confirmPassword="Passwords don't match";
    }
    if(s===1){
      if(!form.venueName.trim()) e.venueName="Venue name required";
      if(!form.venueType) e.venueType="Venue type required";
      if(!form.address.trim()) e.address="Address required";
      if(!form.city.trim()) e.city="City required";
    }
    if(s===2){
      if(!form.contactName.trim()) e.contactName="Name required";
      if(!form.contactEmail.includes("@")) e.contactEmail="Valid email required";
    }
    if(s===4){
      if(!form.agreeTerms) e.agreeTerms="You must agree to the terms";
      if(!form.agreeAge) e.agreeAge="Age confirmation required";
    }
    return e;
  };

  const next=()=>{ const e=validate(step); setErrors(e); if(!Object.keys(e).length) setStep(s=>s+1); };

  const submit=async()=>{
    const e=validate(4); setErrors(e);
    if(Object.keys(e).length) return;
    setSubmitting(true);
    const account={
      username:form.username.toLowerCase().trim(),
      password:form.password,
      venueName:form.venueName.trim(),
      venueType:form.venueType,
      capacity:parseInt(form.capacity)||0,
      address:form.address.trim(), city:form.city.trim(), postcode:form.postcode.trim(),
      contactName:form.contactName.trim(), contactEmail:form.contactEmail.trim(), contactPhone:form.contactPhone.trim(),
      licenceNumber:form.licenceNumber.trim(), vatNumber:form.vatNumber.trim(),
      referralCode:form.referralCode, referredBy:refValid||null,
      plan:form.plan, emoji:"🏪", tier:"bronze",
      earned:0, pending:0, crawls:0, refs:0, streak:0,
      refCode:form.username.slice(0,6).toUpperCase()+(Math.floor(Math.random()*90)+10),
      joinedAt:Date.now(),
    };
    const result=await saveSignup("barpartners",account);
    if(result.error){ setErrors({submit:result.error}); setSubmitting(false); return; }
    setDone(true); setSubmitting(false);
    setTimeout(()=>onDone(account),1800);
  };

  if(done) return(
    <div style={{...S.screen,alignItems:"center",justifyContent:"center",textAlign:"center",gap:16}}>
      <div style={{fontSize:72,animation:"breathe 1.5s ease-in-out infinite",filter:"drop-shadow(0 0 20px #007AFF)"}}>🏪</div>
      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:26,letterSpacing:2,color:"#007AFF"}}>VENUE REGISTERED!</div>
      <div style={{fontSize:12,color:"#555",lineHeight:1.8}}>{form.venueName} is now on CrawlFire.<br/>Setting up your dashboard…</div>
    </div>
  );

  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={step===0?onBack:()=>setStep(s=>s-1)}>← BACK</button>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:36,marginBottom:4}}>🏪</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,letterSpacing:2,color:"#f0f0f8"}}>BAR PARTNER SIGN-UP</div>
        <div style={{fontSize:10,color:"#555",marginTop:2}}>List your venue · earn revenue · host events</div>
      </div>

      <SignupSteps steps={STEPS} current={step} color="#007AFF"/>

      {step===0&&(<>
        <SignupField label="USERNAME" value={form.username} onChange={v=>set("username",v)} placeholder="therustyanchor"/>
        {errors.username&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.username}</div>}
        <SignupField label="PASSWORD" value={form.password} onChange={v=>set("password",v)} placeholder="••••••••" type="password"/>
        {errors.password&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.password}</div>}
        <SignupField label="CONFIRM PASSWORD" value={form.confirmPassword} onChange={v=>set("confirmPassword",v)} placeholder="••••••••" type="password"/>
        {errors.confirmPassword&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.confirmPassword}</div>}
        <div style={{display:"flex",flexDirection:"column",gap:5}}>
          <label style={{fontSize:9,color:"#555",letterSpacing:2,fontFamily:"'Black Han Sans',sans-serif"}}>REFERRAL CODE (optional)</label>
          <input value={form.referralCode} onChange={e=>checkRef(e.target.value)} placeholder="ANCHOR7" maxLength={10}
            style={{background:"#0d0e1a",border:`1.5px solid ${refValid===true||refValid?refValid?"#34C759":"#FF2D55":"#2a2a3a"}`,borderRadius:10,color:"#f0f0f8",fontFamily:"'Space Mono',monospace",fontSize:13,padding:"11px 14px",outline:"none"}}/>
          {refValid&&<div style={{fontSize:10,color:"#34C759"}}>✅ Referred by: {refValid}</div>}
          {refValid===false&&<div style={{fontSize:10,color:"#FF9500"}}>⚠️ Code not found — you can still sign up</div>}
        </div>
      </>)}

      {step===1&&(<>
        <SignupField label="VENUE NAME" value={form.venueName} onChange={v=>set("venueName",v)} placeholder="The Rusty Anchor"/>
        {errors.venueName&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.venueName}</div>}
        <SignupSelect label="VENUE TYPE" value={form.venueType} onChange={v=>set("venueType",v)} options={VENUE_TYPES}/>
        {errors.venueType&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.venueType}</div>}
        <SignupField label="CAPACITY" value={form.capacity} onChange={v=>set("capacity",v)} placeholder="120" type="number"/>
        <SignupField label="ADDRESS" value={form.address} onChange={v=>set("address",v)} placeholder="123 High Street"/>
        {errors.address&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.address}</div>}
        <SignupField label="CITY" value={form.city} onChange={v=>set("city",v)} placeholder="London"/>
        {errors.city&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.city}</div>}
        <SignupField label="POSTCODE / ZIP" value={form.postcode} onChange={v=>set("postcode",v)} placeholder="EC1A 1BB" maxLength={10}/>
      </>)}

      {step===2&&(<>
        <SignupField label="CONTACT NAME" value={form.contactName} onChange={v=>set("contactName",v)} placeholder="Jane Smith"/>
        {errors.contactName&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.contactName}</div>}
        <SignupField label="CONTACT EMAIL" value={form.contactEmail} onChange={v=>set("contactEmail",v)} placeholder="jane@thebar.co.uk" type="email"/>
        {errors.contactEmail&&<div style={{fontSize:10,color:"#FF2D55"}}>{errors.contactEmail}</div>}
        <SignupField label="PHONE" value={form.contactPhone} onChange={v=>set("contactPhone",v)} placeholder="+44 7700 900000" type="tel"/>
        <SignupField label="ALCOHOL LICENCE NUMBER" value={form.licenceNumber} onChange={v=>set("licenceNumber",v)} placeholder="AB12345" hint="Required for listing on CrawlFire"/>
        <SignupField label="VAT NUMBER (if applicable)" value={form.vatNumber} onChange={v=>set("vatNumber",v)} placeholder="GB123456789"/>
      </>)}

      {step===3&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {PLANS.map(plan=>(
            <div key={plan.id} onClick={()=>set("plan",plan.id)} style={{
              ...S.card,
              border:`2px solid ${form.plan===plan.id?"#007AFF":"#1a1d2e"}`,
              background:form.plan===plan.id?"#007AFF10":"#0d0e1a",
              cursor:"pointer",transition:"all .15s",
            }}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:form.plan===plan.id?"#007AFF":"#f0f0f8",letterSpacing:1}}>{plan.label}</div>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:form.plan===plan.id?"#007AFF":"#FFCC00"}}>{plan.price}</div>
              </div>
              {plan.perks.map((p,i)=><div key={i} style={{fontSize:10,color:"#888",padding:"2px 0"}}>✓ {p}</div>)}
            </div>
          ))}
        </div>
      )}

      {step===4&&(<>
        <div style={{...S.card,background:"#0a0c14",border:"1px solid #1e2237",display:"flex",flexDirection:"column",gap:6}}>
          <div style={{fontSize:9,color:"#555",letterSpacing:3}}>YOUR APPLICATION</div>
          {[
            {l:"Venue",   v:`${form.venueName}, ${form.city}`},
            {l:"Type",    v:VENUE_TYPES.find(([v])=>v===form.venueType)?.[1]||form.venueType},
            {l:"Plan",    v:PLANS.find(p=>p.id===form.plan)?.label+" — "+PLANS.find(p=>p.id===form.plan)?.price},
            {l:"Contact", v:form.contactEmail},
          ].map((r,i)=>(
            <div key={i} style={{display:"flex",justifyContent:"space-between",fontSize:11,padding:"4px 0",borderBottom:"1px solid #1a1d2e"}}>
              <span style={{color:"#555"}}>{r.l}</span>
              <span style={{color:"#f0f0f8"}}>{r.v}</span>
            </div>
          ))}
        </div>
        {[
          [form.agreeTerms,()=>set("agreeTerms",!form.agreeTerms),"I agree to the CrawlFire Bar Partner Agreement and Revenue Share Terms.",errors.agreeTerms],
          [form.agreeAge,()=>set("agreeAge",!form.agreeAge),"I confirm this venue holds a valid alcohol licence and I am authorised to register it.",errors.agreeAge],
        ].map(([checked,toggle,label,err],i)=>(
          <div key={i}>
            <div style={{display:"flex",alignItems:"flex-start",gap:10,padding:"6px 0",cursor:"pointer"}} onClick={toggle}>
              <div style={{width:20,height:20,borderRadius:5,border:`2px solid ${checked?"#34C759":"#2a2a3a"}`,background:checked?"#34C759":"transparent",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:2}}>
                {checked&&<span style={{fontSize:12,color:"#000"}}>✓</span>}
              </div>
              <div style={{fontSize:11,color:"#888",lineHeight:1.7}}>{label}</div>
            </div>
            {err&&<div style={{fontSize:10,color:"#FF2D55",marginTop:-4,marginBottom:4}}>{err}</div>}
          </div>
        ))}
        {errors.submit&&<div style={{fontSize:11,color:"#FF2D55",textAlign:"center"}}>{errors.submit}</div>}
      </>)}

      {step<4
        ? <button onClick={next} style={{...S.btnPrimary,background:"linear-gradient(135deg,#007AFF,#00C7BE)",color:"#fff"}}>NEXT →</button>
        : <button onClick={submit} disabled={submitting} style={{...S.btnPrimary,background:submitting?"#1a1d2e":"linear-gradient(135deg,#34C759,#00C7BE)",color:submitting?"#555":"#000"}}>
            {submitting?"SUBMITTING…":"🏪 REGISTER VENUE"}
          </button>
      }
    </div>
  );
}


function BarLoginScreen({onLogin,onBack}){
  const [u,setU]=useState(""); const [p,setP]=useState(""); const [err,setErr]=useState("");
  const login=async()=>{
    let a=BAR_ACCOUNTS.find(x=>x.username===u.toLowerCase()&&x.password===p);
    if(!a) a=await findSignup("bartenders",u,p);
    if(a)onLogin(a);else{setErr("Wrong credentials");setTimeout(()=>setErr(""),1500);}
  };
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={S.title}>🍺 BARTENDER LOGIN</div>
      <div style={S.card}>
        <div style={S.label}>USERNAME</div>
        <input style={{...S.input,marginBottom:12}} placeholder="bar1 / bar2 / bar3" value={u} onChange={e=>setU(e.target.value)}/>
        <div style={S.label}>PASSWORD</div>
        <input style={{...S.input,marginBottom:12}} type="password" placeholder="crawl123 (demo)" value={p} onChange={e=>setP(e.target.value)} onKeyDown={e=>e.key==="Enter"&&login()}/>
        {err&&<div style={{fontSize:11,color:"#FF2D55",marginBottom:8}}>⚠️ {err}</div>}
        <button style={S.btnGold} onClick={login}>SIGN IN →</button>
        <div style={{fontSize:10,color:"#333",textAlign:"center",marginTop:8}}>Demo: bar1 / crawl123</div>
      </div>
    </div>
  );
}

function BartenderDash({bartender,game,codes,onGenCode,onLogout}){
  const [tab,setTab]=useState("generate");
  const [selItem,setSelItem]=useState(LOOT_ITEMS[0]);
  const [selPlayer,setSelPlayer]=useState(null);
  const [justGen,setJustGen]=useState(null);
  const [dqTarget,setDqTarget]=useState(null);
  const [dqLog,setDqLog]=useState([]);
  const [handshakeItem,setHandshakeItem]=useState(null); // null = closed; item = show QR
  const [hsReady,setHsReady]=useState(false); // true = pre-select done, show big button
  const [hsSelItem,setHsSelItem]=useState(LOOT_ITEMS[0]);
  const [activeClass,setActiveClass]=useState(bartender.classId||null);
  const cls=BARTENDER_CLASSES[activeClass];
  const players=Object.values(game?.players||{});
  const myCodes=Object.values(codes).filter(c=>c.barName===bartender.barName);
  const active=myCodes.filter(c=>!c.used), used=myCodes.filter(c=>c.used);

  const handleDQ = async ({player, reason, notes, ts}) => {
    // Add to local DQ log
    const entry = {id:uid(), playerName:player.name, playerAvatar:player.avatar, playerId:player.id, reason:reason.label, severity:reason.severity, notes, ts, barName:bartender.barName};
    setDqLog(l=>[entry,...l]);
    setDqTarget(null);
    // In production: write to Firebase DQ log + mutGame to remove player
    // mutGame(g => ({...g, players:{...g.players, [player.id]:{...g.players[player.id], disqualified:true, alive:false}}}));
  };
  const generate=async()=>{
    const code=genCode(bartender.barName);
    const entry={code,itemId:selItem.id,itemName:selItem.n,itemEmoji:selItem.e,rarity:selItem.rarity,barName:bartender.barName,barEmoji:bartender.emoji,forPlayer:selPlayer||null,used:false,createdAt:Date.now()};
    await onGenCode(code,entry);
    setJustGen(entry);setTimeout(()=>setJustGen(null),5000);
  };
  return(
    <div style={S.screen}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1,color:"#FF9500"}}>{bartender.emoji} {bartender.barName}</div>
          <div style={{display:"flex",alignItems:"center",gap:6,marginTop:2}}>
            <div style={{fontSize:9,color:"#555",letterSpacing:2}}>LOOT STATION</div>
            {cls&&<div style={{display:"flex",alignItems:"center",gap:4,background:`${cls.color}15`,border:`1px solid ${cls.color}30`,borderRadius:20,padding:"1px 8px"}}>
              <span style={{fontSize:11}}>{cls.icon}</span>
              <span style={{fontSize:8,color:cls.color,fontFamily:"'Black Han Sans',sans-serif",letterSpacing:1}}>{cls.name}</span>
            </div>}
          </div>
        </div>
        <div style={{display:"flex",gap:6}}>
          <button style={{...S.btnGhost,fontSize:10,padding:"5px 10px"}} onClick={()=>setTab("class")}>{cls?.icon||"⚔️"} CLASS</button>
          <button style={S.btnGhost} onClick={onLogout}>SIGN OUT</button>
        </div>
      </div>
      {/* Stats */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
        {[{l:"PLAYERS",v:players.length,c:"#00C7BE"},{l:"ACTIVE",v:active.length,c:"#34C759"},{l:"REDEEMED",v:used.length,c:"#FF9500"}].map((s,i)=>(
          <div key={i} style={{...S.card,textAlign:"center"}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:28,color:s.c}}>{s.v}</div><div style={{fontSize:8,letterSpacing:2,color:"#555",marginTop:2}}>{s.l}</div></div>
        ))}
      </div>
      {/* Tabs */}
      <div style={{display:"flex",gap:3,flexWrap:"wrap"}}>
        {[["handshake","🤝 TAP"],["class","⚔️ CLASS"],["generate","🎁 CODES"],["players","👥 PLAYERS"],["safety","🚨 SAFETY"],["dqlog","📋 LOG"]].map(([id,label])=>{
          const cls=BARTENDER_CLASSES[bartender.classId];
          const tabColor=id==="handshake"?"#00C7BE":id==="class"?(cls?.color||"#BF5AF2"):id==="safety"?"#FF2D55":"#FF9500";
          return(
          <button key={id} onClick={()=>setTab(id)} style={{flex:1,padding:6,border:`2px solid ${tab===id?tabColor:"#2a2a3a"}`,borderRadius:10,background:tab===id?`${tabColor}18`:"#0d0e1a",color:tab===id?tabColor:"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:8,letterSpacing:.5,cursor:"pointer",minWidth:0,whiteSpace:"nowrap"}}>
            {label}{id==="safety"&&dqLog.length>0&&<span style={{marginLeft:2,background:"#FF2D55",color:"#fff",borderRadius:10,padding:"0px 4px",fontSize:7}}>{dqLog.length}</span>}
          </button>
        );})}
      </div>
      {tab==="handshake"&&(
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          {/* Hero explainer */}
          <div style={{...S.card,background:"#00C7BE08",border:"2px solid #00C7BE30",textAlign:"center",padding:"18px 16px"}}>
            <div style={{fontSize:44,marginBottom:8}}>🤝</div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,color:"#00C7BE"}}>QUICK HANDSHAKE</div>
            <div style={{fontSize:11,color:"#666",marginTop:6,lineHeight:1.8}}>
              Pick an item below, tap the big button.<br/>
              A QR appears — player scans it in seconds.<br/>
              <strong style={{color:"#00C7BE"}}>No typing. No disruption.</strong>
            </div>
          </div>

          {/* Item picker — large tap targets */}
          <div style={{fontSize:9,color:"#555",letterSpacing:2}}>SELECT ITEM TO GIVE</div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:8}}>
            {LOOT_ITEMS.map(item=>(
              <button key={item.id} onClick={()=>setHsSelItem(item)} style={{display:"flex",alignItems:"center",gap:10,padding:"12px 14px",background:"#0d0e1a",border:`2px solid ${hsSelItem.id===item.id?RARITY_C[item.rarity]:"#2a2a3a"}`,borderRadius:12,cursor:"pointer",transition:"all .12s",textAlign:"left"}}>
                <span style={{fontSize:26,flexShrink:0}}>{item.e}</span>
                <div>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:hsSelItem.id===item.id?RARITY_C[item.rarity]:"#f0f0f8"}}>{item.n}</div>
                  <div style={{fontSize:9,color:RARITY_C[item.rarity],letterSpacing:1,marginTop:2}}>{item.rarity.toUpperCase()}</div>
                </div>
              </button>
            ))}
          </div>

          {/* THE BIG BUTTON */}
          <button
            onClick={()=>setHandshakeItem(hsSelItem)}
            style={{
              width:"100%",padding:"22px 0",border:"none",borderRadius:16,cursor:"pointer",
              background:`linear-gradient(135deg,#00C7BE,#007AFF)`,
              color:"#fff",fontFamily:"'Black Han Sans',sans-serif",fontSize:24,letterSpacing:4,
              boxShadow:"0 6px 28px #00C7BE50",
              display:"flex",flexDirection:"column",alignItems:"center",gap:6,
              transition:"all .15s",
            }}>
            <span style={{fontSize:40}}>📲</span>
            TAP TO SHOW QR
            <span style={{fontSize:11,letterSpacing:2,opacity:.8}}>Player scans · instant claim</span>
          </button>

          {/* How it works steps */}
          <div style={{...S.card,display:"flex",flexDirection:"column",gap:8}}>
            <div style={{fontSize:9,color:"#555",letterSpacing:2,marginBottom:4}}>HOW IT WORKS</div>
            {[
              {n:"1",t:"Pick an item above",   c:"#00C7BE"},
              {n:"2",t:"Tap the big button",   c:"#00C7BE"},
              {n:"3",t:"Show QR to player",    c:"#00C7BE"},
              {n:"4",t:"Player scans — done!", c:"#34C759"},
            ].map(s=>(
              <div key={s.n} style={{display:"flex",alignItems:"center",gap:10}}>
                <div style={{width:22,height:22,borderRadius:"50%",background:`${s.c}20`,border:`1px solid ${s.c}40`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                  <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:s.c}}>{s.n}</span>
                </div>
                <span style={{fontSize:11,color:"#888"}}>{s.t}</span>
              </div>
            ))}
          </div>

          {/* Recent handshakes */}
          {active.length>0&&(
            <div style={{...S.card}}>
              <div style={{fontSize:9,color:"#555",letterSpacing:2,marginBottom:8}}>RECENT HANDSHAKES</div>
              {active.slice(0,3).map(c=>(
                <div key={c.code} style={{display:"flex",alignItems:"center",gap:8,padding:"6px 0",borderBottom:"1px solid #1a1d2e"}}>
                  <span style={{fontSize:16}}>{c.itemEmoji}</span>
                  <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:"#FF9500",letterSpacing:1}}>{c.code}</div></div>
                  <span style={{fontSize:8,padding:"2px 8px",borderRadius:10,background:"#34C75920",border:"1px solid #34C75940",color:"#34C759",fontFamily:"'Space Mono',monospace"}}>ACTIVE</span>
                  {/* Re-show QR for this code */}
                  <button onClick={()=>setHandshakeItem(LOOT_ITEMS.find(x=>x.id===c.itemId)||LOOT_ITEMS[0])} style={{fontSize:14,background:"none",border:"1px solid #2a2a3a",borderRadius:8,padding:"3px 8px",cursor:"pointer",color:"#00C7BE"}}>📲</button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab==="class"&&(
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          {!cls ? (
            <>
              <div style={{...S.card,background:"#1a0a2e",border:"2px solid #BF5AF230",textAlign:"center",padding:"20px 16px"}}>
                <div style={{fontSize:44,marginBottom:8}}>⚔️</div>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,color:"#BF5AF2"}}>NO CLASS SELECTED</div>
                <div style={{fontSize:11,color:"#666",marginTop:6,lineHeight:1.7}}>Choose a class to unlock special abilities that affect the game for your players.</div>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                {CLASS_IDS.map(cid=>{
                  const c=BARTENDER_CLASSES[cid];
                  return(
                    <button key={cid} onClick={()=>setActiveClass(cid)} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:5,padding:"14px 8px",border:"1px solid #1a1d2e",borderRadius:12,background:"#0d0e1a",cursor:"pointer",transition:"all .15s"}}
                      onMouseOver={e=>{e.currentTarget.style.borderColor=c.color;e.currentTarget.style.background=`${c.color}10`;}}
                      onMouseOut={e=>{e.currentTarget.style.borderColor="#1a1d2e";e.currentTarget.style.background="#0d0e1a";}}>
                      <span style={{fontSize:28,filter:`drop-shadow(0 0 6px ${c.color}60)`}}>{c.icon}</span>
                      <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:c.color,letterSpacing:1}}>{c.name}</span>
                      <span style={{fontSize:9,color:"#555",textAlign:"center",lineHeight:1.3}}>{c.tagline.slice(0,30)}</span>
                    </button>
                  );
                })}
              </div>
            </>
          ) : (
            <>
              <AbilityUsePanel bartender={bartender} cls={cls} players={players} onAbilityUsed={entry=>setDqLog(l=>[{...entry,type:"ability"},...l])}/>
              <button onClick={()=>setActiveClass(null)} style={{...S.btnGhost,width:"100%",textAlign:"center",padding:10,fontSize:11}}>↺ CHANGE CLASS</button>
              <div style={{...S.card,display:"flex",flexDirection:"column",gap:6}}>
                <div style={{fontSize:9,letterSpacing:3,color:"#555"}}>ALL CLASSES</div>
                <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:5}}>
                  {CLASS_IDS.map(cid=>{
                    const c=BARTENDER_CLASSES[cid];
                    return(
                      <button key={cid} onClick={()=>setActiveClass(cid)} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:3,padding:"8px 4px",border:`1px solid ${activeClass===cid?c.color:"#1a1d2e"}`,borderRadius:10,background:activeClass===cid?`${c.color}15`:"#0d0e1a",cursor:"pointer"}}>
                        <span style={{fontSize:18}}>{c.icon}</span>
                        <span style={{fontSize:7,color:activeClass===cid?c.color:"#555",letterSpacing:.5}}>{c.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </div>
      )}

      {tab==="generate"&&(
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <div style={{fontSize:10,color:"#555",letterSpacing:2}}>SELECT LOOT ITEM</div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:6}}>
            {LOOT_ITEMS.map(item=>(
              <button key={item.id} onClick={()=>setSelItem(item)} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:3,padding:"8px 4px",background:"#0d0e1a",border:`2px solid ${selItem.id===item.id?RARITY_C[item.rarity]:"#2a2a3a"}`,borderRadius:10,cursor:"pointer"}}>
                <span style={{fontSize:20}}>{item.e}</span>
                <span style={{fontSize:8,color:"#f0f0f8",fontFamily:"'Space Mono',monospace",textAlign:"center",lineHeight:1.2}}>{item.n}</span>
                <span style={{fontSize:7,color:RARITY_C[item.rarity],letterSpacing:1}}>{item.rarity}</span>
              </button>
            ))}
          </div>
          <div style={{fontSize:10,color:"#555",letterSpacing:2}}>FOR PLAYER (optional)</div>
          <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
            <button onClick={()=>setSelPlayer(null)} style={{padding:"5px 10px",borderRadius:20,border:`1px solid ${!selPlayer?"#FF9500":"#2a2a3a"}`,background:!selPlayer?"#FF950015":"#0d0e1a",color:!selPlayer?"#FF9500":"#666",fontFamily:"'Space Mono',monospace",fontSize:10,cursor:"pointer"}}>Anyone</button>
            {players.map(p=><button key={p.id} onClick={()=>setSelPlayer(p.id===selPlayer?null:p.id)} style={{padding:"5px 10px",borderRadius:20,border:`1px solid ${selPlayer===p.id?"#FF9500":"#2a2a3a"}`,background:selPlayer===p.id?"#FF950015":"#0d0e1a",color:selPlayer===p.id?"#FF9500":"#666",fontFamily:"'Space Mono',monospace",fontSize:10,cursor:"pointer"}}>{p.avatar} {p.name}</button>)}
          </div>
          <button style={S.btnGold} onClick={generate}>⚡ GENERATE LOOT CODE</button>
          {justGen&&(
            <div style={{...S.card,background:"#FF950010",border:"2px solid #FF9500",textAlign:"center",animation:"popIn .4s ease"}}>
              <div style={{fontSize:10,color:"#555",letterSpacing:2,marginBottom:6}}>SHOW THIS TO THE PLAYER</div>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:40,color:"#FF9500",letterSpacing:6,textShadow:"0 0 20px #FF950060"}}>{justGen.code}</div>
              <div style={{fontSize:14,marginTop:6}}>{justGen.itemEmoji} {justGen.itemName}</div>
            </div>
          )}
        </div>
      )}
      {tab==="codes"&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {active.length===0&&used.length===0&&<div style={{...S.card,textAlign:"center",color:"#444",fontSize:12}}>No codes yet — generate one!</div>}
          {active.length>0&&<><div style={{fontSize:10,color:"#34C759",letterSpacing:2}}>⏳ ACTIVE ({active.length})</div>
          {active.map(c=>(
            <div key={c.code} style={{...S.card,display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:22}}>{c.itemEmoji}</span>
              <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:2,color:"#FF9500"}}>{c.code}</div><div style={{fontSize:10,color:"#555"}}>{c.itemName} · <span style={{color:RARITY_C[c.rarity]}}>{c.rarity}</span></div></div>
              <Pill label="ACTIVE" color="#34C759"/>
            </div>
          ))}</>}
          {used.length>0&&<><div style={{fontSize:10,color:"#555",letterSpacing:2,marginTop:4}}>✅ REDEEMED ({used.length})</div>
          {used.map(c=>{const who=game?.players?.[c.usedBy];return(
            <div key={c.code} style={{...S.card,display:"flex",alignItems:"center",gap:10,opacity:.5}}>
              <span style={{fontSize:22}}>{c.itemEmoji}</span>
              <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1}}>{c.code}</div><div style={{fontSize:10,color:"#555"}}>{who?`${who.avatar} ${who.name}`:"player"}</div></div>
              <Pill label="USED" color="#555"/>
            </div>
          );})}</>}
        </div>
      )}
      {tab==="players"&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {players.length===0&&<div style={{...S.card,textAlign:"center",color:"#444",fontSize:12}}>No players in game yet</div>}
          {[...players].sort((a,b)=>b.kills-a.kills).map((p,i)=>(
            <div key={p.id} style={{...S.card,display:"flex",alignItems:"center",gap:10,opacity:p.disqualified?.3:p.alive?1:.5,border:`1px solid ${p.disqualified?"#FF2D55":"#1a1d2e"}`}}>
              <div style={{fontSize:16,width:24,textAlign:"center"}}>{["🥇","🥈","🥉"][i]||`#${i+1}`}</div>
              <span style={{fontSize:24}}>{p.avatar}</span>
              <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1}}>{p.name}{p.disqualified&&<span style={{fontSize:9,color:"#FF2D55",marginLeft:5}}>DQ'd</span>}</div><HPBar hp={p.hp} max={p.maxHp}/><div style={{fontSize:9,color:"#555",marginTop:3}}>{p.kills}💀·{Math.max(0,p.hp)}hp·🪙{p.coins}</div></div>
              <div style={{display:"flex",flexDirection:"column",gap:4,alignItems:"flex-end"}}>
                <Pill label={p.disqualified?"DQ'd":p.alive?"ALIVE":"DEAD"} color={p.disqualified?"#FF2D55":p.alive?"#34C759":"#555"}/>
                {!p.disqualified&&<button onClick={()=>setDqTarget(p)} style={{fontSize:9,padding:"3px 8px",borderRadius:8,border:"1px solid #FF2D5540",background:"#FF2D5510",color:"#FF2D55",cursor:"pointer",fontFamily:"'Space Mono',monospace",letterSpacing:1}}>🚨 DQ</button>}
              </div>
            </div>
          ))}
        </div>
      )}

      {tab==="safety"&&(
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {/* Bartender authority banner */}
          <div style={{...S.card,background:"#FF2D5510",border:"2px solid #FF2D5530",textAlign:"center",padding:"16px 14px"}}>
            <div style={{fontSize:28,marginBottom:6}}>🚨</div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2,color:"#FF2D55"}}>BARTENDER AUTHORITY</div>
            <div style={{fontSize:11,color:"#888",marginTop:6,lineHeight:1.7}}>You have full authority to issue warnings and disqualify any player who violates conduct rules. Your decision is final.</div>
          </div>

          {/* Quick DQ — big tap targets */}
          <div style={{fontSize:10,color:"#555",letterSpacing:2}}>QUICK DISQUALIFY</div>
          {players.filter(p=>!p.disqualified).length===0&&<div style={{...S.card,textAlign:"center",color:"#444",fontSize:12}}>No active players</div>}
          {players.filter(p=>!p.disqualified).map(p=>(
            <div key={p.id} style={{...S.card,display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:24}}>{p.avatar}</span>
              <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1}}>{p.name}</div><div style={{fontSize:9,color:"#555"}}>{p.hp}hp · {p.kills} kills</div></div>
              <button onClick={()=>setDqTarget(p)} style={{padding:"10px 14px",border:"none",borderRadius:10,background:"linear-gradient(135deg,#FF2D55,#FF6B35)",color:"#fff",fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,cursor:"pointer",boxShadow:"0 3px 12px #FF2D5540"}}>
                🚫 DQ
              </button>
            </div>
          ))}

          {/* Rules summary */}
          <div style={{fontSize:10,color:"#555",letterSpacing:2,marginTop:4}}>KEY RULES REMINDER</div>
          {CONDUCT_RULES.slice(0,5).map(rule=>(
            <div key={rule.id} style={{...S.card,display:"flex",gap:10,alignItems:"flex-start",border:`1px solid ${rule.color}20`}}>
              <span style={{fontSize:18,flexShrink:0}}>{rule.icon}</span>
              <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:"#f0f0f8"}}>{rule.title}</div><div style={{fontSize:10,color:"#555",marginTop:2,lineHeight:1.5}}>{rule.body.slice(0,80)}...</div></div>
              <span style={{fontSize:8,letterSpacing:1,padding:"2px 7px",borderRadius:10,background:rule.severity.includes("INSTANT")?"#FF2D5520":"#FF950020",border:`1px solid ${rule.severity.includes("INSTANT")?"#FF2D5540":"#FF950040"}`,color:rule.severity.includes("INSTANT")?"#FF2D55":"#FF9500",flexShrink:0,fontFamily:"'Space Mono',monospace",whiteSpace:"nowrap"}}>{rule.severity.split(" ")[0]}</span>
            </div>
          ))}

          {/* Zone overrides */}
          <div style={{fontSize:10,color:"#555",letterSpacing:2,marginTop:4}}>📍 PLAY ZONE OVERRIDES</div>
          <ZoneOverridePanel
            players={players}
            exemptions={[]}
            onExempt={pid=>{/* In production: write to shared state */window.alert(`Zone exemption granted for player ${pid}. They can leave the play area temporarily.`);}}
            onRevoke={pid=>{window.alert(`Zone exemption revoked for player ${pid}.`);}}
          />
        </div>
      )}

      {tab==="dqlog"&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {dqLog.length===0&&<div style={{...S.card,textAlign:"center",color:"#444",fontSize:12,lineHeight:1.7}}>No warnings or DQs issued yet.<br/>This log is shared with the game operator.</div>}
          {dqLog.map((entry,i)=>(
            <div key={entry.id||i} style={{...S.card,border:`1px solid ${entry.severity==="instant"?"#FF2D5540":"#FF950040"}`,background:entry.severity==="instant"?"#FF2D5508":"#FF950008"}}>
              <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:6}}>
                <span style={{fontSize:22}}>{entry.playerAvatar}</span>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1}}>{entry.playerName}</div>
                  <div style={{fontSize:9,color:"#555"}}>{new Date(entry.ts).toLocaleTimeString()} · {entry.barName}</div>
                </div>
                <Pill label={entry.severity==="instant"?"DQ'd":"WARNING"} color={entry.severity==="instant"?"#FF2D55":"#FF9500"}/>
              </div>
              <div style={{fontSize:11,color:"#888",background:"#12121a",borderRadius:8,padding:"7px 10px"}}>{entry.reason}</div>
              {entry.notes&&<div style={{fontSize:10,color:"#555",marginTop:5,fontStyle:"italic"}}>"{entry.notes}"</div>}
            </div>
          ))}
        </div>
      )}

      {/* DQ Modal */}
      {dqTarget&&<DQConfirmModal player={dqTarget} onConfirm={handleDQ} onCancel={()=>setDqTarget(null)}/>}

      {/* Handshake QR Overlay */}
      {handshakeItem&&(
        <HandshakeDisplay
          item={handshakeItem}
          barName={bartender.barName}
          onExpired={()=>setHandshakeItem(null)}
          onClose={()=>setHandshakeItem(null)}
        />
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ─── MUSICIAN SCREENS ─────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════
function MusicianLoginScreen({onLogin,onBack}){
  const [u,setU]=useState("");const [p,setP]=useState("");const [err,setErr]=useState("");
  const [showSignup,setShowSignup]=useState(false);
  const login=async()=>{
    let a=MUSICIAN_ACCOUNTS.find(x=>x.username===u.toLowerCase()&&x.password===p);
    if(!a) a=await findSignup("musicians",u,p);
    if(a)onLogin(a);else{setErr("Wrong credentials");setTimeout(()=>setErr(""),1500);}
  };
  if(showSignup)return<MusicianSignup onDone={acc=>onLogin(acc)} onBack={()=>setShowSignup(false)}/>;
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={S.title}>🎸 MUSICIAN LOGIN</div>
      <div style={S.card}>
        <div style={S.label}>USERNAME</div>
        <input style={{...S.input,marginBottom:12}} placeholder="luna / djstatic / brass / ivy" value={u} onChange={e=>setU(e.target.value)}/>
        <div style={S.label}>PASSWORD</div>
        <input style={{...S.input,marginBottom:12}} type="password" placeholder="music123 (demo)" value={p} onChange={e=>setP(e.target.value)} onKeyDown={e=>e.key==="Enter"&&login()}/>
        {err&&<div style={{fontSize:11,color:"#FF2D55",marginBottom:8}}>⚠️ {err}</div>}
        <button style={S.btnPrimary} onClick={login}>SIGN IN →</button>
        <div style={{fontSize:10,color:"#333",textAlign:"center",marginTop:8}}>Demo: luna / music123</div>
      </div>
    </div>
  );
}

function MusicianDash({account,hunt,onLogout}){
  const m=hunt?.musicians?.find(x=>x.id===account.musicianId)||MUSICIANS.find(x=>x.id===account.musicianId);
  const tipLog=(hunt?.tipLog||[]).filter(t=>t.musicianId===account.musicianId);
  const scans=m?.scannedBy?.length||0;
  const tips=((m?.tipPool||0)/100).toFixed(2);
  const base=(scans*(m?.baseFeeCents||200)/100).toFixed(2);
  const total=(parseFloat(tips)+parseFloat(base)).toFixed(2);
  const qr=genQR(m?.id||"MUSC",160);
  return(
    <div style={S.screen}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div style={{display:"flex",gap:12,alignItems:"center"}}>
          <span style={{fontSize:36}}>{m?.av}</span>
          <div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2}}>{m?.name}</div><div style={{fontSize:10,color:"#8855cc"}}>{m?.inst} · {m?.bar}</div></div>
        </div>
        <button style={S.btnGhost} onClick={onLogout}>SIGN OUT</button>
      </div>
      {/* Earnings */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
        <div style={{...S.card,textAlign:"center",background:"#1a0a2e",border:"1px solid #4a2a6a"}}><div style={{fontSize:9,color:"#8855cc",letterSpacing:2,marginBottom:4}}>TIPS TONIGHT</div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:32,color:"#BF5AF2"}}>${tips}</div></div>
        <div style={{...S.card,textAlign:"center",background:"#0a1a0a",border:"1px solid #2a4a2a"}}><div style={{fontSize:9,color:"#34C759",letterSpacing:2,marginBottom:4}}>BASE FEE</div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:32,color:"#34C759"}}>${base}</div></div>
      </div>
      <div style={{...S.card,textAlign:"center",background:"#1a1400",border:"2px solid #FFCC0040"}}>
        <div style={{fontSize:9,color:"#FFCC00",letterSpacing:3,marginBottom:4}}>TOTAL PAYOUT TONIGHT</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:44,color:"#FFCC00",textShadow:"0 0 24px #FFCC0060"}}>${total}</div>
        <div style={{fontSize:10,color:"#555",marginTop:4}}>Auto-paid via Stripe at 23:59</div>
      </div>
      {/* QR */}
      <div style={{...S.card,textAlign:"center"}}>
        <div style={{fontSize:10,color:"#555",letterSpacing:2,marginBottom:12}}>YOUR QR CODE — HIDE IT SOMEWHERE FUN 🎯</div>
        <div style={{background:"#fff",borderRadius:12,padding:14,display:"inline-flex",flexDirection:"column",alignItems:"center",gap:6}}>
          <img src={qr} alt="QR" style={{width:160,height:160,imageRendering:"pixelated"}}/>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:"#000",letterSpacing:3}}>{m?.id}</div>
        </div>
        <div style={{fontSize:11,color:"#555",marginTop:10,lineHeight:1.7}}>Players scan this to find you & claim a reward</div>
      </div>
      {/* Tip feed */}
      <div style={S.card}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
          <div style={{fontSize:10,letterSpacing:2,color:"#555"}}>LIVE TIP FEED</div>
          <div style={{display:"flex",alignItems:"center",gap:5}}><div style={{width:6,height:6,borderRadius:"50%",background:"#BF5AF2",animation:"pulse 1.5s infinite"}}/><span style={{fontSize:9,color:"#BF5AF2"}}>LIVE</span></div>
        </div>
        {tipLog.length===0&&<div style={{textAlign:"center",fontSize:11,color:"#333",padding:12}}>Tips will appear here...</div>}
        {tipLog.slice().reverse().slice(0,5).map((t,i)=>(
          <div key={i} style={{display:"flex",alignItems:"center",gap:8,padding:"8px 0",borderBottom:"1px solid #1a1d2e"}}>
            <span style={{fontSize:18}}>🪙</span>
            <div style={{flex:1}}><div style={{fontSize:11}}>Anonymous tipper</div><div style={{fontSize:9,color:"#555"}}>{new Date(t.ts).toLocaleTimeString()}</div></div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#BF5AF2"}}>+${(t.cents/100).toFixed(2)}</div>
          </div>
        ))}
      </div>
      {/* Reward they carry */}
      {m?.reward&&(()=>{const rm=RARITY[m.reward.rarity||"common"];return(
        <div style={{...S.card,border:`1px solid ${rm.c}30`}}>
          <div style={{fontSize:10,color:"#555",letterSpacing:2,marginBottom:8}}>REWARD YOU'RE CARRYING</div>
          <div style={{display:"flex",alignItems:"center",gap:12}}>
            <span style={{fontSize:36,filter:`drop-shadow(${rm.g})`}}>{m.reward.e}</span>
            <div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:15,color:rm.c}}>{m.reward.n}</div><div style={{fontSize:11,color:"#555"}}>{m.reward.d}</div><div style={{fontSize:9,color:rm.c,letterSpacing:2,marginTop:4}}>{m.reward.rarity?.toUpperCase()}</div></div>
          </div>
        </div>
      );})()}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ─── TEAM COMMS ────────────────────────────────────────────────────────────────
const QUICK_PINGS = [
  {id:"p1", e:"🎯", label:"SPOTTED",    msg:"👁️ SPOTTED enemy nearby!"},
  {id:"p2", e:"🏃", label:"INCOMING",   msg:"🏃 INCOMING — they're heading your way!"},
  {id:"p3", e:"🚩", label:"FLAG",        msg:"🚩 Going for the flag — back me up!"},
  {id:"p4", e:"💀", label:"I'M DOWN",   msg:"💀 I'm down — need revive!"},
  {id:"p5", e:"💊", label:"REVIVE ME",  msg:"❤️ Someone revive me please!"},
  {id:"p6", e:"🍺", label:"AT BAR",     msg:"🍺 I'm at the bar — come get loot codes!"},
  {id:"p7", e:"🛡️", label:"DEFENDING",  msg:"🛡️ Defending the flag — holding position"},
  {id:"p8", e:"📍", label:"MEET HERE",  msg:"📍 Meet me at my location — need backup"},
  {id:"p9", e:"⚡", label:"ATTACK!",    msg:"⚡ ATTACK NOW — I'm flanking left!"},
  {id:"p10",e:"🔇", label:"QUIET",      msg:"🔇 Keep low — hostile in the area"},
];

const CHANNEL_NAMES = {
  all:   {label:"ALL PLAYERS", icon:"📡", color:"#00C7BE"},
  red:   {label:"RED WOLVES",  icon:"🔴", color:"#FF2D55"},
  blue:  {label:"BLUE SHARKS", icon:"🔵", color:"#007AFF"},
  green: {label:"GREEN VIPERS",icon:"🟢", color:"#34C759"},
  gold:  {label:"GOLD EAGLES", icon:"🟡", color:"#FFCC00"},
  ops:   {label:"OPS BOARD",   icon:"⚡", color:"#FF9500"},
};

// ─── QR PRINTER SHOP CARD ────────────────────────────────────────────────────
const QR_PRINTERS = [
  {
    id:"niimbot_b21",
    name:"NIIMBOT B21",
    badge:"BEST VALUE",
    badgeColor:"#34C759",
    emoji:"🖨️",
    price:"$49",
    desc:"Wireless label printer. Prints QR stickers up to 60mm wide. No ink — thermal paper. App controlled. Perfect for printing flag codes and loot codes on demand.",
    features:["📱 App controlled","⚡ Prints in 5 sec","📦 No ink cartridges","🔋 Rechargeable USB-C"],
    url:"https://www.amazon.com/s?k=niimbot+b21+label+printer",
    affiliateNote:"Amazon",
    color:"#34C759",
  },
  {
    id:"brother_ql820",
    name:"BROTHER QL-820NWB",
    badge:"PRO PICK",
    badgeColor:"#FF9500",
    emoji:"🖨️",
    price:"$169",
    desc:"Professional wireless label printer. WiFi + Bluetooth. Prints up to 62mm continuous QR stickers at high speed. Built for bar counter use.",
    features:["📶 WiFi + Bluetooth","🚀 High speed","🏷️ Up to 62mm wide","🏢 Built for counter use"],
    url:"https://www.amazon.com/s?k=brother+ql-820nwb+label+printer",
    affiliateNote:"Amazon",
    color:"#FF9500",
  },
  {
    id:"munbyn_p941",
    name:"MUNBYN P941",
    badge:"POPULAR",
    badgeColor:"#007AFF",
    emoji:"🖨️",
    price:"$79",
    desc:"4-inch thermal label printer. Fast USB + WiFi. Great QR code quality. Compatible with iOS, Android, Windows. Ships with starter label roll.",
    features:["🖥️ USB + WiFi","📱 iOS & Android","🏷️ 4-inch labels","📦 Labels included"],
    url:"https://www.amazon.com/s?k=munbyn+thermal+label+printer",
    affiliateNote:"Amazon",
    color:"#007AFF",
  },
];

function QRPrinterCard({compact=false}){
  const [expanded,setExpanded]=useState(false);
  const [chosen,setChosen]=useState(null);
  const showAll=expanded||!compact;

  return(
    <div style={{...S.card,border:"2px dashed #00C7BE40",background:"#00C7BE06",display:"flex",flexDirection:"column",gap:12}}>
      {/* Header */}
      <div style={{display:"flex",alignItems:"center",gap:10}}>
        <div style={{fontSize:28}}>🖨️</div>
        <div style={{flex:1}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:1,color:"#00C7BE"}}>
            NEED A QR CODE PRINTER?
          </div>
          <div style={{fontSize:11,color:"#555",marginTop:2}}>
            Print flag codes &amp; loot codes instantly at the bar
          </div>
        </div>
        {compact&&(
          <button onClick={()=>setExpanded(e=>!e)} style={{background:"none",border:"1px solid #00C7BE40",borderRadius:8,padding:"5px 10px",color:"#00C7BE",fontFamily:"'Space Mono',monospace",fontSize:10,cursor:"pointer"}}>
            {expanded?"HIDE ↑":"SHOP ↓"}
          </button>
        )}
      </div>

      {showAll&&(<>
        <div style={{fontSize:11,color:"#777",lineHeight:1.7}}>
          Stick printed QR codes on bar mats, menus, or windows so players can scan flags and loot codes without needing a phone input. These printers work straight from the CrawlFire bartender dashboard.
        </div>

        {/* Printer cards */}
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {QR_PRINTERS.map(printer=>(
            <div key={printer.id}
              onClick={()=>setChosen(chosen===printer.id?null:printer.id)}
              style={{
                background:chosen===printer.id?"#12121a":"#0d0e1a",
                border:`2px solid ${chosen===printer.id?printer.color:"#1a1d2e"}`,
                borderRadius:14,padding:"14px 16px",cursor:"pointer",
                transition:"all .2s",
                boxShadow:chosen===printer.id?`0 0 16px ${printer.color}25`:"none",
              }}>
              {/* Top row */}
              <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:chosen===printer.id?10:0}}>
                <div style={{fontSize:26}}>{printer.emoji}</div>
                <div style={{flex:1}}>
                  <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:3}}>
                    <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:15,letterSpacing:1,color:"#f0f0f8"}}>{printer.name}</div>
                    <div style={{background:`${printer.badgeColor}20`,border:`1px solid ${printer.badgeColor}50`,color:printer.badgeColor,fontSize:8,letterSpacing:1,borderRadius:6,padding:"1px 7px",fontFamily:"'Space Mono',monospace"}}>{printer.badge}</div>
                  </div>
                  <div style={{fontSize:11,color:"#555"}}>{printer.desc.slice(0,55)}...</div>
                </div>
                <div style={{textAlign:"right",flexShrink:0}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:printer.color}}>{printer.price}</div>
                  <div style={{fontSize:9,color:"#444",marginTop:2}}>{printer.affiliateNote}</div>
                </div>
              </div>

              {/* Expanded detail */}
              {chosen===printer.id&&(
                <div style={{animation:"popIn .25s ease"}}>
                  <div style={{fontSize:12,color:"#aaa",lineHeight:1.7,marginBottom:10}}>{printer.desc}</div>
                  <div style={{display:"flex",gap:5,flexWrap:"wrap",marginBottom:12}}>
                    {printer.features.map(f=>(
                      <span key={f} style={{fontSize:10,background:`${printer.color}12`,border:`1px solid ${printer.color}30`,color:printer.color,borderRadius:20,padding:"3px 9px"}}>{f}</span>
                    ))}
                  </div>
                  <a
                    href={printer.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      display:"block",textAlign:"center",textDecoration:"none",
                      padding:"13px 0",borderRadius:12,
                      background:`linear-gradient(135deg,${printer.color},${printer.color}99)`,
                      color: printer.color==="#FF9500"||printer.color==="#34C759"||printer.color==="#FFCC00"?"#000":"#fff",
                      fontFamily:"'Black Han Sans',sans-serif",
                      fontSize:16,letterSpacing:2,
                      transition:"all .15s",
                    }}
                    onClick={e=>e.stopPropagation()}
                  >
                    🛒 BUY ON AMAZON →
                  </a>
                  <div style={{fontSize:9,color:"#444",textAlign:"center",marginTop:6}}>
                    Opens Amazon search · CrawlFire may earn a small commission
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* What to print guide */}
        <div style={{background:"#12121a",border:"1px solid #1a1d2e",borderRadius:12,padding:"12px 14px"}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:"#f0f0f8",marginBottom:8}}>WHAT TO PRINT WITH IT</div>
          {[
            {e:"⚑",t:"CTF Flag codes",   d:"Stick on bar mirrors or beer mats"},
            {e:"🎁",t:"Loot code stickers",d:"Print fresh codes per crawl night"},
            {e:"🎵",t:"Musician QR codes", d:"Place where musicians are hiding"},
            {e:"📸",t:"Player target QRs", d:"Print spares if someone forgets theirs"},
          ].map((x,i)=>(
            <div key={i} style={{display:"flex",gap:8,alignItems:"center",padding:"5px 0",borderBottom:i<3?"1px solid #1a1d2e":"none"}}>
              <span style={{fontSize:16,flexShrink:0}}>{x.e}</span>
              <div style={{flex:1}}><span style={{fontSize:12,fontFamily:"'Black Han Sans',sans-serif",color:"#f0f0f8"}}>{x.t}</span><span style={{fontSize:10,color:"#555",marginLeft:6}}>{x.d}</span></div>
            </div>
          ))}
        </div>
      </>)}
    </div>
  );
}

// ─── BAR OWNER / PARTNER SCREENS ──────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════
function BarOwnerLanding({onSignUp,onLogin,onBack}){
  return(
    <div style={{...S.screen,gap:20}}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={{textAlign:"center"}}>
        <div style={{fontSize:52,marginBottom:8}}>🏪</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:32,letterSpacing:3,color:"#f0f0f8",lineHeight:1}}>TURN YOUR BAR<br/><span style={{color:"#FF9500"}}>INTO A BATTLEGROUND</span></div>
        <div style={{fontSize:12,color:"#666",marginTop:10,lineHeight:1.8}}>Earn in-game coins every time crawl groups visit, tip musicians, and redeem loot codes at your venue.</div>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
        {[{e:"🎮",l:"Per crawl",v:"$5–$12"},{e:"🎁",l:"Per code",v:"$0.50–$1"},{e:"🤝",l:"Per referral",v:"$25–$60"},{e:"📈",l:"Rev share",v:"15–25%"}].map((x,i)=>(
          <div key={i} style={{...S.card,textAlign:"center"}}><div style={{fontSize:28,marginBottom:4}}>{x.e}</div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:"#FF9500"}}>{x.v}</div><div style={{fontSize:10,color:"#555",marginTop:2}}>{x.l}</div></div>
        ))}
      </div>
      <button style={S.btnPrimary} onClick={onSignUp}>JOIN FREE →</button>
      <button style={{...S.btnGhost,width:"100%",padding:12}} onClick={onLogin}>I'm already a partner</button>
      <div style={{...S.card,display:"flex",flexDirection:"column",gap:6}}>
        {Object.entries(TIERS).reverse().map(([key,t])=>(
          <div key={key} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:"1px solid #1a1d2e"}}>
            <Pill label={t.label} color={t.c}/>
            <div style={{flex:1,fontSize:11,color:"#888"}}>{t.perks[0]}</div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:t.c}}>{t.rate}%</div>
          </div>
        ))}
      </div>
      <QRPrinterCard/>
    </div>
  );
}

function BarSignup({onDone,onBack}){
  // Show our new full signup flow
  return <BarPartnerSignup onDone={onDone} onBack={onBack}/>;
}
function BarSignupLegacy({onDone,onBack}){
  const [step,setStep]=useState(1);
  const [barName,setBarName]=useState("");
  const [area,setArea]=useState("");
  const [email,setEmail]=useState("");
  const [refCode,setRefCode]=useState("");
  const [refValid,setRefValid]=useState(null);
  const checkRef=v=>{setRefCode(v.toUpperCase());const m=BAR_ACCOUNTS.find(b=>b.refCode===v.toUpperCase());setRefValid(v.length>=6?(m?m.barName:false):null);};
  const generatedCode=barName.split(" ").map(w=>w[0]).join("").toUpperCase().slice(0,3)+(Math.floor(Math.random()*90+10));
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={S.title}>🏪 JOIN AS A PARTNER</div>
      <div style={{display:"flex",gap:6,justifyContent:"center"}}>
        {[1,2,3].map(n=><div key={n} style={{width:10,height:10,borderRadius:"50%",background:step>=n?"#FF9500":"#2a2a3a",transition:"all .3s",boxShadow:step>=n?"0 0 8px #FF950060":"none"}}/>)}
      </div>
      {step===1&&<div style={{display:"flex",flexDirection:"column",gap:12}}>
        <div><div style={S.label}>BAR / VENUE NAME</div><input style={S.input} placeholder="e.g. The Rusty Anchor" value={barName} onChange={e=>setBarName(e.target.value)}/></div>
        <div><div style={S.label}>AREA</div><input style={S.input} placeholder="e.g. Shoreditch, London" value={area} onChange={e=>setArea(e.target.value)}/></div>
        <div><div style={S.label}>REFERRAL CODE (optional)</div><input style={S.input} placeholder="Ask another partner bar" value={refCode} onChange={e=>checkRef(e.target.value)} maxLength={8}/>
          {typeof refValid==="string"&&<div style={{fontSize:11,color:"#34C759",marginTop:4}}>✅ Referred by: {refValid}</div>}
          {refValid===false&&<div style={{fontSize:11,color:"#FF2D55",marginTop:4}}>❌ Invalid code</div>}
        </div>
        <button style={{...S.btnGold,opacity:barName.trim()&&area.trim()?1:.4}} disabled={!barName.trim()||!area.trim()} onClick={()=>setStep(2)}>NEXT →</button>
      </div>}
      {step===2&&<div style={{display:"flex",flexDirection:"column",gap:12}}>
        <div><div style={S.label}>YOUR EMAIL</div><input style={S.input} type="email" placeholder="manager@yourbar.com" value={email} onChange={e=>setEmail(e.target.value)}/></div>
        <div><div style={S.label}>CHOOSE A PASSWORD</div><input style={S.input} type="password" placeholder="••••••••"/></div>
        <div style={{fontSize:11,color:"#444",lineHeight:1.6}}>By signing up you agree to the CrawlFire Partner Terms &amp; Revenue Share Agreement.</div>
        <button style={{...S.btnGold,opacity:email.trim()?1:.4}} disabled={!email.trim()} onClick={()=>setStep(3)}>CREATE ACCOUNT →</button>
      </div>}
      {step===3&&<div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:14,textAlign:"center"}}>
        <div style={{fontSize:56,animation:"popIn .5s ease"}}>🎉</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:24,color:"#FF9500"}}>Welcome, {barName}!</div>
        <div style={{fontSize:12,color:"#888",lineHeight:1.8,maxWidth:280}}>You're enrolled as a <strong style={{color:"#cd7f32"}}>Bronze</strong> partner. Your referral code is ready to share.</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:44,letterSpacing:6,color:"#FF9500",background:"#FF950015",border:"2px solid #FF9500",borderRadius:14,padding:"14px 24px",textShadow:"0 0 20px #FF950060"}}>{generatedCode}</div>
        <div style={{fontSize:10,color:"#555",letterSpacing:2}}>YOUR REFERRAL CODE</div>
        <button style={S.btnGold} onClick={onDone}>GO TO DASHBOARD →</button>
      </div>}
    </div>
  );
}

function BarDashboard({bar,onLogout}){
  const [tab,setTab]=useState("overview");
  const [copied,setCopied]=useState(false);
  const tier=TIERS[bar.tier];
  const nextTierKey=bar.tier==="bronze"?"silver":bar.tier==="silver"?"gold":null;
  const nextTier=nextTierKey?TIERS[nextTierKey]:null;
  const toNext=nextTier?nextTier.min-bar.earned:0;
  const copy=()=>{setCopied(true);setTimeout(()=>setCopied(false),2000);};
  return(
    <div style={S.screen}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1}}>{bar.emoji} {bar.barName}</div><Pill label={tier.label} color={tier.c}/></div>
        <button style={S.btnGhost} onClick={onLogout}>SIGN OUT</button>
      </div>
      <div style={{display:"flex",gap:6}}>
        {[["overview","📊"],["earnings","💰"],["referrals","🤝"],["leaderboard","🏆"]].map(([id,e])=>(
          <button key={id} onClick={()=>setTab(id)} style={{flex:1,padding:"8px 4px",border:`2px solid ${tab===id?"#FF9500":"#2a2a3a"}`,borderRadius:10,background:tab===id?"#FF950015":"#0d0e1a",color:tab===id?"#FF9500":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:14,cursor:"pointer"}}>{e}</button>
        ))}
      </div>
      {tab==="overview"&&(<>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <div style={{...S.card,textAlign:"center"}}><div style={{fontSize:9,color:"#555",letterSpacing:2,marginBottom:4}}>TOTAL EARNED</div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:32,color:"#FF9500"}}>${bar.earned}</div></div>
          <div style={{...S.card,textAlign:"center",background:"#0a1a0a",border:"1px solid #2a4a2a"}}><div style={{fontSize:9,color:"#34C759",letterSpacing:2,marginBottom:4}}>PENDING</div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:32,color:"#34C759"}}>${bar.pending}</div></div>
        </div>
        {nextTier&&<div style={S.card}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}><Pill label={tier.label} color={tier.c}/><Pill label={`Next: ${nextTier.label}`} color={nextTier.c}/></div>
          <div style={{height:8,background:"#2a2a3a",borderRadius:4,overflow:"hidden",marginBottom:6}}><div style={{height:"100%",width:`${Math.min(100,bar.earned/nextTier.min*100)}%`,background:tier.c,borderRadius:4,transition:"width .6s"}}/></div>
          <div style={{fontSize:11,color:"#555"}}>${bar.earned} / ${nextTier.min} — ${toNext} to unlock {nextTierKey}</div>
        </div>}
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>
          {[{e:"🎮",v:bar.crawls,l:"Crawls"},{e:"👥",v:bar.players||"—",l:"Players"},{e:"🎁",v:bar.codes,l:"Codes"},{e:"🤝",v:bar.refs,l:"Refs"}].map((s,i)=>(
            <div key={i} style={{...S.card,textAlign:"center"}}><div style={{fontSize:20,marginBottom:4}}>{s.e}</div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:"#FF9500"}}>{s.v}</div><div style={{fontSize:9,color:"#555",marginTop:2}}>{s.l}</div></div>
          ))}
        </div>
        <div style={{...S.card,background:"#FF950010",border:"1px solid #FF950030"}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:"#FF9500",marginBottom:6}}>🔥 {bar.streak} WEEK STREAK {bar.streak>=4?"· +20% BONUS ACTIVE!":""}</div>
          <div style={{display:"flex",gap:5}}>{Array.from({length:8},(_,i)=><div key={i} style={{width:12,height:12,borderRadius:"50%",background:i<bar.streak?"#FF9500":"#2a2a3a",boxShadow:i<bar.streak?"0 0 6px #FF950080":"none"}}/>)}</div>
        </div>
        <div style={{...S.card,border:"1px solid #FFCC0030"}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:"#FFCC00",marginBottom:6}}>🤝 YOUR REFERRAL CODE</div>
          <div style={{display:"flex",gap:8}}>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:28,letterSpacing:5,color:"#FFCC00",background:"#FFCC0010",border:"1px solid #FFCC0040",borderRadius:10,padding:"8px 16px",flex:1,textAlign:"center"}}>{bar.refCode}</div>
            <button onClick={copy} style={{background:"#FFCC00",border:"none",borderRadius:10,padding:"0 16px",fontFamily:"'Black Han Sans',sans-serif",fontSize:12,color:"#000",cursor:"pointer"}}>{copied?"✓":"COPY"}</button>
          </div>
          <div style={{fontSize:10,color:"#555",marginTop:6}}>Earn ${tier.perRef} per bar you refer that goes live</div>
        </div>
        <QRPrinterCard compact/>
      </>)}
      {tab==="earnings"&&(<>
        <div style={S.card}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,marginBottom:10}}>HOW YOU EARN AT {tier.label}</div>
          {[{e:"🎮",l:"Per crawl hosted",v:`${fmt(tier.perCrawl)}/crawl`},{e:"🎁",l:"Per loot code",v:`${fmt(tier.perCode)}/code`},{e:"🤝",l:"Per referral",v:`${fmt(tier.perRef)}/ref`},{e:"📈",l:"Revenue share",v:`${tier.rate}%`}].map((x,i)=>(
            <div key={i} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 0",borderBottom:"1px solid #1a1d2e"}}>
              <span style={{fontSize:22}}>{x.e}</span>
              <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1}}>{x.l}</div></div>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#FF9500"}}>{x.v}</div>
            </div>
          ))}
        </div>
        {nextTierKey&&<div style={{...S.card,border:`1px solid ${nextTier.c}40`,background:`${nextTier.c}08`}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:nextTier.c,marginBottom:6}}>🚀 UNLOCK {nextTier.label}</div>
          <div style={{fontSize:12,color:"#888",lineHeight:1.7}}>Earn ${toNext} more to get {nextTier.rate}% rev share, {fmt(nextTier.perCode)}/code and {fmt(nextTier.perRef)}/referral</div>
        </div>}
      </>)}
      {tab==="referrals"&&(<>
        <div style={{...S.card,textAlign:"center",background:"#FF950010",border:"1px solid #FF950030"}}>
          <div style={{fontSize:42,marginBottom:8}}>🤝</div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,color:"#FF9500"}}>REFER &amp; EARN</div>
          <div style={{fontSize:12,color:"#888",marginTop:6,lineHeight:1.7}}>Every bar you bring on earns you <strong style={{color:"#FFCC00"}}>${tier.perRef}</strong> when they go live. No cap.</div>
        </div>
        <div style={{...S.card}}>
          <div style={{fontSize:10,color:"#555",letterSpacing:2,marginBottom:6,textAlign:"center"}}>YOUR CODE</div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:44,letterSpacing:8,color:"#FFCC00",textAlign:"center",textShadow:"0 0 24px #FFCC0060"}}>{bar.refCode}</div>
          <div style={{display:"flex",gap:8,marginTop:10}}>
            {["📧 Email","📱 WhatsApp","🔗 Copy Link"].map(b=><button key={b} style={{flex:1,padding:9,border:"1px solid #2a2a3a",borderRadius:8,background:"none",color:"#666",fontFamily:"'Space Mono',monospace",fontSize:9,cursor:"pointer"}}>{b}</button>)}
          </div>
        </div>
        <div style={S.card}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,marginBottom:10}}>REFERRAL MULTIPLIERS</div>
          {[["1–2 referrals","Standard","1×",bar.refs>=1],["3–5 referrals","Bonus","1.25×",bar.refs>=3],["6+ referrals","Elite","1.5×",bar.refs>=6]].map(([l,d,m,active])=>(
            <div key={l} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 10px",borderRadius:10,border:`1px solid ${active?"#FF9500":"#2a2a3a"}`,background:active?"#FF950010":"transparent",marginBottom:6}}>
              <div style={{flex:1}}><div style={{fontSize:12,color:"#f0f0f8"}}>{l}</div><div style={{fontSize:10,color:"#555"}}>{d}</div></div>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,color:active?"#FFCC00":"#555"}}>{m}</div>
            </div>
          ))}
        </div>
      </>)}
      {tab==="leaderboard"&&(<>
        <div style={{...S.card,textAlign:"center",background:"#FFCC0010",border:"1px solid #FFCC0030"}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:"#FFCC00",letterSpacing:2}}>🏆 PARTNER RANKINGS</div>
          <div style={{fontSize:10,color:"#555",marginTop:4}}>By total earnings</div>
        </div>
        {[...BAR_ACCOUNTS].sort((a,b)=>b.earned-a.earned).map((b,i)=>(
          <div key={b.username} style={{...S.card,display:"flex",alignItems:"center",gap:10,border:`1px solid ${b.username===bar.username?"#FF9500":"#1a1d2e"}`,background:b.username===bar.username?"#FF950010":"#0d0e1a"}}>
            <div style={{fontSize:20,width:28,textAlign:"center"}}>{["🥇","🥈","🥉"][i]||`#${i+1}`}</div>
            <span style={{fontSize:22}}>{b.emoji}</span>
            <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1}}>{b.barName}{b.username===bar.username&&<span style={{fontSize:9,color:"#FF9500",marginLeft:6}}>YOU</span>}</div><div style={{fontSize:10,color:"#555"}}>{b.crawls} crawls · {b.refs} refs</div></div>
            <div style={{textAlign:"right"}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:"#FF9500"}}>${b.earned}</div><Pill label={TIERS[b.tier].label} color={TIERS[b.tier].c}/></div>
          </div>
        ))}
      </>)}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ─── OPERATOR SETTLEMENT DASHBOARD ────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════
function OperatorDash({game,onBack}){
  const [tab,setTab]=useState("settlement");
  const [log,setLog]=useState([]);
  const [running,setRunning]=useState(false);
  const [done,setDone]=useState(false);
  const [timeStr,setTimeStr]=useState("");
  const [nextRun,setNextRun]=useState("");
  const [dayData]=useState(()=>BAR_ACCOUNTS.map(bar=>{
    const rates=TIERS[bar.tier],crawls=Math.floor(Math.random()*6)+2,players=crawls*(Math.floor(Math.random()*8)+4),entryRev=players*(Math.random()<.5?5:8),codes=Math.floor(Math.random()*20)+2,hasStreak=Math.random()>.5;
    const sub=crawls*rates.perCrawl+codes*rates.perCode+entryRev*rates.rate/100,bonus=hasStreak?sub*.2:0;
    return{...bar,crawls,players,entryRev,codes,hasStreak,total:sub+bonus,platformCut:entryRev*.3,status:"pending"};
  }));
  const [data,setData]=useState(dayData);
  useEffect(()=>{const tick=()=>{const now=new Date();setTimeStr(now.toLocaleTimeString("en-US",{hour12:false}));const mid=new Date(now);mid.setHours(23,59,0,0);const diff=mid-now;if(diff>0){const h=Math.floor(diff/3600000),m=Math.floor((diff%3600000)/60000),s=Math.floor((diff%60000)/1000);setNextRun(`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`);}}; tick();const id=setInterval(tick,1000);return()=>clearInterval(id);},[]);
  const addLog=(msg,type)=>setLog(l=>[...l,{msg,type,ts:new Date().toLocaleTimeString("en-US",{hour12:false})}]);
  const runPayouts=async()=>{
    if(running)return; setRunning(true); setLog([]);
    addLog("🚀 Daily settlement initiated","info"); await sleep(600);
    addLog(`🎮 ${data.length} bars to process`,"info"); await sleep(400);
    addLog("🏦 Connecting to Stripe Connect...","info"); await sleep(800);
    addLog("✅ Stripe authenticated","success"); await sleep(300);
    const updated=[...data];
    for(let i=0;i<updated.length;i++){
      updated[i]={...updated[i],status:"processing"};setData([...updated]);
      addLog(`⚡ Processing ${updated[i].barName}...`,"info"); await sleep(700+Math.random()*400);
      const ok=Math.random()>.05;
      updated[i]={...updated[i],status:ok?"paid":"failed"};setData([...updated]);
      if(ok)addLog(`✅ Transferred $${updated[i].total.toFixed(2)} → ${updated[i].barName}`,"success");
      else  addLog(`❌ FAILED ${updated[i].barName}: Transfer declined`,"error");
      await sleep(200);
    }
    await sleep(400);
    const paid=updated.filter(b=>b.status==="paid"),failed=updated.filter(b=>b.status==="failed");
    addLog(`──────────────────────`,"divider");
    addLog(`✅ ${paid.length} payouts successful`,"success");
    if(failed.length)addLog(`❌ ${failed.length} failed — retrying tomorrow`,"error");
    addLog(`💰 Platform earned: $${updated.reduce((s,b)=>s+b.platformCut,0).toFixed(2)}`,"owner");
    addLog("🎉 Settlement complete","success");
    setRunning(false);setDone(true);
  };
  const statusC={pending:"#555",processing:"#FF9500",paid:"#34C759",failed:"#FF2D55"};
  const statusL={pending:"QUEUED",processing:"PROCESSING",paid:"PAID",failed:"FAILED"};
  const totalOut=data.filter(b=>b.status==="paid").reduce((s,b)=>s+b.total,0);
  const totalPlat=data.reduce((s,b)=>s+b.platformCut,0);
  return(
    <div style={S.screen}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2}}>⚡ OPERATOR DASHBOARD</div>
        <button style={S.btnGhost} onClick={onBack}>← EXIT</button>
      </div>
      <div style={{display:"flex",gap:6}}>
        {[["settlement","⚡ SETTLE"],["history","📋 HISTORY"],["split","💰 P&L"]].map(([id,label])=>(
          <button key={id} onClick={()=>setTab(id)} style={{flex:1,padding:9,border:`2px solid ${tab===id?"#34C759":"#2a2a3a"}`,borderRadius:10,background:tab===id?"#34C75915":"#0d0e1a",color:tab===id?"#34C759":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:11,cursor:"pointer"}}>{label}</button>
        ))}
      </div>
      {tab==="settlement"&&(<>
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
          {[{l:"PAID OUT",v:`$${totalOut.toFixed(2)}`,c:"#34C759"},{l:"PLATFORM",v:`$${totalPlat.toFixed(2)}`,c:"#FF9500"},{l:"FAILED",v:data.filter(b=>b.status==="failed").length,c:"#FF2D55"}].map((k,i)=>(
            <div key={i} style={{...S.card,textAlign:"center"}}><div style={{fontSize:9,color:"#555",letterSpacing:2,marginBottom:4}}>{k.l}</div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:24,color:k.c}}>{k.v}</div></div>
          ))}
        </div>
        {data.map(bar=>(
          <div key={bar.username} style={{...S.card}}>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
              <span style={{fontSize:22}}>{bar.emoji}</span>
              <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1}}>{bar.barName}</div><div style={{fontSize:10,color:"#555"}}>{bar.crawls} crawls · {bar.codes} codes · {bar.hasStreak?"🔥 streak":"no streak"}</div></div>
              <div style={{textAlign:"right"}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:"#34C759"}}>${bar.total.toFixed(2)}</div><div style={{fontSize:10,color:statusC[bar.status],letterSpacing:1,marginTop:2}}>{statusL[bar.status]}</div></div>
            </div>
            <div style={{height:3,background:"#2a2a3a",borderRadius:2,overflow:"hidden"}}><div style={{height:"100%",width:bar.status==="paid"?"100%":bar.status==="processing"?"50%":"0%",background:statusC[bar.status],borderRadius:2,transition:"width .5s"}}/></div>
          </div>
        ))}
        <div style={{...S.card}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:8,fontSize:10,color:"#555",letterSpacing:1}}>
            <span>PAYOUT LOG</span>
            <div style={{display:"flex",alignItems:"center",gap:5}}><div style={{width:6,height:6,borderRadius:"50%",background:running?"#34C759":"#2a2a3a",boxShadow:running?"0 0 6px #34C75980":"none"}}/><span style={{color:running?"#34C759":"#555"}}>LIVE</span></div>
          </div>
          <div style={{maxHeight:180,overflowY:"auto",display:"flex",flexDirection:"column",gap:3}}>
            {log.length===0&&<div style={{fontSize:11,color:"#333",textAlign:"center",padding:12}}>Log appears here during payout run</div>}
            {log.map((l,i)=>l.type==="divider"?<div key={i} style={{height:1,background:"#2a2a3a",margin:"3px 0"}}/>:
              <div key={i} style={{display:"flex",gap:8,fontFamily:"'Space Mono',monospace",fontSize:10}}>
                <span style={{color:"#333",flexShrink:0}}>{l.ts}</span>
                <span style={{color:l.type==="success"?"#34C759":l.type==="error"?"#FF2D55":l.type==="owner"?"#FFCC00":l.type==="warn"?"#FF9500":"#555"}}>{l.msg}</span>
              </div>
            )}
          </div>
        </div>
        <div style={{...S.card,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
          <div><div style={{fontSize:10,color:"#555",letterSpacing:1}}>NEXT AUTO-RUN</div><div style={{fontFamily:"'Space Mono',monospace",fontSize:16,color:"#34C759"}}>{nextRun}</div></div>
          <button onClick={runPayouts} disabled={running||done} style={{padding:"12px 20px",border:"none",borderRadius:12,background:done?"#34C75920":running?"#2a2a3a":"linear-gradient(135deg,#34C759,#00C7BE)",color:done?"#34C759":running?"#555":"#000",fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:2,cursor:running||done?"not-allowed":"pointer"}}>
            {done?"✅ DONE":running?"RUNNING...":"▶ RUN NOW"}
          </button>
        </div>
      </>)}
      {tab==="history"&&(<>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2}}>5-DAY HISTORY</div>
        {[{d:"2024-06-14",paid:4,failed:0,bars:312.40,platform:134.20},{d:"2024-06-13",paid:5,failed:0,bars:398.80,platform:171.10},{d:"2024-06-12",paid:4,failed:1,bars:274.50,platform:117.80},{d:"2024-06-11",paid:5,failed:0,bars:441.20,platform:189.50},{d:"2024-06-10",paid:3,failed:0,bars:218.60,platform:93.80}].map((h,i)=>(
          <div key={i} style={S.card}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:6}}>
              <div style={{fontFamily:"'Space Mono',monospace",fontSize:13,color:"#f0f0f8"}}>{h.d}</div>
              <div style={{display:"flex",gap:6}}>
                <Pill label={`${h.paid} PAID`} color="#34C759"/>
                {h.failed>0&&<Pill label={`${h.failed} FAILED`} color="#FF2D55"/>}
              </div>
            </div>
            <div style={{display:"flex",justifyContent:"space-between",fontSize:13}}>
              <span style={{color:"#555"}}>Bars: <span style={{color:"#34C759",fontFamily:"'Black Han Sans',sans-serif"}}>${h.bars}</span></span>
              <span style={{color:"#555"}}>Platform: <span style={{color:"#FF9500",fontFamily:"'Black Han Sans',sans-serif"}}>${h.platform}</span></span>
              <span style={{color:"#555"}}>Total: <span style={{color:"#00C7BE",fontFamily:"'Black Han Sans',sans-serif"}}>${(h.bars+h.platform).toFixed(2)}</span></span>
            </div>
          </div>
        ))}
      </>)}
      {tab==="split"&&(<>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2}}>REVENUE SPLIT</div>
        <div style={S.card}>
          <div style={{fontSize:10,color:"#555",letterSpacing:2,marginBottom:10}}>EVERY 1,000 COINS EARNED</div>
          <div style={{display:"flex",height:40,borderRadius:8,overflow:"hidden",gap:2}}>
            {[{l:"Platform 30%",p:30,c:"#FF9500"},{l:"Gold 25%",p:25,c:"#FFCC00"},{l:"Silver 20%",p:20,c:"#aaaaaa"},{l:"Bronze 15%",p:15,c:"#cd7f32"},{l:"Costs 10%",p:10,c:"#2a2a3a"}].map((s,i)=>(
              <div key={i} style={{flex:s.p,background:s.c,display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,color:i>3?"#666":"#000",fontWeight:700}}>{s.p>=15?`${s.p}%`:""}</div>
            ))}
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:8,marginTop:10}}>
            {[{c:"#FF9500",l:"Platform 30%"},{c:"#FFCC00",l:"Gold 25%"},{c:"#aaaaaa",l:"Silver 20%"},{c:"#cd7f32",l:"Bronze 15%"},{c:"#2a2a3a",l:"Other 10%"}].map((x,i)=>(
              <div key={i} style={{display:"flex",alignItems:"center",gap:5,fontSize:10,color:"#666"}}><div style={{width:8,height:8,borderRadius:2,background:x.c}}/>{x.l}</div>
            ))}
          </div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
          {[{l:"MONTHLY PLATFORM",v:"$706",c:"#FF9500",s:"+18% MoM"},{l:"MONTHLY PAYOUTS",v:"$1,645",c:"#34C759",s:"To all bars"},{l:"NET REVENUE",v:"$706",c:"#00C7BE",s:"After payouts"}].map((k,i)=>(
            <div key={i} style={{...S.card,textAlign:"center"}}><div style={{fontSize:9,color:"#555",letterSpacing:1,marginBottom:4}}>{k.l}</div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:k.c}}>{k.v}</div><div style={{fontSize:9,color:"#34C759",marginTop:2}}>{k.s}</div></div>
          ))}
        </div>
      </>)}
    </div>
  );
}


// ═══════════════════════════════════════════════════════════════════════════════
// ─── CTF SCREENS ─────────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════

const fmtT=ms=>{const s=Math.floor(ms/1000),m=Math.floor(s/60);return m>0?`${m}m ${s%60}s`:`${s}s`;};

function CTFTeamBadge({teamId,size="sm"}){
  const t=CTF_TEAMS.find(x=>x.id===teamId);if(!t)return null;
  return<span style={{background:t.bg,border:`1px solid ${t.color}60`,color:t.color,borderRadius:20,padding:size==="lg"?"6px 14px":"3px 9px",fontFamily:"'Black Han Sans',sans-serif",fontSize:size==="lg"?13:10,letterSpacing:1.5,whiteSpace:"nowrap"}}>{t.emoji} {t.name}</span>;
}

function CTFHomeScreen({ctfGame,onSetup,onJoin,onBack}){
  const hasGame=ctfGame&&ctfGame.status==="active";
  return(
    <div style={{...S.screen,alignItems:"center",textAlign:"center",gap:20}}>
      <button style={{...S.btnGhost,alignSelf:"flex-start"}} onClick={onBack}>← BACK</button>
      <div style={{fontSize:64,filter:"drop-shadow(0 0 20px #007AFF)",animation:"breathe 3s ease-in-out infinite"}}>⚑</div>
      <div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:40,letterSpacing:4,color:"#f0f0f8",textShadow:"0 0 30px #007AFF"}}>CRAWL<span style={{color:"#007AFF"}}>FIRE</span></div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:3,color:"#007AFF",marginTop:2}}>CAPTURE THE FLAG</div>
      </div>
      <div style={{...S.card,width:"100%",display:"flex",flexDirection:"column",gap:8}}>
        {[{e:"🚩",t:"Flags hidden at partner bars",d:"Each bar has a unique QR code to scan"},{e:"📸",t:"Scan to capture for your team",d:"Live broadcast to all players instantly"},{e:"🔥",t:"Steal from enemies",d:"+25 bonus pts to steal a held flag"},{e:"⏱️",t:"Hold flags to keep scoring",d:"+10 pts per minute per flag held"},{e:"🏆",t:"Most points wins",d:"Live leaderboard throughout the crawl"}].map((r,i)=>(
          <div key={i} style={{display:"flex",gap:10,alignItems:"center",padding:"7px 0",borderBottom:i<4?"1px solid #1a1d2e":"none"}}>
            <span style={{fontSize:20,flexShrink:0}}>{r.e}</span>
            <div style={{textAlign:"left"}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1}}>{r.t}</div><div style={{fontSize:10,color:"#555",marginTop:1}}>{r.d}</div></div>
          </div>
        ))}
      </div>
      <div style={{display:"flex",gap:8,width:"100%"}}>
        <button style={{...S.btnPrimary,flex:2,background:"linear-gradient(135deg,#007AFF,#BF5AF2)"}} onClick={onSetup}>⚑ HOST A GAME</button>
        <button style={{...S.btnPrimary,flex:1,background:"#1a1d2e",color:"#007AFF",border:"2px solid #007AFF40",fontSize:14}} onClick={()=>{if(hasGame)onJoin();else alert("No active CTF game. Host one first!");}}>JOIN</button>
      </div>
    </div>
  );
}

function CTFSetupScreen({setup,setSetup,step,setStep,onLaunch,onBack}){
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={S.title}>⚑ SET UP CTF GAME</div>
      {step===1&&(
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <div><div style={S.label}>GAME NAME</div><input style={S.input} placeholder="e.g. Saturday Night Crawl" value={setup.name} onChange={e=>setSetup(s=>({...s,name:e.target.value}))} maxLength={30}/></div>
          <div>
            <div style={S.label}>NUMBER OF TEAMS</div>
            <div style={{display:"flex",gap:8}}>
              {[2,3,4].map(n=><button key={n} onClick={()=>setSetup(s=>({...s,teamCount:n}))} style={{flex:1,padding:"14px 8px",borderRadius:12,border:`2px solid ${setup.teamCount===n?"#007AFF":"#2a2a3a"}`,background:setup.teamCount===n?"#007AFF15":"#12121a",cursor:"pointer",fontFamily:"'Black Han Sans',sans-serif",fontSize:28,color:setup.teamCount===n?"#007AFF":"#f0f0f8"}}>{n}<div style={{fontSize:10,color:"#555",marginTop:2}}>teams</div></button>)}
            </div>
            <div style={{display:"flex",gap:6,flexWrap:"wrap",marginTop:8}}>
              {CTF_TEAMS.slice(0,setup.teamCount).map(t=><span key={t.id} style={{background:t.bg,border:`1px solid ${t.color}60`,color:t.color,borderRadius:20,padding:"4px 12px",fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1}}>{t.emoji} {t.name}</span>)}
            </div>
          </div>
          <div>
            <div style={S.label}>FLAGS (bars on route)</div>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              {[3,4,5,6,8].map(n=><button key={n} onClick={()=>setSetup(s=>({...s,flagCount:n}))} style={{padding:"10px 16px",borderRadius:10,border:`2px solid ${setup.flagCount===n?"#FFCC00":"#2a2a3a"}`,background:setup.flagCount===n?"#FFCC0015":"#12121a",cursor:"pointer",fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:setup.flagCount===n?"#FFCC00":"#f0f0f8"}}>{n}</button>)}
            </div>
            <div style={{marginTop:8,display:"flex",flexWrap:"wrap",gap:5}}>
              {CTF_FLAG_NAMES.slice(0,setup.flagCount).map((n,i)=><span key={i} style={{fontSize:10,background:"#0d0e1a",border:"1px solid #2a2a3a",borderRadius:8,padding:"2px 8px",color:"#555"}}>🚩 {n}</span>)}
            </div>
          </div>
          <button style={S.btnPrimary} onClick={()=>setStep(2)}>PREVIEW →</button>
        </div>
      )}
      {step===2&&(
        <div style={{display:"flex",flexDirection:"column",gap:12}}>
          <div style={{...S.card,textAlign:"center"}}><div style={S.label}>GAME NAME</div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:"#f0f0f8"}}>{setup.name||"CRAWLFIRE CTF"}</div></div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
            {[{l:"TEAMS",v:setup.teamCount,c:"#007AFF"},{l:"FLAGS",v:setup.flagCount,c:"#FFCC00"},{l:"WIN",v:"POINTS",c:"#34C759"}].map((x,i)=>(
              <div key={i} style={{...S.card,textAlign:"center"}}><div style={S.label}>{x.l}</div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:28,color:x.c}}>{x.v}</div></div>
            ))}
          </div>
          <div style={{...S.card,display:"flex",flexDirection:"column",gap:8}}>
            {CTF_TEAMS.slice(0,setup.teamCount).map(t=>(
              <div key={t.id} style={{display:"flex",alignItems:"center",gap:10,background:t.bg,border:`1px solid ${t.color}40`,borderRadius:10,padding:"10px 14px"}}>
                <span style={{fontSize:24}}>{t.emoji}</span>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:15,letterSpacing:1,color:t.color}}>{t.name}</div>
              </div>
            ))}
          </div>
          <div style={{display:"flex",gap:8}}>
            <button style={{...S.btnGhost,flex:1}} onClick={()=>setStep(1)}>← EDIT</button>
            <button style={{...S.btnPrimary,flex:2,background:"linear-gradient(135deg,#007AFF,#BF5AF2)"}} onClick={onLaunch}>🚀 LAUNCH CTF!</button>
          </div>
        </div>
      )}
    </div>
  );
}

function CTFJoinScreen({ctfGame,onJoin,onBack}){
  const [name,setName]=useState("");
  const [avatar,setAvatar]=useState("⚡");
  const [teamId,setTeamId]=useState(ctfGame?.teams?.[0]?.id||"red");
  const avs=["⚡","💀","🔥","🎯","💣","🦊","🐺","👊","🗡️","🛡️"];
  const teams=ctfGame?.teams||CTF_TEAMS.slice(0,2);
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={S.title}>⚑ JOIN THE BATTLE</div>
      <div><div style={S.label}>YOUR CALLSIGN</div><input style={S.input} placeholder="ENTER NAME" maxLength={12} value={name} onChange={e=>setName(e.target.value.toUpperCase())}/></div>
      <div>
        <div style={S.label}>AVATAR</div>
        <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
          {avs.map(a=><button key={a} onClick={()=>setAvatar(a)} style={{fontSize:24,background:"#0d0e1a",border:`2px solid ${avatar===a?"#007AFF":"#2a2a3a"}`,borderRadius:10,padding:8,cursor:"pointer",aspectRatio:1}}>{a}</button>)}
        </div>
      </div>
      <div>
        <div style={S.label}>CHOOSE YOUR TEAM</div>
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {teams.map(t=>{
            const to=CTF_TEAMS.find(x=>x.id===t.id)||t;
            const cnt=Object.values(ctfGame?.players||{}).filter(p=>p.teamId===t.id).length;
            return(
              <button key={t.id} onClick={()=>setTeamId(t.id)} style={{display:"flex",alignItems:"center",gap:12,padding:"14px 16px",border:`2px solid ${teamId===t.id?to.color:"#2a2a3a"}`,borderRadius:12,background:teamId===t.id?to.bg:"#0d0e1a",cursor:"pointer",transition:"all .15s"}}>
                <span style={{fontSize:28}}>{to.emoji}</span>
                <div style={{flex:1,textAlign:"left"}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1,color:teamId===t.id?to.color:"#f0f0f8"}}>{to.name}</div><div style={{fontSize:10,color:"#555",marginTop:2}}>{cnt} players</div></div>
              </button>
            );
          })}
        </div>
      </div>
      <button style={{...S.btnPrimary,background:"linear-gradient(135deg,#007AFF,#BF5AF2)",opacity:name.trim()?1:.4}} disabled={!name.trim()} onClick={()=>onJoin(name.trim(),avatar,teamId)}>
        JOIN {CTF_TEAMS.find(t=>t.id===teamId)?.name} →
      </button>
    </div>
  );
}

function CTFHudScreen({ctfGame,myId,onCapture,onNav,onBack}){
  const player=ctfGame?.players?.[myId];
  const myTeam=CTF_TEAMS.find(t=>t.id===player?.teamId);
  const flags=ctfGame?.flags||[];
  const events=[...(ctfGame?.events||[])].reverse().slice(0,5);
  const sortedTeams=[...(ctfGame?.teams||[])].sort((a,b)=>b.points-a.points);
  const [scanAnim,setScanAnim]=useState(null);
  const [manual,setManual]=useState("");
  const doCapture=async(flagId)=>{
    if(scanAnim)return;
    const r=await onCapture(flagId);
    setScanAnim({result:r.result,pts:r.pts});
    setTimeout(()=>setScanAnim(null),2000);
    setManual("");
  };
  if(!player||!myTeam)return null;
  const myFlags=flags.filter(f=>f.heldByTeam===player.teamId);
  const topPts=Math.max(1,...sortedTeams.map(t=>t.points));
  return(
    <div style={{...S.screen,gap:12}}>
      {/* Team header */}
      <div style={{background:myTeam.bg,border:`1px solid ${myTeam.color}40`,borderRadius:14,padding:"12px 14px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div style={{display:"flex",alignItems:"center",gap:10}}>
          <span style={{fontSize:28,filter:`drop-shadow(0 0 6px ${myTeam.color})`}}>{myTeam.emoji}</span>
          <div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2,color:myTeam.color}}>{myTeam.name}</div><div style={{fontSize:11,color:"#888"}}>{player.avatar} {player.name}</div></div>
        </div>
        <div style={{display:"flex",gap:12}}>
          {[{v:player.points||0,l:"PTS",c:myTeam.color},{v:player.captures||0,l:"CAPS",c:"#f0f0f8"},{v:player.steals||0,l:"STEALS",c:"#FF9500"}].map((s,i)=>(
            <div key={i} style={{textAlign:"center"}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:s.c,lineHeight:1}}>{s.v}</div><div style={{fontSize:8,color:"#555",letterSpacing:2}}>{s.l}</div></div>
          ))}
        </div>
      </div>
      {/* Mini scoreboard */}
      <div style={{...S.card,display:"flex",flexDirection:"column",gap:5}}>
        {sortedTeams.map((t,i)=>{
          const to=CTF_TEAMS.find(x=>x.id===t.id);
          const tFlags=flags.filter(f=>f.heldByTeam===t.id).length;
          const pct=Math.max(0,(t.points/topPts)*100);
          const isMe=t.id===player.teamId;
          return(
            <div key={t.id} style={{display:"flex",alignItems:"center",gap:8,padding:"4px 6px",borderRadius:8,background:isMe?`${to.color}10`:"transparent",border:isMe?`1px solid ${to.color}30`:"1px solid transparent"}}>
              <span style={{fontSize:14,width:22}}>{["🥇","🥈","🥉","4️⃣"][i]}</span>
              <span style={{fontSize:16}}>{to.emoji}</span>
              <div style={{flex:1}}>
                <div style={{height:5,background:"#2a2a3a",borderRadius:3,overflow:"hidden"}}><div style={{height:"100%",width:`${pct}%`,background:to.color,borderRadius:3,transition:"width .6s"}}/></div>
                <div style={{fontSize:9,color:"#555",marginTop:2,letterSpacing:1,fontFamily:"'Black Han Sans',sans-serif"}}>{to.name}</div>
              </div>
              <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,color:to.color,minWidth:32,textAlign:"right"}}>{t.points}</span>
              <span style={{fontSize:10,color:"#555",minWidth:24}}>🚩×{tFlags}</span>
            </div>
          );
        })}
      </div>
      {/* Capture anim */}
      {scanAnim&&(
        <div style={{padding:"12px 16px",borderRadius:12,textAlign:"center",fontFamily:"'Black Han Sans',sans-serif",fontSize:20,letterSpacing:2,animation:"popIn .3s ease",
          background:scanAnim.result==="steal"?"#FF2D5520":scanAnim.result==="capture"?"#34C75920":scanAnim.result==="defended"?"#007AFF20":"#FFCC0020",
          border:`2px solid ${scanAnim.result==="steal"?"#FF2D55":scanAnim.result==="capture"?"#34C759":scanAnim.result==="defended"?"#007AFF":"#FFCC00"}`,
          color:scanAnim.result==="steal"?"#FF2D55":scanAnim.result==="capture"?"#34C759":scanAnim.result==="defended"?"#007AFF":"#FFCC00"}}>
          {scanAnim.result==="steal"?`🔥 STOLEN! +${scanAnim.pts} pts`:scanAnim.result==="capture"?`🚩 CAPTURED! +${scanAnim.pts} pts`:scanAnim.result==="defended"?"🛡️ FLAG DEFENDED!":"✓ Done"}
        </div>
      )}
      {/* Flags grid */}
      <div style={S.label}>🚩 FLAGS</div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:8}}>
        {flags.map(flag=>{
          const ft=flag.heldByTeam?CTF_TEAMS.find(t=>t.id===flag.heldByTeam):null;
          const isMine=flag.heldByTeam===player.teamId;
          return(
            <div key={flag.id} style={{background:ft?ft.bg:"#0d0e1a",border:`2px solid ${ft?ft.color+"60":"#2a2a3a"}`,borderRadius:12,padding:"10px",display:"flex",flexDirection:"column",gap:5,boxShadow:ft?`0 0 12px ${ft.color}20`:"none",transition:"all .3s"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{fontSize:20,filter:ft?`drop-shadow(0 0 4px ${ft.color})`:"none"}}>🚩</span>
                {ft?<span style={{fontSize:14}}>{ft.emoji}</span>:<span style={{fontSize:9,color:"#444",background:"#1a1d2e",borderRadius:6,padding:"2px 7px",letterSpacing:1}}>FREE</span>}
              </div>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,color:ft?ft.color:"#888",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{flag.name.split(" ").slice(-1)[0]}</div>
              {isMine&&<div style={{fontSize:9,color:ft.color,letterSpacing:1}}>YOUR FLAG</div>}
            </div>
          );
        })}
      </div>
      {/* Quick scan */}
      <div style={S.label}>📸 SCAN FLAG QR</div>
      <div style={{display:"flex",gap:8}}>
        <input style={{...S.input,flex:1,fontSize:13,padding:"10px 12px"}} placeholder="FLAG ID (e.g. FLAG_0)" value={manual} onChange={e=>setManual(e.target.value.toUpperCase())} maxLength={8}/>
        <button style={{...S.btnGold,width:"auto",padding:"0 16px",fontSize:14}} onClick={()=>{if(manual.trim())doCapture(manual.trim());}}>CAPTURE ⚑</button>
      </div>
      {/* Live feed */}
      <div style={S.label}>📡 LIVE FEED</div>
      <div style={{display:"flex",flexDirection:"column",gap:4}}>
        {events.length===0&&<div style={{...S.card,textAlign:"center",color:"#444",fontSize:11}}>No captures yet — go steal some flags!</div>}
        {events.map(ev=>{const et=CTF_TEAMS.find(t=>t.id===ev.teamId);return(
          <div key={ev.id} style={{padding:"7px 11px",borderRadius:8,fontSize:11,borderLeft:`3px solid ${et?.color||"#555"}`,background:"#0d0e1a",color:"#aaa",display:"flex",gap:8,alignItems:"center"}}>
            <span style={{fontSize:9,color:"#444",flexShrink:0}}>{new Date(ev.ts).toLocaleTimeString("en-US",{hour12:false,hour:"2-digit",minute:"2-digit"})}</span>
            <span style={{flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{ev.msg}</span>
            {ev.pts&&<span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:"#FFCC00",flexShrink:0}}>+{ev.pts}</span>}
          </div>
        );})}
      </div>
      {/* Nav */}
      <div style={{display:"flex",gap:6,paddingTop:10,borderTop:"1px solid #1a1d2e"}}>
        {[["ctf_hud","🏠"],["ctf_flags","🚩 FLAGS"],["ctf_board","🏆 BOARD"],["ctf_qrcards","📄 QR"]].map(([sc,label])=>(
          <button key={sc} onClick={()=>onNav(sc)} style={{flex:1,padding:"9px 4px",background:sc==="ctf_hud"?"#007AFF15":"#0d0e1a",border:`1px solid ${sc==="ctf_hud"?"#007AFF40":"#1a1d2e"}`,borderRadius:10,color:sc==="ctf_hud"?"#007AFF":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,cursor:"pointer",whiteSpace:"nowrap"}}>{label}</button>
        ))}
      </div>
      <button style={{...S.btnGhost,width:"100%"}} onClick={onBack}>← EXIT CTF</button>
    </div>
  );
}

function CTFFlagsScreen({ctfGame,myId,onCapture,onBack}){
  const player=ctfGame?.players?.[myId];
  const [result,setResult]=useState(null);
  const doCapture=async flagId=>{const r=await onCapture(flagId);setResult({flagId,...r});setTimeout(()=>setResult(null),2000);};
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← HUD</button>
      <div style={S.title}>⚑ ALL FLAGS</div>
      {result&&<div style={{padding:"12px 16px",borderRadius:12,textAlign:"center",fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,animation:"popIn .3s ease",background:result.result==="steal"?"#FF2D5520":"#34C75920",border:`2px solid ${result.result==="steal"?"#FF2D55":"#34C759"}`,color:result.result==="steal"?"#FF2D55":"#34C759"}}>
        {result.result==="steal"?`🔥 STOLEN! +${result.pts} pts`:result.result==="capture"?`🚩 CAPTURED! +${result.pts} pts`:result.result==="defended"?"🛡️ Defended!":"Done"}
      </div>}
      {(ctfGame?.flags||[]).map(flag=>{
        const ft=flag.heldByTeam?CTF_TEAMS.find(t=>t.id===flag.heldByTeam):null;
        const holder=flag.heldBy?ctfGame.players?.[flag.heldBy]:null;
        const isMine=flag.heldByTeam===player?.teamId;
        const isEnemy=flag.heldBy&&!isMine;
        return(
          <div key={flag.id} style={{...S.card,border:`2px solid ${ft?ft.color+"50":"#1a1d2e"}`,background:ft?ft.bg:"#0d0e1a",boxShadow:ft?`0 0 16px ${ft.color}20`:"none",display:"flex",flexDirection:"column",gap:10}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:32,filter:ft?`drop-shadow(0 0 6px ${ft.color})`:"none"}}>🚩</span>
              <div style={{flex:1}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1,color:ft?ft.color:"#f0f0f8"}}>{flag.name}</div>
                {holder&&ft&&<div style={{fontSize:11,color:ft.color,marginTop:2}}>{holder.avatar} {holder.name} · {ft.name}</div>}
                {!ft&&<div style={{fontSize:11,color:"#444",marginTop:2}}>Uncaptured — free to take!</div>}
              </div>
              {ft?<CTFTeamBadge teamId={flag.heldByTeam} size="lg"/>:<span style={{background:"#1a1d2e",border:"1px solid #2a2a3a",borderRadius:8,padding:"4px 12px",fontSize:10,color:"#444",fontFamily:"'Black Han Sans',sans-serif",letterSpacing:1}}>FREE</span>}
            </div>
            {flag.history?.length>0&&<div style={{display:"flex",gap:4,flexWrap:"wrap",paddingTop:8,borderTop:"1px solid #1a1d2e"}}>
              {[...flag.history].reverse().slice(0,4).map((h,i)=>{const ht=CTF_TEAMS.find(t=>t.id===h.teamId);return<span key={i} style={{fontSize:10,color:ht?.color||"#555",background:ht?ht.bg:"#1a1d2e",border:`1px solid ${ht?.color||"#2a2a3a"}40`,borderRadius:20,padding:"2px 8px"}}>{ht?.emoji} {h.playerName}</span>;})}
            </div>}
            <button onClick={()=>doCapture(flag.id)} style={{...isMine?{...S.btnGhost,width:"100%",color:"#007AFF",borderColor:"#007AFF40"}:isEnemy?{...S.btnPrimary}:{...S.btnPrimary,background:"linear-gradient(135deg,#34C759,#00C7BE)",boxShadow:"0 4px 16px #34C75940"},padding:12,fontSize:14}}>
              {isMine?"🛡️ YOUR FLAG — DEFEND IT":isEnemy?`🔥 STEAL FROM ${ft?.name}`:"⚑ CAPTURE THIS FLAG"}
            </button>
          </div>
        );
      })}
    </div>
  );
}

function CTFLeaderboard({ctfGame,myId,onBack}){
  const teams=[...(ctfGame?.teams||[])].sort((a,b)=>b.points-a.points);
  const players=Object.values(ctfGame?.players||{}).sort((a,b)=>(b.points||0)-(a.points||0));
  const flags=ctfGame?.flags||[];
  const [tab,setTab]=useState("teams");
  const maxPts=Math.max(1,...teams.map(t=>t.points));
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← HUD</button>
      <div style={S.title}>⚑ LEADERBOARD</div>
      <div style={{display:"flex",gap:6}}>
        {[["teams","🏴 TEAMS"],["players","👊 PLAYERS"],["flags","🚩 FLAGS"]].map(([id,label])=>(
          <button key={id} onClick={()=>setTab(id)} style={{flex:1,padding:"9px 4px",border:`2px solid ${tab===id?"#007AFF":"#2a2a3a"}`,borderRadius:10,background:tab===id?"#007AFF15":"#0d0e1a",color:tab===id?"#007AFF":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,cursor:"pointer"}}>{label}</button>
        ))}
      </div>
      {tab==="teams"&&teams.map((t,i)=>{
        const to=CTF_TEAMS.find(x=>x.id===t.id);
        const tFlags=flags.filter(f=>f.heldByTeam===t.id);
        const pct=Math.max(0,(t.points/maxPts)*100);
        const isMe=myId&&ctfGame?.players?.[myId]?.teamId===t.id;
        return(
          <div key={t.id} style={{...S.card,border:`2px solid ${isMe?to.color:"#1a1d2e"}`,background:isMe?to.bg:"#0d0e1a",display:"flex",flexDirection:"column",gap:10}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:22,width:28}}>{["🥇","🥈","🥉","4️⃣"][i]}</span>
              <span style={{fontSize:26}}>{to.emoji}</span>
              <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:1,color:to.color}}>{to.name}{isMe&&<span style={{fontSize:9,color:"#FF9500",background:"#FF950020",border:"1px solid #FF950040",borderRadius:10,padding:"1px 7px",marginLeft:6,letterSpacing:1}}>YOU</span>}</div><div style={{fontSize:10,color:"#555",marginTop:2}}>{t.captures} captures · {tFlags.length} flags held</div></div>
              <div style={{textAlign:"right"}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:28,color:to.color,lineHeight:1}}>{t.points}</div><div style={{fontSize:9,color:"#555",letterSpacing:2}}>PTS</div></div>
            </div>
            <div style={{height:6,background:"#2a2a3a",borderRadius:3,overflow:"hidden"}}><div style={{height:"100%",width:`${pct}%`,background:to.color,borderRadius:3,transition:"width .6s"}}/></div>
            {tFlags.length>0&&<div style={{display:"flex",flexWrap:"wrap",gap:5}}>
              {tFlags.map(f=><span key={f.id} style={{fontSize:10,color:to.color,background:to.bg,border:`1px solid ${to.color}40`,borderRadius:6,padding:"2px 8px"}}>🚩 {f.name}</span>)}
            </div>}
          </div>
        );
      })}
      {tab==="players"&&players.map((p,i)=>{
        const pt=CTF_TEAMS.find(t=>t.id===p.teamId);
        return(
          <div key={p.id} style={{...S.card,display:"flex",alignItems:"center",gap:10,border:`2px solid ${p.id===myId?pt?.color||"#FF9500":"#1a1d2e"}`,background:p.id===myId?`${pt?.color||"#FF9500"}10`:"#0d0e1a"}}>
            <div style={{fontSize:18,width:26}}>{["🥇","🥈","🥉"][i]||`#${i+1}`}</div>
            <span style={{fontSize:26}}>{p.avatar}</span>
            <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1}}>{p.name}{p.id===myId&&<span style={{fontSize:9,color:"#FF9500",marginLeft:6}}>YOU</span>}</div><div style={{fontSize:10,color:"#555",marginTop:2}}>{p.captures||0} caps · {p.steals||0} steals · {p.defends||0} defends</div></div>
            <div style={{textAlign:"right"}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,color:pt?.color||"#f0f0f8"}}>{p.points||0}</div>{pt&&<CTFTeamBadge teamId={p.teamId}/>}</div>
          </div>
        );
      })}
      {tab==="flags"&&flags.map(flag=>{
        const ft=flag.heldByTeam?CTF_TEAMS.find(t=>t.id===flag.heldByTeam):null;
        const holder=flag.heldBy?ctfGame.players?.[flag.heldBy]:null;
        return(
          <div key={flag.id} style={{...S.card,border:`1px solid ${ft?ft.color+"50":"#1a1d2e"}`,background:ft?ft.bg:"#0d0e1a"}}>
            <div style={{display:"flex",alignItems:"center",gap:10}}>
              <span style={{fontSize:28,filter:ft?`drop-shadow(0 0 5px ${ft.color})`:"none"}}>🚩</span>
              <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:15,color:ft?ft.color:"#f0f0f8"}}>{flag.name}</div>{holder&&ft&&<div style={{fontSize:10,color:ft.color,marginTop:2}}>{holder.avatar} {holder.name}</div>}{!ft&&<div style={{fontSize:10,color:"#444",marginTop:2}}>Uncaptured</div>}</div>
              {ft?<CTFTeamBadge teamId={flag.heldByTeam} size="lg"/>:<span style={{fontSize:9,color:"#444",background:"#1a1d2e",borderRadius:6,padding:"3px 8px",letterSpacing:1}}>FREE</span>}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function CTFQRCards({ctfGame,onBack}){
  const flags=ctfGame?.flags||[];
  const [sel,setSel]=useState(flags[0]?.id||null);
  const selFlag=flags.find(f=>f.id===sel);
  const qr=selFlag?genQR(selFlag.id,180):null;
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← HUD</button>
      <div style={S.title}>📄 BAR QR CARDS</div>
      <div style={{fontSize:11,color:"#555",lineHeight:1.7}}>Each bar gets a QR card. Print it and stick it somewhere fun — players scan it to capture the flag for their team.</div>
      <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
        {flags.map(f=><button key={f.id} onClick={()=>setSel(f.id)} style={{padding:"6px 12px",border:`1px solid ${sel===f.id?"#FFCC00":"#2a2a3a"}`,borderRadius:20,background:sel===f.id?"#FFCC0015":"#0d0e1a",color:sel===f.id?"#FFCC00":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:12,cursor:"pointer"}}>🚩 {f.name}</button>)}
      </div>
      {selFlag&&qr&&(
        <div style={{background:"#fff",borderRadius:20,padding:20,display:"flex",flexDirection:"column",alignItems:"center",gap:12,boxShadow:"0 0 40px rgba(0,122,255,.2)"}}>
          <div style={{display:"flex",alignItems:"center",gap:10,width:"100%"}}>
            <span style={{fontSize:32}}>🚩</span>
            <div><div style={{fontSize:9,letterSpacing:3,color:"#888",fontFamily:"'Black Han Sans',sans-serif"}}>CRAWLFIRE · CAPTURE THE FLAG</div><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:"#000",letterSpacing:1}}>{selFlag.name}</div></div>
          </div>
          <img src={qr} alt="QR" style={{width:180,height:180,imageRendering:"pixelated"}}/>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:5,color:"#FF2D55",background:"#FF2D5508",border:"1px solid #FF2D5520",borderRadius:8,padding:"6px 16px"}}>{selFlag.id.toUpperCase()}</div>
          <div style={{background:"#f5f5f5",borderRadius:12,padding:"12px 14px",width:"100%",display:"flex",flexDirection:"column",gap:5}}>
            {["1. Open CrawlFire app",`2. Go to FLAGS → Scan QR`,`3. Or type code: ${selFlag.id.toUpperCase()}`,`4. Capture for your team! ⚑`].map((s,i)=><div key={i} style={{fontSize:12,color:"#333",fontFamily:"'Black Han Sans',sans-serif"}}>{s}</div>)}
          </div>
          <div style={{display:"flex",gap:8,flexWrap:"wrap",justifyContent:"center"}}>
            {[`⚑ ${100} pts capture`,`+${25} pts steal`,`+${10} pts/min held`].map(s=><span key={s} style={{fontSize:11,color:"#555",background:"#f5f5f5",borderRadius:20,padding:"4px 12px",fontFamily:"'Black Han Sans',sans-serif"}}>{s}</span>)}
          </div>
          <div style={{fontSize:10,color:"#aaa",letterSpacing:2,fontFamily:"'Black Han Sans',sans-serif"}}>crawlfire.app · CTF Edition</div>
        </div>
      )}
      <div style={{...S.card}}>
        <div style={S.label}>ALL FLAG CODES</div>
        {flags.map(f=>(
          <div key={f.id} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:"1px solid #1a1d2e"}}>
            <span style={{fontSize:16}}>🚩</span>
            <span style={{flex:1,fontFamily:"'Black Han Sans',sans-serif",fontSize:13}}>{f.name}</span>
            <span style={{fontSize:11,color:"#FFCC00",background:"#FFCC0015",border:"1px solid #FFCC0030",borderRadius:6,padding:"2px 10px",letterSpacing:2,fontFamily:"'Black Han Sans',sans-serif"}}>{f.id.toUpperCase()}</span>
          </div>
        ))}
      </div>
    </div>
  );
}


// ═══════════════════════════════════════════════════════════════════════════════
// ─── DESIGNER PORTAL ─────────────────────────────────────────────────────────
// Secure admin panel for approved designers only.
// Controls: pricing, feature toggles, weapon tuning, maintenance mode.
// ═══════════════════════════════════════════════════════════════════════════════

function DesignerLogin({onLogin, onBack}) {
  const [username, setUsername] = useState("");
  const [token,    setToken]    = useState("");
  const [err,      setErr]      = useState("");
  const [attempts, setAttempts] = useState(0);
  const [locked,   setLocked]   = useState(false);
  const [lockTimer,setLockTimer]= useState(0);

  // Rate-limit: 3 failed attempts = 60s lockout
  useEffect(() => {
    if (!locked) return;
    let t = 60;
    setLockTimer(t);
    const id = setInterval(() => { t--; setLockTimer(t); if (t <= 0) { setLocked(false); setAttempts(0); clearInterval(id); } }, 1000);
    return () => clearInterval(id);
  }, [locked]);

  const login = () => {
    if (locked) return;
    const account = DESIGNER_ACCOUNTS.find(d => d.username === username.toLowerCase().trim() && d.token === token.trim());
    if (account) {
      setErr("");
      onLogin(account);
    } else {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      if (newAttempts >= 3) { setLocked(true); setErr("Too many failed attempts. Locked for 60 seconds."); }
      else { setErr(`Invalid credentials. ${3 - newAttempts} attempt${3-newAttempts===1?"":"s"} remaining.`); }
    }
  };

  return (
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
      <div style={{textAlign:"center",padding:"20px 0"}}>
        <div style={{fontSize:52,marginBottom:10,filter:"drop-shadow(0 0 16px #BF5AF2)"}}>🎨</div>
        <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:26,letterSpacing:4,color:"#BF5AF2"}}>DESIGNER PORTAL</div>
        <div style={{fontSize:10,color:"#555",letterSpacing:3,marginTop:6}}>AUTHORISED ACCESS ONLY</div>
      </div>

      <div style={{...S.card,border:"2px solid #BF5AF240",background:"#1a0a2e"}}>
        <div style={{fontSize:10,color:"#BF5AF2",letterSpacing:3,marginBottom:12}}>DESIGNER CREDENTIALS</div>

        <div style={S.label}>USERNAME</div>
        <input style={{...S.input,marginBottom:12,borderColor:err?"#FF2D55":"#2a2a3a"}}
          placeholder="designer / dev / gamemaster"
          value={username} onChange={e=>setUsername(e.target.value)}
          disabled={locked}/>

        <div style={S.label}>ACCESS TOKEN</div>
        <input style={{...S.input,marginBottom:12,fontFamily:"'Space Mono',monospace",fontSize:13,letterSpacing:1,borderColor:err?"#FF2D55":"#2a2a3a"}}
          type="password" placeholder="CRAWLFIRE-DESIGN-****"
          value={token} onChange={e=>setToken(e.target.value)}
          disabled={locked}
          onKeyDown={e=>e.key==="Enter"&&!locked&&login()}/>

        {err && (
          <div style={{background:"#FF2D5515",border:"1px solid #FF2D5540",borderRadius:8,padding:"8px 12px",fontSize:11,color:"#FF2D55",marginBottom:12,lineHeight:1.6}}>
            🔒 {err}{locked&&<span style={{display:"block",marginTop:4,fontFamily:"'Space Mono',monospace"}}>Retry in {lockTimer}s</span>}
          </div>
        )}

        <button onClick={login} disabled={locked||!username.trim()||!token.trim()} style={{...S.btnPrimary,background:locked?"#2a2a3a":"linear-gradient(135deg,#BF5AF2,#7B2FBE)",opacity:locked||!username.trim()||!token.trim()?.4:1,marginBottom:0}}>
          {locked?`LOCKED (${lockTimer}s)`:"🔐 AUTHENTICATE →"}
        </button>
      </div>

      <div style={{...S.card,background:"#0a0a12",border:"1px dashed #2a2a3a"}}>
        <div style={{fontSize:10,color:"#555",letterSpacing:2,marginBottom:6}}>DEMO ACCESS TOKENS</div>
        {[["designer","CRAWLFIRE-DESIGN-2024"],["dev","CRAWLFIRE-DEV-2024"],["gamemaster","CRAWLFIRE-GM-2024"]].map(([u,t])=>(
          <div key={u} style={{display:"flex",justifyContent:"space-between",padding:"4px 0",borderBottom:"1px solid #1a1d2e"}}>
            <span style={{fontSize:10,color:"#888",fontFamily:"'Space Mono',monospace"}}>{u}</span>
            <span style={{fontSize:10,color:"#555",fontFamily:"'Space Mono',monospace"}}>{t}</span>
          </div>
        ))}
      </div>

      <div style={{fontSize:10,color:"#333",textAlign:"center",lineHeight:1.7}}>
        All designer actions are logged with timestamp and account ID.<br/>
        Unauthorised access attempts are recorded.
      </div>
    </div>
  );
}

function DesignerPortal({designer, onLogout}) {
  const [tab,     setTab]    = useState("features");
  const [config,  setConfig] = useState(JSON.parse(JSON.stringify(DEFAULT_GAME_CONFIG)));
  const [saved,   setSaved]  = useState(false);
  const [confirm, setConfirm]= useState(null); // {action, label, onConfirm}
  const [changelog, setChangelog] = useState([]);

  const addLog = (action) => {
    setChangelog(l => [{id:uid(), designer:designer.name, action, ts:Date.now()}, ...l].slice(0,50));
  };

  const save = () => {
    const updated = {...config, _updatedAt:Date.now(), _updatedBy:designer.name};
    setConfig(updated);
    // In production: wr(KEYS.config, updated)
    addLog("Config saved");
    setSaved(true); setTimeout(()=>setSaved(false), 2000);
  };

  const toggleFeature = (key) => {
    const newVal = !config.features[key].enabled;
    const newCfg = {...config, features:{...config.features,[key]:{...config.features[key],enabled:newVal}}};
    setConfig(newCfg);
    addLog(`${newVal?"Enabled":"Disabled"}: ${config.features[key].label}`);
  };

  const toggleMaintenance = () => {
    if (!config.maintenance.active) {
      setConfirm({
        action:"maintenance",
        label:"ENABLE MAINTENANCE MODE",
        body:"This will show a maintenance banner to all players and block new game joins. Active games continue.",
        color:"#FF9500",
        onConfirm:() => {
          setConfig(c=>({...c,maintenance:{...c.maintenance,active:true}}));
          addLog("Maintenance mode ENABLED");
          setConfirm(null);
        }
      });
    } else {
      setConfig(c=>({...c,maintenance:{...c.maintenance,active:false}}));
      addLog("Maintenance mode disabled");
    }
  };

  const TABS = [
    {id:"features",   label:"⚙️ FEATURES",  color:"#BF5AF2"},
    {id:"pricing",    label:"💰 PRICING",    color:"#FFCC00"},
    {id:"weapons",    label:"🎯 WEAPONS",    color:"#FF2D55"},
    {id:"ctf",        label:"⚑ CTF",        color:"#007AFF"},
    {id:"tiers",      label:"🏆 TIERS",      color:"#FF9500"},
    {id:"system",     label:"🔧 SYSTEM",     color:"#34C759"},
    {id:"changelog",  label:"📋 LOG",        color:"#00C7BE"},
  ];

  const isSuper = designer.level === "super";

  return (
    <div style={S.screen}>
      {/* Maintenance banner */}
      {config.maintenance.active && (
        <div style={{background:"#FF9500",color:"#000",fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:2,padding:"10px 16px",borderRadius:10,textAlign:"center",animation:"flash 2s ease-in-out infinite"}}>
          🔧 MAINTENANCE MODE ACTIVE — Players see maintenance banner
        </div>
      )}

      {/* Header */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:15,letterSpacing:2,color:"#BF5AF2"}}>
            {designer.avatar} {designer.name}
          </div>
          <div style={{fontSize:9,color:"#555",letterSpacing:2,marginTop:2}}>
            DESIGNER PORTAL · {designer.level.toUpperCase()}
          </div>
        </div>
        <div style={{display:"flex",gap:6,alignItems:"center"}}>
          {saved&&<div style={{fontSize:11,color:"#34C759",animation:"fadeIn .3s ease"}}>✅ SAVED</div>}
          <button onClick={save} style={{background:"#34C75920",border:"1px solid #34C75940",color:"#34C759",padding:"7px 14px",borderRadius:8,fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,cursor:"pointer"}}>SAVE</button>
          <button style={S.btnGhost} onClick={onLogout}>SIGN OUT</button>
        </div>
      </div>

      {/* Tab bar */}
      <div style={{display:"flex",gap:4,overflowX:"auto",paddingBottom:4,scrollbarWidth:"none"}}>
        {TABS.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{padding:"8px 10px",border:`2px solid ${tab===t.id?t.color:"#2a2a3a"}`,borderRadius:10,background:tab===t.id?`${t.color}18`:"#0d0e1a",color:tab===t.id?t.color:"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:10,letterSpacing:1,cursor:"pointer",whiteSpace:"nowrap",flexShrink:0}}>
            {t.label}
          </button>
        ))}
      </div>

      {/* ── FEATURES TAB ── */}
      {tab==="features"&&(
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          <div style={{...S.card,background:"#1a0a2e",border:"1px solid #BF5AF230",fontSize:11,color:"#888",lineHeight:1.7}}>
            🎨 Toggle game features on/off instantly. Changes take effect for all new sessions. Active games are not interrupted.
          </div>
          {Object.entries(config.features).map(([key,feat])=>{
            const isOn = feat.enabled;
            const dangerKeys = ["payments","prizePayouts","newRegistrations"];
            const isDanger = dangerKeys.includes(key);
            return(
              <div key={key} style={{...S.card,border:`1px solid ${isOn?"#1a1d2e":isDanger?"#FF2D5530":"#2a2a3a"}`,background:isOn?"#0d0e1a":isDanger?"#FF2D5508":"#0a0a0a",display:"flex",alignItems:"center",gap:12}}>
                <span style={{fontSize:24,flexShrink:0,opacity:isOn?1:.4}}>{feat.icon}</span>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,color:isOn?"#f0f0f8":"#555"}}>{feat.label}</div>
                  {!isOn&&isDanger&&<div style={{fontSize:10,color:"#FF2D55",marginTop:2}}>⚠️ Currently suspended</div>}
                </div>
                <button onClick={()=>{
                  if(!isOn&&isDanger&&!isSuper){alert("Only Super designers can re-enable payment systems.");return;}
                  if(isOn&&isDanger){setConfirm({action:"suspend-"+key,label:`SUSPEND ${feat.label.toUpperCase()}`,body:`This will immediately stop ${feat.label} for all players. Are you sure?`,color:"#FF2D55",onConfirm:()=>{toggleFeature(key);setConfirm(null);}});return;}
                  toggleFeature(key);
                }} style={{padding:"8px 16px",border:"none",borderRadius:10,background:isOn?"#34C75920":"#FF2D5520",color:isOn?"#34C759":"#FF2D55",border:`1px solid ${isOn?"#34C75940":"#FF2D5540"}`,fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,cursor:"pointer",minWidth:70,textAlign:"center"}}>
                  {isOn?"● ON":"○ OFF"}
                </button>
              </div>
            );
          })}
          {/* Maintenance mode */}
          <div style={{...S.card,border:`2px solid ${config.maintenance.active?"#FF9500":"#2a2a3a"}`,background:config.maintenance.active?"#FF950010":"#0d0e1a",display:"flex",alignItems:"center",gap:12}}>
            <span style={{fontSize:24,flexShrink:0}}>🔧</span>
            <div style={{flex:1}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,color:"#f0f0f8"}}>Maintenance Mode</div>
              <div style={{fontSize:10,color:"#555",marginTop:2}}>Shows banner to all users · blocks new game joins</div>
              {config.maintenance.active&&<div style={{marginTop:6}}>
                <input value={config.maintenance.banner} onChange={e=>setConfig(c=>({...c,maintenance:{...c.maintenance,banner:e.target.value}}))} placeholder="Banner message..." style={{...S.input,fontSize:12,padding:"7px 10px",letterSpacing:0}}/>
              </div>}
            </div>
            <button onClick={toggleMaintenance} style={{padding:"8px 16px",border:"none",borderRadius:10,background:config.maintenance.active?"#FF950020":"#34C75920",color:config.maintenance.active?"#FF9500":"#34C759",border:`1px solid ${config.maintenance.active?"#FF950040":"#34C75940"}`,fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1,cursor:"pointer",minWidth:70}}>
              {config.maintenance.active?"● ON":"○ OFF"}
            </button>
          </div>
        </div>
      )}

      {/* ── PRICING TAB ── */}
      {tab==="pricing"&&(
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {!isSuper&&<div style={{...S.card,background:"#FF2D5510",border:"1px solid #FF2D5530",fontSize:11,color:"#FF2D55"}}>⚠️ Pricing changes require Super designer access. Contact Lead Designer.</div>}
          <div style={{...S.card}}>
            <div style={S.sectionTitle}>ENTRY TIERS</div>
            {Object.entries(config.entry).map(([key,pack])=>(
              <div key={key} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 0",borderBottom:"1px solid #1a1d2e"}}>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,textTransform:"uppercase"}}>{key}</div>
                  <div style={{fontSize:10,color:"#555"}}>🪙{pack.coins} coins</div>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:6}}>
                  <span style={{fontSize:11,color:"#555"}}>$</span>
                  <input type="number" step="0.50" min="0.50" max="50" value={pack.price} disabled={!isSuper}
                    onChange={e=>setConfig(c=>({...c,entry:{...c.entry,[key]:{...c.entry[key],price:parseFloat(e.target.value)||pack.price}}))}
                    } style={{width:60,background:"#12121a",border:`1px solid ${isSuper?"#2a2a3a":"#1a1d2e"}`,borderRadius:8,color:isSuper?"#FFCC00":"#555",fontFamily:"'Space Mono',monospace",fontSize:14,padding:"6px 8px",outline:"none",textAlign:"center",cursor:isSuper?"text":"not-allowed"}}/>
                </div>
                <button onClick={()=>{ if(!isSuper)return; setConfig(c=>({...c,entry:{...c.entry,[key]:{...c.entry[key],enabled:!pack.enabled}}})); addLog(`${pack.enabled?"Disabled":"Enabled"} entry tier: ${key}`); }} style={{padding:"5px 12px",borderRadius:20,border:`1px solid ${pack.enabled?"#34C75940":"#FF2D5540"}`,background:pack.enabled?"#34C75915":"#FF2D5515",color:pack.enabled?"#34C759":"#FF2D55",fontFamily:"'Space Mono',monospace",fontSize:9,cursor:isSuper?"pointer":"not-allowed",opacity:isSuper?1:.5}}>
                  {pack.enabled?"ON":"OFF"}
                </button>
              </div>
            ))}
          </div>
          <div style={{...S.card}}>
            <div style={S.sectionTitle}>XP POOL SPLIT</div>
            <div style={{marginBottom:8}}>
              <div style={S.label}>WINNER GETS (%)</div>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <input type="range" min={50} max={90} step={5} value={config.pot.winnerSharePct} disabled={!isSuper}
                  onChange={e=>setConfig(c=>({...c,pot:{winnerSharePct:parseInt(e.target.value),platformPct:100-parseInt(e.target.value)}}))}
                  style={{flex:1,accentColor:"#FFCC00",cursor:isSuper?"pointer":"not-allowed"}}/>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:"#FFCC00",minWidth:48,textAlign:"right"}}>{config.pot.winnerSharePct}%</div>
              </div>
            </div>
            {/* Visual split */}
            <div style={{height:10,borderRadius:5,overflow:"hidden",display:"flex",marginTop:8}}>
              <div style={{flex:config.pot.winnerSharePct,background:"linear-gradient(90deg,#FFCC00,#FF9500)",display:"flex",alignItems:"center",justifyContent:"center"}}><span style={{fontSize:7,color:"#000",fontWeight:"bold"}}>WINNER {config.pot.winnerSharePct}%</span></div>
              <div style={{flex:config.pot.platformPct,background:"linear-gradient(90deg,#FF2D55,#FF6B35)",display:"flex",alignItems:"center",justifyContent:"center"}}><span style={{fontSize:7,color:"#fff",fontWeight:"bold"}}>PLATFORM {config.pot.platformPct}%</span></div>
            </div>
          </div>
          <div style={{...S.card}}>
            <div style={S.sectionTitle}>SHOP ITEM COSTS</div>
            {Object.entries(config.shop).map(([key,item])=>{
              const shopItem = SHOP_ITEMS.find(x=>x.id===key)||{e:"❓",n:key};
              return(
                <div key={key} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:"1px solid #1a1d2e"}}>
                  <span style={{fontSize:20}}>{shopItem.e}</span>
                  <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1}}>{shopItem.n}</div></div>
                  <div style={{display:"flex",alignItems:"center",gap:5}}>
                    <span style={{fontSize:11,color:"#FFCC00"}}>🪙</span>
                    <input type="number" step="5" min="5" max="200" value={item.cost} disabled={!isSuper}
                      onChange={e=>setConfig(c=>({...c,shop:{...c.shop,[key]:{...c.shop[key],cost:parseInt(e.target.value)||item.cost}}))}
                      } style={{width:55,background:"#12121a",border:`1px solid ${isSuper?"#2a2a3a":"#1a1d2e"}`,borderRadius:8,color:isSuper?"#FFCC00":"#555",fontFamily:"'Space Mono',monospace",fontSize:13,padding:"5px 8px",outline:"none",textAlign:"center",cursor:isSuper?"text":"not-allowed"}}/>
                  </div>
                  <button onClick={()=>{if(!isSuper)return;setConfig(c=>({...c,shop:{...c.shop,[key]:{...c.shop[key],enabled:!item.enabled}}}));addLog(`${item.enabled?"Disabled":"Enabled"} shop item: ${key}`);}} style={{padding:"4px 10px",borderRadius:20,border:`1px solid ${item.enabled?"#34C75940":"#FF2D5540"}`,background:item.enabled?"#34C75915":"#FF2D5515",color:item.enabled?"#34C759":"#FF2D55",fontFamily:"'Space Mono',monospace",fontSize:9,cursor:isSuper?"pointer":"not-allowed",opacity:isSuper?1:.5}}>
                    {item.enabled?"ON":"OFF"}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── WEAPONS TAB ── */}
      {tab==="weapons"&&(
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          <div style={{...S.card,fontSize:11,color:"#888",lineHeight:1.7}}>Adjust weapon damage values or disable specific weapons. Changes apply to all new shots immediately.</div>
          {Object.entries(config.weapons).map(([name,wpn])=>{
            const base=DEFAULT_GAME_CONFIG.weapons[name]?.dmg||20;
            const diff=wpn.dmg-base;
            return(
              <div key={name} style={{...S.card,border:`1px solid ${wpn.enabled?"#1a1d2e":"#2a2a3a"}`,opacity:wpn.enabled?1:.5}}>
                <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
                  <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1}}>{name}</div></div>
                  <button onClick={()=>{setConfig(c=>({...c,weapons:{...c.weapons,[name]:{...c.weapons[name],enabled:!wpn.enabled}}}));addLog(`${wpn.enabled?"Disabled":"Enabled"} weapon: ${name}`);}} style={{padding:"5px 12px",borderRadius:20,border:`1px solid ${wpn.enabled?"#34C75940":"#FF2D5540"}`,background:wpn.enabled?"#34C75915":"#FF2D5515",color:wpn.enabled?"#34C759":"#FF2D55",fontFamily:"'Space Mono',monospace",fontSize:9,cursor:"pointer"}}>
                    {wpn.enabled?"ENABLED":"DISABLED"}
                  </button>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:10}}>
                  <span style={{fontSize:10,color:"#555",width:28}}>DMG</span>
                  <input type="range" min={5} max={60} step={5} value={wpn.dmg}
                    onChange={e=>{const v=parseInt(e.target.value);setConfig(c=>({...c,weapons:{...c.weapons,[name]:{...c.weapons[name],dmg:v}}}));}}
                    style={{flex:1,accentColor:"#FF2D55"}}/>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,color:"#FF2D55",minWidth:36,textAlign:"right"}}>{wpn.dmg}</div>
                  {diff!==0&&<div style={{fontSize:9,color:diff>0?"#FF2D55":"#34C759",fontFamily:"'Space Mono',monospace"}}>{diff>0?"+":""}{diff}</div>}
                </div>
                <div style={{height:4,background:"#2a2a3a",borderRadius:2,overflow:"hidden",marginTop:6}}>
                  <div style={{height:"100%",width:`${(wpn.dmg/60)*100}%`,background:wpn.dmg>40?"#FF2D55":wpn.dmg>20?"#FF9500":"#34C759",borderRadius:2,transition:"width .3s"}}/>
                </div>
              </div>
            );
          })}
          <button onClick={()=>{setConfig(c=>({...c,weapons:JSON.parse(JSON.stringify(DEFAULT_GAME_CONFIG.weapons))}));addLog("Weapons reset to defaults");}} style={{...S.btnGhost,width:"100%",textAlign:"center",padding:10}}>↺ RESET ALL TO DEFAULTS</button>
        </div>
      )}

      {/* ── CTF TAB ── */}
      {tab==="ctf"&&(
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          <div style={{...S.card,fontSize:11,color:"#888",lineHeight:1.7}}>Tune CTF scoring values. Applied to all new captures after saving.</div>
          {[
            {key:"ptsCapture",   label:"Capture a free flag",  color:"#34C759", min:50, max:300, step:25},
            {key:"ptsSteal",     label:"Steal bonus",           color:"#FF2D55", min:0,  max:100, step:5},
            {key:"ptsDefend",    label:"Defend your flag",      color:"#007AFF", min:0,  max:100, step:5},
            {key:"ptsHoldPerMin",label:"Points per min held",   color:"#FFCC00", min:0,  max:50,  step:5},
          ].map(({key,label,color,min,max,step})=>(
            <div key={key} style={{...S.card}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:8}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1}}>{label}</div>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,color}}>{config.ctf[key]} pts</div>
              </div>
              <input type="range" min={min} max={max} step={step} value={config.ctf[key]}
                onChange={e=>setConfig(c=>({...c,ctf:{...c.ctf,[key]:parseInt(e.target.value)}}))}
                style={{width:"100%",accentColor:color}}/>
              <div style={{display:"flex",justifyContent:"space-between",fontSize:9,color:"#555",marginTop:3}}>
                <span>{min}</span><span>Default: {DEFAULT_GAME_CONFIG.ctf[key]}</span><span>{max}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── TIERS TAB ── */}
      {tab==="tiers"&&(
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {!isSuper&&<div style={{...S.card,background:"#FF2D5510",border:"1px solid #FF2D5530",fontSize:11,color:"#FF2D55"}}>⚠️ Revenue tier changes require Super designer access.</div>}
          {Object.entries(config.tiers).map(([tier,vals])=>{
            const tc=TIERS[tier]?.c||"#888";
            return(
              <div key={tier} style={{...S.card,border:`1px solid ${tc}30`}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:15,color:tc,letterSpacing:2,marginBottom:10,textTransform:"uppercase"}}>{tier} TIER</div>
                {[
                  {key:"rate",     label:"Revenue share %", suffix:"%",  min:5,   max:40, step:5},
                  {key:"perCrawl", label:"Per crawl $",     suffix:"$",  min:0,   max:50, step:1},
                  {key:"perCode",  label:"Per loot code $", suffix:"$",  min:0,   max:5,  step:0.25},
                  {key:"perRef",   label:"Per referral $",  suffix:"$",  min:0,   max:200,step:5},
                ].map(({key,label,suffix,min,max,step})=>(
                  <div key={key} style={{display:"flex",alignItems:"center",gap:10,padding:"7px 0",borderBottom:"1px solid #1a1d2e"}}>
                    <div style={{flex:1,fontSize:11,color:"#888"}}>{label}</div>
                    <input type="number" step={step} min={min} max={max} value={vals[key]} disabled={!isSuper}
                      onChange={e=>{const v=parseFloat(e.target.value)||vals[key];setConfig(c=>({...c,tiers:{...c.tiers,[tier]:{...c.tiers[tier],[key]:v}}}));}}
                      style={{width:70,background:"#12121a",border:`1px solid ${isSuper?tc+"40":"#1a1d2e"}`,borderRadius:8,color:isSuper?tc:"#555",fontFamily:"'Space Mono',monospace",fontSize:13,padding:"5px 8px",outline:"none",textAlign:"center",cursor:isSuper?"text":"not-allowed"}}/>
                    <span style={{fontSize:11,color:tc,width:16}}>{suffix}</span>
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      )}

      {/* ── SYSTEM TAB ── */}
      {tab==="system"&&(
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          <div style={{...S.card}}>
            <div style={S.sectionTitle}>PLAY ZONE SETTINGS</div>
            <div style={{fontSize:11,color:"#888",lineHeight:1.7,marginBottom:10}}>Sets the geographic boundary for the crawl. Players outside the zone for more than the grace period are automatically DQ'd.</div>
            {[
              {key:"radiusMeters",  label:"Zone radius",         unit:"m",  min:200,  max:5000, step:100},
              {key:"warnMeters",    label:"Warning distance",    unit:"m",  min:50,   max:500,  step:50},
              {key:"graceSecs",     label:"Grace period",        unit:"s",  min:30,   max:300,  step:30},
            ].map(({key,label,unit,min,max,step})=>(
              <div key={key} style={{marginBottom:10}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                  <div style={{fontSize:11,color:"#888"}}>{label}</div>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#34C759"}}>{config.zone?.[key]||DEFAULT_GAME_CONFIG.zone[key]}{unit}</div>
                </div>
                <input type="range" min={min} max={max} step={step} value={config.zone?.[key]||DEFAULT_GAME_CONFIG.zone[key]}
                  onChange={e=>setConfig(c=>({...c,zone:{...(c.zone||DEFAULT_GAME_CONFIG.zone),[key]:parseInt(e.target.value)}}))}
                  style={{width:"100%",accentColor:"#34C759"}}/>
              </div>
            ))}
            <div style={{display:"flex",flexDirection:"column",gap:8,marginTop:4}}>
              <div style={S.label}>ZONE CENTRE (lat, lng)</div>
              <div style={{display:"flex",gap:8}}>
                <input type="number" step="0.0001" value={(config.zone?.centerLat||DEFAULT_GAME_CONFIG.zone.centerLat).toFixed(4)}
                  onChange={e=>setConfig(c=>({...c,zone:{...(c.zone||DEFAULT_GAME_CONFIG.zone),centerLat:parseFloat(e.target.value)}}))}
                  style={{flex:1,background:"#12121a",border:"1px solid #2a2a3a",borderRadius:8,color:"#34C759",fontFamily:"'Space Mono',monospace",fontSize:11,padding:"7px 8px",outline:"none",textAlign:"center"}}/>
                <input type="number" step="0.0001" value={(config.zone?.centerLng||DEFAULT_GAME_CONFIG.zone.centerLng).toFixed(4)}
                  onChange={e=>setConfig(c=>({...c,zone:{...(c.zone||DEFAULT_GAME_CONFIG.zone),centerLng:parseFloat(e.target.value)}}))}
                  style={{flex:1,background:"#12121a",border:"1px solid #2a2a3a",borderRadius:8,color:"#34C759",fontFamily:"'Space Mono',monospace",fontSize:11,padding:"7px 8px",outline:"none",textAlign:"center"}}/>
              </div>
              <div style={{fontSize:9,color:"#444",fontFamily:"'Space Mono',monospace"}}>Tip: paste coordinates from Google Maps or use the bars map centre</div>
            </div>
            {/* Speed thresholds */}
            <div style={{marginTop:12,padding:"10px 12px",background:"#FF2D5510",border:"1px solid #FF2D5530",borderRadius:10}}>
              <div style={{fontSize:9,letterSpacing:2,color:"#FF2D55",marginBottom:6}}>SPEED SAFETY THRESHOLDS</div>
              <div style={{fontSize:10,color:"#888",lineHeight:1.7}}>
                Warning at: <strong style={{color:"#FF9500"}}>{SPEED_WARN_KMH} km/h</strong> · Lock at: <strong style={{color:"#FF2D55"}}>{SPEED_LOCK_KMH} km/h</strong> · Clear below: <strong style={{color:"#34C759"}}>{SPEED_CLEAR_KMH} km/h</strong>
              </div>
              <div style={{fontSize:9,color:"#555",marginTop:4}}>These values are hardcoded for safety and cannot be changed by designers.</div>
            </div>
            </div>
          </div>

          <div style={{...S.card}}>
            <div style={S.sectionTitle}>INACTIVITY TIMEOUTS</div>
            {[{key:"warnSecs",label:"Warn after (mins)",min:300,max:3600,step:60},{key:"kickSecs",label:"Kick after (mins)",min:600,max:7200,step:60}].map(({key,label,min,max,step})=>(
              <div key={key} style={{marginBottom:12}}>
                <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                  <div style={{fontSize:11,color:"#888"}}>{label}</div>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:16,color:"#00C7BE"}}>{Math.floor(config.inactivity[key]/60)}m</div>
                </div>
                <input type="range" min={min} max={max} step={step} value={config.inactivity[key]}
                  onChange={e=>setConfig(c=>({...c,inactivity:{...c.inactivity,[key]:parseInt(e.target.value)}}))}
                  style={{width:"100%",accentColor:"#00C7BE"}}/>
              </div>
            ))}
          </div>
          <div style={{...S.card}}>
            <div style={S.sectionTitle}>BROADCAST MESSAGE</div>
            <div style={{fontSize:10,color:"#555",marginBottom:8}}>Shown as a banner to all players in the app</div>
            <textarea value={config.maintenance.message} onChange={e=>setConfig(c=>({...c,maintenance:{...c.maintenance,message:e.target.value}}))} placeholder="e.g. 🎉 Special event tonight at The Rusty Anchor — double XP until midnight!" maxLength={200} style={{width:"100%",background:"#12121a",border:"1px solid #2a2a3a",borderRadius:10,color:"#f0f0f8",fontFamily:"'Space Mono',monospace",fontSize:11,padding:"10px 12px",outline:"none",resize:"none",height:72,lineHeight:1.6,marginBottom:8}}/>
            {config.maintenance.message&&<div style={{background:"#FF950015",border:"1px solid #FF950030",borderRadius:8,padding:"8px 12px",fontSize:11,color:"#FF9500"}}>📢 Preview: {config.maintenance.message}</div>}
          </div>
          <div style={{...S.card}}>
            <div style={S.sectionTitle}>DESIGNER ACCOUNTS</div>
            {DESIGNER_ACCOUNTS.map(d=>(
              <div key={d.id} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:"1px solid #1a1d2e"}}>
                <span style={{fontSize:20}}>{d.avatar}</span>
                <div style={{flex:1}}><div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,letterSpacing:1}}>{d.name}</div><div style={{fontSize:9,color:"#555"}}>{d.username} · {d.level}</div></div>
                <Pill label={d.level.toUpperCase()} color={d.level==="super"?"#BF5AF2":"#00C7BE"}/>
              </div>
            ))}
            <div style={{fontSize:10,color:"#444",marginTop:8,lineHeight:1.6}}>To add/remove designers, update DESIGNER_ACCOUNTS in the source and redeploy.</div>
          </div>
          {isSuper&&(
            <button onClick={()=>setConfirm({action:"reset",label:"RESET ALL CONFIG TO DEFAULTS",body:"This will reset ALL pricing, weapons, features, and CTF settings to factory defaults. This cannot be undone.",color:"#FF2D55",onConfirm:()=>{setConfig(JSON.parse(JSON.stringify(DEFAULT_GAME_CONFIG)));addLog("⚠️ FULL CONFIG RESET TO DEFAULTS");setConfirm(null);}})} style={{...S.btnGhost,width:"100%",padding:12,color:"#FF2D55",borderColor:"#FF2D5540",textAlign:"center"}}>
              ⚠️ RESET ALL CONFIG TO DEFAULTS
            </button>
          )}
        </div>
      )}

      {/* ── CHANGELOG TAB ── */}
      {tab==="changelog"&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          <div style={{...S.card,fontSize:11,color:"#888",lineHeight:1.7}}>All configuration changes made in this session. Persisted to Firebase in production.</div>
          {changelog.length===0&&<div style={{...S.card,textAlign:"center",color:"#444",fontSize:12}}>No changes yet this session.</div>}
          {changelog.map((entry,i)=>(
            <div key={entry.id||i} style={{...S.card,display:"flex",gap:10,alignItems:"flex-start"}}>
              <div style={{flex:1}}>
                <div style={{fontSize:12,color:"#f0f0f8",fontFamily:"'Space Mono',monospace"}}>{entry.action}</div>
                <div style={{fontSize:9,color:"#555",marginTop:3}}>{entry.designer} · {new Date(entry.ts).toLocaleTimeString()}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Save button (sticky) */}
      <button onClick={save} style={{...S.btnPrimary,background:"linear-gradient(135deg,#BF5AF2,#7B2FBE)",position:"sticky",bottom:12}}>
        {saved?"✅ SAVED!":"💾 SAVE CHANGES"}
      </button>

      {/* Confirm modal */}
      {confirm&&(
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.9)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:500,padding:20}}>
          <div style={{background:"#0d0e1a",border:`2px solid ${confirm.color}`,borderRadius:20,padding:"28px 24px",maxWidth:340,width:"100%",textAlign:"center",boxShadow:`0 0 40px ${confirm.color}30`,animation:"popIn .3s ease"}}>
            <div style={{fontSize:40,marginBottom:12}}>⚠️</div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:18,letterSpacing:2,color:confirm.color,marginBottom:10}}>{confirm.label}</div>
            <div style={{fontSize:12,color:"#888",marginBottom:20,lineHeight:1.7}}>{confirm.body}</div>
            <div style={{display:"flex",gap:8}}>
              <button onClick={()=>setConfirm(null)} style={{...S.btnGhost,flex:1,padding:12}}>CANCEL</button>
              <button onClick={confirm.onConfirm} style={{flex:2,padding:13,border:"none",borderRadius:12,background:`linear-gradient(135deg,${confirm.color},${confirm.color}aa)`,color:confirm.color==="#FF9500"?"#000":"#fff",fontFamily:"'Black Han Sans',sans-serif",fontSize:16,letterSpacing:2,cursor:"pointer"}}>CONFIRM</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}


// ═══════════════════════════════════════════════════════════════════════════════
// LIVE SCOREBOARD — "CrawlFire Sports Network"
// ─────────────────────────────────────────────────────────────────────────────
// A live sports-broadcast-style scoreboard covering all active crawls globally.
// Pulls from Firebase lobby/ index + game state in real time.
// Shows: active games, live kill feeds, top players, territory leaderboard,
//        city heat map, and rolling news ticker.
// Designed to look like a real sports broadcast — think Sky Sports or ESPN
// but for pub crawl QR laser tag.
// ═══════════════════════════════════════════════════════════════════════════════

// Demo data generator for scoreboard (replaced by Firebase in prod)
function makeScoreboardData() {
  const now = Date.now();
  return {
    activeCrawls: [
      {id:"g1",code:"FIRE7A",region:"london",regionFlag:"🇬🇧",title:"Friday Night Mayhem",
       difficulty:"advanced",status:"active",
       players:[
         {id:"p1",name:"GINTONIC",  av:"🎯",kills:7,hp:45,coins:380,team:null,alive:true},
         {id:"p2",name:"BEERCAT",   av:"💣",kills:5,hp:20,coins:210,team:null,alive:true},
         {id:"p3",name:"ALEHEAD",   av:"⚡",kills:4,hp:88,coins:290,team:null,alive:true},
         {id:"p4",name:"HOPHEAD",   av:"🔥",kills:3,hp:0, coins:120,team:null,alive:false},
         {id:"p5",name:"MALTMAGE",  av:"🐺",kills:2,hp:61,coins:175,team:null,alive:true},
       ],
       pot:24.85, startedAt:now-18*60000, events:[
         {type:"kill",from:"GINTONIC",to:"HOPHEAD",weapon:"Tequila Bomb",ts:now-90000},
         {type:"kill",from:"BEERCAT",to:"MALTMAGE",weapon:"Gin Sniper",ts:now-45000},
         {type:"mine_trigger",msg:"💥 ALEHEAD hit Proximity Mine!",ts:now-20000},
         {type:"loot",from:"GINTONIC",item:"Nuke Shot",ts:now-8000},
       ]},
      {id:"g2",code:"WOLF3X",region:"nyc",regionFlag:"🇺🇸",title:"Manhattan Massacre",
       difficulty:"intermediate",status:"active",
       players:[
         {id:"q1",name:"QUEENS",    av:"🦁",kills:9,hp:72,coins:420,team:"red",alive:true},
         {id:"q2",name:"BRONXBREW", av:"🐯",kills:6,hp:55,coins:310,team:"blue",alive:true},
         {id:"q3",name:"HARLEMHOP", av:"🦊",kills:4,hp:30,coins:180,team:"red",alive:true},
         {id:"q4",name:"BROOKBEER", av:"🐻",kills:2,hp:90,coins:140,team:"blue",alive:true},
       ],
       pot:18.60, startedAt:now-32*60000, events:[
         {type:"flag",from:"QUEENS",msg:"⚑ QUEENS captured The Dead Rabbit flag!",ts:now-60000},
         {type:"kill",from:"BRONXBREW",to:"HARLEMHOP",weapon:"Whiskey Blast",ts:now-30000},
         {type:"flag",from:"BROOKBEER",msg:"🔥 BROOKBEER STOLE McSorley's flag!",ts:now-15000},
       ]},
      {id:"g3",code:"BEAR9K",region:"berlin",regionFlag:"🇩🇪",title:"Berliner Bash",
       difficulty:"beginner",status:"active",
       players:[
         {id:"r1",name:"BERLINER",  av:"🐯",kills:3,hp:130,coins:95, team:null,alive:true},
         {id:"r2",name:"BRATWURST", av:"🦊",kills:2,hp:105,coins:70, team:null,alive:true},
         {id:"r3",name:"WEIZENGUY", av:"🐺",kills:1,hp:80, coins:45, team:null,alive:true},
       ],
       pot:9.20, startedAt:now-8*60000, events:[
         {type:"kill",from:"BERLINER",to:"WEIZENGUY",weapon:"Stout Shot",ts:now-120000},
       ]},
      {id:"g4",code:"MALT5R",region:"manchester",regionFlag:"🇬🇧",title:"Madchester Monday",
       difficulty:"intermediate",status:"active",
       players:[
         {id:"s1",name:"MADMALT",   av:"🍺",kills:5,hp:60, coins:255,team:null,alive:true},
         {id:"s2",name:"CITYALE",   av:"⭐",kills:4,hp:40, coins:200,team:null,alive:true},
         {id:"s3",name:"UNITEDIPA", av:"🏆",kills:3,hp:75, coins:160,team:null,alive:true},
         {id:"s4",name:"TRAFFORD",  av:"🔥",kills:1,hp:15, coins:80, team:null,alive:false},
       ],
       pot:15.40, startedAt:now-25*60000, events:[
         {type:"kill",from:"MADMALT",to:"TRAFFORD",weapon:"Cider Surge",ts:now-180000},
         {type:"kill",from:"CITYALE",to:"TRAFFORD",weapon:"Stout Shot",ts:now-90000},
       ]},
    ],
    recentlyEnded:[
      {code:"GONE1A",region:"london",regionFlag:"🇬🇧",title:"Thursday Thrash",winner:"NIGHTCAP",av:"🌙",kills:11,pot:31.50,endedAt:now-2*3600000},
      {code:"OVER7B",region:"nyc",regionFlag:"🇺🇸",title:"Tuesday Takedown",winner:"GUINNESS",av:"🍀",kills:8,pot:22.00,endedAt:now-5*3600000},
    ],
    topPlayers:[
      {id:"p1",name:"GINTONIC",  av:"🎯",weeklyKills:47,weeklyWins:3,territory:8, rank:1},
      {id:"q1",name:"QUEENS",    av:"🦁",weeklyKills:38,weeklyWins:2,territory:5, rank:2},
      {id:"p2",name:"BEERCAT",   av:"💣",weeklyKills:31,weeklyWins:1,territory:3, rank:3},
      {id:"r1",name:"BERLINER",  av:"🐯",weeklyKills:28,weeklyWins:2,territory:6, rank:4},
      {id:"s1",name:"MADMALT",   av:"🍺",weeklyKills:25,weeklyWins:1,territory:4, rank:5},
    ],
    cityHeat:[
      {region:"london",    flag:"🇬🇧",activePlayers:17,activeCrawls:2,topPlayer:"GINTONIC",hotBar:"The Rusty Anchor"},
      {region:"nyc",       flag:"🇺🇸",activePlayers:12,activeCrawls:1,topPlayer:"QUEENS",   hotBar:"The Dead Rabbit"},
      {region:"berlin",    flag:"🇩🇪",activePlayers:6, activeCrawls:1,topPlayer:"BERLINER", hotBar:"Zum Schmutzigen"},
      {region:"manchester",flag:"🇬🇧",activePlayers:8, activeCrawls:1,topPlayer:"MADMALT",  hotBar:"The Marble Arch"},
      {region:"sydney",    flag:"🇦🇺",activePlayers:0, activeCrawls:0,topPlayer:"—",         hotBar:"—"},
      {region:"toronto",   flag:"🇨🇦",activePlayers:0, activeCrawls:0,topPlayer:"—",         hotBar:"—"},
    ],
  };
}

// ── Ticker component ──────────────────────────────────────────────────────────
function Ticker({ events }) {
  const allMsgs = events.map(ev => {
    if(ev.type==="kill")    return `💀 ${ev.from} ELIMINATED ${ev.to} with ${ev.weapon}`;
    if(ev.type==="flag")    return ev.msg;
    if(ev.type==="mine_trigger") return ev.msg;
    if(ev.type==="loot")    return `🎁 ${ev.from} grabbed ${ev.item}`;
    return ev.msg||"";
  }).filter(Boolean);

  const [pos, setPos] = useState(0);
  const text = allMsgs.join("   ·   ");
  useEffect(()=>{
    const id=setInterval(()=>setPos(p=>(p+1)%(text.length*8)),50);
    return()=>clearInterval(id);
  },[text]);

  return(
    <div style={{overflow:"hidden",whiteSpace:"nowrap",flex:1}}>
      <div style={{
        display:"inline-block",
        transform:`translateX(${-pos}px)`,
        fontFamily:"'DM Mono',monospace",
        fontSize:10, color:"#FF9500", letterSpacing:.5,
        paddingRight:200,
      }}>
        {text}{"   ·   "}{text}
      </div>
    </div>
  );
}

// ── ScoreCard — one active game ───────────────────────────────────────────────
function ScoreCard({ game, expanded, onClick }) {
  const diff     = DIFFICULTY_LEVELS[game.difficulty||"intermediate"]||DIFFICULTY_LEVELS.intermediate;
  const alive    = game.players.filter(p=>p.alive);
  const sorted   = [...game.players].sort((a,b)=>b.kills-a.kills);
  const elapsed  = Math.floor((Date.now()-game.startedAt)/60000);
  const leader   = sorted[0];
  const isCTF    = game.players.some(p=>p.team);
  const teams    = isCTF ? [...new Set(game.players.map(p=>p.team).filter(Boolean))].map(tid=>({
    id:tid, name:CTF_TEAMS.find(t=>t.id===tid)?.n||tid, color:CTF_TEAMS.find(t=>t.id===tid)?.c||"#888",
    kills:game.players.filter(p=>p.team===tid&&p.alive).reduce((s,p)=>s+p.kills,0),
  })) : [];

  return(
    <div onClick={onClick} style={{
      background:"#0c0e1a",border:`2px solid ${diff.color}30`,borderRadius:14,
      overflow:"hidden",cursor:"pointer",transition:"all .2s",
      boxShadow:expanded?`0 0 24px ${diff.color}20`:"none",
    }}>
      {/* Header bar */}
      <div style={{background:`${diff.color}18`,borderBottom:`1px solid ${diff.color}25`,padding:"10px 14px",display:"flex",alignItems:"center",gap:10}}>
        <span style={{fontSize:20,flexShrink:0}}>{game.regionFlag}</span>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,color:"#f0f0f8",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{game.title}</div>
          <div style={{fontSize:9,color:"#555",marginTop:1,display:"flex",gap:8}}>
            <span>⏱ {elapsed}m</span>
            <span>👥 {alive.length}/{game.players.length}</span>
            <span style={{color:"#FFCC00"}}>💰 {typeof game.pot==="number"?`$${game.pot.toFixed(2)}`:game.pot}</span>
            <span style={{color:diff.color}}>{diff.icon} {diff.label}</span>
          </div>
        </div>
        {/* Live badge */}
        <div style={{display:"flex",alignItems:"center",gap:4,padding:"2px 8px",background:"#FF2D5520",border:"1px solid #FF2D5540",borderRadius:20,flexShrink:0}}>
          <div style={{width:5,height:5,borderRadius:"50%",background:"#FF2D55",animation:"pulse 1.5s ease-in-out infinite"}}/>
          <span style={{fontSize:8,color:"#FF2D55",letterSpacing:1,fontFamily:"'DM Mono',monospace"}}>LIVE</span>
        </div>
      </div>

      {/* Mini leaderboard (always visible) */}
      <div style={{padding:"8px 14px"}}>
        {/* Top 3 players */}
        <div style={{display:"flex",gap:6,marginBottom:6}}>
          {sorted.slice(0,3).map((p,i)=>(
            <div key={p.id} style={{flex:1,background:"#07080f",border:`1px solid ${i===0?"#FFCC0040":"#1a1d2e"}`,borderRadius:8,padding:"6px 8px",textAlign:"center",position:"relative"}}>
              {i===0&&<div style={{position:"absolute",top:-1,left:"50%",transform:"translateX(-50%)",fontSize:8,color:"#FFCC00"}}>👑</div>}
              <div style={{fontSize:18,marginTop:i===0?6:0}}>{p.av}</div>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:9,color:i===0?"#FFCC00":"#888",letterSpacing:.5,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.name}</div>
              <div style={{fontSize:10,color:"#FF2D55",fontFamily:"'Black Han Sans',sans-serif"}}>{p.kills}💀</div>
              <div style={{height:2,background:"#1a1d2e",borderRadius:1,overflow:"hidden",marginTop:3}}>
                <div style={{height:"100%",width:`${(p.hp/120)*100}%`,background:p.hp>60?"#34C759":p.hp>25?"#FF9500":"#FF2D55",borderRadius:1}}/>
              </div>
            </div>
          ))}
        </div>

        {/* CTF team scores */}
        {isCTF&&teams.length>0&&(
          <div style={{display:"flex",gap:6,marginBottom:6}}>
            {teams.map(t=>(
              <div key={t.id} style={{flex:1,padding:"5px 8px",background:`${t.color}15`,border:`1px solid ${t.color}40`,borderRadius:8,textAlign:"center"}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,color:t.color}}>{t.kills}</div>
                <div style={{fontSize:8,color:t.color+"88",letterSpacing:1}}>{t.name.split(" ")[0]}</div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Expanded: full player list + recent events */}
      {expanded&&(
        <div style={{borderTop:"1px solid #1a1d2e",padding:"10px 14px",display:"flex",flexDirection:"column",gap:8,animation:"slideUp .2s ease"}}>
          {/* Full standings */}
          <div style={{fontSize:8,color:"#555",letterSpacing:2}}>FULL STANDINGS</div>
          {sorted.map((p,i)=>(
            <div key={p.id} style={{display:"flex",alignItems:"center",gap:8,opacity:p.alive?1:.4}}>
              <span style={{fontSize:13,width:18,textAlign:"center"}}>{["🥇","🥈","🥉","4️⃣","5️⃣"][i]||`${i+1}.`}</span>
              <span style={{fontSize:16}}>{p.av}</span>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:11,color:p.alive?"#f0f0f8":"#555"}}>{p.name}{!p.alive&&" 💀"}</div>
                <div style={{height:3,background:"#1a1d2e",borderRadius:1.5,overflow:"hidden",marginTop:2}}>
                  <div style={{height:"100%",width:`${(p.hp/120)*100}%`,background:p.hp>60?"#34C759":p.hp>25?"#FF9500":"#FF2D55",borderRadius:1.5}}/>
                </div>
              </div>
              <div style={{textAlign:"right",flexShrink:0}}>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:"#FF2D55"}}>{p.kills}</div>
                <div style={{fontSize:8,color:"#555"}}>kills</div>
              </div>
              <div style={{textAlign:"right",flexShrink:0}}>
                <div style={{fontSize:10,color:"#FFCC00"}}>🪙{p.coins}</div>
              </div>
            </div>
          ))}

          {/* Recent events */}
          {game.events.length>0&&(
            <>
              <div style={{fontSize:8,color:"#555",letterSpacing:2,marginTop:4}}>LIVE FEED</div>
              {[...game.events].reverse().slice(0,3).map((ev,i)=>(
                <div key={i} style={{fontSize:10,padding:"4px 10px",borderRadius:7,borderLeft:`3px solid ${ev.type==="kill"?"#FF2D55":ev.type==="flag"?"#007AFF":"#FF9500"}`,background:"#07080f",color:"#888",fontFamily:"'DM Mono',monospace",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                  {ev.type==="kill"?`💀 ${ev.from} → ${ev.to} (${ev.weapon})`:ev.type==="flag"?ev.msg:ev.type==="mine_trigger"?ev.msg:`🎁 ${ev.from} got ${ev.item}`}
                  <span style={{color:"#333",marginLeft:6,fontSize:8}}>{Math.floor((Date.now()-ev.ts)/1000)}s ago</span>
                </div>
              ))}
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ── Main LiveScoreboard component ─────────────────────────────────────────────
function LiveScoreboard({ onBack, myId }) {
  const [data,       setData]       = useState(()=>makeScoreboardData());
  const [expanded,   setExpanded]   = useState("g1");
  const [sbTab,      setSbTab]      = useState("live");   // live | global | cities | ended
  const [ticker,     setTicker]     = useState(true);
  const [lastUpdate, setLastUpdate] = useState(Date.now());
  const [tick,       setTick]       = useState(0);

  // Simulate live updates every 8 seconds (in prod: Firebase subscribe("lobby",…))
  useEffect(() => {
    const id = setInterval(() => {
      setData(d => {
        const crawls = d.activeCrawls.map(g => {
          // Simulate a random kill event
          const alive = g.players.filter(p=>p.alive);
          if(alive.length < 2 || Math.random() > 0.4) return g;
          const att = alive[Math.floor(Math.random()*alive.length)];
          const tgts = alive.filter(p=>p.id!==att.id);
          const tgt = tgts[Math.floor(Math.random()*tgts.length)];
          if(!tgt) return g;
          const wpns = ["Tequila Bomb","Gin Sniper","Stout Shot","Whiskey Blast","Nuke Shot"];
          const wpn = wpns[Math.floor(Math.random()*wpns.length)];
          const newHp = Math.max(0, tgt.hp - (10+Math.floor(Math.random()*30)));
          const tagged = newHp <= 0;
          const newEv = {type:"kill",from:att.name,to:tgt.name,weapon:wpn,ts:Date.now()};
          return{...g,
            players:g.players.map(p=>{
              if(p.id===att.id)return{...p,kills:p.kills+(tagged?1:0)};
              if(p.id===tgt.id)return{...p,hp:newHp,alive:!tagged};
              return p;
            }),
            events:[newEv,...g.events].slice(0,10),
          };
        });
        return {...d, activeCrawls:crawls};
      });
      setLastUpdate(Date.now());
      setTick(t=>t+1);
    }, 8000);
    return () => clearInterval(id);
  }, []);

  const allEvents = data.activeCrawls.flatMap(g=>g.events);
  const totalPot  = data.activeCrawls.reduce((s,g)=>s+(typeof g.pot==="number"?g.pot:0),0);
  const totalAlive= data.activeCrawls.reduce((s,g)=>s+g.players.filter(p=>p.alive).length,0);

  return (
    <div style={S.screen}>
      {/* ── BROADCAST HEADER ── */}
      <div style={{background:"#0a0c14",border:"1px solid #FF2D5530",borderRadius:14,overflow:"hidden",position:"relative"}}>
        {/* Network logo */}
        <div style={{background:"linear-gradient(135deg,#FF2D55,#FF6B35)",padding:"10px 16px",display:"flex",alignItems:"center",gap:10}}>
          <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,letterSpacing:4,color:"#fff",textShadow:"0 2px 4px rgba(0,0,0,.3)"}}>📺 CRAWLFIRE SPORTS</div>
          <div style={{flex:1}}/>
          <div style={{display:"flex",alignItems:"center",gap:5}}>
            <div style={{width:8,height:8,borderRadius:"50%",background:"#fff",animation:"pulse 1s ease-in-out infinite"}}/>
            <span style={{fontSize:11,color:"#fff",fontFamily:"'DM Mono',monospace",letterSpacing:1}}>LIVE</span>
          </div>
        </div>

        {/* Stats strip */}
        <div style={{display:"flex",borderBottom:"1px solid #1a1d2e"}}>
          {[
            {v:data.activeCrawls.length,l:"ACTIVE GAMES",c:"#FF2D55"},
            {v:totalAlive,               l:"PLAYERS LIVE", c:"#34C759"},
            {v:`$${totalPot.toFixed(0)}`,l:"IN POTS",       c:"#FFCC00"},
            {v:data.cityHeat.filter(c=>c.activeCrawls>0).length,l:"CITIES",c:"#007AFF"},
          ].map((s,i)=>(
            <div key={i} style={{flex:1,textAlign:"center",padding:"8px 4px",borderRight:i<3?"1px solid #1a1d2e":"none"}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:20,color:s.c,lineHeight:1}}>{s.v}</div>
              <div style={{fontSize:7,color:"#555",letterSpacing:1,marginTop:2}}>{s.l}</div>
            </div>
          ))}
        </div>

        {/* Ticker */}
        {ticker&&allEvents.length>0&&(
          <div style={{display:"flex",alignItems:"center",gap:8,padding:"6px 12px",background:"#FF950015",borderBottom:"1px solid #FF950030"}}>
            <div style={{background:"#FF9500",color:"#000",fontFamily:"'Black Han Sans',sans-serif",fontSize:9,letterSpacing:1,padding:"2px 7px",borderRadius:4,flexShrink:0}}>LIVE</div>
            <Ticker events={allEvents}/>
            <button onClick={()=>setTicker(false)} style={{background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:12,flexShrink:0}}>✕</button>
          </div>
        )}

        {/* Last update */}
        <div style={{padding:"4px 14px",fontSize:8,color:"#333",letterSpacing:1,fontFamily:"'DM Mono',monospace",textAlign:"right"}}>
          Updated {Math.floor((Date.now()-lastUpdate)/1000)}s ago · AUTO-REFRESH ON
        </div>
      </div>

      {/* ── TAB BAR ── */}
      <div style={{display:"flex",gap:5}}>
        {[["live","🔴 LIVE"],["global","🌍 GLOBAL"],["cities","🏙️ CITIES"],["ended","🏁 ENDED"]].map(([id,label])=>(
          <button key={id} onClick={()=>setSbTab(id)} style={{flex:1,padding:"8px 4px",border:`2px solid ${sbTab===id?"#FF2D55":"#1a1d2e"}`,borderRadius:10,background:sbTab===id?"#FF2D5515":"#0d0e1a",color:sbTab===id?"#FF2D55":"#555",fontFamily:"'Black Han Sans',sans-serif",fontSize:9,letterSpacing:1,cursor:"pointer",whiteSpace:"nowrap"}}>
            {label}
          </button>
        ))}
      </div>

      {/* ── LIVE GAMES ── */}
      {sbTab==="live"&&(
        <div style={{display:"flex",flexDirection:"column",gap:10}}>
          {data.activeCrawls.map(g=>(
            <ScoreCard key={g.id} game={g} expanded={expanded===g.id} onClick={()=>setExpanded(expanded===g.id?null:g.id)}/>
          ))}
        </div>
      )}

      {/* ── GLOBAL TOP PLAYERS ── */}
      {sbTab==="global"&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          <div style={{...S.card,background:"#0a0c14",border:"1px solid #FFCC0030"}}>
            <div style={{fontSize:9,color:"#FFCC00",letterSpacing:3,marginBottom:8}}>🏆 WEEKLY TOP PLAYERS</div>
            {data.topPlayers.map((p,i)=>(
              <div key={p.id} style={{display:"flex",alignItems:"center",gap:10,padding:"9px 0",borderBottom:i<data.topPlayers.length-1?"1px solid #1a1d2e":"none"}}>
                <span style={{fontSize:18,width:26,textAlign:"center"}}>{["🥇","🥈","🥉","4️⃣","5️⃣"][i]}</span>
                <span style={{fontSize:24}}>{p.av}</span>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:p.id===myId?"#FFCC00":"#f0f0f8"}}>{p.name}{p.id===myId&&<span style={{fontSize:9,color:"#FFCC00",marginLeft:5}}>YOU</span>}</div>
                  <div style={{fontSize:9,color:"#555",marginTop:2,display:"flex",gap:8}}>
                    <span style={{color:"#FF2D55"}}>💀 {p.weeklyKills} kills</span>
                    <span style={{color:"#34C759"}}>🏆 {p.weeklyWins} wins</span>
                    <span style={{color:"#FFCC00"}}>🗺️ {p.territory} bars</span>
                  </div>
                </div>
                <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:"#FF2D55"}}>#<span style={{fontSize:18}}>{p.rank}</span></div>
              </div>
            ))}
          </div>

          {/* Live pot totals */}
          <div style={{...S.card,background:"#FFCC0010",border:"1px solid #FFCC0030",textAlign:"center"}}>
            <div style={{fontSize:9,color:"#FFCC00",letterSpacing:3,marginBottom:4}}>💰 TOTAL IN PLAY TONIGHT</div>
            <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:44,color:"#FFCC00",textShadow:"0 0 20px #FFCC0060"}}>${totalPot.toFixed(2)}</div>
            <div style={{fontSize:11,color:"#555",marginTop:4}}>Across {data.activeCrawls.length} active crawls</div>
          </div>
        </div>
      )}

      {/* ── CITY HEAT MAP ── */}
      {sbTab==="cities"&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {/* Dead City active players global counter */}
          <div style={{...S.card,background:"#34C75910",border:"1px solid #34C75930",display:"flex",alignItems:"center",gap:10}}>
            <span style={{fontSize:24,animation:"breathe 2s ease-in-out infinite"}}>☣️</span>
            <div style={{flex:1}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,color:"#34C759"}}>DEAD CITY — GLOBAL</div>
              <div style={{fontSize:10,color:"#555",marginTop:2}}>Solo zombie hunters active right now across all cities</div>
            </div>
            <div style={{textAlign:"center"}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:28,color:"#34C759"}}>{Math.floor(Math.random()*40)+12}</div>
              <div style={{fontSize:7,color:"#555",letterSpacing:1}}>HUNTERS</div>
            </div>
          </div>
          <div style={{fontSize:9,color:"#555",letterSpacing:3}}>CRAWL ACTIVITY — LIVE</div>
          {data.cityHeat.map((city,i)=>{
            const heat = Math.min(100,(city.activePlayers/20)*100);
            const heatColor = heat>60?"#FF2D55":heat>20?"#FF9500":"#34C759";
            const isActive = city.activeCrawls>0;
            return(
              <div key={city.region} style={{...S.card,border:`1px solid ${isActive?heatColor+"40":"#1a1d2e"}`,background:isActive?`${heatColor}08`:"#0d0e1a"}}>
                <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:isActive?8:0}}>
                  <span style={{fontSize:28,flexShrink:0}}>{city.flag}</span>
                  <div style={{flex:1}}>
                    <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,letterSpacing:1,color:isActive?heatColor:"#555",textTransform:"capitalize"}}>{city.region}</div>
                    <div style={{fontSize:10,color:"#555",marginTop:2}}>
                      {isActive?`${city.activePlayers} players · ${city.activeCrawls} crawl${city.activeCrawls!==1?"s":""}`:(<span style={{color:"#333"}}>No active games</span>)}
                    </div>
                  </div>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,color:heatColor}}>{city.activePlayers}</div>
                    <div style={{fontSize:7,color:"#555",letterSpacing:1}}>PLAYERS</div>
                  </div>
                </div>
                {isActive&&(
                  <>
                    <div style={{height:6,background:"#1a1d2e",borderRadius:3,overflow:"hidden"}}>
                      <div style={{height:"100%",width:`${heat}%`,background:`linear-gradient(90deg,${heatColor},${heatColor}cc)`,borderRadius:3,transition:"width .6s"}}/>
                    </div>
                    <div style={{display:"flex",justifyContent:"space-between",fontSize:9,color:"#555",marginTop:4}}>
                      <span>🔥 Hot bar: {city.hotBar}</span>
                      <span>👑 Leader: {city.topPlayer}</span>
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* ── RECENTLY ENDED ── */}
      {sbTab==="ended"&&(
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          <div style={{fontSize:9,color:"#555",letterSpacing:3}}>RECENTLY COMPLETED</div>
          {data.recentlyEnded.map(g=>(
            <div key={g.code} style={{...S.card,border:"1px solid #34C75930"}}>
              <div style={{display:"flex",alignItems:"center",gap:10}}>
                <span style={{fontSize:24}}>{g.regionFlag}</span>
                <div style={{flex:1}}>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,color:"#f0f0f8"}}>{g.title}</div>
                  <div style={{fontSize:10,color:"#555",marginTop:2}}>{Math.floor((Date.now()-g.endedAt)/3600000)}h ago</div>
                </div>
                <div style={{textAlign:"right"}}>
                  <div style={{fontSize:10,color:"#34C759"}}>CHAMPION</div>
                  <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:14,color:"#FFCC00"}}>{g.av} {g.winner}</div>
                  <div style={{fontSize:11,color:"#FFCC00"}}>💀{g.kills} kills · 🏆${g.pot.toFixed(2)}</div>
                </div>
              </div>
            </div>
          ))}
          {data.recentlyEnded.length===0&&<div style={{...S.card,textAlign:"center",color:"#555",fontSize:12,padding:20}}>No recently completed games</div>}
        </div>
      )}

      <button style={S.btnGhost} onClick={onBack}>← BACK</button>
    </div>
  );
}


// ═══════════════════════════════════════════════════════════════════════════════
// FIREBASE SETUP GUIDE — shown when FIREBASE_CONFIG has placeholder values
// ═══════════════════════════════════════════════════════════════════════════════
function FirebaseSetupGuide({onClose}){
  const steps=[
    {n:"1",title:"Create Firebase project",body:"Go to console.firebase.google.com → Add project → name it CrawlFire → disable Google Analytics → Create project.",link:"https://console.firebase.google.com",cta:"Open Firebase Console"},
    {n:"2",title:"Enable Realtime Database",body:"In your project → Build → Realtime Database → Create database → Choose your region → Start in test mode (you'll lock it down later).",link:null},
    {n:"3",title:"Enable Anonymous Auth",body:"Build → Authentication → Get started → Sign-in method → Anonymous → Enable → Save. This lets players join without creating accounts.",link:null},
    {n:"4",title:"Get your config",body:"Project settings (⚙️ gear icon) → Your apps → Add web app → Register app → copy the firebaseConfig object.",link:null},
    {n:"5",title:"Paste config into the app",body:"Replace the placeholder values in FIREBASE_CONFIG at the top of crawlfire-complete.jsx with your real values. The apiKey, databaseURL and appId are the critical ones.",link:null},
    {n:"6",title:"Set database rules",body:'Realtime Database → Rules tab → paste the rules below → Publish.',ruleBlock:`{
  "rules": {
    "games": {
      "$gameId": {
        ".read": true,
        ".write": "auth != null"
      }
    },
    "cf:chat": { ".read": true, ".write": "auth != null" },
    "cf:codes": { ".read": true, ".write": "auth != null" }
  }
}`},
    {n:"7",title:"Deploy & test",body:"Run your dev server or deploy to Vercel. Open the app on two different phones — both should see each other's game state update within ~100ms.",link:null},
  ];
  return(
    <div style={S.screen}>
      <button style={S.btnGhost} onClick={onClose}>← BACK</button>
      <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:22,letterSpacing:2,color:"#f0f0f8",textAlign:"center"}}>🔥 FIREBASE SETUP</div>
      <div style={{fontSize:11,color:"#888",textAlign:"center",lineHeight:1.7}}>Connect CrawlFire to Firebase for real-time cross-device multiplayer in 7 steps.</div>

      {steps.map((step,i)=>(
        <div key={step.n} style={{...S.card,border:"1px solid #1e2237",display:"flex",flexDirection:"column",gap:8}}>
          <div style={{display:"flex",alignItems:"flex-start",gap:10}}>
            <div style={{width:26,height:26,borderRadius:"50%",background:"#FF2D5520",border:"1px solid #FF2D5540",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
              <span style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:12,color:"#FF2D55"}}>{step.n}</span>
            </div>
            <div style={{flex:1}}>
              <div style={{fontFamily:"'Black Han Sans',sans-serif",fontSize:13,letterSpacing:1,color:"#f0f0f8",marginBottom:4}}>{step.title}</div>
              <div style={{fontSize:11,color:"#888",lineHeight:1.7}}>{step.body}</div>
            </div>
          </div>
          {step.link&&<a href={step.link} target="_blank" rel="noopener noreferrer" style={{display:"block",padding:"8px 14px",border:"1px solid #FF2D5540",borderRadius:10,background:"#FF2D5510",color:"#FF2D55",fontFamily:"'Black Han Sans',sans-serif",fontSize:11,letterSpacing:1,textDecoration:"none",textAlign:"center"}}>{step.cta} →</a>}
          {step.ruleBlock&&<pre style={{background:"#07080f",border:"1px solid #1e2237",borderRadius:8,padding:"10px 12px",fontSize:10,color:"#34C759",fontFamily:"'Space Mono',monospace",overflowX:"auto",lineHeight:1.6,whiteSpace:"pre-wrap"}}>{step.ruleBlock}</pre>}
        </div>
      ))}

      <div style={{...S.card,background:"#FF950010",border:"1px solid #FF950030",fontSize:11,color:"#FF9500",lineHeight:1.8}}>
        ⚡ <strong>Free tier is more than enough</strong> for pub crawls.<br/>
        Firebase Spark (free) supports 100 simultaneous connections and 1GB storage.<br/>
        A 20-player crawl uses ~2MB of realtime data.
      </div>
      <button style={S.btnGhost} onClick={onClose}>← DONE</button>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ROOT APP
// ═══════════════════════════════════════════════════════════════════════════════
export default function App(){
  // Pass region+code so useShared writes to the correct Firebase path
  const gameCode = game?.code || null;
  const shared=useShared({ regionId: regionId||undefined, gameCode: gameCode||undefined });
  const {game,hunt,codes,keys,mutGame,mutHunt,mutCodes}=shared;

  // Navigation
  const [screen,setScreen]=useState("splash");
  const [role,setRole]=useState(null);

  // Player state
  const [myId,setMyId]=useState(null);
  const [pendingCoins,     setPendingCoins]      = useState(200);
  const [difficulty,       setDifficulty]         = useState("intermediate");
  const [pendingDifficulty,setPendingDifficulty]  = useState(null);
  const [deepLinkCode,     setDeepLinkCode]        = useState(null);
  // ── Multi-city region context ────────────────────────────────────────────
  const [regionId,         setRegionId]            = useState(null);
  // ── PROGRESSION ──────────────────────────────────────────────────────────
  const { totalXp, level, rank, addXP, levelUp, dismissLevelUp } = useXP(myId||ctfMyId||"demo");   // e.g. "london"
  const [gameTitle,        setGameTitle]            = useState("");     // display name
  const [browsing,         setBrowsing]             = useState(false);  // lobby browser open

  // ── Deep-link boot: detect #join= in URL hash on first load ───────────────
  useEffect(()=>{
    const parsed=parseJoinLink();
    if(parsed?.code){
      setDeepLinkCode(parsed.code);
      setPendingDifficulty(parsed.difficulty||"intermediate");
      // Fast-path: jump straight to setup with join flow
      setIsJoining(true);
      goto("deeplink_join");
    }
  },[]);
  const [isJoining,setIsJoining]=useState(false);
  const [isHost,setIsHost]=useState(false);

  // Auth state
  const [bartender,setBartender]=useState(null);
  const [musicianAccount,setMusicianAccount]=useState(null);
  const [barAccount,setBarAccount]=useState(null);
  const [barSignupDone,setBarSignupDone]=useState(false);

  // Designer state
  const [designer,setDesigner]=useState(null);

  // CTF state
  const [ctfGame,setCtfGame]=useState(null);
  const [ctfMyId,setCtfMyId]=useState(null);
  const [ctfSetup,setCtfSetup]=useState({teamCount:2,flagCount:4,name:""});
  const [ctfSetupStep,setCtfSetupStep]=useState(1);
  useEffect(()=>{
    // Real-time CTF subscription
    const unsub = subscribe(KEYS.ctf, v => { if(v) setCtfGame(v); });
    return unsub;
  },[]);
  const mutCTF=useCallback(async fn=>{
    const d=await rd(KEYS.ctf);
    if(!d)return;
    const n=fn(d);
    setCtfGame(n);        // optimistic
    await wr(KEYS.ctf,n); // broadcast
  },[]);
  const ctfCapture=useCallback(async(flagId)=>{
    let result={};
    await mutCTF(g=>{const r=applyCTFCapture(g,flagId,ctfMyId);result={result:r.result,pts:r.pts};return r.game;});
    return result;
  },[ctfMyId,mutCTF]);

  const goto=useCallback(s=>setScreen(s),[]);
  const player=game?.players?.[myId];

  // ── INACTIVITY SYSTEM ──────────────────────────────────────────────────────
  const [inactiveWarn, setInactiveWarn] = useState(false);
  const [inactiveSecs, setInactiveSecs] = useState(30);
  const ACTIVE_SCREENS = ["play","scan","shop","inventory","hunt","leaderboard","qr","bar_dash","musician_dash","bar_dashboard","ctf_hud","ctf_flags","ctf_board"];
  const isActiveScreen = ACTIVE_SCREENS.includes(screen);

  const handleInactiveWarn = useCallback((secsLeft) => {
    setInactiveSecs(secsLeft);
    setInactiveWarn(true);
  }, []);

  const handleInactiveKick = useCallback(async () => {
    setInactiveWarn(false);
    // Drop CTF flags held by this player
    if (ctfMyId && ctfGame) {
      await mutCTF(g => ({
        ...g,
        flags: g.flags.map(f => f.heldBy === ctfMyId
          ? {...f, heldBy:null, heldByTeam:null, capturedAt:null}
          : f
        ),
        events: [...(g.events||[]), {
          id:uid(), type:"afk", playerId:ctfMyId,
          msg:`⏱️ ${ctfGame.players[ctfMyId]?.name||"Player"} went AFK — flag dropped!`,
          ts:Date.now()
        }].slice(-50),
      }));
    }
    // Mark laser-tag player as away
    if (myId && game) {
      await mutGame(g => ({
        ...g,
        players: { ...g.players, [myId]: { ...g.players[myId], away: true } },
        events: [...(g.events||[]), {
          id:uid(), type:"afk",
          msg:`⏱️ ${game.players[myId]?.name||"Player"} went AFK`,
          ts:Date.now()
        }].slice(-30),
      }));
    }
    goto("splash");
  }, [ctfMyId, ctfGame, myId, game, mutCTF, mutGame, goto]);

  const handleStayIn = useCallback(() => {
    setInactiveWarn(false);
    // Mark player as back from away
    if (myId && game?.players?.[myId]?.away) {
      mutGame(g => ({...g, players:{...g.players,[myId]:{...g.players[myId],away:false}}}));
    }
  }, [myId, game, mutGame]);

  useInactivity({
    active: isActiveScreen,
    onWarn: handleInactiveWarn,
    onKick: handleInactiveKick,
  });

  // ── TEAM COMMS ────────────────────────────────────────────────────────────
  const [chatOpen,  setChatOpen]  = useState(false);
  const [chatUnread,setChatUnread]= useState(0);
  const chatPlayer = game?.players?.[myId];
  const chatTeamId = chatPlayer?.teamId || ctfGame?.players?.[ctfMyId]?.teamId || "all";
  const chatTeamColor = {red:"#FF2D55",blue:"#007AFF",green:"#34C759",gold:"#FFCC00"}[chatTeamId] || "#00C7BE";
  const chatActive = ["play","scan","shop","inventory","hunt","leaderboard","qr","ctf_hud","ctf_flags","ctf_board"].includes(screen);

  // Poll unread count
  useEffect(()=>{
    if(!chatActive||chatOpen)return;
    const id=setInterval(async()=>{
      try{
        const r=await window.storage.get("cf:chat:all",true);
        if(!r)return;
        const msgs=JSON.parse(r.value);
        const recent=msgs.filter(m=>m.from!==(myId||ctfMyId)&&m.ts>Date.now()-30000);
        if(recent.length>0)setChatUnread(u=>Math.min(u+1,99));
      }catch{}
    },3000);
    return()=>clearInterval(id);
  },[chatActive,chatOpen,myId,ctfMyId]);

  // ── SPEED SAFETY SYSTEM ───────────────────────────────────────────────────
  const { speedKmh, speedState } = useSpeedMonitor({ active: isActiveScreen });
  const [speedLockAcked, setSpeedLockAcked] = useState(false);
  // If speed drops below clear threshold, auto-remove the override
  useEffect(() => {
    if (speedState === "clear") setSpeedLockAcked(false);
  }, [speedState]);
  const isSpeedLocked = speedState === "locked" && !speedLockAcked;

  // ── PLAY ZONE SYSTEM ───────────────────────────────────────────────────────
  const [zoneConfig] = useState(() => ({...DEFAULT_GAME_CONFIG.zone}));
  const [zoneExemptions, setZoneExemptions] = useState([]); // playerIds exempted by bartender
  const [zoneDismissed,  setZoneDismissed]  = useState(false);
  const isInGame = ["play","scan","shop","inventory","hunt","leaderboard","qr","ctf_hud","ctf_flags","ctf_board"].includes(screen);
  const myExempted = zoneExemptions.includes(myId) || zoneExemptions.includes(ctfMyId);

  const { pos: zonePos, distToEdge, status: zoneStatus, graceSecs: zoneGraceSecs } = usePlayZone({
    config: { zone: zoneConfig },
    active: isInGame && !myExempted,
    myId: myId || ctfMyId,
    onWarn: () => { setZoneDismissed(false); },
    onApproaching: () => { setZoneDismissed(false); },
    onReturn: () => { setZoneDismissed(false); },
    onDQ: async () => {
      // Drop CTF flags
      if(ctfMyId && ctfGame) {
        await mutCTF(g=>({...g,
          flags:g.flags.map(f=>f.heldBy===ctfMyId?{...f,heldBy:null,heldByTeam:null,capturedAt:null}:f),
          events:[...(g.events||[]),{id:uid(),type:"zone_dq",playerId:ctfMyId,msg:`📍 ${ctfGame.players[ctfMyId]?.name||"Player"} DQ'd — left the play zone`,ts:Date.now()}].slice(-50),
        }));
      }
      if(myId && game) {
        await mutGame(g=>({...g,
          players:{...g.players,[myId]:{...g.players[myId],disqualified:true,alive:false}},
          events:[...(g.events||[]),{id:uid(),type:"zone_dq",msg:`📍 ${game.players[myId]?.name||"Player"} DQ'd — left play zone`,ts:Date.now()}].slice(-30),
        }));
      }
      goto("splash");
    },
  });

  // ── Player actions ──────────────────────────────────────────────────────────
  const hostGame=useCallback(async(name,avatar)=>{
    const diff=DIFFICULTY_LEVELS[difficulty]||DIFFICULTY_LEVELS.intermediate;
    const adjCoins=Math.round(pendingCoins*(diff.coinMulti||1));
    const p={...makePlayer(name,avatar,adjCoins),hp:diff.hpBase||100,maxHp:diff.hpBase||100};
    const gameCode=uid().slice(0,6);
    const g={...makeGame(p),code:gameCode,id:gameCode,difficulty,
      regionId:regionId||"custom",
      title:gameTitle||(REGIONS.find(r=>r.id===regionId)||{name:"Crawl"}).name+" Crawl",
      pot:Math.round(adjCoins*(diff.potShare||.7)*.007*100)/100,
    };
    const k=K(regionId||"custom",gameCode);
    await wr(k.game,g);
    if(!hunt){const h=makeHunt();await wr(k.hunt,h);}
    // Write to global lobby index
    await wr(k.lobby||`lobby/${regionId||"custom"}_${gameCode}`,{
      regionId:regionId||"custom",gameCode,
      title:g.title,status:"lobby",difficulty,
      playerCount:1,createdAt:Date.now(),updatedAt:Date.now(),
    });
    // Update region active crawl count
    const rMeta=await rd(`regions/${regionId||"custom"}/meta`)||{activeCrawls:0};
    await wr(`regions/${regionId||"custom"}/meta`,{...rMeta,activeCrawls:(rMeta.activeCrawls||0)+1,updatedAt:Date.now()});
    setMyId(p.id);setIsHost(true);goto("waiting");
  },[pendingCoins,hunt]);

  const joinGame=useCallback(async(name,avatar,code)=>{
    let g=await rd(KEYS.game);
    if(!g){alert("Game not found. Check the code.");return;}
    const p=makePlayer(name,avatar,pendingCoins);
    g.players[p.id]=p;
    g.pot=(g.pot||0)+Math.round(pendingCoins*.007*100)/100;
    await wr(KEYS.game,g);
    setMyId(p.id);setIsHost(false);goto("waiting");
  },[pendingCoins]);

  const startGame=useCallback(async()=>{
    await mutGame(g=>({...g,status:"active"}));
    goto("play");
  },[mutGame]);

  const fire=useCallback(async(toId,weapon)=>{
    let result,dmg;
    await mutGame(g=>{
      const diff=DIFFICULTY_LEVELS[g.difficulty||"intermediate"]||DIFFICULTY_LEVELS.intermediate;
      const r=applyHit(g,myId,toId,weapon,diff.dmgMulti||1,diff.respawn);
      result=r.result;dmg=r.dmg;return r.game;
    });
    return {result,dmg};
  },[myId,mutGame]);

  const buyItem=useCallback(async item=>{
    await mutGame(g=>{const p=g.players[myId];if(!p||p.coins<item.c)return g;return{...g,players:{...g.players,[myId]:{...p,coins:p.coins-item.c,inventory:{...p.inventory,[item.id]:(p.inventory[item.id]||0)+1}}}};});
  },[myId,mutGame]);

  const topUp=useCallback(async coins=>{
    await mutGame(g=>{const p=g.players[myId];if(!p)return g;return{...g,players:{...g.players,[myId]:{...p,coins:(p.coins||0)+coins}}};});
  },[myId,mutGame]);

  const useItem=useCallback(async id=>{
    await mutGame(g=>{
      const p=g.players[myId];if(!p||!(p.inventory[id]>0))return g;
      let u={...p,inventory:{...p.inventory,[id]:p.inventory[id]-1}};
      if(id==="medkit")u.hp=Math.min(p.maxHp,p.hp+30);
      if(id==="shield")u.shield=(p.shield||0)+30;
      if(id==="revive"){u.hp=p.maxHp;u.alive=true;}
      if(id==="double")u.doubleDmg=(p.doubleDmg||0)+3;
      if(id==="cloak"){u.cloaked=true;setTimeout(()=>mutGame(g2=>{const p2=g2.players[myId];if(!p2)return g2;return{...g2,players:{...g2.players,[myId]:{...p2,cloaked:false}}};}),60000);}
      return{...g,players:{...g.players,[myId]:u}};
    });
    // Mine/sweeper: open modals but don't consume item yet (consumed on plant/sweep)
    if(["mine","mine_emp","mine_smoke"].includes(id)){
      setMinePlanting(id); return g;
    }
    if(id==="sweeper"){
      setSweeping(true); return g;
    }
    return{...g,players:{...g.players,[myId]:u}};
  },[myId,mutGame]);

  // ── BET STATE ─────────────────────────────────────────────────────────────
  const placeBet = useCallback(async(bet) => {
    await mutGame(g=>({...g,bets:[...(g.bets||[]),bet]}));
  },[mutGame]);

  const acceptBet = useCallback(async(betId) => {
    await mutGame(g=>{
      const bet=g.bets?.find(b=>b.id===betId); if(!bet) return g;
      let players={...g.players};
      // Deduct coins from both players immediately on accept (coins bets)
      if(bet.currency==="coins"){
        const from=players[bet.fromId]; const to=players[bet.toId];
        if(from) players[bet.fromId]={...from,coins:Math.max(0,(from.coins||0)-bet.amountCoins)};
        if(to)   players[bet.toId]  ={...to,  coins:Math.max(0,(to.coins||0)  -bet.amountCoins)};
      }
      // Cash bets: charge small coin rake equivalent to both players
      if(bet.currency==="cash"&&bet.rakeCash){
        const rakePer=Math.max(1,Math.round(bet.rakeCash*20)); // ~5% of cash in coins
        const from=players[bet.fromId]; const to=players[bet.toId];
        if(from) players[bet.fromId]={...from,coins:Math.max(0,(from.coins||0)-rakePer)};
        if(to)   players[bet.toId]  ={...to,  coins:Math.max(0,(to.coins||0)  -rakePer)};
      }
      const updated={...g,players,bets:(g.bets||[]).map(b=>b.id===betId?{...b,status:"accepted",acceptedAt:Date.now()}:b)};
      // Log rake
      updated.events=[...(g.events||[]),{id:uid(),type:"bet_accepted",msg:`🤝 ${bet.fromName} vs ${bet.toName} — ${bet.currency==="coins"?`🪙${bet.amountCoins}`:`$${bet.amountCash}`} bet accepted · ${DEV_RAKE_LABEL} to CrawlFire`,ts:Date.now()}].slice(-30);
      return updated;
    });
  },[mutGame]);

  const declineBet = useCallback(async(betId) => {
    await mutGame(g=>({...g,bets:(g.bets||[]).map(b=>b.id===betId?{...b,status:"declined"}:b)}));
  },[mutGame]);

  // ── MINE STATE ────────────────────────────────────────────────────────────
  const [minePlanting,  setMinePlanting]  = useState(null);  // mineType being planted
  const [sweeping,      setSweeping]      = useState(false);
  const [triggeredMine, setTriggeredMine] = useState(null);  // mine that just hit player
  const MINE_CHECK_INTERVAL = 4000; // ms between mine trigger checks

  // Plant a mine
  const plantMine = useCallback(async(mineType, bar) => {
    setMinePlanting(null);
    const mineId = uid();
    await mutGame(g=>{
      const p=g.players[myId]; if(!p) return g;
      // consume item from inventory
      const inv={...p.inventory,[mineType]:Math.max(0,(p.inventory[mineType]||0)-1)};
      const mine={id:mineId,type:mineType,plantedBy:myId,plantedByName:p.name,plantedAt:Date.now(),barId:bar.id,barName:bar.name,armed:true,triggered:false,disabled:false,damage:MINE_TYPES[mineType]?.dmg||35};
      return{...g,players:{...g.players,[myId]:{...p,inventory:inv}},mines:{...(g.mines||{}),[mineId]:mine},events:[...(g.events||[]),{id:uid(),type:"mine_planted",msg:`💥 ${p.name} planted a ${MINE_TYPES[mineType]?.n} at ${bar.name}!`,ts:Date.now()}].slice(-30)};
    });
  },[myId,mutGame]);

  // Disarm a mine
  const sweepMine = useCallback(async(mineId) => {
    setSweeping(false);
    await mutGame(g=>{
      const p=g.players[myId]; if(!p) return g;
      const m=g.mines?.[mineId]; if(!m) return g;
      const inv={...p.inventory,sweeper:Math.max(0,(p.inventory.sweeper||0)-1)};
      const updatedMine={...m,disabled:true,disabledBy:myId,disabledAt:Date.now()};
      return{...g,players:{...g.players,[myId]:{...p,inventory:inv}},mines:{...(g.mines||{}),[mineId]:updatedMine},events:[...(g.events||[]),{id:uid(),type:"mine_swept",msg:`🧹 ${p.name} disarmed a ${MINE_TYPES[m.type]?.n} at ${m.barName}!`,ts:Date.now()}].slice(-30)};
    });
  },[myId,mutGame]);

  // Periodic mine trigger check — simulates player "walking through" a bar
  // In production: triggered by GPS entering a bar's geofence
  useEffect(()=>{
    if(!myId||!game?.mines) return;
    const checkMines = () => {
      const activeMines=Object.values(game.mines||{}).filter(m=>!m.triggered&&!m.disabled&&m.plantedBy!==myId);
      if(!activeMines.length) return;
      // 8% chance per check to "enter" a mined bar (simulates movement in demo)
      if(Math.random()<0.08){
        const mine=activeMines[Math.floor(Math.random()*activeMines.length)];
        // Trigger the mine
        mutGame(g=>{
          const p=g.players[myId]; if(!p||!p.alive) return g;
          const m=g.mines?.[mine.id]; if(!m||m.triggered||m.disabled) return g;
          const mt=MINE_TYPES[m.type]||MINE_TYPES.mine;
          let u={...p,hp:Math.max(0,p.hp-mt.dmg)};
          if(u.hp<=0){u.alive=false;}
          if(m.type==="mine_emp")  u.coins=Math.max(0,(p.coins||0)-30);
          if(m.type==="mine_smoke"){u.cloaked=true;setTimeout(()=>mutGame(g2=>({...g2,players:{...g2.players,[myId]:{...g2.players[myId],cloaked:false}}})),30000);}
          const attacker=g.players[m.plantedBy];
          const newAttacker=attacker?{...attacker,kills:attacker.kills+(u.hp<=0?1:0)}:attacker;
          return{...g,players:{...g.players,[myId]:u,...(newAttacker?{[m.plantedBy]:newAttacker}:{})},mines:{...g.mines,[mine.id]:{...m,triggered:true,triggeredBy:myId,triggeredAt:Date.now()}},events:[...(g.events||[]),{id:uid(),type:"mine_trigger",msg:`💥 ${p.name} hit ${mt.n} planted by ${m.plantedByName} at ${m.barName}! -${mt.dmg}hp`,ts:Date.now()}].slice(-30)};
        });
        setTriggeredMine(mine);
      }
    };
    const id=setInterval(checkMines, MINE_CHECK_INTERVAL);
    return ()=>clearInterval(id);
  },[myId,game?.mines,mutGame]);

  const scanMusician=useCallback(async(musicianId,tipCents)=>{
    let h=await rd(KEYS.hunt);if(!h)return;
    const mIdx=h.musicians.findIndex(x=>x.id===musicianId);if(mIdx===-1)return;
    if(h.musicians[mIdx].scannedBy.includes(myId))return;
    h.musicians[mIdx].scannedBy.push(myId);
    h.musicians[mIdx].tipPool+=tipCents;
    const reward=h.musicians[mIdx].reward;
    const pl=h.players[myId]||{name:player?.name||"",coins:0,found:[],rewards:[]};
    pl.found=[...(pl.found||[]),musicianId];
    pl.rewards=[...(pl.rewards||[]),reward];
    if(reward.id==="coins_b")pl.coins=(pl.coins||0)+150;
    else if(reward.id==="coins_m")pl.coins=(pl.coins||0)+75;
    h.players[myId]=pl;
    if(tipCents>0)h.tipLog.push({musicianId,playerId:myId,cents:tipCents,ts:Date.now()});
    await wr(KEYS.hunt,h);
  },[myId,player]);

  // Auto-advance waiting room when game starts
  useEffect(()=>{
    if(screen==="waiting"&&game?.status==="active")goto("play");
    if(screen==="play"&&game?.status==="ended")goto("gameover");
  },[game?.status,screen]);

  // ── RENDER ──────────────────────────────────────────────────────────────────
  const sub=s=>{if(s==="rules")goto("rules");else if(s==="territory")goto("territory");else if(s==="scoreboard")goto("scoreboard");else if(s==="zombie")goto("zombie");else if(s==="daily_spin")goto("daily_spin");else setScreen(s);}; // sub-screen

  return(
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Black+Han+Sans&family=Space+Mono:wght@400;700&display=swap');
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
        html,body{background:#07070e;color:#f0f0f8;font-family:'Space Mono',monospace;min-height:100%;-webkit-font-smoothing:antialiased;}
        ::-webkit-scrollbar{width:5px;} ::-webkit-scrollbar-track{background:#0d0e1a;} ::-webkit-scrollbar-thumb{background:#2a2a3a;border-radius:3px;}
        button{font-family:inherit;} input{font-family:inherit;}
        @keyframes breathe{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}
          @keyframes fadeIn{from{opacity:0}to{opacity:1}}
          @keyframes popUp{from{transform:scale(.5) translateY(40px);opacity:0}to{transform:scale(1) translateY(0);opacity:1}}
          @keyframes glow{0%,100%{box-shadow:0 0 12px #FF2D55}50%{box-shadow:0 0 28px #FF2D55}}
        @keyframes popIn{from{transform:scale(.5) translateY(20px);opacity:0}to{transform:scale(1) translateY(0);opacity:1}}
        @keyframes slideUp{from{transform:translateY(60px)}to{transform:translateY(0)}}
        @keyframes flash{0%,100%{opacity:1}50%{opacity:.4}}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes wheelSpin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
        @keyframes prizePop{0%{transform:scale(0) rotate(-20deg);opacity:0}70%{transform:scale(1.15) rotate(5deg)}100%{transform:scale(1) rotate(0deg);opacity:1}}
        @keyframes shimmer{0%,100%{opacity:1}50%{opacity:.6}}
        @keyframes float{0%,100%{transform:translateY(0px)}50%{transform:translateY(-6px)}}
        @keyframes arScan{0%{opacity:.6;transform:scaleX(1)}50%{opacity:.3;transform:scaleX(1.02)}100%{opacity:.6;transform:scaleX(1)}}
        @keyframes slideInRight{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}
        @keyframes slideInLeft{from{transform:translateX(-100%);opacity:0}to{transform:translateX(0);opacity:1}}
        @keyframes slideInUp{from{transform:translateY(100%);opacity:0}to{transform:translateY(0);opacity:1}}
        @keyframes fadeIn{from{opacity:0}to{opacity:1}}
        @keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.5;transform:scale(1.3)}}
      `}</style>
      <div style={{maxWidth:420,margin:"0 auto",minHeight:"100vh"}}>

        {/* ── TEAM COMMS ── */}
        {chatOpen && (
          <TeamComms
            myId={myId||ctfMyId||"demo"}
            myName={chatPlayer?.name||ctfGame?.players?.[ctfMyId]?.name||"PLAYER"}
            myAvatar={chatPlayer?.avatar||ctfGame?.players?.[ctfMyId]?.avatar||"🍺"}
            myTeam={chatTeamId}
            myTeamColor={chatTeamColor}
            onClose={()=>{setChatOpen(false);setChatUnread(0);}}
          />
        )}
        {chatActive && !chatOpen && (
          <ChatFAB
            unread={chatUnread}
            teamColor={chatTeamColor}
            onClick={()=>{setChatOpen(true);setChatUnread(0);}}
          />
        )}

        {/* ── SPEED SAFETY ── */}
        {isSpeedLocked && (
          <SpeedLockOverlay
            speedKmh={speedKmh}
            onAcknowledge={() => setSpeedLockAcked(true)}
          />
        )}
        {/* Speed FAB — always visible in HUD while moving */}
        {isActiveScreen && <SpeedFAB speedKmh={speedKmh} speedState={speedState}/>}

        {/* ── MINE SYSTEM MODALS ── */}
        {minePlanting&&game&&myId&&(
          <MinePlantModal mineType={minePlanting} myId={myId} myName={player?.name||""} game={game} onPlant={plantMine} onCancel={()=>setMinePlanting(null)}/>
        )}
        {sweeping&&game&&myId&&(
          <MineSweepModal myId={myId} myName={player?.name||""} game={game} onSweep={sweepMine} onCancel={()=>setSweeping(false)}/>
        )}
        {triggeredMine&&(
          <MineTriggerFlash mine={triggeredMine} onDismiss={()=>setTriggeredMine(null)}/>
        )}

        {/* ── INACTIVITY WARNING MODAL ── */}
        {inactiveWarn && (
          <InactivityModal
            secondsLeft={inactiveSecs}
            onStayIn={handleStayIn}
            onLeave={handleInactiveKick}
          />
        )}

        {/* ── PLAY ZONE SCREENS & BANNER ── */}
        {screen==="zone"&&<ZoneScreen zone={zoneConfig} pos={zonePos} distToEdge={distToEdge} status={zoneStatus} graceSecs={zoneGraceSecs} exempted={myExempted} onBack={()=>goto(["ctf_hud","ctf_flags"].includes(screen)?"ctf_hud":"play")} onExempt={()=>setZoneExemptions(e=>[...e,myId||ctfMyId])}/>}

        {/* ── SPLASH ── */}
        {screen==="splash"&&<SplashScreen onRole={r=>{setRole(r);if(r==="player")goto("difficulty");else if(r==="bartender")goto("bar_login");else if(r==="musician")goto("musician_login");else if(r==="bar_owner")goto("bar_landing");else if(r==="operator")goto("operator");else if(r==="rules")goto("rules");else if(r==="designer")goto("designer_login");else if(r==="territory")goto("territory");else if(r==="scoreboard")goto("scoreboard");else if(r==="zombie")goto("zombie");else if(r==="daily_spin")goto("daily_spin");else if(r==="crew")goto("crew");else if(r==="quick_start")goto("quick_start");}} onCTF={()=>goto("ctf_home")}/>}

        {/* ── PLAYER FLOW ── */}
        {screen==="difficulty"&&<DifficultySelect onSelect={d=>{setPendingDifficulty(d);goto("payment");}} onBack={()=>goto("splash")}/>}
        {screen==="payment"&&<PaymentScreen difficulty={pendingDifficulty||"intermediate"} onPaid={c=>{setPendingCoins(c);setDifficulty(pendingDifficulty||"intermediate");goto("lobby");}} onBack={()=>goto("difficulty")}/>}
        {screen==="lobby"&&<LobbyChoiceScreen
          onBrowse={()=>goto("global_lobby")}
          onHost={()=>{setIsJoining(false);goto("region_pick");}}
          onJoin={()=>{setIsJoining(true);goto("setup");}}
          onBack={()=>goto("payment")}/>}
        {screen==="global_lobby"&&<LobbyBrowser
          onBack={()=>goto("lobby")}
          onHostGame={(rid,title)=>{setRegionId(rid);setGameTitle(title);setIsJoining(false);goto("setup");}}
          onJoinGame={(rid,code)=>{setRegionId(rid);setDeepLinkCode(code);setIsJoining(true);goto("deeplink_join");}}/>}
        {screen==="region_pick"&&<RegionPicker
          onSelect={(rid,title)=>{setRegionId(rid);setGameTitle(title);goto("setup");}}
          onBack={()=>goto("lobby")}/>}
        {screen==="deeplink_join"&&<DeepLinkJoinScreen code={deepLinkCode} onJoin={(name,avatar)=>{joinGame(name,avatar,deepLinkCode);}} onBack={()=>{setDeepLinkCode(null);goto("splash");}}/>}
        {screen==="setup"&&<SetupScreen isJoining={isJoining} onJoin={isJoining?joinGame:(n,a)=>hostGame(n,a)} onBack={()=>goto("lobby")} pendingCode=""/>}
        {screen==="waiting"&&game&&<WaitingScreen game={game} myId={myId} isHost={isHost} onStart={startGame} onBack={()=>goto("splash")} onPlaceBet={placeBet} onAcceptBet={acceptBet} onDeclineBet={declineBet}/>}
        {screen==="play"&&game&&player&&(
          <>
            {/* Original PlayScreen — still renders game state cards */}
            <PlayScreen game={game} myId={myId} onNav={goto} onSetScreen={sub} shared={shared} zoneStatus={zoneStatus} distToEdge={distToEdge} graceSecs={zoneGraceSecs} onZoneScreen={()=>goto("zone")} zoneDismissed={zoneDismissed} onZoneDismiss={()=>setZoneDismissed(true)} speedState={speedState} speedKmh={speedKmh}/>
            {/* TacticalHUD overlays everything — CoD style */}
            <TacticalHUD
              game={game} myId={myId} shared={shared}
              fire={fire} buyItem={buyItem} useItem={useItem}
              plantMine={plantMine} sweepMine={sweepMine}
              zoneStatus={zoneStatus} distToEdge={distToEdge} graceSecs={zoneGraceSecs}
              onZoneScreen={()=>goto("zone")}
              zoneDismissed={zoneDismissed} onZoneDismiss={()=>setZoneDismissed(true)}
              speedState={speedState} speedKmh={speedKmh}
              ctfGame={ctfGame} ctfMyId={ctfMyId}
              onFullScreen={sub}/>
          </>
        )}
        {screen==="qr"&&player&&<QRScreen player={player} onBack={()=>goto("play")}/>}
        {screen==="scan"&&game&&<ScanScreen game={game} myId={myId} onFire={fire} onBack={()=>goto("play")}/>}
        {screen==="shop"&&game&&<ShopScreen game={game} myId={myId} onBuy={buyItem} onTopUp={topUp} onBack={()=>goto("play")}/>}
        {screen==="inventory"&&game&&<InventoryScreen game={game} myId={myId} onUse={useItem} onBack={()=>goto("play")}/>}
        {screen==="hunt"&&<HuntScreen hunt={hunt} game={game} myId={myId} onScanMusician={scanMusician} onBack={()=>goto("play")}/>}
        {screen==="leaderboard"&&game&&<LeaderboardScreen game={game} myId={myId} onBack={()=>goto("play")}/>}
        {screen==="gameover"&&game&&<GameOverScreen game={game} myId={myId} onPlayAgain={()=>goto("splash")}/>}

        {/* ── BARTENDER FLOW ── */}
        {screen==="bar_login"&&<BarLoginScreen onLogin={acc=>{setBartender(acc);goto("bar_dash");}} onBack={()=>goto("splash")}/>}
        {screen==="class_select"&&bartender&&<ClassSelectScreen bartender={bartender} onSelect={cid=>{setBartender(b=>({...b,classId:cid}));goto("bar_dash");}} onBack={()=>goto("bar_dash")}/>}
        {screen==="bar_dash"&&bartender&&<BartenderDash bartender={bartender} game={game} codes={codes} onGenCode={async(code,entry)=>mutCodes(c=>({...c,[code]:entry}))} onLogout={()=>{setBartender(null);goto("splash");}}/>}

        {/* ── MUSICIAN FLOW ── */}
        {screen==="musician_login"&&<MusicianLoginScreen onLogin={acc=>{setMusicianAccount(acc);goto("musician_dash");}} onBack={()=>goto("splash")}/>}
        {screen==="musician_dash"&&musicianAccount&&<MusicianDash account={musicianAccount} hunt={hunt} onLogout={()=>{setMusicianAccount(null);goto("splash");}}/>}

        {/* ── BAR OWNER FLOW ── */}
        {screen==="bar_landing"&&<BarOwnerLanding onSignUp={()=>goto("bar_signup")} onLogin={()=>goto("bar_owner_login")} onBack={()=>goto("splash")}/>}
        {screen==="bar_signup"&&<BarSignup onDone={()=>{setBarAccount(BAR_ACCOUNTS[0]);goto("bar_dashboard");}} onBack={()=>goto("bar_landing")}/>}
        {screen==="bar_owner_login"&&<BarLoginScreen onLogin={acc=>{setBarAccount(acc);goto("bar_dashboard");}} onBack={()=>goto("bar_landing")}/>}
        {screen==="bar_dashboard"&&barAccount&&<BarDashboard bar={barAccount} onLogout={()=>{setBarAccount(null);goto("bar_landing");}}/>}

        {/* ── OPERATOR ── */}
        {screen==="operator"&&<OperatorDash game={game} onBack={()=>goto("splash")}/>}

        {/* ── RULES ── */}
        {screen==="rules"&&<RulesScreen onBack={()=>goto("splash")}/>}

        {/* ── LIVE SCOREBOARD ── */}
        {screen==="scoreboard"&&<LiveScoreboard myId={myId||ctfMyId||null} onBack={()=>goto("splash")}/>}

        {/* ── LEVEL UP TOAST ── */}
        {levelUp&&<LevelUpToast level={levelUp.level} rank={levelUp.rank} reward={levelUp.reward} onClose={dismissLevelUp}/>}

        {/* ── CREW SCREEN ── */}
        {screen==="crew"&&<CrewScreen
          playerId={myId||ctfMyId||"demo"}
          playerName={player?.name||ctfGame?.players?.[ctfMyId]?.name||"PLAYER"}
          playerAvatar={player?.avatar||ctfGame?.players?.[ctfMyId]?.avatar||"🍺"}
          totalXp={totalXp}
          onBack={()=>goto("splash")}/>}

        {/* ── FAST ONBOARDING ── */}
        {screen==="quick_start"&&<FastOnboarding
          gameCode={deepLinkCode||null}
          onDone={(name,avatar,mode)=>{
            if(mode==="zombie"){goto("zombie");}
            else if(mode==="pay"){setIsJoining(false);goto("difficulty");}
          }}
          onSpectate={(name,avatar)=>{goto("spectate");}}/>}

        {/* ── SPECTATOR MODE ── */}
        {screen==="spectate"&&game&&<SpectatorView
          game={game} myId={myId||"spectator"}
          onJoinProperly={()=>goto("difficulty")}
          onBack={()=>goto("splash")}/>}

        {/* ── FIREBASE SETUP GUIDE ── */}
        {screen==="firebase_setup"&&<FirebaseSetupGuide onClose={()=>goto("splash")}/>}

        {/* ── TERRITORY MAP ── */}
        {screen==="territory"&&<TerritoryMap
          myId={myId||ctfMyId||null}
          myName={player?.name||ctfGame?.players?.[ctfMyId]?.name||null}
          myAvatar={player?.avatar||ctfGame?.players?.[ctfMyId]?.avatar||null}
          onBack={()=>goto("splash")}/>}

        {screen==="daily_spin"&&<DailySpinScreen
          playerId={myId||ctfMyId||"demo"}
          playerName={player?.name||ctfGame?.players?.[ctfMyId]?.name||"PLAYER"}
          playerAvatar={player?.avatar||ctfGame?.players?.[ctfMyId]?.avatar||"🎯"}
          onBack={()=>goto("splash")}
          onPrizeClaimed={prize=>{
            // Credit coins into player wallet; add items to inventory
            if(!prize)return;
            if(myId&&game){
              mutGame(g=>{
                const p=g.players[myId]; if(!p) return g;
                let u={...p};
                if(prize.reward.coins) u.coins=(u.coins||0)+prize.reward.coins;
                if(prize.reward.item){
                  u.inventory={...u.inventory,[prize.reward.item]:(u.inventory?.[prize.reward.item]||0)+prize.reward.qty};
                  if(prize.reward.extra)
                    u.inventory={...u.inventory,[prize.reward.extra.item]:(u.inventory?.[prize.reward.extra.item]||0)+prize.reward.extra.qty};
                }
                return{...g,players:{...g.players,[myId]:u}};
              });
            }
          }}/>}

        {screen==="zombie"&&<ZombieHunt
          myId={myId||ctfMyId||"demo"}
          myName={player?.name||ctfGame?.players?.[ctfMyId]?.name||"SURVIVOR"}
          myAvatar={player?.avatar||ctfGame?.players?.[ctfMyId]?.avatar||"🎯"}
          onBack={()=>goto("splash")}
          onCoinsEarned={earned=>{
            // Credit earned coins back into the player's wallet + track zombie earnings
            if(myId&&game){
              mutGame(g=>{
                const p=g.players[myId];
                if(!p)return g;
                return{...g,players:{...g.players,[myId]:{
                  ...p,
                  coins:(p.coins||0)+earned,
                  zombieCoins:(p.zombieCoins||0)+earned,
                }}};
              });
            }
          }}/>}

        {/* ── DESIGNER PORTAL ── */}
        {screen==="designer_login"&&<DesignerLogin onLogin={acc=>{setDesigner(acc);goto("designer");}} onBack={()=>goto("splash")}/>}
        {screen==="designer"&&designer&&<DesignerPortal designer={designer} onLogout={()=>{setDesigner(null);goto("splash");}}/>}

        {/* ── CTF FLOW ── */}
        {screen==="ctf_home"&&<CTFHomeScreen ctfGame={ctfGame} onSetup={()=>goto("ctf_setup")} onJoin={()=>goto("ctf_join")} onBack={()=>goto("splash")}/>}
        {screen==="ctf_setup"&&<CTFSetupScreen setup={ctfSetup} setSetup={setCtfSetup} step={ctfSetupStep} setStep={setCtfSetupStep} onLaunch={async()=>{const g=makeCTFGame(ctfSetup.teamCount,ctfSetup.flagCount,ctfSetup.name);await wr(KEYS.ctf,g);setCtfGame(g);goto("ctf_join");}} onBack={()=>goto("ctf_home")}/>}
        {screen==="ctf_join"&&ctfGame&&<CTFJoinScreen ctfGame={ctfGame} onJoin={async(name,avatar,teamId)=>{const pid=uid();await mutCTF(g=>({...g,players:{...g.players,[pid]:{id:pid,name,avatar,teamId,captures:0,steals:0,defends:0,points:0,joinedAt:Date.now()}},events:[...(g.events||[]),{id:uid(),type:"join",playerName:name,teamId,ts:Date.now(),msg:`${avatar} ${name} joined ${CTF_TEAMS.find(t=>t.id===teamId)?.name}!`}].slice(-50)}));setCtfMyId(pid);goto("ctf_hud");}} onBack={()=>goto("ctf_home")}/>}
        {screen==="ctf_hud"&&ctfGame&&ctfMyId&&<CTFHudScreen ctfGame={ctfGame} myId={ctfMyId} onCapture={ctfCapture} onNav={s=>goto(s)} onBack={()=>goto("splash")}/>}
        {screen==="ctf_flags"&&ctfGame&&<CTFFlagsScreen ctfGame={ctfGame} myId={ctfMyId} onCapture={ctfCapture} onBack={()=>goto("ctf_hud")}/>}
        {screen==="ctf_board"&&ctfGame&&<CTFLeaderboard ctfGame={ctfGame} myId={ctfMyId} onBack={()=>goto("ctf_hud")}/>}
        {screen==="ctf_qrcards"&&ctfGame&&<CTFQRCards ctfGame={ctfGame} onBack={()=>goto("ctf_hud")}/>}

      </div>
    </>
  );
}
